/* PATCH 1.0.1 — guard-флаги для старых перехватчиков (PATCH 1.0.1-fix: __trkLogSaveUnifiedV1035 отключает старый блок B3, новый блок ниже использует __trkLogSaveUnifiedV1101) */
(function(){
    'use strict';
    window.__trkOverflowModalV2 = true;
    window.__trkLogFormFocusFetch = true;
    window.__trkAutoAssignFetch = true;
    window.__trkLogDupDayFetch = true;
    window.__trkCloseAllAfterLogV1024 = true;
    window.__trkMultiFieldsFixV1032 = true;
    window.__trkCompactModeV112 = true;
    window.__trkLogSaveUnifiedV1035 = true;
})();
/* ============================================================
   PATCH 1.0.3 — реестр плагинов + дропдаун под вкладкой «Статистика»
   ============================================================ */
(function(){
'use strict';
if (window.__trkPluginMenuV103) return;
window.__trkPluginMenuV103 = true;

window.__trkPluginRegistry = window.__trkPluginRegistry || [];

window.__trkRegisterPlugin = function(opts){
    if (!opts) return;
    if (!opts.url && typeof opts.onClick !== 'function') return;
    var arr = window.__trkPluginRegistry;
    var key = opts.id || opts.url || opts.name || '';
    if (!key) return;
    for (var i = 0; i < arr.length; i++) {
        var ex = arr[i];
        if ((opts.id && ex.id === opts.id) || (opts.url && ex.url && ex.url === opts.url)) return;
    }
    arr.push(opts);
    if (window.__trkBuildStatsMenu) setTimeout(window.__trkBuildStatsMenu, 30);
};

window.__trkBuildStatsMenu = function(){
    var statsTab = document.querySelector('.tracker-tab[data-tab="stats"]');
    if (!statsTab) return;
    if (!statsTab.querySelector('.tab-menu-arrow')) {
        var arrow = document.createElement('span');
        arrow.className = 'tab-menu-arrow';
        arrow.textContent = '▾';
        statsTab.appendChild(arrow);
    }
    var menu = document.getElementById('statsPluginMenu');
    if (!menu) {
        menu = document.createElement('div');
        menu.id = 'statsPluginMenu';
        menu.className = 'stats-plugin-menu';
        document.body.appendChild(menu);
    }
    var perms = window.REESTR_PERMS || {};
    var html = '<div class="spm-item" data-action="builtin"><span>📊</span><span>Встроенная статистика</span></div>';
    var arr = window.__trkPluginRegistry || [];
    for (var i = 0; i < arr.length; i++) {
        var p = arr[i];
        if (p.perm && !perms[p.perm]) continue;
        if (typeof p.onClick === 'function') {
            html += '<button type="button" class="spm-item" data-plugin-idx="' + i + '"><span>' + (p.icon || '🔗') + '</span><span>' + p.name + '</span></button>';
        } else if (p.url && p.url !== '#') {
            html += '<a class="spm-item" href="' + p.url + '"><span>' + (p.icon || '🔗') + '</span><span>' + p.name + '</span></a>';
        } else {
            html += '<button type="button" class="spm-item" data-plugin-idx="' + i + '"><span>' + (p.icon || '🔗') + '</span><span>' + p.name + '</span></button>';
        }
    }
    if (perms['tab.stats']) {
        html += '<a class="spm-item" href="/plugins/task_heatmap/"><span>🔥</span><span>Тепловая карта задач</span></a>';
    }

    if (perms['tab.settings']) {
        html += '<a class="spm-item" href="/plugins/weekly_report/"><span>📥</span><span>Недельные отчёты</span></a>';
    }
    menu.innerHTML = html;
};

document.addEventListener('click', function(e){
    if (!e.target || !e.target.closest) return;
    // PATCH 1.0.12: клик по всей кнопке «Статистика» открывает меню,
    // вкладка при этом не переключается.
    var statsTab = e.target.closest('.tracker-tab[data-tab="stats"]');
    if (statsTab) {
        e.preventDefault();
        e.stopPropagation();
        if (e.stopImmediatePropagation) e.stopImmediatePropagation();
        var menu = document.getElementById('statsPluginMenu');
        if (!menu) { window.__trkBuildStatsMenu(); menu = document.getElementById('statsPluginMenu'); }
        if (!menu) return;
        var rect = statsTab.getBoundingClientRect();
        menu.style.left = Math.min(rect.left, window.innerWidth - 280) + 'px';
        menu.style.top = (rect.bottom + 6) + 'px';
        menu.classList.toggle('active');
        return;
    }
    var builtin = e.target.closest('#statsPluginMenu [data-action="builtin"]');
    if (builtin) {
        e.preventDefault();
        e.stopPropagation();
        var st = document.querySelector('.tracker-tab[data-tab="stats"]');
        if (st) {
            document.querySelectorAll('.tracker-tab').forEach(function(t) {
                t.classList.toggle('active', t === st);
            });
            document.querySelectorAll('.tracker-panel').forEach(function(p) {
                p.classList.toggle('active', p.id === 'panel-stats');
            });
            try { localStorage.setItem('tracker_activeTab', 'stats'); } catch (er) {}
            if (typeof window.__trkLoadStats === 'function') {
                try { window.__trkLoadStats(); } catch (er) {}
            }
        }
        var m = document.getElementById('statsPluginMenu');
        if (m) m.classList.remove('active');
        return;
    }
    if (!e.target.closest('#statsPluginMenu')) {
        var m2 = document.getElementById('statsPluginMenu');
        if (m2 && m2.classList.contains('active')) m2.classList.remove('active');
    }
}, true);

setTimeout(function(){ try { window.__trkBuildStatsMenu(); } catch(e){} }, 500);
setTimeout(function(){ try { window.__trkBuildStatsMenu(); } catch(e){} }, 1500);
setTimeout(function(){ try { window.__trkBuildStatsMenu(); } catch(e){} }, 3000);

// PATCH 1.0.16: клик по кнопке плагина с onClick
document.addEventListener('click', function(e){
    if (!e.target || !e.target.closest) return;
    var btn = e.target.closest('#statsPluginMenu [data-plugin-idx]');
    if (!btn) return;
    e.preventDefault();
    e.stopPropagation();
    if (e.stopImmediatePropagation) e.stopImmediatePropagation();
    var idx = parseInt(btn.getAttribute('data-plugin-idx'), 10);
    var arr = window.__trkPluginRegistry || [];
    if (!isNaN(idx) && arr[idx] && typeof arr[idx].onClick === 'function') {
        try { arr[idx].onClick(); } catch (er) { console.error('[plugin-menu]', er); }
    }
    var m = document.getElementById('statsPluginMenu');
    if (m) m.classList.remove('active');
}, true);

})();
/* ============================================================
   PATCH 1.0.1 — применён (2026-10-15)
   Guard-флаги конфликтов + маркер версии.
   Проверка в браузере: window.__trkPatchVersion
   ============================================================ */
(function () {
    'use strict';
    window.__trkPatchVersion = '1.0.1';
    window.__trkPatchAppliedAt = '2026-10-15';
    window.__trkLogEditTaskMergeV1015 = true;
    window.__trkDelLogFeedbackV1013 = true;
    window.__trkQuickAddAssigned = true;
    try {
        console.log('%c[tracker.js] патч 1.0.1 применён', 'color:#2ecc71;font-weight:bold');
    } catch (e) {}
})();

/* ============================================================
   PATCH 1.0.1 — Фикс конфликтов патчей (guard-флаги)
   -------------------------------------------------------------
   ВАЖНО: prepend. Флаги выставляются ДО исполнения старых IIFE,
   иначе те успевают зарегистрировать свои обработчики.
   ============================================================ */
(function() {
    'use strict';

    // v1.0.15 — двойное заполнение формы отметки при редактировании.
    // Полностью перекрыт v1.0.16 (MutationObserver на #logModal).
    window.__trkLogEditTaskMergeV1015 = true;

    // v1.0.13 — старый оверлей удаления отметки с визуальными артефактами.
    // Перекрыт v1.0.18 (чистый оверлей на .modal, снимается по promise).
    window.__trkDelLogFeedbackV1013 = true;

    // v1.2.3 — быстрый quick-add, недостижим из-за stopImmediatePropagation
    // в v1.0.3. Guard-флаг экономит регистрацию лишнего fetch-хука.
    window.__trkQuickAddAssigned = true;

})();
/* Трекер задач — клиентская логика (standalone). v1.4 */
(function() {
'use strict';

var PERMS = window.REESTR_PERMS || {};
function hasPerm(k) { return !!PERMS[k]; }

var state = {
    employees: [], tasks: [], log: [], emoji: [], palette: [],
    departments: [], teams: [], holidays: {},
    allTags: [], tagPresets: [],
    statusLabels: {}, taskStatusLabels: {}, absenceTypes: {},
    calendar: null, heatmap: null, summary: null, summaryIsGrid: true,
    currentYM: '', currentEmployee: '', currentDepartment: '', currentTeam: '', currentDay: '',
    calViewMode: 'tasks', tskViewMode: 'all',
    tskDisplayMode: 'list', tskGridCols: 3, tskView: 'tile',
    hmYM: '', hmDateFrom: '', hmDateTo: '',
    sumViewMode: 'grid', sumShowDayTotals: true, sumTaskRowMode: 'full',
    today: '', theme: 'dark', maskNames: false,
    currentUser: null,
    calExpandOnHover: true,
    tskCompactMode: false,
};

var MONTHS_RU = ['Январь','Февраль','Март','Апрель','Май','Июнь',
                 'Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];

var CSRF = window.REESTR_CSRF || '';
window.__trkState = state;
var meta = document.querySelector('meta[name="csrf-token"]');
if (!CSRF && meta) CSRF = meta.getAttribute('content') || '';

var _tagDraft = [];
var _logExistingMode = 'me';
var _logExistingEmpId = '';

/* ============================================================
   УТИЛИТЫ
   ============================================================ */
function $(id) { return document.getElementById(id); }
function on(id, ev, fn) {
    var el = $(id);
    if (el) el.addEventListener(ev, fn);
    return el;
}
function escapeHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}
function maskName(name) {
    if (!state.maskNames) return name;
    var s = String(name == null ? '' : name);
    if (!s) return s;
    return s.split(/\s+/).map(function(w) {
        if (w.length <= 1) return w;
        return w[0] + new Array(w.length).join('*');
    }).join(' ');
}
function escName(name) { return escapeHtml(maskName(name)); }

function notify(msg, kind) {
    var n = $('trackerNotif'); if (!n) return;
    var isErr = (kind === 'error');
    n.className = 'tracker-notification show' + (isErr ? ' error' : '');
    clearTimeout(n._t);
    // PATCH v1.0.11: ошибка не автоскрывается — только по крестику или новому notify
    if (isErr) {
        n.innerHTML = '';
        var msgSpan = document.createElement('span');
        msgSpan.className = 'notif-msg';
        msgSpan.textContent = String(msg == null ? '' : msg);
        n.appendChild(msgSpan);
        var closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.className = 'notif-close';
        closeBtn.setAttribute('aria-label', 'Закрыть');
        closeBtn.title = 'Закрыть';
        closeBtn.textContent = '×';
        closeBtn.addEventListener('click', function() {
            n.classList.remove('show');
            clearTimeout(n._t);
        });
        n.appendChild(closeBtn);
    } else {
        n.textContent = msg;
        n._t = setTimeout(function() { n.classList.remove('show'); }, 4500);
    }
}
window.__trackerNotify = notify;

/* ============================================================
   ЛОАДЕР
   ============================================================ */
var _reqCount = 0;
var _minHideTimer = null;
var LOADER_MIN_MS = 250;

function _setLoaderLabel(label) {
    var l = $('globalLoader');
    if (!l) return;
    var t = l.querySelector('.gl-text');
    if (!t) return;
    t.textContent = label || 'Загрузка…';
}
// PATCH v1.0.11: опциональный label — 'Сохранение…', 'Удаление…' и т.п.
// PATCH v1.0.12: стек меток параллельных запросов.
var _loaderStack = [];
function _showLoader(label) {
    _reqCount++;
    _loaderStack.push(label || '');
    if (_minHideTimer) { clearTimeout(_minHideTimer); _minHideTimer = null; }
    var l = $('globalLoader');
    if (l) l.classList.add('active');
    _setLoaderLabel(label);
}
function _hideLoader() {
    _reqCount = Math.max(0, _reqCount - 1);
    _loaderStack.pop();
    if (_reqCount > 0) {
        var top = _loaderStack.length ? _loaderStack[_loaderStack.length - 1] : '';
        _setLoaderLabel(top);
        return;
    }
    if (_minHideTimer) return;
    _minHideTimer = setTimeout(function() {
        if (_reqCount === 0) {
            var l = $('globalLoader');
            if (l) l.classList.remove('active');
            _setLoaderLabel('');
        }
        _minHideTimer = null;
    }, LOADER_MIN_MS);
}
(function() {
    var SEL = [
        'button', 'a[href]',
        '.tracker-tab', '.segmented button', '.dict-action-btn', '.btn',
        '.cal-nav-btn', '.period-arrow-btn', '.log-existing-tab',
        '.tracker-back-btn', '.theme-toggle-btn', '.mask-toggle-btn',
        '.user-btn', '.dict-add-btn', '.icon-picker-btn', '.emoji-btn',
        '.palette-dot', '.assignees-item', '.dept-multi-item',
        '.chart-bar', '.chart-slice', '.donut-legend-item.clickable',
        '.task-tag-chip.clickable',
    ].join(', ');
    document.addEventListener('click', function(e) {
        var t = e.target.closest(SEL);
        if (!t) return;
        if (t.disabled) return;
        if (t.dataset && t.dataset.noLoader === '1') return;
        _showLoader();
        setTimeout(_hideLoader, 0);
    }, true);
})();

function apiJson(url, options) {
    options = options || {};
    options.headers = Object.assign({}, options.headers || {});
    if (CSRF && options.method && options.method !== 'GET')
        options.headers['X-CSRF-Token'] = CSRF;
    if (!options.credentials) options.credentials = 'same-origin';
    if (!options.cache) options.cache = 'no-store';
    // PATCH v1.0.11: пробрасываем подпись загрузчика (options.label)
    _showLoader(options.label);
    return fetch(url, options).then(function(r) {
        if (r.status === 401) { location.href = '/login'; return new Promise(function(){}); }
        if (r.status === 403) {
            return r.text().then(function(t) {
                var m = 'Недостаточно прав';
                try { var j = JSON.parse(t); if (j.error) m += ': ' + j.error; } catch (e) {}
                throw new Error(m);
            });
        }
        if (!r.ok) {
            return r.text().then(function(t) {
                var msg = 'HTTP ' + r.status;
                try { var j = JSON.parse(t); if (j && j.error) msg += ' — ' + j.error; }
                catch (e) { if (t) msg += ' — ' + t.slice(0, 200); }
                throw new Error(msg);
            });
        }
        return r.json();
    }).finally(_hideLoader);
}

/* ============================================================
   ДАТЫ / ЧИСЛА
   ============================================================ */
function todayYM() {
    var t = new Date();
    return t.getFullYear() + '-' + String(t.getMonth() + 1).padStart(2, '0');
}
function todayISO() {
    var t = new Date();
    return t.getFullYear() + '-' + String(t.getMonth() + 1).padStart(2, '0') + '-' + String(t.getDate()).padStart(2, '0');
}
function isoFromDate(d) {
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function parseISO(s) {
    var p = String(s).split('-');
    return new Date(parseInt(p[0], 10), parseInt(p[1], 10) - 1, parseInt(p[2], 10));
}
function addDaysISO(iso, delta) {
    var d = parseISO(iso);
    d.setDate(d.getDate() + delta);
    return isoFromDate(d);
}
function firstOfMonthISO(ym) { return ym + '-01'; }
function firstOfMonthISOFromDate(d) {
    var t = d || new Date();
    return t.getFullYear() + '-' + String(t.getMonth() + 1).padStart(2, '0') + '-01';
}
function getMondayISO() {
    var t = new Date();
    var wd = t.getDay();
    var diff = (wd === 0) ? -6 : (1 - wd);
    var mon = new Date(t.getTime() + diff * 86400000);
    return isoFromDate(mon);
}
function getSundayISO() {
    var mon = getMondayISO();
    var sun = new Date(new Date(mon + 'T00:00:00').getTime() + 6 * 86400000);
    return isoFromDate(sun);
}
function setDefaultWeekRange() {
    var a = $('sumDateFrom'), b = $('sumDateTo');
    if (a) a.value = getMondayISO();
    if (b) b.value = getSundayISO();
}
function setMonthRange() {
    var a = $('sumDateFrom'), b = $('sumDateTo');
    if (a) a.value = firstOfMonthISOFromDate(new Date());
    if (b) b.value = todayISO();
}
function formatDateHuman(iso) {
    try {
        var p = iso.split('-');
        return parseInt(p[2], 10) + ' ' + MONTHS_RU[parseInt(p[1], 10) - 1].toLowerCase() + ' ' + p[0];
    } catch (e) { return iso; }
}
function formatDateShort(iso) {
    try { var p = iso.split('-'); return parseInt(p[2], 10) + '.' + p[1]; }
    catch (e) { return iso; }
}
function formatHours(h) {
    h = Number(h) || 0;
    if (h === Math.floor(h)) return h + ' ч';
    return h.toFixed(2).replace(/0+$/, '').replace(/\.$/, '') + ' ч';
}
function shortHours(h) {
    h = Number(h) || 0;
    if (h === Math.floor(h)) return String(h);
    return h.toFixed(2).replace(/0+$/, '').replace(/\.$/, '');
}
function hoursClass(h) {
    h = Number(h) || 0;
    if (h <= 0) return '';
    if (h < 2) return 'hours-1';
    if (h < 4) return 'hours-2';
    if (h < 6) return 'hours-3';
    return 'hours-4';
}
function heatmapColor(hours) {
    return cellLightGreen(hours) || '';
}

function cellLightGreen(hours) {
    var h = Number(hours) || 0;
    if (h <= 0) return '';
    if (h > 24) h = 24;
    var yellow = [250, 235, 150];
    var green  = [110, 200, 140];
    var pink   = [250, 180, 200];
    var a, b, t;
    if (h <= 8) {
        a = yellow; b = green; t = h / 8;
    } else {
        a = green; b = pink; t = Math.min((h - 8) / 8, 1);
    }
    var r = Math.round(a[0] + (b[0] - a[0]) * t);
    var g = Math.round(a[1] + (b[1] - a[1]) * t);
    var bl = Math.round(a[2] + (b[2] - a[2]) * t);
    return 'rgb(' + r + ',' + g + ',' + bl + ')';
}

function initials(name) {
    var parts = String(name || '').trim().split(/\s+/);
    if (!parts.length) return '?';
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + (parts[1][0] || '')).toUpperCase();
}
function statusClass(s) {
    if (s === 'done') return 'status-done';
    if (s === 'in_progress') return 'status-in_progress';
    if (s === 'planned') return 'status-planned';
    if (s === 'blocked') return 'status-blocked';
    return '';
}
function absenceIcon(t) {
    if (t === 'sick_leave') return '🤒';
    if (t === 'business_trip') return '✈️';
    if (t === 'vacation') return '🏖';
    if (t === 'remote') return '🏠';
    return '';
}
function absenceLabel(t) {
    var m = state.absenceTypes || {};
    if (m[t]) return m[t];
    if (t === 'sick_leave') return '🤒 Больничный';
    if (t === 'business_trip') return '✈️ Командировка';
    if (t === 'remote') return '🏠 Удаленка';
    return '🏖 Отпуск';
}
function absenceClass(t) {
    if (t === 'sick_leave') return 'sick_leave';
    if (t === 'business_trip') return 'business_trip';
    if (t === 'remote') return 'remote';
    return 'vacation';
}

/* ============================================================
   ТЕМА
   ============================================================ */
function applyTrkTheme(theme) {
    if (theme !== 'light' && theme !== 'dark') theme = 'dark';
    state.theme = theme;
    document.body.classList.remove('trk-theme-dark', 'trk-theme-light');
    document.body.classList.add('trk-theme-' + theme);
    document.documentElement.setAttribute('data-trk-theme', theme);
    try { localStorage.setItem('reestr_tracker_theme', theme); } catch (e) {}
    var icon = $('trkThemeIcon'), label = $('trkThemeLabel');
    if (icon) icon.textContent = theme === 'dark' ? '☀️' : '🌙';
    if (label) label.textContent = theme === 'dark' ? 'Светлая' : 'Тёмная';
}
(function initTheme() {
    var saved = 'dark';
    try { saved = localStorage.getItem('reestr_tracker_theme') || 'dark'; } catch (e) {}
    applyTrkTheme(saved);
})();
on('trkThemeToggle', 'click', function() {
    applyTrkTheme(state.theme === 'dark' ? 'light' : 'dark');
});

/* ============================================================
   ОПЦИОНАЛЬНЫЙ РАЗВОРОТ ДНЯ
   ============================================================ */
function applyCalExpand(on) {
    state.calExpandOnHover = !!on;
    try { localStorage.setItem('tracker_cal_expand', on ? '1' : '0'); } catch (e) {}
    var grid = $('calGrid');
    if (grid) grid.setAttribute('data-expand', on ? 'on' : 'off');
    document.body.classList.toggle('cal-expand-off', !on);
    var btn = $('calExpandToggle');
    if (btn) btn.classList.toggle('active', on);
    var icon = $('calExpandIcon');
    var label = $('calExpandLabel');
    if (icon) icon.textContent = on ? '⤢' : '⤡';
    if (label) label.textContent = on ? 'Разворот дня: вкл' : 'Разворот дня: выкл';
}
(function initCalExpand() {
    var saved = '1';
    try { saved = localStorage.getItem('tracker_cal_expand') || '1'; } catch (e) {}
    applyCalExpand(saved === '1');
})();
on('calExpandToggle', 'click', function() {
    applyCalExpand(!state.calExpandOnHover);
});

/* ============================================================
   МАСКИРОВАНИЕ
   ============================================================ */
function applyMask(enabled) {
    state.maskNames = !!enabled;
    try { localStorage.setItem('reestr_tracker_mask', enabled ? '1' : '0'); } catch (e) {}
    window.__trkMaskNames = state.maskNames;
    if (typeof window.__trkOnMaskChange === 'function') {
        try { window.__trkOnMaskChange(state.maskNames); } catch (e) {}
    }
    var btn = $('trkMaskToggle');
    if (btn) btn.classList.toggle('active', state.maskNames);
    var icon = $('trkMaskIcon'), label = $('trkMaskLabel');
    if (icon) icon.textContent = state.maskNames ? '🙈' : '👁';
    if (label) label.textContent = state.maskNames ? 'Показать ФИО' : 'Маска ФИО';
}
(function initMask() {
    var saved = '0';
    try { saved = localStorage.getItem('reestr_tracker_mask') || '0'; } catch (e) {}
    applyMask(saved === '1');
})();
on('trkMaskToggle', 'click', function() {
    applyMask(!state.maskNames);
    renderDepartments();
    renderEmployees();
    renderTeams();
    renderTasks();
    renderHolidaysInline();
    if (state.calendar) renderCalendar();
    if (state.summary) {
        if (state.summaryIsGrid) renderSummaryGrid();
        else renderSummary();
    }
    if (state.heatmap) renderHeatmap();
});

/* ============================================================
   ТАБЫ
   ============================================================ */
document.querySelectorAll('.tracker-tab').forEach(function(tab) {
    tab.addEventListener('click', function() {
        var id = this.getAttribute('data-tab');
        document.querySelectorAll('.tracker-tab').forEach(function(t) {
            t.classList.toggle('active', t === tab);
        });
        document.querySelectorAll('.tracker-panel').forEach(function(p) {
            p.classList.toggle('active', p.id === 'panel-' + id);
        });
        try { localStorage.setItem('tracker_activeTab', id); } catch (e) {}
        if (id === 'tasks') renderTasksFull();
        if (id === 'heatmap') loadHeatmap();
        if (id === 'summary') loadSummary();
        if (id === 'stats') {
            var a = $('stDateFrom'), b = $('stDateTo');
            if (a && !a.value) a.value = firstOfMonthISO(todayYM());
            if (b && !b.value) b.value = todayISO();
            loadStats();
        }
    });
});
(function restoreTab() {
    try {
        var savedTab = localStorage.getItem('tracker_activeTab');
        if (savedTab && savedTab !== 'calendar') {
            var tabBtn = document.querySelector('.tracker-tab[data-tab="' + savedTab + '"]');
            if (tabBtn) setTimeout(function() { tabBtn.click(); }, 50);
        }
        var savedDept = localStorage.getItem('tracker_calDept');
        if (savedDept) state.currentDepartment = savedDept;
    } catch (e) {}
})();

/* ============================================================
   SEGMENTED
   ============================================================ */
function setupSegmented(elId, initial, onChange) {
    var wrap = $(elId); if (!wrap) return;
    var btns = wrap.querySelectorAll('button');
    btns.forEach(function(b) {
        b.classList.toggle('active', b.getAttribute('data-mode') === initial);
        b.addEventListener('click', function() {
            btns.forEach(function(x) { x.classList.remove('active'); });
            this.classList.add('active');
            onChange(this.getAttribute('data-mode'));
        });
    });
}

/* ============================================================
   STATE
   ============================================================ */
window.__trkState = state;
window.__trkRenderSummaryGrid = function() {
    try { renderSummaryGrid(); } catch (e) { console.error(e); }
};

/* PATCH: не затираем внешний __trkOnSummaryRender — раньше он терялся
   при второй обёртке renderSummaryGrid (collapse-all v2). Теперь 
   вызываем оба: и внешний хук, и collapse-all-функцию. */
(function() {
    var _orig = renderSummaryGrid;
    renderSummaryGrid = function() {
        _orig.apply(this, arguments);
        // Сначала внешний хук (штриховки missing, future-даты)
        if (typeof window.__trkOnSummaryRender === 'function') {
            try { window.__trkOnSummaryRender(); } catch (e) { console.error(e); }
        }
    };
})();

/* === Bridge в window === */
window.__trkState = state;
window.__trkOpenDayModal = openDayModal;
window.__trkOpenTaskModal = openTaskModal;
window.__trkLoadSummary = loadSummary;   // PATCH: раньше не экспортировался — 
                                          // пилюли тегов в Своде не перерисовывали
window.__trkLoadStats = loadStats;
window.__trkRenderTasksFull = renderTasksFull;
window.__trkRenderCalendar = loadCalendar;
window.__trkLoadState = loadState;
window.__trkOpenLogModal = openLogModal;
window.__trkFillTaskSelect = fillTaskSelect;
window.__trkBindDayEntryActions = bindDayEntryActions;
window.__trkCanEditEntry = canEditEntry;
window.__trkCanDeleteEntry = canDeleteEntry;
window.__trackerNotify = notify;

/* Инициализация режима просмотра дневной карточки */
(function initDayViewMode() {
    var v = 'task';
    try { v = localStorage.getItem('tracker_day_view') || 'task'; } catch (e) {}
    if (v !== 'task' && v !== 'employee') v = 'task';
    state.dayViewMode = v;
})();

/* Обёртка renderDayList — диспатч по режиму */
var __origRenderDayList = renderDayList;
renderDayList = function(entries, totalHours, day) {
    var mode = state.dayViewMode || 'task';
    if (mode === 'employee' && typeof window.__trkRenderDayByEmployee === 'function') {
        try {
            var handled = window.__trkRenderDayByEmployee(entries, totalHours, day);
            if (handled) return;
        } catch (e) { console.error('[day-view]', e); }
    }
    return __origRenderDayList.call(this, entries, totalHours, day);
};

/* PATCH: __lastTaskCardData — чтобы PATCH 26/29 могли вставить 
   расширенную карточку задачи. Обёртка над openTaskCardModal сохраняет
   ответ в state. */
(function() {
    var _origOpenTaskCard = openTaskCardModal;
    openTaskCardModal = function(taskId) {
        var from = $('sumDateFrom') ? $('sumDateFrom').value : '';
        var to = $('sumDateTo') ? $('sumDateTo').value : '';
        if (!from || !to) {
            var t = new Date();
            from = firstOfMonthISOFromDate(t);
            to = todayISO();
        }
        var qs = '?task=' + encodeURIComponent(taskId)
            + '&from=' + encodeURIComponent(from) + '&to=' + encodeURIComponent(to);
        return apiJson('/api/tracker/task/card' + qs)
            .then(function(d) {
                if (!d.success) throw new Error(d.error || 'Ошибка');
                // PATCH: сохраняем данные для PATCH 26/29
                state.__lastTaskCardData = d;
                renderTaskCardModal(d);
                if (window.__trkTaskFeedRender) { try { window.__trkTaskFeedRender(d); } catch(e){} }
                if (window.__trkRenderTaskCardEmployees) {
                    try { window.__trkRenderTaskCardEmployees(d); } catch(e){}
                }
                if (window.__trkInjectTaskSummary) {
                    setTimeout(function() {
                        try { window.__trkInjectTaskSummary(); } catch(e){}
                    }, 80);
                }
                var m = $('taskCardModal'); if (m) m.classList.add('active');
            })
            .catch(function(err) {
                if (err && (err.message || '').indexOf('cancelled') !== -1) return;
                notify('❌ ' + (err.message || 'Ошибка'), 'error');
            });
    };
    window.__trkOpenTaskCardModal = openTaskCardModal;
})();

function trkRefreshAll() {
    return loadState().then(function() {
        return trkRefreshCurrentTab();
    });
}
function trkRefreshCurrentTab() {
    var activeTab = document.querySelector('.tracker-tab.active');
    var tabId = activeTab ? activeTab.getAttribute('data-tab') : '';
    var p = Promise.resolve();
    if (tabId === 'calendar') p = loadCalendar();
    else if (tabId === 'heatmap') p = loadHeatmap();
    else if (tabId === 'summary') p = loadSummary();
    else if (tabId === 'stats') p = loadStats();
    return p;
}
window.__trkRefreshAll = trkRefreshAll;
function loadState() {
    return apiJson('/api/tracker/state').then(function(d) {
        if (!d.success) throw new Error(d.error || 'Ошибка загрузки');
        state.employees = d.employees || [];
        state.tasks = d.tasks || [];
        state.log = d.log || [];
        state.emoji = d.emoji || [];
        state.palette = d.palette || [];
        state.departments = d.departments || [];
        state.teams = d.teams || [];
        state.holidays = d.holidays || {};
        state.today = d.today || todayISO();
        state.allTags = d.all_tags || [];
        state.tagPresets = d.tag_presets || [];
        state.currentUser = d.current_user || null;
        state.workSchedule = d.work_schedule || 'legacy';
        if (d.status_labels) state.statusLabels = d.status_labels;
        if (d.task_status_labels) state.taskStatusLabels = d.task_status_labels;
        if (d.absence_types) state.absenceTypes = d.absence_types;
        if (d.permissions) { PERMS = d.permissions; window.REESTR_PERMS = PERMS; }
        renderDepartments();
        renderEmployees();
        renderTeams();
        renderTasks();
        renderHolidaysInline();
        renderPalette();
        renderEmojiGrid();
        fillDepartmentFilters();
        fillTeamFilters();
        fillEmployeeFilter();
        fillEmployeeSelect();
        fillTaskSelect();
        fillSummaryFilters();
        fillTagFilters();
        // PATCH 1.0.9: читаем сохранённый вид задач
        try {
            var _tv109 = localStorage.getItem('tracker_tsk_view');
            if (_tv109 !== 'tile' && _tv109 !== 'compact' && _tv109 !== 'list') _tv109 = 'tile';
            state.tskView = _tv109;
        } catch (e) { state.tskView = 'tile'; }
        applyPermsToUI();
        try {
            state.tskCompactMode = (localStorage.getItem('tracker_tsk_compact') === '1');
        } catch (e) { state.tskCompactMode = false; }
    }).catch(function(err) {
        notify('❌ ' + (err.message || 'Ошибка'), 'error');
    });
}

function applyPermsToUI() {
    var map = [
        ['addEmployeeBtn', 'action.employee.create'],
        ['addDepartmentBtn', 'action.department.create'],
        ['addTeamBtn', 'action.team.create'],
        ['addTaskBtn', 'action.task.create'],
        ['addTaskBtn2', 'action.task.create'],
        ['dayAddBtn', 'action.log.create'],
        ['dayCopyPrevBtn', 'action.log.create'],
        ['dayClearBtn', 'action.log.delete.any'],
        ['trkMaskToggle', 'action.mask.use'],
    ];
    map.forEach(function(p) {
        var el = $(p[0]);
        if (el && !hasPerm(p[1])) el.style.display = 'none';
    });
}

/* ============================================================
   ОТДЕЛЫ
   ============================================================ */
function renderDepartments() {
    var list = $('departmentsList'), cnt = $('departmentsCount');
    if (!list) return;
    var deps = state.departments || [];
    if (cnt) cnt.textContent = deps.length;
    if (!deps.length) { list.innerHTML = '<div class="dict-empty">Пока нет отделов</div>'; return; }
    var canEdit = hasPerm('action.department.edit');
    var canDel = hasPerm('action.department.delete');
    var html = '';
    deps.forEach(function(dep) {
        var count = (state.employees || []).filter(function(e) { return e.department_id === dep.id; }).length;
        var _head = dep.head_employee_id ? state.employees.find(function(e) { return e.id === dep.head_employee_id; }) : null;
        var _headTxt = _head ? '<span class="badge badge-dept">👤 ' + escName(_head.name) + '</span>' : '';
        html += '<div class="dict-item" data-id="' + escapeHtml(dep.id) + '">'
            + '<span class="dict-item-dot" style="background:' + escapeHtml(dep.color || '#7a9ab5') + '; box-shadow:0 0 8px ' + escapeHtml(dep.color || '#7a9ab5') + ';"></span>'
            + '<div class="dict-item-body"><div class="dict-item-name">' + escapeHtml(dep.name) + '</div>'
            + '<div class="dict-item-meta"><span class="badge">👥 ' + count + '</span>' + _headTxt + '</div>'
            + '</div><div class="dict-actions">'
            + (canEdit ? '<button class="dict-action-btn" data-act="edit">✏️</button>' : '')
            + (canDel ? '<button class="dict-action-btn danger" data-act="delete">🗑</button>' : '')
            + '</div></div>';
    });
    list.innerHTML = html;
    list.querySelectorAll('.dict-item').forEach(function(item) {
        var id = item.getAttribute('data-id');
        var eb = item.querySelector('[data-act="edit"]');
        var db = item.querySelector('[data-act="delete"]');
        if (eb) eb.addEventListener('click', function() {
            var dep = state.departments.find(function(x) { return x.id === id; });
            if (dep) openDepartmentModal(dep);
        });
        if (db) db.addEventListener('click', function() { deleteDepartment(id); });
    });
}

/* ============================================================
   СОТРУДНИКИ
   ============================================================ */
function renderEmployees() {
    var list = $('employeesList'), cnt = $('employeesCount');
    if (!list) return;
    if (cnt) cnt.textContent = state.employees.length;
    if (!state.employees.length) { list.innerHTML = '<div class="dict-empty">Пока нет сотрудников</div>'; return; }
    var canEdit = hasPerm('action.employee.edit');
    var canDel = hasPerm('action.employee.delete');
    var html = '';
    state.employees.forEach(function(e) {
        var color = e.color || '#00897b';
        var vac = (e.vacations || []).filter(function(v) { return (v.type||'vacation') === 'vacation'; }).length;
        var sick = (e.vacations || []).filter(function(v) { return v.type === 'sick_leave'; }).length;
        var trip = (e.vacations || []).filter(function(v) { return v.type === 'business_trip'; }).length;
        var badges = '';
        if (vac) badges += '<span class="badge badge-vac">🏖 ' + vac + '</span>';
        if (sick) badges += '<span class="badge badge-sick">🤒 ' + sick + '</span>';
        if (trip) badges += '<span class="badge badge-trip">✈️ ' + trip + '</span>';
        var metaArr = [];
        if (e.department) metaArr.push('<span class="badge badge-dept">🏢 ' + escapeHtml(e.department) + '</span>');
        if (e.role) metaArr.push(escapeHtml(e.role));
        if (e.fired) metaArr.push('<span class="badge badge-fired">🚪 уволен ' + escapeHtml(e.fired_date || '') + '</span>');
        html += '<div class="dict-item' + (e.fired ? ' fired' : '') + '" data-id="' + escapeHtml(e.id) + '">'
            + '<span class="dict-item-dot" style="background:' + escapeHtml(color) + '; box-shadow:0 0 8px ' + escapeHtml(color) + ';"></span>'
            + '<div class="dict-item-body"><div class="dict-item-name">' + escName(e.name) + '</div>'
            + (metaArr.length || badges ? '<div class="dict-item-meta">' + badges + metaArr.join(' ') + '</div>' : '')
            + '</div><div class="dict-actions">'
            + (canEdit ? '<button class="dict-action-btn" data-act="edit">✏️</button>' : '')
            + (canDel ? '<button class="dict-action-btn danger" data-act="delete">🗑</button>' : '')
            + '</div></div>';
    });
    list.innerHTML = html;
    list.querySelectorAll('.dict-item').forEach(function(item) {
        var id = item.getAttribute('data-id');
        var eb = item.querySelector('[data-act="edit"]');
        var db = item.querySelector('[data-act="delete"]');
        if (eb) eb.addEventListener('click', function() {
            var emp = state.employees.find(function(x) { return x.id === id; });
            if (emp) openEmployeeModal(emp);
        });
        if (db) db.addEventListener('click', function() { deleteEmployee(id); });
    });
}

/* ============================================================
   КОМАНДЫ
   ============================================================ */
function renderTeams() {
    var list = $('teamsList'), cnt = $('teamsCount');
    if (!list) return;
    var teams = state.teams || [];
    if (cnt) cnt.textContent = teams.length;
    if (!teams.length) { list.innerHTML = '<div class="dict-empty">Пока нет команд</div>'; return; }
    var canEdit = hasPerm('action.team.edit');
    var canDel = hasPerm('action.team.delete');
    var html = '';
    teams.forEach(function(tm) {
        var mgr = state.employees.find(function(e) { return e.id === tm.manager_id; });
        var mgrName = mgr ? maskName(mgr.name) : '—';
        var dept = (state.departments || []).find(function(d) { return d.id === tm.department_id; });
        var deptName = dept ? dept.name : '';
        var mc = (tm.member_ids || []).length;
        html += '<div class="dict-item" data-id="' + escapeHtml(tm.id) + '">'
            + '<span class="dict-item-icon">👥</span>'
            + '<div class="dict-item-body"><div class="dict-item-name">' + escapeHtml(tm.name) + '</div>'
            + '<div class="dict-item-meta">'
            + (deptName ? '<span class="badge badge-dept">🏢 ' + escapeHtml(deptName) + '</span>' : '')
            + '<span class="badge badge-team">👤 ' + escapeHtml(mgrName) + '</span>'
            + '<span class="badge">👥 ' + mc + '</span>'
            + '</div></div><div class="dict-actions">'
            + (canEdit ? '<button class="dict-action-btn" data-act="edit">✏️</button>' : '')
            + (canDel ? '<button class="dict-action-btn danger" data-act="delete">🗑</button>' : '')
            + '</div></div>';
    });
    list.innerHTML = html;
    list.querySelectorAll('.dict-item').forEach(function(item) {
        var id = item.getAttribute('data-id');
        var eb = item.querySelector('[data-act="edit"]');
        var db = item.querySelector('[data-act="delete"]');
        if (eb) eb.addEventListener('click', function() {
            var tm = state.teams.find(function(x) { return x.id === id; });
            if (tm) openTeamModal(tm);
        });
        if (db) db.addEventListener('click', function() { deleteTeam(id); });
    });
}

/* ============================================================
   ПРАЗДНИКИ INLINE
   ============================================================ */
function renderHolidaysInline() {
    var list = $('holidaysInlineList'); if (!list) return;
    var grid = $('holidaysGrid') || list;
    var hol = state.holidays || {};
    var keys = Object.keys(hol).sort().slice(0, 80);
    if (!keys.length) { grid.innerHTML = '<div class="dict-empty">Нет праздников</div>'; return; }
    var html = '';
    keys.forEach(function(k) {
        html += '<div class="dict-item">'
            + '<span class="dict-item-icon">🎉</span>'
            + '<div class="dict-item-body"><div class="dict-item-name">' + escapeHtml(hol[k]) + '</div>'
            + '<div class="dict-item-meta">' + escapeHtml(k) + '</div>'
            + '</div></div>';
    });
    grid.innerHTML = html;
}

/* ============================================================
   ЗАДАЧИ
   ============================================================ */
function _deptBadgesForTask(t) {
    var ids = t.department_ids || [];
    if (!ids.length) return '';
    var names = ids.map(function(id) {
        var d = (state.departments || []).find(function(x) { return x.id === id; });
        return d ? d.name : id;
    });
    var limit = 2;
    var shown = names.slice(0, limit).map(function(n) {
        return '<span class="badge badge-dept">🏢 ' + escapeHtml(n) + '</span>';
    }).join('');
    if (names.length > limit) {
        shown += '<span class="badge badge-dept" title="' + escapeHtml(names.join(', ')) + '">+' + (names.length - limit) + '</span>';
    }
    return shown;
}
function _tagChipsForTask(t) {
    var tags = t.tags || [];
    if (!tags.length) return '';
    return tags.slice(0, 6).map(function(tag) {
        return '<span class="task-tag-chip">#' + escapeHtml(tag) + '</span>';
    }).join('');
}
function _completionBadge(t) {
    if (!t || !t.completion_kind) return '';
    var cls = t.completion_kind;
    var label = cls === 'early' ? '✅ Досрочно' : (cls === 'late' ? '⏰ С опозданием' : '✅ В срок');
    var extra = t.completed_at ? ' · ' + escapeHtml(t.completed_at) : '';
    // PATCH v1.0.9: помечаем автозакрытие в бейдже выполнения
    var auto = t.auto_closed_at ? ' 🤖' : '';
    var autoTitle = t.auto_closed_at ? (' title="Закрыто автоматически: ' + escapeHtml(t.auto_closed_at) + '"') : '';
    return '<span class="task-completion-badge ' + cls + '"' + autoTitle + '>' + label + extra + auto + '</span>';
}
function taskCardRow(t) {
    var meta = [];
    if (t.overdue) meta.push('<span class="badge badge-danger">⚠ просрочено</span>');
    if (t.status && t.status !== 'active') {
        var lbl = state.taskStatusLabels[t.status] || t.status;
        meta.push('<span class="badge">' + escapeHtml(lbl) + '</span>');
    }
    var db = _deptBadgesForTask(t);
    if (db) meta.push(db);
    if (t.start_date) meta.push('🚀 ' + escapeHtml(t.start_date));
    if (t.deadline) meta.push('⏰ ' + escapeHtml(t.deadline));
    if (t.assignees && t.assignees.length) {
        var names = t.assignees.map(function(aid) {
            var e = state.employees.find(function(x) { return x.id === aid; });
            return e ? maskName(e.name) : '?';
        }).slice(0, 3);
        meta.push('👥 ' + names.map(escapeHtml).join(', ') + (t.assignees.length > 3 ? ' +' + (t.assignees.length - 3) : ''));
    }
    var tagsHtml = _tagChipsForTask(t);
    var compBadge = _completionBadge(t);
    var canCard = hasPerm('tab.summary') || hasPerm('tab.stats');
    var canEdit = hasPerm('action.task.edit');
    var canDel = hasPerm('action.task.delete');
    return '<div class="dict-item" data-id="' + escapeHtml(t.id) + '">'
        + '<span class="dict-item-icon">' + escapeHtml(t.icon || '📋') + '</span>'
        + '<div class="dict-item-body"><div class="dict-item-name' + (t.overdue ? ' overdue' : '') + '">' + escapeHtml(t.name) + '</div>'
        + (meta.length ? '<div class="dict-item-meta">' + meta.join(' · ') + '</div>' : '')
        + (tagsHtml ? '<div class="dict-item-meta" style="margin-top:3px;">' + tagsHtml + '</div>' : '')
        + (compBadge ? '<div class="dict-item-meta" style="margin-top:3px;">' + compBadge + '</div>' : '')
        + '</div><div class="dict-actions">'
        + (canCard ? '<button class="dict-action-btn" data-act="card" title="Карточка">📊</button>' : '')
        + (canEdit ? '<button class="dict-action-btn" data-act="edit" title="Редактировать">✏️</button>' : '')
        + (canDel ? '<button class="dict-action-btn danger" data-act="delete" title="Удалить">🗑</button>' : '')
        + '</div></div>';
}
/* PATCH v1.0.10: K/N по задаче — сколько исполнителей уже закрыли */
var _lastDoneCacheClient = null;
var _lastDoneCacheClientSrc = null;
function _buildLastDoneMapClient() {
    var m = {};
    var logs = (state && state.log) || [];
    for (var i = 0; i < logs.length; i++) {
        var l = logs[i];
        if (!l || l.status !== 'done') continue;
        var eid = l.employee_id;
        var tid = l.task_id;
        var d = l.date || '';
        if (!eid || !tid || !d) continue;
        var k = tid + '|' + eid;
        if (!m[k] || d > m[k]) m[k] = d;
    }
    return m;
}
function _taskProgressClient(t) {
    if (!t || !t.id) return null;
    var ids = t.assignees || [];
    if (!ids.length) return null;
    var src = (state && state.log) || null;
    if (_lastDoneCacheClient === null || _lastDoneCacheClientSrc !== src) {
        _lastDoneCacheClient = _buildLastDoneMapClient();
        _lastDoneCacheClientSrc = src;
    }
    var closed = 0;
    for (var i = 0; i < ids.length; i++) {
        if (_lastDoneCacheClient[t.id + '|' + ids[i]]) closed++;
    }
    return { total: ids.length, closed: closed, pct: Math.round(100 * closed / ids.length) };
}

function taskCardRowGrid(t) {
    var canCard = hasPerm('tab.summary') || hasPerm('tab.stats');
    var canEdit = hasPerm('action.task.edit');
    var canDel = hasPerm('action.task.delete');
    var today = state.today || todayISO();

    function daysBetween(a, b) {
        try {
            var d1 = new Date(a + 'T00:00:00');
            var d2 = new Date(b + 'T00:00:00');
            return Math.round((d2 - d1) / 86400000);
        } catch (err) { return null; }
    }
    function pluralDays(n) {
        n = Math.abs(n);
        var l2 = n % 100;
        var l1 = n % 10;
        if (l2 >= 11 && l2 <= 14) return n + ' дней';
        if (l1 === 1) return n + ' день';
        if (l1 >= 2 && l1 <= 4) return n + ' дня';
        return n + ' дней';
    }
    function countdown() {
        var dl = t.deadline;
        var st = t.start_date;
        if (t.status === 'done' || t.status === 'archived') {
            if (t.completed_at) return { text: '✅ завершено ' + formatDateShort(t.completed_at), kind: 'ok' };
            return { text: '✅ завершено', kind: 'ok' };
        }
        if (dl) {
            var d = daysBetween(today, dl);
            if (d === null) return null;
            if (d < 0) return { text: '⚠ просрочено ' + pluralDays(-d), kind: 'danger' };
            if (d === 0) return { text: '🔥 сегодня', kind: 'warn' };
            if (d === 1) return { text: '⏰ завтра', kind: 'warn' };
            if (d <= 3) return { text: '⏰ ' + pluralDays(d), kind: 'warn' };
            return { text: 'осталось ' + pluralDays(d), kind: 'neutral' };
        }
        if (st) {
            var s = daysBetween(today, st);
            if (s !== null && s > 0) return { text: '🚀 старт ' + formatDateShort(st), kind: 'neutral' };
        }
        return null;
    }
    function progress() {
        if (!t.start_date || !t.deadline) return null;
        try {
            var s = new Date(t.start_date + 'T00:00:00');
            var e = new Date(t.deadline + 'T00:00:00');
            var n = new Date(today + 'T00:00:00');
            var total = (e - s) / 86400000;
            if (total <= 0) return 100;
            var elapsed = (n - s) / 86400000;
            return Math.round(Math.max(0, Math.min(100, (elapsed / total) * 100)));
        } catch (err) { return null; }
    }

    var statusKey = t.status || 'active';
    var cardCls = 'task-card st-' + statusKey;
    if (t.overdue) cardCls += ' overdue';
    // PATCH v1.0.18: розовая подсветка «очень срочных»
    if (t.is_urgent) cardCls += ' task-card--urgent';

    // PATCH v1.0.9: помечаем задачи, закрытые автоматически (🤖 + tooltip)
    var _autoClosed = !!(t.auto_closed_at);
    var _autoSuffix = _autoClosed ? ' 🤖' : '';
    var _autoTitle = _autoClosed ? (' title="Закрыто автоматически: ' + escapeHtml(t.auto_closed_at) + '"') : '';

    // PATCH v1.0.10: K/N — сколько исполнителей закрыли задачу (виден, если их больше одного)
    var _prog = _taskProgressClient(t);
    var _progSuffix = (_prog && _prog.total > 1 && _prog.closed > 0)
        ? ' · ' + _prog.closed + '/' + _prog.total
        : '';
    var _progTitle = (_prog && _prog.total > 1)
        ? (' title="Закрыли ' + _prog.closed + ' из ' + _prog.total + ' исполнителей"')
        : '';

    var _urgBadge = t.is_urgent ? '<span class="task-card-badge urgent">🚨 Срочно</span>' : '';
    var statusBadge = '';
    if (t.overdue) {
        statusBadge = '<span class="task-card-badge overdue"' + _autoTitle + _progTitle + '>⚠ Просрочено' + _autoSuffix + _progSuffix + '</span>' + _urgBadge;
    } else if (t.status && t.status !== 'active') {
        var slbl = state.taskStatusLabels[t.status] || t.status;
        var _cls = 'task-card-badge status-' + escapeHtml(t.status)
            + (_autoClosed ? ' auto-closed' : '');
        statusBadge = '<span class="' + _cls + '"' + _autoTitle + _progTitle + '>' + escapeHtml(slbl) + _autoSuffix + _progSuffix + '</span>' + _urgBadge;
    } else if (_prog && _prog.total > 1 && _prog.closed > 0) {
        statusBadge = '<span class="task-card-badge status-active"' + _progTitle + '>🔵 В работе' + _progSuffix + '</span>' + _urgBadge;
    } else if (t.is_urgent) {
        statusBadge = _urgBadge;
    }

    var deptBadges = _deptBadgesForTask(t);

    var pct = progress();
    var progressHtml = '';
    if (pct !== null) {
        var pcls = 'ok';
        if (t.overdue) pcls = 'danger';
        else if (pct >= 70) pcls = 'warn';
        progressHtml = '<div class="task-card-progress" title="Пройдено ' + pct + '% срока">'
            + '<div class="task-card-progress-fill ' + pcls + '" style="width:' + pct + '%"></div>'
            + '</div>';
    }

    var datesHtml = '';
    if (t.start_date || t.deadline) {
        datesHtml = '<div class="task-card-dates">';
        if (t.start_date) datesHtml += '<span class="date-chip">🚀 ' + escapeHtml(formatDateShort(t.start_date)) + '</span>';
        if (t.start_date && t.deadline) datesHtml += '<span class="date-chip-arrow">→</span>';
        if (t.deadline) datesHtml += '<span class="date-chip' + (t.overdue ? ' overdue' : '') + '">⏰ ' + escapeHtml(formatDateShort(t.deadline)) + '</span>';
        datesHtml += '</div>';
    }

    var cd = countdown();
    var cdHtml = cd ? '<span class="task-card-countdown ' + cd.kind + '">' + escapeHtml(cd.text) + '</span>' : '';

    var tagsHtml = '';
    if (t.tags && t.tags.length) {
        tagsHtml = '<div class="task-card-tags">'
            + t.tags.slice(0, 4).map(function(x) {
                return '<span class="task-tag-chip">#' + escapeHtml(x) + '</span>';
            }).join('')
            + (t.tags.length > 4 ? '<span class="task-tag-chip more">+' + (t.tags.length - 4) + '</span>' : '')
            + '</div>';
    }

    var assigneesHtml = '';
    if (t.assignees && t.assignees.length) {
        var allNames = t.assignees.map(function(aid) {
            var e = state.employees.find(function(x) { return x.id === aid; });
            return e ? e.name : '?';
        });
        assigneesHtml = '<div class="task-card-assignees" title="' + escapeHtml(allNames.join(', ')) + '">';
        t.assignees.slice(0, 4).forEach(function(aid) {
            var e = state.employees.find(function(x) { return x.id === aid; });
            if (!e) return;
            var color = e.color || '#888';
            assigneesHtml += '<span class="assignee-dot" '
                + 'style="background:' + escapeHtml(color) + ';" '
                + 'title="' + escapeHtml(maskName(e.name)) + '">'
                + escapeHtml(initials(e.name)) + '</span>';
        });
        if (t.assignees.length > 4) {
            assigneesHtml += '<span class="assignee-dot more">+' + (t.assignees.length - 4) + '</span>';
        }
        assigneesHtml += '</div>';
    }

    var actionsHtml = '<div class="task-card-actions">'
        + (canCard ? '<button class="dict-action-btn" data-act="card" title="Карточка (статистика)">📊</button>' : '')
        + (canDel ? '<button class="dict-action-btn danger" data-act="delete" title="Удалить">🗑</button>' : '')
        + '</div>';

    return '<div class="' + cardCls + '" data-id="' + escapeHtml(t.id) + '">'
        + '<div class="task-card-accent"></div>'
        + '<div class="task-card-head">'
        +   '<div class="task-card-icon-wrap"><span class="task-card-icon">' + escapeHtml(t.icon || '📋') + '</span></div>'
        +   '<div class="task-card-titles">'
        +     '<div class="task-card-title' + (t.overdue ? ' overdue' : '') + '">' + escapeHtml(t.name) + '</div>'
        +     (deptBadges ? '<div class="task-card-sub">' + deptBadges + '</div>' : '')
        +   '</div>'
        +   '<div class="task-card-topright">'
        +     (statusBadge || '')
        +   '</div>'
        + '</div>'
        + progressHtml
        + '<div class="task-card-mid">'
        +   (datesHtml || '<div class="task-card-dates"></div>')
        +   (cdHtml || '')
        + '</div>'
        + '<div class="task-card-foot">'
        +   (tagsHtml || '<div class="task-card-tags"></div>')
        +   (assigneesHtml || '')
        +   actionsHtml
        + '</div>'
        + '</div>';
}

function bindTaskCardActions(container, sel) {
    container.querySelectorAll(sel || '.dict-item').forEach(function(item) {
        var id = item.getAttribute('data-id');
        if (!id) return;
        var cardBtn = item.querySelector('[data-act="card"]');
        var editBtn = item.querySelector('[data-act="edit"]');
        var delBtn = item.querySelector('[data-act="delete"]');
        if (cardBtn) cardBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            openTaskCardModal(id);
        });
        if (editBtn) editBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            var t = state.tasks.find(function(x) { return x.id === id; });
            if (t) openTaskModal(t);
        });
        if (delBtn) delBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            deleteTask(id);
        });
        var canEdit = hasPerm('action.task.edit');
        var noAssignees = !((state.tasks.find(function(x) { return x.id === id; }) || {}).assignees || []).length;
        if (noAssignees) item.classList.add('task-card--no-assignees');
        if (canEdit) {
            item.classList.add('task-card-clickable');
            item.addEventListener('click', function(e) {
                if (e.target.closest('.dict-action-btn')) return;
                if (e.target.closest('a')) return;
                var t = state.tasks.find(function(x) { return x.id === id; });
                if (t) openTaskModal(t);
            });
        }
    });
}
function _taskMatchesDept(t, deptId) {
    if (!deptId) return true;
    var ids = t.department_ids || [];
    if (ids.indexOf(deptId) !== -1) return true;
    if (!ids.length) {
        var deps = (t.assignees || []).map(function(aid) {
            var e = state.employees.find(function(x) { return x.id === aid; });
            return e ? e.department_id : '';
        });
        return deps.indexOf(deptId) !== -1;
    }
    return false;
}
function _teamEmpIds(teamId) {
    if (!teamId) return null;
    var tm = (state.teams || []).find(function(x) { return x.id === teamId; });
    if (!tm) return new Set();
    var s = new Set();
    if (tm.manager_id) s.add(tm.manager_id);
    (tm.member_ids || []).forEach(function(m) { if (m) s.add(m); });
    return s;
}
function _taskMatchesTeam(t, teamId) {
    if (!teamId) return true;
    var ids = _teamEmpIds(teamId);
    if (!ids) return true;
    return (t.assignees || []).some(function(a) { return ids.has(a); });
}
function renderTasks() {
    var list = $('tasksList'), cnt = $('tasksCount');
    var archList = $('tasksArchivedList'), archCnt = $('tasksArchivedCount');
    if (!list) {
        // PATCH 1.0.10: задач в справочниках больше нет — плитку всё равно перерисуем
        try { renderTasksFull(); } catch (e) { console.error('[renderTasks]', e); }
        return;
    }
    var active = [], archived = [];
    state.tasks.forEach(function(t) {
        if (t.status === 'archived' || t.status === 'done') archived.push(t);
        else active.push(t);
    });
    if (cnt) cnt.textContent = active.length;
    if (archCnt) archCnt.textContent = archived.length;

    function fill(el, arr, emptyMsg) {
        if (!el) return;
        if (!arr.length) { el.innerHTML = '<div class="dict-empty">' + emptyMsg + '</div>'; return; }
        var html = '';
        arr.forEach(function(t) { html += taskCardRow(t); });
        el.innerHTML = html;
        bindTaskCardActions(el, '.dict-item');
    }
    fill(list, active, 'Пока нет активных задач');
    fill(archList, archived, 'Пока нет архива');
    renderTasksFull();
}
function _highlightInCard(card, query) {
    if (!card) return;
    var nameEl = card.querySelector('.task-card-title');
    if (!nameEl) return;
    if (!card._origTitleHtml) card._origTitleHtml = nameEl.innerHTML;
    if (!query) {
        if (nameEl.innerHTML !== card._origTitleHtml) nameEl.innerHTML = card._origTitleHtml;
        return;
    }
    var txt = nameEl.textContent || '';
    var rx = new RegExp('(' + query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'ig');
    var out = txt.replace(/[&<>"']/g, function(c) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    }).replace(rx, '<mark>$1</mark>');
    if (nameEl.innerHTML !== out) nameEl.innerHTML = out;
}

function renderTasksFull() {
    var list = $('tasksFullList'); if (!list) return;
    // PATCH v1.0.12: восстанавливаем колонки из localStorage до рендера
    try {
        var _savedCols = parseInt(localStorage.getItem('tracker_tsk_cols'), 10);
        if (_savedCols >= 1 && _savedCols <= 5) state.tskGridCols = _savedCols;
    } catch (e) {}
    var dept = $('tskDeptFilter') ? ($('tskDeptFilter').value || '') : '';
    var team = $('tskTeamFilter') ? ($('tskTeamFilter').value || '') : '';
    var emp  = $('tskEmployeeFilter') ? ($('tskEmployeeFilter').value || '') : '';
    var selectedTags = (window.__trkSelectedTags && window.__trkSelectedTags.tskTagFilter) || [];
    var sort = $('tskSortSelect') ? ($('tskSortSelect').value || 'deadline_asc') : 'deadline_asc';
    var mode = state.tskViewMode || 'all';

    var tasks = state.tasks.slice();
    if (dept) tasks = tasks.filter(function(t) { return _taskMatchesDept(t, dept); });
    if (team) tasks = tasks.filter(function(t) { return _taskMatchesTeam(t, team); });
    if (emp)  tasks = tasks.filter(function(t) { return (t.assignees || []).indexOf(emp) !== -1; });
    if (selectedTags.length) {
        var tskMode = (window.__trkTagMode && window.__trkTagMode.tskTagFilter) || 'any';
        tasks = tasks.filter(function(t) {
            var tg = t.tags || [];
            if (tskMode === 'all') {
                return selectedTags.every(function(x) { return tg.indexOf(x) !== -1; });
            }
            return selectedTags.some(function(x) { return tg.indexOf(x) !== -1; });
        });
    }

    if (mode === 'active') tasks = tasks.filter(function(t) { return t.status === 'active' && !t.overdue; });
    else if (mode === 'overdue') tasks = tasks.filter(function(t) { return t.overdue; });
    else if (mode === 'done') tasks = tasks.filter(function(t) { return t.status === 'done'; });
    else if (mode === 'archived') tasks = tasks.filter(function(t) { return t.status === 'archived'; });
    else if (mode === 'attention') {
        var _ac = (typeof window.__trkAttentionCount === 'function') ? window.__trkAttentionCount() : { byId: {} };
        tasks = tasks.filter(function(t) { return !!_ac.byId[t.id]; });
    }

    function statusRank(t) {
        if (t.status === 'archived') return 5;
        if (t.status === 'done') return 4;
        if (t.status === 'paused') return 2;
        return 1;
    }
    tasks.sort(function(a, b) {
        switch (sort) {
            case 'deadline_asc':  return (a.deadline || '9999').localeCompare(b.deadline || '9999');
            case 'deadline_desc': return (b.deadline || '').localeCompare(a.deadline || '');
            case 'created_desc':  return (b.created_at || '').localeCompare(a.created_at || '');
            case 'created_asc':   return (a.created_at || '').localeCompare(b.created_at || '');
            case 'name_asc':      return (a.name || '').toLowerCase().localeCompare((b.name || '').toLowerCase());
            case 'name_desc':     return (b.name || '').toLowerCase().localeCompare((a.name || '').toLowerCase());
            case 'status':        return statusRank(a) - statusRank(b);
            case 'overdue_first':
                if (a.overdue && !b.overdue) return -1;
                if (!a.overdue && b.overdue) return 1;
                return (a.deadline || '').localeCompare(b.deadline || '');
        }
        return 0;
    });

    if (!tasks.length) { list.innerHTML = '<div class="dict-empty">Нет задач по фильтру</div>'; return; }
    var html = '';
    tasks.forEach(function(t) { html += taskCardRowGrid(t); });
    // PATCH 1.0.9: три режима — плитка / компактно / список
    var _view = state.tskView || 'tile';
    var _cols = parseInt(state.tskGridCols, 10) || 3;
    if (_cols < 1) _cols = 1;
    if (_cols > 5) _cols = 5;

    if (_view === 'list') {
        // Список: dict-item как на Справочниках, но в N колонках
        var _listHtml = '';
        tasks.forEach(function(t) { _listHtml += taskCardRow(t); });
        list.className = 'dict-list tasks-list-view';
        list.setAttribute('data-cols', String(_cols));
        list.removeAttribute('data-compact');
        list.removeAttribute('data-view');
        list.style.maxHeight = 'none';
        list.style.display = 'grid';
        list.innerHTML = _listHtml;
        bindTaskCardActions(list, '.dict-item');
        try {
            var _sInpL = $('tskSearchInput');
            if (_sInpL && (_sInpL.value || '').trim()) {
                var _qL = _sInpL.value.trim();
                list.querySelectorAll('.dict-item').forEach(function(card) {
                    var nameEl = card.querySelector('.dict-item-name');
                    if (!nameEl) return;
                    if (!card._origTitleHtml) card._origTitleHtml = nameEl.innerHTML;
                    var txt = nameEl.textContent || '';
                    var rx = new RegExp('(' + _qL.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'ig');
                    var out = txt.replace(/[&<>"']/g, function(c) {
                        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
                    }).replace(rx, '<mark>$1</mark>');
                    if (nameEl.innerHTML !== out) nameEl.innerHTML = out;
                });
            }
        } catch (e) { console.error('[list-highlight]', e); }
        return;
    }

    var cols = _cols;
    list.className = 'tasks-grid';
    list.setAttribute('data-cols', String(cols));
    list.style.maxHeight = 'none';
    list.style.display = 'grid';
    // PATCH v1.0.12: компактный режим (data-compact=1)
    if (_view === 'compact' || _view === 'tree') {
        list.setAttribute('data-compact', '1');
        if (_view === 'tree') {
            list.setAttribute('data-view', 'tree');
        } else {
            list.removeAttribute('data-view');
        }
    } else {
        list.removeAttribute('data-compact');
        list.removeAttribute('data-view');
    }
    list.innerHTML = html;
    bindTaskCardActions(list, '.task-card');
    // PATCH v1.0.12: если поиск активен — сразу подсветить совпадения
    try {
        var _sInp = $('tskSearchInput');
        if (_sInp && (_sInp.value || '').trim()) {
            var _q = _sInp.value.trim();
            list.querySelectorAll('.task-card').forEach(function(card) {
                _highlightInCard(card, _q);
            });
        }
    } catch (e) { console.error('[highlight]', e); }
}

/* ============================================================
   ЭМОДЗИ / ПАЛИТРА
   ============================================================ */
function renderEmojiGrid() {
    var grid = $('emojiGrid'); if (!grid) return;
    var list = state.emoji.length ? state.emoji :
        ['🚀','📋','💼','📊','🎯','💡','📁','📌','🔖','📅','👥','💻'];
    grid.innerHTML = list.map(function(e) {
        return '<button type="button" class="emoji-btn" data-emoji="' + escapeHtml(e) + '">' + e + '</button>';
    }).join('');
    grid.querySelectorAll('.emoji-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var em = this.getAttribute('data-emoji') || '🚀';
            var ti = $('task_icon'); if (ti) ti.value = em;
            var prev = $('taskIconPreview'); if (prev) prev.textContent = em;
            var m = $('emojiModal'); if (m) m.classList.remove('active');
        });
    });
}
function renderPalette() {
    var wrap = $('empPalette'); if (!wrap) return;
    var colors = state.palette.length ? state.palette :
        ['#00897b','#ef6c00','#c62828','#0277bd','#2e7d32','#6d4c41'];
    wrap.innerHTML = colors.map(function(c) {
        return '<span class="palette-dot" style="background:' + c + ';" data-color="' + c + '" title="' + c + '"></span>';
    }).join('');
    wrap.querySelectorAll('.palette-dot').forEach(function(dot) {
        dot.addEventListener('click', function() {
            var c = this.getAttribute('data-color');
            var inp = $('emp_color'); if (inp) inp.value = c;
            wrap.querySelectorAll('.palette-dot').forEach(function(d) { d.classList.remove('active'); });
            this.classList.add('active');
        });
    });
}

/* ============================================================
   ФИЛЬТРЫ
   ============================================================ */
function fillDepartmentFilters() {
    // PATCH v1.0.12: сортировка по имени
    var deps = (state.departments || []).slice().sort(function(a, b) {
        return String(a.name || '').toLowerCase().localeCompare(String(b.name || '').toLowerCase(), 'ru');
    });
    ['calDeptFilter','hmDeptFilter','sumDeptFilter','stDeptFilter','tskDeptFilter'].forEach(function(elId) {
        var sel = $(elId); if (!sel) return;
        var cur = sel.value;
        sel.innerHTML = '<option value="">Отделы</option>'
            + deps.map(function(d) {
                return '<option value="' + escapeHtml(d.id) + '">' + escapeHtml(d.name) + '</option>';
            }).join('');
        sel.value = cur;
    });
    var cal = $('calDeptFilter');
    if (cal && state.currentDepartment) cal.value = state.currentDepartment;
    if (typeof renderHmDeptPills === 'function') renderHmDeptPills();
}
function fillTeamFilters() {
    // PATCH v1.0.12: сортировка команд по имени
    var teams = (state.teams || []).slice().sort(function(a, b) {
        return String(a.name || '').toLowerCase().localeCompare(String(b.name || '').toLowerCase(), 'ru');
    });
    ['calTeamFilter','hmTeamFilter','sumTeamFilter','stTeamFilter','tskTeamFilter'].forEach(function(elId) {
        var sel = $(elId); if (!sel) return;
        var cur = sel.value;
        sel.innerHTML = '<option value="">Команды</option>'
            + teams.map(function(t) {
                return '<option value="' + escapeHtml(t.id) + '">' + escapeHtml(t.name) + '</option>';
            }).join('');
        sel.value = cur;
    });
    var cal = $('calTeamFilter');
    if (cal && state.currentTeam) cal.value = state.currentTeam;
}
(function(){
    try {
        var _saved = JSON.parse(localStorage.getItem('trk_hm_depts') || 'null');
        if (Array.isArray(_saved)) window.__trkHmDepts = _saved.filter(function(x) { return !!x; });
        else window.__trkHmDepts = window.__trkHmDepts || [];
    } catch (e) { window.__trkHmDepts = window.__trkHmDepts || []; }
})();
function _saveHmDepts() {
    try { localStorage.setItem('trk_hm_depts', JSON.stringify(window.__trkHmDepts || [])); } catch (e) {}
}
function renderHmDeptPills() {
    var wrap = $('hmDeptPills');
    if (!wrap) return;
    var deps = (state.departments || []).slice().sort(function(a, b) {
        return String(a.name || '').toLowerCase().localeCompare(String(b.name || '').toLowerCase(), 'ru');
    });
    var validIds = {};
    deps.forEach(function(d) { validIds[d.id] = true; });
    var cur = (window.__trkHmDepts || []).filter(function(x) { return validIds[x]; });
    window.__trkHmDepts = cur;
    if (!deps.length) { wrap.innerHTML = '<span style="color:var(--trk-meta);font-size:0.72rem;">Нет отделов</span>'; return; }
    var html = '';
    deps.forEach(function(d) {
        var act = cur.indexOf(d.id) !== -1 ? ' active' : '';
        html += '<button type="button" class="tag-chip' + act + '" data-dept-id="' + escapeHtml(d.id) + '" title="' + escapeHtml(d.name) + '">' + escapeHtml(d.name) + '</button>';
    });
    if (cur.length) html += '<button type="button" class="tag-clear" title="Очистить">✕</button>';
    wrap.innerHTML = html;
    wrap.querySelectorAll('.tag-chip').forEach(function(b) {
        b.addEventListener('click', function(e) {
            e.stopPropagation();
            var id = this.getAttribute('data-dept-id');
            var arr = window.__trkHmDepts = window.__trkHmDepts || [];
            var i = arr.indexOf(id);
            if (i === -1) arr.push(id); else arr.splice(i, 1);
            _saveHmDepts();
            renderHmDeptPills();
            loadHeatmap();
        });
    });
    var clr = wrap.querySelector('.tag-clear');
    if (clr) clr.addEventListener('click', function(e) {
        e.stopPropagation();
        window.__trkHmDepts = [];
        _saveHmDepts();
        renderHmDeptPills();
        loadHeatmap();
    });
}

function fillEmployeeFilter() {
    var sel = $('calEmployeeFilter'); if (!sel) return;
    var cur = sel.value;
    var deptId = state.currentDepartment || '';
    var teamId = state.currentTeam || '';
    var teamIds = _teamEmpIds(teamId);
    var emps = state.employees;
    if (deptId) emps = emps.filter(function(e) { return e.department_id === deptId; });
    if (teamIds) emps = emps.filter(function(e) { return teamIds.has(e.id); });
    sel.innerHTML = '<option value="">Сотрудники</option>'
        + emps.map(function(e) {
            var name = maskName(e.name) + (e.fired ? ' 🚪' : '');
            return '<option value="' + escapeHtml(e.id) + '">' + escapeHtml(name) + '</option>';
        }).join('');
    sel.value = cur || state.currentEmployee || '';
}
function fillEmployeeSelect() {
    var sel = $('log_employee'); if (!sel) return;
    // PATCH v1.0.12: сортировка по ФИО
    var emps = (state.employees || []).slice().sort(function(a, b) {
        return String(a.name || '').toLowerCase().localeCompare(String(b.name || '').toLowerCase(), 'ru');
    });
    sel.innerHTML = emps.map(function(e) {
        var name = maskName(e.name) + (e.fired ? ' 🚪' : '');
        return '<option value="' + escapeHtml(e.id) + '">' + escapeHtml(name) + '</option>';
    }).join('');
}
function fillTaskSelect() {
    var dl = $('log_task_list');
    if (!dl) return;
    var active = state.tasks.filter(function(t) { return t.status !== 'archived'; });
    dl.innerHTML = active.map(function(t) {
        var mark = t.overdue ? ' ⚠' : '';
        var suffix = (t.status === 'done' || t.status === 'archived') ? ' (архив)' : '';
        var label = (t.name || '') + suffix + mark;
        return '<option value="' + escapeHtml(label) + '" data-id="' + escapeHtml(t.id) + '"></option>';
    }).join('');
}
function fillSummaryFilters() {
    var selEmp = $('sumEmployeeFilter');
    if (selEmp) {
        var c1 = selEmp.value;
        selEmp.innerHTML = '<option value="">Сотрудники</option>'
            + state.employees.map(function(e) {
                var name = maskName(e.name) + (e.fired ? ' 🚪' : '');
                return '<option value="' + escapeHtml(e.id) + '">' + escapeHtml(name) + '</option>';
            }).join('');
        selEmp.value = c1;
    }
    var selTask = $('sumTaskFilter');
    if (selTask) {
        var c2 = selTask.value;
        selTask.innerHTML = '<option value="">Задачи</option>'
            + state.tasks.map(function(t) {
                var tagsTxt = (t.tags && t.tags.length) ? (' · ' + t.tags.map(function(x){return '#'+x;}).join(' ')) : '';
                return '<option value="' + escapeHtml(t.id) + '">'
                    + escapeHtml((t.icon || '📋') + ' ' + t.name + tagsTxt) + '</option>';
            }).join('');
        selTask.value = c2;
    }
    var stDept = $('stDeptFilter');
    if (stDept) {
        var sd = stDept.value;
        stDept.innerHTML = '<option value="">Отделы</option>'
            + (state.departments || []).map(function(d) {
                return '<option value="' + escapeHtml(d.id) + '">' + escapeHtml(d.name) + '</option>';
            }).join('');
        stDept.value = sd;
    }
    var stEmp = $('stEmployeeFilter');
    if (stEmp) {
        var se = stEmp.value;
        stEmp.innerHTML = '<option value="">Сотрудники</option>'
            + state.employees.map(function(e) {
                var name = maskName(e.name) + (e.fired ? ' 🚪' : '');
                return '<option value="' + escapeHtml(e.id) + '">' + escapeHtml(name) + '</option>';
            }).join('');
        stEmp.value = se;
    }
    var tskEmp = $('tskEmployeeFilter');
    if (tskEmp) {
        var te = tskEmp.value;
        tskEmp.innerHTML = '<option value="">Сотрудники</option>'
            + state.employees.map(function(e) {
                var name = maskName(e.name) + (e.fired ? ' 🚪' : '');
                return '<option value="' + escapeHtml(e.id) + '">' + escapeHtml(name) + '</option>';
            }).join('');
        tskEmp.value = te;
    }
}
function fillTagFilters() {
    var tagsSet = {};
    state.tasks.forEach(function(t) {
        (t.tags || []).forEach(function(x) { tagsSet[x] = true; });
    });
    (state.allTags || []).forEach(function(x) { tagsSet[x] = true; });
    var tags = Object.keys(tagsSet).sort();
    window.__trkAllTags = {};
    tags.forEach(function(t) { window.__trkAllTags[t] = true; });
    if (window.__trkInitTagFilterUI) window.__trkInitTagFilterUI();
    if (window.__trkRenderTagPills) window.__trkRenderTagPills();
}
/* ============================================================
   КАЛЕНДАРЬ
   ============================================================ */
function loadCalendar() {
    var ym = state.currentYM || todayYM();
    state.currentYM = ym;
    var emp = state.currentEmployee || '';
    var dept = state.currentDepartment || '';
    var team = state.currentTeam || '';
    var url = '/api/tracker/calendar?ym=' + encodeURIComponent(ym)
        + '&employee=' + encodeURIComponent(emp)
        + '&department=' + encodeURIComponent(dept)
        + '&team=' + encodeURIComponent(team);
    return apiJson(url)
        .then(function(d) { 
            state.calendar = d; 
            renderCalendar(); 
            // PATCH v3: применяем штриховку будущих дней после перерисовки
            if (window.__trkDecorateFuture && window.__trkDecorateFuture.calendar) {
                setTimeout(window.__trkDecorateFuture.calendar, 50);
            }
        })
        .catch(function(err) { if (err && (err.message || '').indexOf('cancelled') !== -1) return; notify('❌ ' + (err.message || 'Ошибка'), 'error'); });
}
/* PATCH 1.0.1 — экспорт в Excel */
function exportCalendarToExcel() {
    var month = state.calendar ? state.calendar.month : new Date().getMonth() + 1;
    var year = state.calendar ? state.calendar.year : new Date().getFullYear();
    var params = new URLSearchParams();
    params.set('month', month);
    params.set('year', year);
    var deptFilter = document.getElementById('calDeptFilter');
    if (deptFilter && deptFilter.value) params.set('department', deptFilter.value);
    var teamFilter = document.getElementById('calTeamFilter');
    if (teamFilter && teamFilter.value) params.set('team', teamFilter.value);
    var empFilter = document.getElementById('calEmployeeFilter');
    if (empFilter && empFilter.value) params.set('employee', empFilter.value);
    notify('📊 Генерируем Excel...', 'info');
    window.open('/api/tracker/calendar/export?' + params.toString(), '_blank');
}
function toggleExportMenu(force) {
    var drop = document.getElementById('exportMenuDrop');
    if (!drop) return;
    var show = (force === true) || drop.style.display === 'none';
    drop.style.display = show ? 'block' : 'none';
}
function runExportForm(form) {
    toggleExportMenu(false);
    if (form === 'calendar') exportCalendarToExcel();
    else if (form === 'debtors') exportDebtorsToExcel();
}
function exportDebtorsToExcel() {
    var d = new Date();
    var iso = d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
    var params = new URLSearchParams();
    params.set('date', iso);
    var deptFilter = document.getElementById('calDeptFilter');
    if (deptFilter && deptFilter.value) params.set('department', deptFilter.value);
    var teamFilter = document.getElementById('calTeamFilter');
    if (teamFilter && teamFilter.value) params.set('team', teamFilter.value);
    notify('⚠️ Считаем, кто не заполнил отчёт...', 'info');
    window.open('/api/tracker/export/debtors?' + params.toString(), '_blank');
}
(function(){
    if (window.__trkExportMenuBound) return;
    window.__trkExportMenuBound = true;
    document.addEventListener('click', function(e) {
        var t = e.target;
        if (!t || !t.closest) return;
        if (t.closest('#exportMenuBtn')) {
            e.preventDefault();
            e.stopPropagation();
            toggleExportMenu();
            return;
        }
        var item = t.closest('.export-menu-item');
        if (item) { runExportForm(item.getAttribute('data-form')); return; }
        var drop = document.getElementById('exportMenuDrop');
        if (drop && drop.style.display !== 'none' && !t.closest('.export-menu-wrap')) {
            drop.style.display = 'none';
        }
    }, true);
})();

function renderCalendar() {
    var cal = state.calendar; if (!cal) return;
    var titleEl = $('calMonthTitle');
    if (titleEl) titleEl.textContent = MONTHS_RU[cal.month - 1] + ' ' + cal.year;
    var grid = $('calGrid'); if (!grid) return;
    grid.setAttribute('data-expand', state.calExpandOnHover ? 'on' : 'off');
    grid.querySelectorAll('.cal-cell').forEach(function(c) { c.remove(); });
    var today = todayISO();
    cal.days.forEach(function(day) {
        var cell = document.createElement('div');
        cell.className = 'cal-cell';
        if (!day.in_month) cell.classList.add('out-month');
        if (day.date === today) cell.classList.add('today');
        if (day.is_weekend && !day.is_holiday) cell.classList.add('weekend');
        if (day.is_holiday) cell.classList.add('holiday');
        if (day.total_hours > 0) cell.classList.add(hoursClass(day.total_hours));
        if (day.missing && day.missing.length) cell.classList.add('missing');
        if (day.overdue_tasks && day.overdue_tasks.length) cell.classList.add('has-overdue');
        cell.setAttribute('data-date', day.date);
        if (day.is_holiday) cell.setAttribute('title', '🎉 ' + (day.holiday_name || 'Праздник'));
        var entriesHtml = '';
        var allEntries = day.entries;
        if (state.calViewMode === 'tasks') {
            allEntries.forEach(function(en) {
                entriesHtml += '<div class="cal-entry" title="' + escapeHtml(en.task_name + (en.comment ? ' — ' + en.comment : '')) + '">'
                    + '<span>' + escapeHtml(en.task_icon) + '</span>'
                    + '<span style="overflow:hidden;text-overflow:ellipsis;">' + escapeHtml(en.task_name) + '</span>'
                    + '<span class="entry-hours">' + formatHours(en.hours) + '</span></div>';
            });
        } else {
            var tot = {}, colors = {}, names = {};
            allEntries.forEach(function(en) {
                tot[en.employee_id] = (tot[en.employee_id] || 0) + en.hours;
                colors[en.employee_id] = en.employee_color;
                names[en.employee_id] = en.employee_name;
            });
            var ids = Object.keys(tot).sort(function(a, b) { return tot[b] - tot[a]; });
            ids.forEach(function(eid) {
                entriesHtml += '<div class="cal-entry" title="' + escapeHtml(maskName(names[eid] || '?') + ' — ' + formatHours(tot[eid])) + '">'
                    + '<span class="cal-dot" style="background:' + escapeHtml(colors[eid]) + ';"></span>'
                    + '<span style="overflow:hidden;text-overflow:ellipsis;">' + escName(names[eid] || '?') + '</span>'
                    + '<span class="entry-hours">' + formatHours(tot[eid]) + '</span></div>';
            });
        }
        var more = '';
        if (allEntries.length > 3) {
            more = '<div class="cal-more">+' + (allEntries.length - 3) + ' ещё</div>';
        }
        // PATCH v1.0.11: счётчик отметившихся сотрудников в углу ячейки
        var _empSet = {};
        allEntries.forEach(function(en) { if (en.employee_id) _empSet[en.employee_id] = true; });
        var _empCount = Object.keys(_empSet).length;
        var _empBadge = '';
        if (state.calViewMode === 'tasks' && _empCount > 1) {
            _empBadge = '<span class="cal-badge-emps" title="Отметились: ' + _empCount + ' сотр.">👥 ' + _empCount + '</span>';
        }
        var warn = '';
        if (day.missing && day.missing.length) {
            warn = '<span class="cal-badge-warn" title="Не заполнено: '
                + day.missing.map(function(m) { return escapeHtml(maskName(m.name)); }).join(', ')
                + '">!' + day.missing.length + '</span>';
        }
        var vacBadge = '';
        if (day.vacation && day.vacation.length) {
            vacBadge = '<span class="cal-badge-vac" title="Отсутствуют: '
                + day.vacation.map(function(vid) {
                    var e = state.employees.find(function(x) { return x.id === vid; });
                    return escapeHtml(maskName(e ? e.name : '?'));
                }).join(', ') + '">🏖</span>';
        }
        var remBadge = '';
        if (day.remote && day.remote.length) {
            remBadge = '<span class="cal-badge-remote" title="На удаленке: '
                + day.remote.map(function(vid) {
                    var e = state.employees.find(function(x) { return x.id === vid; });
                    return escapeHtml(maskName(e ? e.name : '?'));
                }).join(', ') + '">🏠</span>';
        }
        cell.innerHTML = warn + vacBadge + remBadge + _empBadge
            + '<div class="cal-day-head"><span class="cal-day-num">' + parseInt(day.date.split('-')[2], 10) + '</span>'
            + (day.total_hours > 0 ? '<span class="cal-day-hours">' + formatHours(day.total_hours) + '</span>' : '')
            + '</div><div class="cal-day-entries">' + entriesHtml + more + '</div>';
        cell.addEventListener('click', function() { openDayModal(day.date); });
        grid.appendChild(cell);
    });
}
function shiftMonth(delta) {
    if (!state.currentYM) state.currentYM = todayYM();
    var p = state.currentYM.split('-'); var y = parseInt(p[0], 10), m = parseInt(p[1], 10);
    m += delta;
    while (m < 1) { m += 12; y -= 1; }
    while (m > 12) { m -= 12; y += 1; }
    state.currentYM = y + '-' + String(m).padStart(2, '0');
    loadCalendar();
}
on('calPrevBtn', 'click', function() { shiftMonth(-1); });
on('calNextBtn', 'click', function() { shiftMonth(1); });
on('calTodayBtn', 'click', function() { state.currentYM = todayYM(); loadCalendar(); });
on('calEmployeeFilter', 'change', function() {
    state.currentEmployee = this.value;
    loadCalendar();
});
on('calDeptFilter', 'change', function() {
    state.currentDepartment = this.value;
    try { localStorage.setItem('tracker_calDept', this.value); } catch (e) {}
    if (state.currentEmployee) {
        var emp = state.employees.find(function(e) { return e.id === state.currentEmployee; });
        if (emp && this.value && emp.department_id !== this.value) state.currentEmployee = '';
    }
    fillEmployeeFilter();
    loadCalendar();
});
on('calTeamFilter', 'change', function() {
    state.currentTeam = this.value;
    if (state.currentEmployee) {
        var ids = _teamEmpIds(this.value);
        if (ids && !ids.has(state.currentEmployee)) state.currentEmployee = '';
    }
    fillEmployeeFilter();
    loadCalendar();
});

/* ============================================================
   ДНЕВНОЙ МОДАЛ — сгруппированный
   ============================================================ */
function _entryIsMine(en) {
    if (!en) return false;
    var me = state.currentUser || {};
    if (!me.employee_id) return false;
    return en.employee_id === me.employee_id;
}
function canEditEntry(en) {
    if (hasPerm('action.log.edit.any')) return true;
    if (hasPerm('action.log.edit.own') && _entryIsMine(en)) return true;
    return false;
}
function canDeleteEntry(en) {
    if (hasPerm('action.log.delete.any')) return true;
    if (hasPerm('action.log.delete.own') && _entryIsMine(en)) return true;
    return false;
}
function bindDayEntryActions(container, entries) {
    if (!container) return;
    entries = entries || [];
    container.querySelectorAll('[data-id]').forEach(function(item) {
        var id = parseInt(item.getAttribute('data-id'), 10);
        if (isNaN(id)) return;
        var entry = entries.find(function(x) { return x.id === id; });
        if (!entry) return;
        var eb = item.querySelector('[data-act="edit"]');
        var db = item.querySelector('[data-act="delete"]');
        if (eb) eb.addEventListener('click', function(e) {
            e.stopPropagation();
            openLogModal(entry);
        });
        if (db) db.addEventListener('click', function(e) {
            e.stopPropagation();
            if (!confirm('Удалить эту отметку?')) return;
            var _dayWasOpen = document.getElementById('dayModal') && document.getElementById('dayModal').classList.contains('active');
            apiJson('/api/tracker/log/delete', {
                method: 'POST', headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ id: id })
            }).then(function(d) {
                if (d && d.cancelled) return Promise.reject(new Error('cancelled'));
                notify('✅ Удалено');
                return trkRefreshAll();
            }).then(function() {
                if (_dayWasOpen && state.currentDay) openDayModal(state.currentDay);
            }).catch(function(err) { if (err && (err.message || '').indexOf('cancelled') !== -1) return; notify('❌ ' + (err.message || 'Ошибка'), 'error'); });
        });
    });
}
function openDayModal(dateStr) {
    state.currentDay = dateStr;
    var dd = $('dayModalDate'); if (dd) dd.textContent = formatDateHuman(dateStr);
    var day = null;
    if (state.calendar) day = state.calendar.days.find(function(d) { return d.date === dateStr; });
    renderDayList(day ? day.entries : [], day ? day.total_hours : 0, day);
    var m = $('dayModal'); if (m) m.classList.add('active');
    var acts = $('dayModalLeftActions'); if (acts) acts.style.display = '';
    var clr = $('dayClearBtn'); if (clr) clr.style.display = '';
}
function renderDayList(entries, totalHours, day) {
    var list = $('dayList'); if (!list) return;
    // PATCH 1.0.12: обычный пользователь видит в карточке дня только свои задачи
    try {
        var _meId = (state.currentUser && state.currentUser.employee_id) || '';
        var _showAllDay = hasPerm('block.calendar.other_employees') || hasPerm('action.log.edit.any');
        if (!_showAllDay && _meId && state.dayViewMode !== 'employee') {
            entries = (entries || []).filter(function(en) { return en.employee_id === _meId; });
            var _sum = 0;
            entries.forEach(function(en) { _sum += Number(en.hours) || 0; });
            totalHours = Math.round(_sum * 4) / 4;
        }
    } catch (e) { console.error('[renderDayList] filter', e); }
    var extra = '';
    if (day && day.missing && day.missing.length) extra += ' · не заполнено: ' + day.missing.length;
    var dt = $('dayModalTotal');
    if (dt) dt.textContent = formatHours(totalHours) + ' · ' + entries.length + ' записей' + extra;
    var mb = $('dayMissingBlock');
    if (mb) {
        if (day && day.missing && day.missing.length) {
            mb.style.display = 'block';
            var items = day.missing.map(function(m) {
                return '<span class="dm-item">'
                    + '<span class="dm-dot" style="background:' + escapeHtml(m.color) + '; box-shadow:0 0 6px ' + escapeHtml(m.color) + ';"></span>'
                    + escName(m.name)
                    + (m.department ? ' <span style="opacity:0.7;font-size:0.72rem;">(' + escapeHtml(m.department) + ')</span>' : '')
                    + '</span>';
            }).join('');
            mb.innerHTML = '<div class="dm-title">⚠ Не заполнили день (' + day.missing.length + '):</div>'
                + '<div class="dm-list">' + items + '</div>';
        } else {
            mb.style.display = 'none';
            mb.innerHTML = '';
        }
    }
    if (!entries.length) {
        list.innerHTML = '<div class="day-empty">Пока пусто.</div>';
        return;
    }
    var byTask = {};
    entries.forEach(function(en) {
        var tid = en.task_id;
        if (!byTask[tid]) {
            byTask[tid] = {
                task_id: tid, task_name: en.task_name, task_icon: en.task_icon,
                deadline: en.task_deadline, start_date: en.task_start_date,
                overdue: en.overdue, statuses: {}, people: [], total: 0,
            };
        }
        byTask[tid].people.push(en);
        byTask[tid].total += Number(en.hours) || 0;
        if (en.status) byTask[tid].statuses[en.status] = true;
    });
    var priority = { done: 4, in_progress: 3, blocked: 2, planned: 1 };
    var groups = Object.keys(byTask).map(function(k) { return byTask[k]; });
    groups.forEach(function(g) {
        g.dom = 'planned';
        var best = 0;
        Object.keys(g.statuses).forEach(function(s) {
            var p = priority[s] || 0;
            if (p > best) { best = p; g.dom = s; }
        });
        g.total = Math.round(g.total * 4) / 4;
    });
    groups.sort(function(a, b) { return b.total - a.total; });

    var html = '';
    groups.forEach(function(g) {
        var stLbl = state.statusLabels[g.dom] || g.dom;
        html += '<div class="day-task-group ' + (g.overdue ? 'overdue' : '') + ' ' + g.dom + '">'
            + '<div class="day-task-group-head">'
            +   '<span class="day-task-group-title' + (g.overdue ? ' overdue' : '') + '">'
            +     escapeHtml(g.task_icon || '📋') + ' ' + escapeHtml(g.task_name || '')
            +   '</span>'
            +   '<span class="day-task-group-total">' + formatHours(g.total) + '</span>'
            +   '<span class="day-entry-status ' + statusClass(g.dom) + '">' + escapeHtml(stLbl) + '</span>'
            + '</div>'
            + '<div class="day-entry-meta">'
            +   (g.start_date ? '<span class="mi">🚀 ' + escapeHtml(formatDateHuman(g.start_date)) + '</span>' : '')
            +   (g.deadline ? '<span class="mi' + (g.deadline < todayISO() && g.dom !== 'done' ? ' danger' : '') + '">⏰ ' + escapeHtml(formatDateHuman(g.deadline)) + '</span>' : '')
            + '</div>'
            + '<div class="day-task-group-people">';
        g.people.sort(function(a, b) { return (b.hours || 0) - (a.hours || 0); });
        g.people.forEach(function(en) {
            html += '<div class="day-task-person" data-id="' + en.id + '">'
                + '<div class="dp-avatar" style="background:' + escapeHtml(en.employee_color) + ';">'
                +   escapeHtml(initials(en.employee_name)) + '</div>'
                + '<span class="dp-name">' + escName(en.employee_name) + '</span>'
                + (en.comment ? '<span class="dp-comment">' + escapeHtml(en.comment) + '</span>' : '')
                + '<span class="dp-hours">' + formatHours(en.hours) + '</span>'
                + (canEditEntry(en)
                    ? '<button class="dict-action-btn" data-act="edit" title="Ред.">✏️</button>' : '')
                + (canDeleteEntry(en)
                    ? '<button class="dict-action-btn danger" data-act="delete" title="Удалить">🗑</button>' : '')
                + '</div>';
        });
        html += '</div></div>';
    });
    list.innerHTML = html;

    var allEntries = entries;
    var _dk = (day && day.date) || state.currentDay || '';
    allEntries.forEach(function(en) { if (!en.date) en.date = _dk; });
    bindDayEntryActions(list, allEntries);
}

/* ============================================================
   ДЕНЬ-КАРТОЧКА ОТМЕТКИ
   ============================================================ */
function dayEntryCard(en, compact) {
    var cls = 'day-entry';
    if (en.overdue) cls += ' overdue';
    if (en.status) cls += ' ' + en.status;
    var color = en.employee_color || '#888888';
    var statusLabel = en.status_label || (state.statusLabels[en.status] || '');
    var metaArr = [];
    if (en.task_start_date) metaArr.push('<span class="mi">🚀 ' + escapeHtml(formatDateHuman(en.task_start_date)) + '</span>');
    if (en.task_deadline) {
        var c = 'mi';
        if (en.task_deadline < todayISO() && en.status !== 'done') c += ' danger';
        metaArr.push('<span class="' + c + '">⏰ ' + escapeHtml(formatDateHuman(en.task_deadline)) + '</span>');
    }
    var comment = en.comment ? '<div class="day-entry-comment">' + escapeHtml(en.comment) + '</div>' : '';
    var link = en.link
        ? '<a class="day-entry-link" href="' + escapeHtml(en.link) + '" target="_blank" rel="noopener">🔗 ' + escapeHtml(en.link) + '</a>'
        : '';
    var compactCls = compact ? ' style="padding:8px 10px;"' : '';
    var canEdit = canEditEntry(en);
    var canDel = canDeleteEntry(en);
    return '<div class="' + cls + '" data-id="' + en.id + '"' + compactCls + '>'
        + '<div class="day-entry-avatar" style="background:' + escapeHtml(color) + '; box-shadow:0 0 10px ' + escapeHtml(color) + ';">'
        +     escapeHtml(initials(en.employee_name || '?')) + '</div>'
        + '<div class="day-entry-body">'
        +     '<div class="day-entry-head">'
        +         '<span class="day-entry-task' + (en.overdue ? ' overdue' : '') + '">'
        +             escapeHtml(en.task_icon || '📋') + ' ' + escapeHtml(en.task_name || '')
        +         '</span>'
        +         '<span class="day-entry-hours">' + formatHours(en.hours) + '</span>'
        +         (statusLabel ? '<span class="day-entry-status ' + statusClass(en.status) + '">' + escapeHtml(statusLabel) + '</span>' : '')
        +     '</div>'
        +     '<div class="day-entry-employee-row">'
        +         '<span class="emp-name">' + escName(en.employee_name || '') + '</span>'
        +         (en.employee_department ? '<span class="emp-dept">🏢 ' + escapeHtml(en.employee_department) + '</span>' : '')
        +     '</div>'
        +     (metaArr.length ? '<div class="day-entry-meta">' + metaArr.join('') + '</div>' : '')
        +     comment
        +     link
        + '</div>'
        + '<div class="day-entry-actions">'
        +     (canEdit ? '<button class="dict-action-btn" data-act="edit" title="Редактировать">✏️</button>' : '')
        +     (canDel ? '<button class="dict-action-btn danger" data-act="delete" title="Удалить">🗑</button>' : '')
        + '</div></div>';
}

on('dayAddBtn', 'click', function() { openLogModal(null); });
on('dayTodayBtn', 'click', function() {
    var dk = todayISO();
    state.currentDay = dk;
    var m = $('dayModal'); if (m) m.classList.remove('active');
    state.currentYM = todayYM();
    loadCalendar().then(function() { openDayModal(dk); });
});
function _doCopyPrevDay(empId) {
    if (!state.currentDay) return;
    var cur = new Date(state.currentDay + 'T00:00:00');
    var prev = new Date(cur.getTime() - 86400000);
    var srcISO = isoFromDate(prev);
    var who = empId;
    var empObj = state.employees.find(function(e) { return e.id === who; }) || {};
    var label = maskName(empObj.name || who);
    if (!confirm('Скопировать отметки за ' + formatDateHuman(srcISO) + ' в ' + formatDateHuman(state.currentDay) + ' для: ' + label + '?')) return;
    apiJson('/api/tracker/log/copy_day', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ source: srcISO, target: state.currentDay, employee: who })
    }).then(function(d) {
        if (!d.success) throw new Error(d.error || 'Ошибка');
        notify('✅ Скопировано: ' + d.copied);
        return loadCalendar();
    }).then(function() { openDayModal(state.currentDay); })
    .catch(function(err) { if (err && (err.message || '').indexOf('cancelled') !== -1) return; notify('❌ ' + (err.message || 'Ошибка'), 'error'); });
}
on('dayCopyPrevBtn', 'click', function() {
    if (!state.currentDay) return;
    var me = state.currentUser || {};
    var myEmp = (me.employee_id || '').trim();
    if (myEmp) { _doCopyPrevDay(myEmp); return; }
    if (me.role === 'admin') {
        var sel = $('copyDayEmpSelect');
        if (sel) {
            sel.innerHTML = '<option value="">— выберите сотрудника —</option>'
                + state.employees.map(function(e) {
                    return '<option value="' + escapeHtml(e.id) + '">' + escapeHtml(maskName(e.name)) + '</option>';
                }).join('');
        }
        var m = $('copyDayEmpModal'); if (m) m.classList.add('active');
        return;
    }
    notify('⚠ Ваша учётка не привязана к сотруднику. Обратитесь к администратору.', 'error');
});
on('copyDayEmpConfirm', 'click', function() {
    var sel = $('copyDayEmpSelect');
    var v = sel ? sel.value : '';
    if (!v) { notify('❌ Выберите сотрудника', 'error'); return; }
    var m = $('copyDayEmpModal'); if (m) m.classList.remove('active');
    _doCopyPrevDay(v);
});
on('dayClearBtn', 'click', function() {
    if (!state.currentDay) return;
    if (!confirm('Удалить ВСЕ отметки за ' + formatDateHuman(state.currentDay) + '?')) return;
    apiJson('/api/tracker/log/clear_day', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ date: state.currentDay, employee: state.currentEmployee || '' })
    }).then(function(d) {
        if (!d.success) throw new Error(d.error || 'Ошибка');
        notify('✅ Удалено: ' + d.deleted);
        return loadCalendar();
    }).then(function() { openDayModal(state.currentDay); })
    .catch(function(err) { if (err && (err.message || '').indexOf('cancelled') !== -1) return; notify('❌ ' + (err.message || 'Ошибка'), 'error'); });
});

/* ============================================================
   ОТМЕТКА
   ============================================================ */
function syncLogStatusFromTask() {
    var empSel = $('log_employee'), taskSel = $('log_task'), statusSel = $('log_status');
    if (!empSel || !taskSel || !statusSel) return;
    var empId = empSel.value, tid = taskSel.value;
    if (!empId || !tid) return;
    var last = null;
    (state.log || []).forEach(function(l) {
        if (l.employee_id !== empId || l.task_id !== tid) return;
        if (!last || (l.date || '') > (last.date || '')) last = l;
    });
    if (last && last.status) {
        statusSel.value = last.status;
        return;
    }
    var t = (state.tasks || []).find(function(x) { return x.id === tid; });
    if (t) {
        var map = {active: 'in_progress', done: 'done', paused: 'planned', archived: 'done'};
        statusSel.value = map[t.status] || 'in_progress';
    }
}

function openLogModal(entry) {
    entry = entry || null;
    if (!state.employees.length) { notify('❌ Сначала добавьте сотрудника', 'error'); return; }
    if (!state.tasks.length) { notify('❌ Сначала добавьте задачу', 'error'); return; }
    var t = $('logModalTitle'); if (t) t.textContent = entry ? 'Редактировать отметку' : 'Новая отметка';
    var g = function(id, v) { var el = $(id); if (el) el.value = v; };
    g('log_id', entry ? entry.id : '');
    var dk = state.currentDay || todayISO();
    g('log_date', entry ? (entry.date || dk) : dk);

    var myEmp = (state.currentUser && state.currentUser.employee_id) || '';
    var defaultEmp = '';
    if (entry) defaultEmp = entry.employee_id;
    else if (myEmp && state.employees.some(function(e) { return e.id === myEmp; })) defaultEmp = myEmp;
    else defaultEmp = (state.employees[0] || {}).id || '';
    g('log_employee', defaultEmp);
    var _tid = entry ? entry.task_id : ((state.tasks[0] || {}).id || '');
    g('log_task', _tid);
    var _tin = $('log_task_input');
    if (_tin) {
        var _tobj = _tid ? state.tasks.find(function(x) { return x.id === _tid; }) : null;
        _tin.value = _tobj ? (_tobj.name + (_tobj.status === 'done' || _tobj.status === 'archived' ? ' (архив)' : '')) : '';
    }
    var _w = $('log_task_warn'); if (_w) _w.style.display = 'none';
    g('log_hours', entry ? (window._formatHoursInput ? window._formatHoursInput(entry.hours) : entry.hours) : (window._formatHoursInput ? window._formatHoursInput(8) : 8));
    if (entry) {
        g('log_status', entry.status);
    } else {
        syncLogStatusFromTask();
    }
    g('log_comment', entry ? entry.comment : '');
    g('log_link', entry ? entry.link : '');

    _logExistingMode = 'me';
    _logExistingEmpId = defaultEmp;
    try { if (window.__trkRenderTagPills) window.__trkRenderTagPills(); } catch (e) {}
    _updateLogExistingTabsUI();

    updateDayHoursSummary();
    renderExistingDayEntries($('log_date') ? $('log_date').value : '', entry ? entry.id : null);
    var m = $('logModal'); if (m) m.classList.add('active');
    setTimeout(function() { var h = $('log_hours'); if (h) h.focus(); }, 50);
}
function updateDayHoursSummary() {
    var block = $('logDaySummary'); if (!block) return;
    var dt = $('log_date'); var emp = $('log_employee');
    var lid = $('log_id'); var hours = $('log_hours');
    if (!dt || !emp) return;
    var dk = dt.value, empId = emp.value;
    var curId = lid && lid.value ? parseInt(lid.value, 10) : null;
    if (!dk || !empId) { block.style.display = 'none'; return; }
    var total = 0, tasksList = [];
    if (state.calendar) {
        var day = state.calendar.days.find(function(d) { return d.date === dk; });
        if (day) {
            day.entries.forEach(function(en) {
                if (en.employee_id !== empId) return;
                if (curId && en.id === curId) return;
                total += en.hours;
                tasksList.push(en.task_icon + ' ' + en.task_name + ' (' + en.hours + 'ч)');
            });
        }
    }
    var planned = hours ? ((window._parseHoursInput ? window._parseHoursInput(hours.value) : parseFloat(hours.value)) || 0) : 0;
    var willBe = total + planned;
    var empObj = state.employees.find(function(e) { return e.id === empId; }) || {};
    var empName = maskName(empObj.name || '');
    block.style.display = 'flex';
    block.className = 'log-day-summary';
    var txt = 'За ' + formatDateHuman(dk) + ' у ' + empName + ': уже <b>' + total + ' ч</b>';
    if (planned > 0) txt += ' + ' + planned + ' ч';
    txt += ' = <b>' + willBe + ' ч</b>';
    if (tasksList.length) txt += '<div style="font-size:0.72rem;opacity:0.75;margin-top:3px;">' + tasksList.join(' · ') + '</div>';
    var _dayObj = (state.calendar && state.calendar.days) ? state.calendar.days.find(function(d){ return d.date === dk; }) : null;
    var _norm = (_dayObj && typeof _dayObj.day_norm === 'number') ? _dayObj.day_norm : 8;
    var _fmtN = window._formatHoursInput ? window._formatHoursInput(_norm) : _norm;
    if (willBe > 24) { block.classList.add('danger'); txt = '⚠ Превышение 24 ч! ' + txt; }
    else if (_norm === 0 && willBe > 0) { block.classList.add('warn'); txt = '⚠ Работа в выходной/праздник (' + willBe + 'ч). ' + txt; }
    else if (_norm > 0 && willBe > _norm + 0.01) { block.classList.add('warn'); txt = '⚠ Больше ' + _fmtN + ' ч. ' + txt; }
    else if (_norm > 0 && Math.abs(willBe - _norm) < 0.01) { block.classList.add('ok'); txt = '✓ Ровно ' + _fmtN + ' ч. ' + txt; }
    else { block.classList.add('warn'); }
    block.innerHTML = '<span class="lbl">' + txt + '</span>';
}
function renderExistingDayEntries(dateStr, excludeId) {
    var wrap = $('logDayExisting'), list = $('logDayExistingList');
    if (!wrap || !list) return;
    var tabs = $('logExistingTabs');

    var entries = [];
    if (state.calendar) {
        var day = state.calendar.days.find(function(d) { return d.date === dateStr; });
        if (day) entries = day.entries;
    }
    entries = entries.filter(function(en) { return en.id !== excludeId; });

    var visible = entries;
    if (_logExistingMode === 'me' && _logExistingEmpId) {
        visible = entries.filter(function(en) { return en.employee_id === _logExistingEmpId; });
    }

    if (!entries.length) { wrap.style.display = 'none'; return; }
    wrap.style.display = '';
    if (tabs) tabs.style.display = entries.length > 1 ? '' : 'none';
    _updateLogExistingTabsUI();

    if (!visible.length) {
        list.innerHTML = '<div class="day-empty">У выбранного сотрудника за этот день отметок нет.</div>';
        return;
    }
    var html = '';
    visible.forEach(function(en) {
        if (!en.date) en.date = dateStr;
        html += dayEntryCard(en, true);
    });
    list.innerHTML = html;
    bindDayEntryActions(list, visible);
}
function _updateLogExistingTabsUI() {
    var tabs = $('logExistingTabs');
    if (!tabs) return;
    tabs.querySelectorAll('.log-existing-tab').forEach(function(b) {
        b.classList.toggle('active', b.getAttribute('data-mode') === _logExistingMode);
    });
}
function saveLog() {
    var payload = {
        id: $('log_id') ? ($('log_id').value || null) : null,
        employee_id: $('log_employee') ? $('log_employee').value : '',
        task_id: $('log_task') ? $('log_task').value : '',
        date: $('log_date') ? $('log_date').value : '',
        hours: (window._parseHoursInput ? window._parseHoursInput($('log_hours') ? $('log_hours').value : '0') : (parseFloat($('log_hours') ? $('log_hours').value : 0) || 0)) || 0,
        status: $('log_status') ? $('log_status').value : 'in_progress',
        comment: $('log_comment') ? $('log_comment').value.trim() : '',
        link: $('log_link') ? $('log_link').value.trim() : '',
    };
    if (!payload.employee_id) { notify('❌ Выберите сотрудника', 'error'); return; }
    if (!payload.task_id) { notify('❌ Выберите задачу из списка или создайте новую', 'error'); return; }
    if (!payload.date) { notify('❌ Некорректная дата', 'error'); return; }
    var _dayWasOpen = document.getElementById('dayModal') && document.getElementById('dayModal').classList.contains('active');
    apiJson('/api/tracker/log/save', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload)
    }).then(function(d) {
        if (!d.success) throw new Error(d.error || 'Ошибка');
        notify('✅ Сохранено');
        var m = $('logModal'); if (m) m.classList.remove('active');
        return trkRefreshAll();
    }).then(function() { if (_dayWasOpen && state.currentDay) openDayModal(state.currentDay); })
    .catch(function(err) { if (err && (err.message || '').indexOf('cancelled') !== -1) return; notify('❌ ' + (err.message || 'Ошибка'), 'error'); });
}
on('log_date', 'change', function() {
    updateDayHoursSummary();
    renderExistingDayEntries(this.value, $('log_id') && $('log_id').value ? parseInt($('log_id').value, 10) : null);
});
on('log_employee', 'change', function() {
    _logExistingEmpId = this.value;
    updateDayHoursSummary();
    if (_logExistingMode === 'me') {
        renderExistingDayEntries(
            $('log_date') ? $('log_date').value : '',
            $('log_id') && $('log_id').value ? parseInt($('log_id').value, 10) : null
        );
    }
});
on('log_hours', 'input', updateDayHoursSummary);
on('log_task', 'change', syncLogStatusFromTask);
on('log_employee', 'change', syncLogStatusFromTask);
on('saveLogBtn', 'click', saveLog);
on('log_comment', 'keydown', function(e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); saveLog(); }
});
on('logExistingTabs', 'click', function(e) {
    var t = e.target.closest('.log-existing-tab');
    if (!t) return;
    _logExistingMode = t.getAttribute('data-mode');
    _updateLogExistingTabsUI();
    renderExistingDayEntries(
        $('log_date') ? $('log_date').value : '',
        $('log_id') && $('log_id').value ? parseInt($('log_id').value, 10) : null
    );
});

/* ============================================================
   ОТДЕЛЫ CRUD
   ============================================================ */
function openDepartmentModal(dep) {
    dep = dep || null;
    var t = $('departmentModalTitle'); if (t) t.textContent = dep ? 'Редактировать отдел' : 'Новый отдел';
    var g = function(id, v) { var el = $(id); if (el) el.value = v; };
    g('dep_id', dep ? dep.id : '');
    g('dep_name', dep ? dep.name : '');
    g('dep_color', (dep && dep.color) || '#00897b');
    var headSel = $('dep_head');
    if (headSel) {
        headSel.innerHTML = '<option value="">— не указан —</option>'
            + state.employees.filter(function(e) { return !e.fired; }).map(function(e) {
                return '<option value="' + escapeHtml(e.id) + '">' + escapeHtml(maskName(e.name))
                    + (e.department_id ? ' (' + escapeHtml(e.department || '') + ')' : '') + '</option>';
            }).join('');
        headSel.value = (dep && dep.head_employee_id) || '';
    }
    var m = $('departmentModal'); if (m) m.classList.add('active');
    setTimeout(function() { var n = $('dep_name'); if (n) n.focus(); }, 50);
}
function saveDepartment() {
    var name = $('dep_name') ? $('dep_name').value.trim() : '';
    if (!name) { notify('❌ Укажите название', 'error'); return; }
    var payload = {
        id: $('dep_id') ? ($('dep_id').value || '') : '',
        name: name,
        color: $('dep_color') ? $('dep_color').value : '#00897b',
        head_employee_id: $('dep_head') ? ($('dep_head').value || '') : '',
    };
    apiJson('/api/tracker/department/save', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload)
    }).then(function(d) {
        if (!d.success) throw new Error(d.error || 'Ошибка');
        notify('✅ Сохранено');
        var m = $('departmentModal'); if (m) m.classList.remove('active');
        return trkRefreshAll();
    }).catch(function(err) { if (err && (err.message || '').indexOf('cancelled') !== -1) return; notify('❌ ' + (err.message || 'Ошибка'), 'error'); });
}
function deleteDepartment(id) {
    var dep = (state.departments || []).find(function(x) { return x.id === id; });
    if (!dep) return;
    if (!confirm('Удалить отдел «' + dep.name + '»?')) return;
    apiJson('/api/tracker/department/delete', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ id: id })
    }).then(function(d) {
        if (!d.success) throw new Error(d.error || 'Ошибка');
        notify('✅ Удалено');
        return trkRefreshAll();
    }).catch(function(err) { if (err && (err.message || '').indexOf('cancelled') !== -1) return; notify('❌ ' + (err.message || 'Ошибка'), 'error'); });
}
on('saveDepartmentBtn', 'click', saveDepartment);
on('addDepartmentBtn', 'click', function() { openDepartmentModal(null); });

/* ============================================================
   СОТРУДНИКИ CRUD
   ============================================================ */
var _vacDraftEmpId = null;
var _vacEditId = null; // v1.1.6: id периода, редактируемого через форму (null = добавление)
function openEmployeeModal(emp) {
    emp = emp || null;
    _vacDraftEmpId = emp ? emp.id : null;
    // PATCH v1.2.0: заголовок карточки фиксированный — режим показываем подзаголовком
var t = $('employeeModalTitle'); if (t) t.textContent = 'Карточка сотрудника';
var ts = $('employeeModalSubtitle'); if (ts) ts.textContent = emp ? ('Изменение: ' + (emp.name || '')) : 'Новый сотрудник';
    var g = function(id, v) { var el = $(id); if (el) el.value = v; };
    g('emp_id', emp ? emp.id : '');
    g('emp_name', emp ? emp.name : '');
    var color = (emp && emp.color) || '#00897b';
    g('emp_color', color);
    g('emp_role', (emp && emp.role) || '');
    var deptSel = $('emp_department_select');
    if (deptSel) {
        deptSel.innerHTML = '<option value="">— не указан —</option>'
            + (state.departments || []).map(function(d) {
                return '<option value="' + escapeHtml(d.id) + '">' + escapeHtml(d.name) + '</option>';
            }).join('');
        deptSel.value = (emp && emp.department_id) || '';
    }
    var hiredDate = $('emp_hired_date');
    if (hiredDate) hiredDate.value = (emp && emp.hired_date) || '';
    var firedCb = $('emp_fired');
    var firedDate = $('emp_fired_date');
    if (firedCb) firedCb.checked = !!(emp && emp.fired);
    if (firedDate) {
        firedDate.value = (emp && emp.fired_date) || '';
        firedDate.disabled = !(firedCb && firedCb.checked);
    }
    var pal = $('empPalette');
    if (pal) pal.querySelectorAll('.palette-dot').forEach(function(d) {
        d.classList.toggle('active', d.getAttribute('data-color') === color);
    });
    var vs = $('vacSection'); if (vs) vs.style.display = emp ? '' : 'none';
    // PATCH v1.1.9: селект уровня доступа — только для нового сотрудника
    var epw = $('empPresetWrap'); if (epw) epw.style.display = emp ? 'none' : '';
    _vacEditId = null; // v1.1.6: сброс режима редактирования периода
    renderVacations(emp);
    g('vac_from', ''); g('vac_to', ''); g('vac_comment', '');
    var vt = $('vac_type'); if (vt) vt.value = 'vacation';
    var _vab = $('vacAddBtn'); if (_vab) _vab.textContent = '➕';
    var m = $('employeeModal'); if (m) m.classList.add('active');
    setTimeout(function() { var n = $('emp_name'); if (n) n.focus(); }, 50);
}
on('emp_fired', 'change', function() {
    var cb = $('emp_fired'), fd = $('emp_fired_date');
    if (!cb || !fd) return;
    fd.disabled = !cb.checked;
    if (!cb.checked) fd.value = '';
});
function renderVacations(emp) {
    var list = $('vacList'); if (!list) return;
    var vac = (emp && emp.vacations) || [];
    if (!vac.length) { list.innerHTML = '<div class="vac-empty">Пока нет периодов отсутствия</div>'; return; }
    var html = '';
    vac.forEach(function(v, i) {
        var vt = v.type || 'vacation';
        // PATCH v1.0.6: используем реальный id для удаления (не индекс)
        var _vid = (v.id != null) ? v.id : '';
        html += '<div class="vac-item type-' + vt + '"><div class="vac-item-body">'
            + '<div class="vac-item-dates">' + absenceIcon(vt) + ' ' + escapeHtml(absenceLabel(vt)) + ': '
            + escapeHtml(formatDateHuman(v.from || '')) + ' — ' + escapeHtml(formatDateHuman(v.to || '')) + '</div>'
            + (v.comment ? '<div class="vac-item-comment">' + escapeHtml(v.comment) + '</div>' : '')
            + '</div>'
            + '<button class="dict-action-btn" data-vact="edit" data-vac-id="' + _vid + '" data-idx="' + i + '" type="button" title="Изменить период">✏️</button>'
            + '<button class="dict-action-btn danger" data-vact="del" data-vac-id="' + _vid + '" data-idx="' + i + '" type="button">🗑</button></div>';
    });
    list.innerHTML = html;
    list.querySelectorAll('.dict-action-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var idx = parseInt(this.getAttribute('data-idx'), 10);
            var vid = this.getAttribute('data-vac-id');
            if (!_vacDraftEmpId) return;
            // v1.1.6: кнопка ✏️ — подставить период в форму для редактирования
            if (this.getAttribute('data-vact') === 'edit') {
                var v = vac[idx];
                if (!v) return;
                var g2 = function(id, val) { var el = $(id); if (el) el.value = val || ''; };
                g2('vac_from', v.from); g2('vac_to', v.to); g2('vac_comment', v.comment);
                var vtEl = $('vac_type'); if (vtEl) vtEl.value = v.type || 'vacation';
                _vacEditId = (v.id != null) ? v.id : null;
                var ab = $('vacAddBtn'); if (ab) ab.textContent = '💾';
                return;
            }
            // PATCH v1.0.6: отправляем id, если он есть; иначе fallback на index
            var _payload = { employee_id: _vacDraftEmpId };
            var _vidInt = parseInt(vid, 10);
            if (!isNaN(_vidInt)) {
                _payload.id = _vidInt;
            } else {
                _payload.index = idx;
            }
            if (!isNaN(_vidInt) && _vacEditId === _vidInt) _vacEditId = null;
            apiJson('/api/tracker/employee/vacation/delete', {
                method: 'POST', headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(_payload)
            }).then(function(d) {
                if (!d.success) throw new Error(d.error || 'Ошибка');
                return loadState();
            }).then(function() {
                var emp2 = state.employees.find(function(x) { return x.id === _vacDraftEmpId; });
                renderVacations(emp2);
            }).catch(function(err) { if (err && (err.message || '').indexOf('cancelled') !== -1) return; notify('❌ ' + (err.message || 'Ошибка'), 'error'); });
        });
    });
}
on('vacAddBtn', 'click', function() {
    if (!_vacDraftEmpId) return;
    var from = $('vac_from') ? $('vac_from').value : '';
    var to = $('vac_to') ? $('vac_to').value : '';
    var comment = $('vac_comment') ? $('vac_comment').value.trim() : '';
    var vtype = $('vac_type') ? ($('vac_type').value || 'vacation') : 'vacation';
    if (!from || !to) { notify('❌ Укажите даты', 'error'); return; }
    // v1.1.6: если выбран период для правки — отправляем update по id
    var _edit = (_vacEditId != null);
    var _url = _edit ? '/api/tracker/employee/vacation/update' : '/api/tracker/employee/vacation/add';
    var _body = { employee_id: _vacDraftEmpId, from: from, to: to, type: vtype, comment: comment };
    if (_edit) _body.id = _vacEditId;
    apiJson(_url, {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(_body)
    }).then(function(d) {
        if (!d.success) throw new Error(d.error || 'Ошибка');
        var g = function(id) { var el = $(id); if (el) el.value = ''; };
        g('vac_from'); g('vac_to'); g('vac_comment');
        var vtEl = $('vac_type'); if (vtEl) vtEl.value = 'vacation';
        _vacEditId = null;
        var ab = $('vacAddBtn'); if (ab) ab.textContent = '➕';
        return loadState();
    }).then(function() {
        var emp2 = state.employees.find(function(x) { return x.id === _vacDraftEmpId; });
        renderVacations(emp2);
    }).catch(function(err) { if (err && (err.message || '').indexOf('cancelled') !== -1) return; notify('❌ ' + (err.message || 'Ошибка'), 'error'); });
});
function saveEmployee() {
    var name = $('emp_name') ? $('emp_name').value.trim() : '';
    if (!name) { notify('❌ Укажите имя', 'error'); return; }
    var deptSel = $('emp_department_select');
    var fired = $('emp_fired') ? $('emp_fired').checked : false;
    var firedDate = $('emp_fired_date') ? $('emp_fired_date').value : '';
    if (fired && !firedDate) { notify('❌ Укажите дату увольнения', 'error'); return; }
    var payload = {
        id: $('emp_id') ? ($('emp_id').value || '') : '',
        name: name,
        color: $('emp_color') ? $('emp_color').value : '#00897b',
        role: $('emp_role') ? $('emp_role').value.trim() : '',
        department_id: deptSel ? (deptSel.value || '') : '',
        fired: fired,
        fired_date: fired ? firedDate : '',
        hired_date: $('emp_hired_date') ? ($('emp_hired_date').value || '') : '',
        // PATCH v1.1.9: уровень доступа автосоздаваемой учётки (для нового сотрудника)
        perm_preset: (!$('emp_id') || !$('emp_id').value) ? (($('emp_perm_preset') && $('emp_perm_preset').value) || 'user') : 'user',
    };
    apiJson('/api/tracker/employee/save', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload)
    }).then(function(d) {
        if (!d.success) throw new Error(d.error || 'Ошибка');
        // PATCH v1.2.0: после сохранения перечитываем справочник должностей,
        // чтобы новый вариант сразу появился в выпадающем списке.
        try { if (window.__trkRolesV120 && window.__trkRolesV120.reload) window.__trkRolesV120.reload(); } catch (x) {}
        var m = $('employeeModal'); if (m) m.classList.remove('active');
        return trkRefreshAll();
    }).catch(function(err) { if (err && (err.message || '').indexOf('cancelled') !== -1) return; notify('❌ ' + (err.message || 'Ошибка'), 'error'); });
}
function deleteEmployee(id) {
    var emp = state.employees.find(function(x) { return x.id === id; });
    if (!emp) return;
    if (!confirm('Удалить сотрудника «' + emp.name + '»?')) return;
    apiJson('/api/tracker/employee/delete', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ id: id })
    }).then(function(d) {
        if (!d.success) throw new Error(d.error || 'Ошибка');
        // PATCH v1.3.2: черновик дерева чистим после успешного сохранения
        window.__trkHypDraft = [];
        return trkRefreshAll();
    }).catch(function(err) { if (err && (err.message || '').indexOf('cancelled') !== -1) return; notify('❌ ' + (err.message || 'Ошибка'), 'error'); });
}
on('saveEmployeeBtn', 'click', saveEmployee);
on('addEmployeeBtn', 'click', function() { openEmployeeModal(null); });

/* ============================================================
   КОМАНДЫ CRUD
   ============================================================ */
function openTeamModal(tm) {
    tm = tm || null;
    var t = $('teamModalTitle'); if (t) t.textContent = tm ? 'Редактировать команду' : 'Новая команда';
    var g = function(id, v) { var el = $(id); if (el) el.value = v; };
    g('team_id', tm ? tm.id : '');
    g('team_name', tm ? tm.name : '');
    var deptSel = $('team_department');
    if (deptSel) {
        deptSel.innerHTML = '<option value="">— выберите отдел —</option>'
            + (state.departments || []).map(function(d) {
                return '<option value="' + escapeHtml(d.id) + '">' + escapeHtml(d.name) + '</option>';
            }).join('');
        deptSel.value = (tm && tm.department_id) || '';
    }
    _renderTeamManagers((tm && tm.department_id) || '', (tm && tm.manager_id) || '');
    _renderTeamMembers((tm && tm.department_id) || '', (tm && tm.member_ids) || []);
    var m = $('teamModal'); if (m) m.classList.add('active');
    setTimeout(function() { var n = $('team_name'); if (n) n.focus(); }, 50);
}
function _renderTeamManagers(deptId, selected) {
    var sel = $('team_manager'); if (!sel) return;
    var emps = state.employees;
    if (deptId) emps = emps.filter(function(e) { return e.department_id === deptId; });
    sel.innerHTML = '<option value="">— не указан —</option>'
        + emps.map(function(e) {
            return '<option value="' + escapeHtml(e.id) + '">' + escapeHtml(maskName(e.name)) + (e.fired ? ' 🚪' : '') + '</option>';
        }).join('');
    sel.value = selected || '';
}
function _renderTeamMembers(deptId, selectedIds) {
    var list = $('teamMembersList'); if (!list) return;
    var hint = $('teamMembersHint');
    selectedIds = selectedIds || [];
    var emps = state.employees;
    if (deptId) emps = emps.filter(function(e) { return e.department_id === deptId; });
    if (!emps.length) {
        list.innerHTML = '<div class="dict-empty" style="padding:10px;">' + (deptId ? 'В отделе нет сотрудников' : 'Выберите отдел') + '</div>';
        if (hint) hint.textContent = '';
        return;
    }
    if (hint) hint.textContent = 'Отметьте сотрудников команды';

    var headSet = {};
    (state.departments || []).forEach(function(d) {
        if (d.head_employee_id) headSet[d.head_employee_id] = true;
    });

    var heads = [], others = [];
    emps.forEach(function(e) {
        if (headSet[e.id]) heads.push(e);
        else others.push(e);
    });

    function _itm(e, badge) {
        var checked = selectedIds.indexOf(e.id) !== -1 ? ' checked' : '';
        return '<label class="assignees-item">'
            + '<input type="checkbox" value="' + escapeHtml(e.id) + '"' + checked + '>'
            + '<span class="assignees-dot" style="background:' + escapeHtml(e.color || '#888') + ';"></span>'
            + '<span class="assignees-name">' + escName(e.name) + (e.fired ? ' 🚪' : '') + '</span>'
            + (badge ? '<span class="assignees-badge">' + badge + '</span>' : '')
            + '</label>';
    }
    function _grp(icon, title, arr, badge, cls) {
        if (!arr.length) return '';
        return '<div class="assignees-group ' + cls + '">'
            + '<div class="assignees-group-title">'
            +   '<span class="assignees-group-icon">' + icon + '</span>'
            +   '<span class="assignees-group-name">' + title + '</span>'
            +   '<span class="assignees-group-count">' + arr.length + '</span>'
            + '</div>'
            + arr.map(function(e) { return _itm(e, badge); }).join('')
            + '</div>';
    }

    list.innerHTML =
        _grp('👑', 'Руководители отделов', heads, 'Нач. отдела', 'asg-heads') +
        _grp('👤', 'Сотрудники', others, '', 'asg-others');
}
on('team_department', 'change', function() {
    _renderTeamManagers(this.value, '');
    _renderTeamMembers(this.value, []);
});
function saveTeam() {
    var name = $('team_name') ? $('team_name').value.trim() : '';
    if (!name) { notify('❌ Укажите название', 'error'); return; }
    var deptId = $('team_department') ? $('team_department').value : '';
    if (!deptId) { notify('❌ Выберите отдел', 'error'); return; }
    var managerId = $('team_manager') ? $('team_manager').value : '';
    var members = [];
    var ml = $('teamMembersList');
    if (ml) ml.querySelectorAll('input[type="checkbox"]:checked').forEach(function(cb) {
        members.push(cb.value);
    });
    if (managerId && members.indexOf(managerId) === -1) members.push(managerId);
    var payload = {
        id: $('team_id') ? ($('team_id').value || '') : '',
        name: name,
        department_id: deptId,
        manager_id: managerId,
        member_ids: members,
    };
    apiJson('/api/tracker/team/save', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload)
    }).then(function(d) {
        if (!d.success) throw new Error(d.error || 'Ошибка');
        var m = $('teamModal'); if (m) m.classList.remove('active');
        notify('✅ Сохранено');
        return trkRefreshAll();
    }).catch(function(err) { if (err && (err.message || '').indexOf('cancelled') !== -1) return; notify('❌ ' + (err.message || 'Ошибка'), 'error'); });
}
function deleteTeam(id) {
    var tm = state.teams.find(function(x) { return x.id === id; });
    if (!tm) return;
    if (!confirm('Удалить команду «' + tm.name + '»?')) return;
    apiJson('/api/tracker/team/delete', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ id: id })
    }).then(function(d) {
        if (!d.success) throw new Error(d.error || 'Ошибка');
        return trkRefreshAll();
    }).catch(function(err) { if (err && (err.message || '').indexOf('cancelled') !== -1) return; notify('❌ ' + (err.message || 'Ошибка'), 'error'); });
}
on('saveTeamBtn', 'click', saveTeam);
on('addTeamBtn', 'click', function() { openTeamModal(null); });

/* ============================================================
   ЗАДАЧИ CRUD + ТЕГИ
   ============================================================ */
function renderTaskDepartmentsList(selectedIds) {
    var list = $('taskDepartmentsList'); if (!list) return;
    selectedIds = selectedIds || [];
    var deps = state.departments || [];
    if (!deps.length) {
        list.innerHTML = '<div class="dict-empty" style="padding:10px;">Нет отделов</div>';
        return;
    }
    list.innerHTML = deps.map(function(d) {
        var checked = selectedIds.indexOf(d.id) !== -1 ? ' checked' : '';
        return '<label class="dept-multi-item"><input type="checkbox" value="' + escapeHtml(d.id) + '"' + checked + '>'
            + '<span class="dept-multi-dot" style="background:' + escapeHtml(d.color || '#7a9ab5') + ';"></span>'
            + '<span>' + escapeHtml(d.name) + '</span></label>';
    }).join('');
    list.querySelectorAll('input[type="checkbox"]').forEach(function(cb) {
        cb.addEventListener('change', function() {
            renderAssigneesList(getSelectedAssignees(), getSelectedTaskDepartments());
        });
    });
}
function getSelectedTaskDepartments() {
    var list = $('taskDepartmentsList'); if (!list) return [];
    var out = [];
    list.querySelectorAll('input[type="checkbox"]:checked').forEach(function(cb) { out.push(cb.value); });
    return out;
}
function renderAssigneesList(selectedIds, deptIds) {
    var list = $('taskAssigneesList'); if (!list) return;
    var hint = $('taskAssigneesHint');
    if (!state.employees.length) {
        list.innerHTML = '<div class="dict-empty" style="padding:10px;">Сначала добавьте сотрудников</div>';
        if (hint) hint.textContent = '';
        return;
    }
    selectedIds = selectedIds || [];
    deptIds = deptIds || [];
    var emps = state.employees;
    if (deptIds.length) {
        emps = emps.filter(function(e) { return deptIds.indexOf(e.department_id) !== -1; });
        if (hint) hint.textContent = 'Показаны сотрудники из выбранных отделов (' + deptIds.length + ')';
    } else {
        if (hint) hint.textContent = 'Отметьте отделы выше, чтобы сузить список';
    }
    if (!emps.length) {
        list.innerHTML = '<div class="dict-empty" style="padding:10px;">В выбранных отделах нет сотрудников</div>';
        return;
    }

    var headSet = {};
    (state.departments || []).forEach(function(d) {
        if (d.head_employee_id) headSet[d.head_employee_id] = true;
    });
    var mgrSet = {};
    (state.teams || []).forEach(function(t) {
        if (t.manager_id && !headSet[t.manager_id]) mgrSet[t.manager_id] = true;
    });

    var heads = [], managers = [], others = [];
    emps.forEach(function(e) {
        if (headSet[e.id]) heads.push(e);
        else if (mgrSet[e.id]) managers.push(e);
        else others.push(e);
    });

    function _deptName(e) {
        var d = (state.departments || []).find(function(x) { return x.id === e.department_id; });
        return d ? d.name : '';
    }
    function _item(e, badge) {
        var checked = selectedIds.indexOf(e.id) !== -1 ? ' checked' : '';
        var dn = _deptName(e);
        return '<label class="assignees-item">'
            + '<input type="checkbox" value="' + escapeHtml(e.id) + '"' + checked + '>'
            + '<span class="assignees-dot" style="background:' + escapeHtml(e.color || '#888') + ';"></span>'
            + '<span class="assignees-name">' + escName(e.name) + (e.fired ? ' 🚪' : '') + '</span>'
            + (badge ? '<span class="assignees-badge">' + badge + '</span>' : '')
            + (dn && !deptIds.length ? '<span class="assignees-dept">' + escapeHtml(dn) + '</span>' : '')
            + '</label>';
    }
    function _group(icon, title, arr, badge, cls) {
        if (!arr.length) return '';
        return '<div class="assignees-group ' + cls + '">'
            + '<div class="assignees-group-title">'
            +   '<span class="assignees-group-icon">' + icon + '</span>'
            +   '<span class="assignees-group-name">' + title + '</span>'
            +   '<span class="assignees-group-count">' + arr.length + '</span>'
            + '</div>'
            + arr.map(function(e) { return _item(e, badge); }).join('')
            + '</div>';
    }

    list.innerHTML =
        _group('👑', 'Руководители отделов', heads, 'Нач. отдела', 'asg-heads') +
        _group('⭐', 'Руководители команд', managers, 'Менеджер', 'asg-managers') +
        _group('👤', 'Сотрудники', others, '', 'asg-others');
}
function getSelectedAssignees() {
    var list = $('taskAssigneesList'); if (!list) return [];
    var out = [];
    list.querySelectorAll('input[type="checkbox"]:checked').forEach(function(cb) { out.push(cb.value); });
    return out;
}
function renderTagPills() {
    var box = $('taskTagsBox'); if (!box) return;
    var input = $('task_tags_input');
    box.querySelectorAll('.tag-pill').forEach(function(p) { p.remove(); });
    _tagDraft.forEach(function(tag, i) {
        var pill = document.createElement('span');
        pill.className = 'tag-pill';
        pill.innerHTML = '#' + escapeHtml(tag) + '<button type="button" class="tag-x" data-i="' + i + '">×</button>';
        box.insertBefore(pill, input);
    });
    box.querySelectorAll('.tag-x').forEach(function(b) {
        b.addEventListener('click', function() {
            var idx = parseInt(this.getAttribute('data-i'), 10);
            _tagDraft.splice(idx, 1);
            renderTagPills();
        });
    });
    if (input) {
        box.onclick = function(e) { if (e.target === box) input.focus(); };
    }
}
function addTag(tag) {
    tag = String(tag || '').trim().replace(/^#+/, '').replace(/\s+/g, '_').toLowerCase();
    if (!tag) return;
    if (tag.length > 32) tag = tag.slice(0, 32);
    if (_tagDraft.indexOf(tag) !== -1) return;
    if (_tagDraft.length >= 15) return;
    _tagDraft.push(tag);
    renderTagPills();
}
on('task_tags_input', 'keydown', function(e) {
    if (e.key === 'Enter' || e.key === ',') {
        e.preventDefault();
        addTag(this.value);
        this.value = '';
    } else if (e.key === 'Backspace' && !this.value && _tagDraft.length) {
        _tagDraft.pop();
        renderTagPills();
    }
});
on('tagPresets', 'click', function(e) {
    var b = e.target.closest('.tag-preset-btn');
    if (!b) return;
    addTag(b.getAttribute('data-tag'));
});
function syncTaskCompletedAt() {
    var st = $('task_status'); if (!st) return;
    var field = $('task_completed_at');
    var hint = $('taskCompletionHint');
    if (!field) return;
    var enabled = (st.value === 'done' || st.value === 'archived');
    field.disabled = !enabled;
    // PATCH v1.0.14: при переходе в done/archived, если поле пустое,
    // подставляем сегодня. Админ может очистить — тогда задача
    // закроется без даты (бэкенд значение не перезапишет).
    if (enabled && !field.value) {
        var _d = new Date();
        var _y = _d.getFullYear();
        var _m = String(_d.getMonth() + 1).padStart(2, '0');
        var _dd = String(_d.getDate()).padStart(2, '0');
        field.value = _y + '-' + _m + '-' + _dd;
    }
    if (hint) {
        hint.textContent = enabled
            ? 'Дата админ-закрытия. Оставьте пустой, чтобы закрыть задачу без даты. Снимает просрочку со всех исполнителей.'
            : 'Доступно при статусе «Выполнена» / «Архив».';
    }
    if (!enabled) field.value = '';
}
function openTaskModal(task) {
    task = task || null;
    var t = $('taskModalTitle'); if (t) t.textContent = task ? 'Редактировать задачу' : 'Новая задача';
    // PATCH 1.0.14: если #task_id потерян (_restructure старой сессией),
    // пересоздаём его, чтобы saveTask мог корректно прочитать id.
    if (!$('task_id')) {
        var _tm = $('taskModal');
        var _content = _tm ? _tm.querySelector('.modal-content') : null;
        if (_content) {
            var _tid = document.createElement('input');
            _tid.type = 'hidden';
            _tid.id = 'task_id';
            _content.appendChild(_tid);
        }
    }
    var g = function(id, v) { var el = $(id); if (el) el.value = v; };
    g('task_id', task ? task.id : '');
    var iconVal = (task && task.icon) || '🚀';
    g('task_icon', iconVal);
    var prev = $('taskIconPreview'); if (prev) prev.textContent = iconVal;
    g('task_name', task ? task.name : '');
    g('task_description', (task && task.description) || '');
    g('task_status', (task && task.status) || 'active');
    g('task_start_date', (task && task.start_date) || '');
    g('task_deadline', (task && task.deadline) || '');
    g('task_completed_at', (task && task.completed_at) || '');
    g('task_folder', (task && task.folder) || '');
    g('task_order_ref', (task && task.order_ref) || '');
    // PATCH v1.0.18: чекбокс «очень срочная»
    var _urgCb = $('task_is_urgent');
    if (_urgCb) _urgCb.checked = !!(task && task.is_urgent);
    // PATCH v1.0.19: список ссылок
    _taskLinksDraft = (task && Array.isArray(task.links)) ? task.links.slice() : [];
    renderTaskLinksDraft();
    // PATCH v1.0.32: список приказов
    _taskOrdersDraft = (task && Array.isArray(task.orders)) ? task.orders.slice() : [];
    renderTaskOrdersDraft();

    _tagDraft = (task && task.tags) ? task.tags.slice() : [];
    var ti = $('task_tags_input'); if (ti) ti.value = '';
    renderTagPills();

    var depIds = (task && task.department_ids) ? task.department_ids.slice() : [];
    renderTaskDepartmentsList(depIds);
    renderAssigneesList((task && task.assignees) || [], depIds);
    syncTaskCompletedAt();
    // PATCH v1.4.3: загрузка дерева с защитой от race condition + fallback-fetch сотрудников
    var _freshTask = task;
    try {
        if (task && task.id && window.__trkState && Array.isArray(window.__trkState.tasks)) {
            _freshTask = window.__trkState.tasks.find(function(x){ return x && x.id === task.id; }) || task;
        }
    } catch(e){ _freshTask = task; }
    var _hd = (_freshTask && Array.isArray(_freshTask.hypotheses)) ? JSON.parse(JSON.stringify(_freshTask.hypotheses)) : [];
    var _hm = _hd.filter(function(x){ return x && x.kind === 'hypothesis'; });
    var _nm = [];
    for (var _hi = 0; _hi < _hm.length; _hi++) {
        _nm.push(_hm[_hi]);
        _hd.forEach(function(x){ if (x && x.kind === 'task' && x.parent === _hm[_hi].id) _nm.push(x); });
    }
    _hd.forEach(function(x){ if (x && _nm.indexOf(x) === -1) _nm.push(x); });
    window.__trkHypDraft = _nm;
    var _renderTreeAfter = function(){
        var _hb2 = document.getElementById('hypCountBadge');
        if (_hb2) _hb2.textContent = _hm.length + ' гип., ' + _nm.filter(function(x){return x && x.kind === 'task';}).length + ' зад.';
        if (typeof window.__renderHypTree === 'function') window.__renderHypTree();
        else if (typeof renderHypTree === 'function') renderHypTree();
    };
    var _stV = window.__trkState || {};
    if (_stV.employees && _stV.employees.length) {
        _renderTreeAfter();
    } else {
        var _rootV = document.getElementById('hypTreeRoot');
        if (_rootV) _rootV.innerHTML = '<div class="hyp-empty">Загрузка сотрудников…</div>';
        fetch('/api/tracker/state', {credentials: 'same-origin', cache: 'no-store'})
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (d && d.success && window.__trkState) {
                    if (d.employees) window.__trkState.employees = d.employees;
                    if (d.tasks) window.__trkState.tasks = d.tasks;
                    if (d.departments) window.__trkState.departments = d.departments;
                    if (d.teams) window.__trkState.teams = d.teams;
                }
                _renderTreeAfter();
            })
            .catch(function(){ _renderTreeAfter(); });
    }
    var m = $('taskModal'); if (m) m.classList.add('active');
    setTimeout(function() { var n = $('task_name'); if (n) n.focus(); }, 50);
}
function saveTask() {
    var name = $('task_name') ? $('task_name').value.trim() : '';
    if (!name) { notify('❌ Укажите название', 'error'); return; }
    var status = $('task_status') ? $('task_status').value : 'active';
    var completed = $('task_completed_at') ? $('task_completed_at').value.trim() : '';
    var payload = {
        id: $('task_id') ? ($('task_id').value || '') : '',
        name: name,
        icon: $('task_icon') ? ($('task_icon').value.trim() || '🚀') : '🚀',
        description: $('task_description') ? $('task_description').value.trim() : '',
        status: status,
        start_date: $('task_start_date') ? $('task_start_date').value.trim() : '',
        deadline: $('task_deadline') ? $('task_deadline').value.trim() : '',
        completed_at: (status === 'done' || status === 'archived') ? completed : '',
        folder: $('task_folder') ? $('task_folder').value.trim() : '',
        order_ref: $('task_order_ref') ? $('task_order_ref').value.trim() : '',
        tags: (_tagDraft || []).slice(),
        assignees: getSelectedAssignees(),
        department_ids: getSelectedTaskDepartments(),
        is_urgent: $('task_is_urgent') ? !!$('task_is_urgent').checked : false,
        links: (_taskLinksDraft || []).slice(),
        orders: (_taskOrdersDraft || []).slice(),
        // PATCH v1.4.3: плоский черновик → дерево {hypothesis, tasks:[]}
        hypotheses: (function(){
            var _flat = (window.__trkHypDraft || []).slice();
            var _hyps = _flat.filter(function(x){ return x && x.kind === 'hypothesis'; });
            return _hyps.map(function(h){
                var item = Object.assign({}, h);
                item.tasks = _flat.filter(function(x){
                    return x && x.kind === 'task' && x.parent === h.id;
                });
                return item;
            });
        })(),
    };
    // PATCH v1.0.15: закрываем карточку СРАЗУ — пользователь видит
    // лоадер («Загрузка…»), а не пустую модалку. При ошибке вернём.
    var _taskModal = $('taskModal');
    var _wasActive = !!(_taskModal && _taskModal.classList.contains('active'));
    if (_wasActive) _taskModal.classList.remove('active');
    apiJson('/api/tracker/task/save', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload)
    }).then(function(d) {
        if (!d.success) throw new Error(d.error || 'Ошибка');
        return trkRefreshAll();
    }).catch(function(err) {
        var _msg = (err && err.message) || '';
        // На ошибке или отмене дубликата возвращаем модалку,
        // чтобы пользователь не потерял введённые данные.
        if (_wasActive && _taskModal) _taskModal.classList.add('active');
        if (_msg.indexOf('cancelled') !== -1) return;
        notify('❌ ' + (_msg || 'Ошибка'), 'error');
    });
}
function deleteTask(id) {
    var task = state.tasks.find(function(x) { return x.id === id; });
    if (!task) return;
    if (!confirm('Удалить задачу «' + task.name + '»?')) return;
    apiJson('/api/tracker/task/delete', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ id: id })
    }).then(function(d) {
        if (!d.success) throw new Error(d.error || 'Ошибка');
        return trkRefreshAll();
    }).catch(function(err) { if (err && (err.message || '').indexOf('cancelled') !== -1) return; notify('❌ ' + (err.message || 'Ошибка'), 'error'); });
}
on('saveTaskBtn', 'click', saveTask);
on('addTaskBtn', 'click', function() { openTaskModal(null); });
on('addTaskBtn2', 'click', function() { openTaskModal(null); });
on('taskIconPickBtn', 'click', function() {
    var m = $('emojiModal'); if (m) m.classList.add('active');
});
on('task_status', 'change', syncTaskCompletedAt);

/* ============================================================
   СВОД
   ============================================================ */
function updateSumRowToggle() {
    var el = $('sumTaskRowMode');
    if (!el) return;
    el.style.display = state.summaryIsGrid ? '' : 'none';
}

function loadSummary() {
    var from = $('sumDateFrom') ? $('sumDateFrom').value : '';
    var to = $('sumDateTo') ? $('sumDateTo').value : '';
    if (!from) { from = firstOfMonthISO(todayYM()); if ($('sumDateFrom')) $('sumDateFrom').value = from; }
    if (!to) { to = todayISO(); if ($('sumDateTo')) $('sumDateTo').value = to; }
    var emp = $('sumEmployeeFilter') ? ($('sumEmployeeFilter').value || '') : '';
    var task = $('sumTaskFilter') ? ($('sumTaskFilter').value || '') : '';
    var dept = $('sumDeptFilter') ? ($('sumDeptFilter').value || '') : '';
    var team = $('sumTeamFilter') ? ($('sumTeamFilter').value || '') : '';
    var tagArr = (window.__trkSelectedTags && window.__trkSelectedTags.sumTagFilter) || [];
    var tag = tagArr.join(',');
    var sumTagMode = (window.__trkTagMode && window.__trkTagMode.sumTagFilter) || 'any';
    var view = state.sumViewMode || 'grid';
    var wrap = $('sumWrap');
    if (wrap) wrap.innerHTML = '<div class="sum-empty">Загрузка...</div>';
    var qs = '?from=' + encodeURIComponent(from) + '&to=' + encodeURIComponent(to)
        + '&employee=' + encodeURIComponent(emp) + '&task=' + encodeURIComponent(task)
        + '&department=' + encodeURIComponent(dept) + '&team=' + encodeURIComponent(team)
        + '&tag=' + encodeURIComponent(tag) + '&tag_mode=' + encodeURIComponent(sumTagMode);
    var url = (view === 'grid')
        ? ('/api/tracker/summary_grid' + qs)
        : ('/api/tracker/summary' + qs + '&view=' + encodeURIComponent(view));
    apiJson(url).then(function(d) {
        state.summary = d;
        state.summaryIsGrid = (view === 'grid');
        if (view === 'grid') renderSummaryGrid();
        else renderSummary();
        updateSumRowToggle();
    }).catch(function(err) {
        if (wrap) wrap.innerHTML = '<div class="sum-empty" style="color:#e74c3c;">❌ ' + escapeHtml(err.message || 'Ошибка') + '</div>';
    });
}
function _summaryLegendHtml() {
    return '<div class="grid-legend">'
        + '<span class="grid-legend-item"><span class="grid-legend-swatch" style="background:rgba(46,204,113,0.24);"></span>✅ Готово</span>'
        + '<span class="grid-legend-item"><span class="grid-legend-swatch" style="background:rgba(52,152,219,0.24);"></span>🔵 В работе</span>'
        + '<span class="grid-legend-item"><span class="grid-legend-swatch" style="background:rgba(149,165,166,0.24);"></span>📝 Запланировано</span>'
        + '<span class="grid-legend-item"><span class="grid-legend-swatch" style="background:rgba(231,76,60,0.24);"></span>🔴 Заблокировано</span>'
        + '<span class="grid-legend-item"><span class="grid-legend-swatch" style="background: repeating-linear-gradient(45deg,rgba(52,152,219,0.15) 0,rgba(52,152,219,0.15) 4px,rgba(52,152,219,0.30) 4px,rgba(52,152,219,0.30) 8px);"></span>🏖 Отпуск</span>'
        + '<span class="grid-legend-item"><span class="grid-legend-swatch" style="background: repeating-linear-gradient(45deg,rgba(243,156,18,0.15) 0,rgba(243,156,18,0.15) 4px,rgba(243,156,18,0.30) 4px,rgba(243,156,18,0.30) 8px);"></span>🤒 Больничный</span>'
        + '<span class="grid-legend-item"><span class="grid-legend-swatch" style="background: repeating-linear-gradient(45deg,rgba(155,89,182,0.15) 0,rgba(155,89,182,0.15) 4px,rgba(155,89,182,0.30) 4px,rgba(155,89,182,0.30) 8px);"></span>✈️ Командировка</span>'
        + '</div>';
}
function _absenceBadgeForRow(r) {
    var days = r.absence_days || {};
    var cnt = { vacation: 0, sick_leave: 0, business_trip: 0, remote: 0 };
    Object.keys(days).forEach(function(k) { cnt[days[k]] = (cnt[days[k]] || 0) + 1; });
    var out = '';
    if (cnt.vacation) out += ' <span class="emp-vac-badge">🏖 ' + cnt.vacation + '</span>';
    if (cnt.sick_leave) out += ' <span class="emp-sick-badge">🤒 ' + cnt.sick_leave + '</span>';
    if (cnt.business_trip) out += ' <span class="emp-trip-badge">✈️ ' + cnt.business_trip + '</span>';
    if (cnt.remote) out += ' <span class="emp-remote-badge">🏠 ' + cnt.remote + '</span>';
    return out;
}
function _summaryExtrasHtml(d) {
    var top = '', vac = '';
    if (d.top_tasks && d.top_tasks.length) {
        top = '<div class="sum-extra-block"><div class="sum-extra-title">🏆 Топ задач за период</div>';
        d.top_tasks.forEach(function(t) {
            top += '<div class="sum-top-task">'
                + '<span>' + escapeHtml(t.task_icon) + '</span>'
                + '<span class="name">' + escapeHtml(t.task_name) + '</span>'
                + '<span class="hours">' + formatHours(t.hours) + '</span></div>';
        });
        top += '</div>';
    }
    if (d.vacations && d.vacations.length) {
        vac = '<div class="sum-extra-block"><div class="sum-extra-title">🏖 Отсутствия в периоде</div>';
        d.vacations.forEach(function(v) {
            var vt = v.type || 'vacation';
            var lbl = v.type_label || absenceLabel(vt);
            vac += '<div class="sum-vac-row">'
                + '<span class="vtype-badge ' + vt + '">' + escapeHtml(lbl) + '</span>'
                + '<span class="emp-dot" style="display:inline-block;width:10px;height:10px;border-radius:50%;background:' + escapeHtml(v.employee_color) + ';box-shadow:0 0 6px ' + escapeHtml(v.employee_color) + ';"></span>'
                + '<span style="flex:1;">' + escName(v.employee_name) + '</span>'
                + '<span class="dates">' + escapeHtml(formatDateShort(v.from)) + ' — ' + escapeHtml(formatDateShort(v.to)) + '</span></div>';
        });
        vac += '</div>';
    }
    if (!top && !vac) return '';
    return '<div class="sum-extra-section">'
        + '<div class="sum-extra-section-title"><span>📌</span><span>Дополнительная статистика</span></div>'
        + '<div class="sum-extras">'
        + (top || '<div></div>') + (vac || '<div></div>')
        + '</div></div>';
}
function applySummaryColWidths() {
    var empW = parseInt(localStorage.getItem('sum_emp_w'), 10);
    if (!isFinite(empW) || empW < 60 || empW > 600) empW = 140;
    var taskW = parseInt(localStorage.getItem('sum_task_w'), 10);
    if (!isFinite(taskW) || taskW < 100 || taskW > 1200) taskW = 280;
    document.documentElement.style.setProperty('--sum-emp-w', empW + 'px');
    document.documentElement.style.setProperty('--sum-task-w', taskW + 'px');
}

function _attachColResizer(th, storageKey, cssVar, minW, maxW) {
    if (!th || th.querySelector('.col-resizer')) return;
    var h = document.createElement('div');
    h.className = 'col-resizer';
    h.title = 'Потяните, чтобы изменить ширину';
    th.appendChild(h);
    h.addEventListener('mousedown', function(e) {
        e.preventDefault();
        e.stopPropagation();
        h.classList.add('dragging');
        var startX = e.clientX;
        var cur = getComputedStyle(document.documentElement).getPropertyValue(cssVar).trim();
        var startW = parseInt(cur, 10) || th.offsetWidth;
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
        function onMove(ev) {
            var w = Math.max(minW, Math.min(maxW, startW + ev.clientX - startX));
            document.documentElement.style.setProperty(cssVar, w + 'px');
        }
        function onUp() {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
            h.classList.remove('dragging');
            document.body.style.cursor = '';
            document.body.style.userSelect = '';
            var cur2 = getComputedStyle(document.documentElement).getPropertyValue(cssVar).trim();
            var w2 = parseInt(cur2, 10);
            if (isFinite(w2)) try { localStorage.setItem(storageKey, String(w2)); } catch (er) {}
        }
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
    });
}

function initSummaryResizers() {
    applySummaryColWidths();
    var wrap = $('sumWrap');
    if (!wrap) return;
    var thEmp = wrap.querySelector('thead th.emp-col');
    _attachColResizer(thEmp, 'sum_emp_w', '--sum-emp-w', 80, 600);
}

function renderSummaryGrid() {
    var d = state.summary;
    var wrap = $('sumWrap'), extras = $('sumExtras');
    if (!wrap) return;
    if (!d || !d.rows.length) {
        wrap.innerHTML = '<div class="sum-empty">Нет данных за выбранный период.</div>';
        if (extras) extras.innerHTML = '';
        return;
    }

    if (state.sumTaskSort === undefined) {
        try { state.sumTaskSort = localStorage.getItem('sum_task_sort') || 'default'; }
        catch (e) { state.sumTaskSort = 'default'; }
    }
    if (state.sumTotalSort === undefined) {
        try { state.sumTotalSort = localStorage.getItem('sum_total_sort') || 'default'; }
        catch (e) { state.sumTotalSort = 'default'; }
    }
    if (!state.sumCollapsed) state.sumCollapsed = {};

    var days = d.days, dm = d.day_meta || {}, today = todayISO();
    var showTotals = state.sumShowDayTotals !== false;
    var taskSort = state.sumTaskSort || 'default';
    var totalSort = state.sumTotalSort || 'default';
    var collapsed = state.sumCollapsed;

    var rowsSorted = d.rows.slice();
    if (totalSort === 'hours_desc') rowsSorted.sort(function(a, b) { return (b.total_hours || 0) - (a.total_hours || 0); });
    else if (totalSort === 'hours_asc') rowsSorted.sort(function(a, b) { return (a.total_hours || 0) - (b.total_hours || 0); });

    var workdays = 0;
    days.forEach(function(dk) { if ((dm[dk] || {}).is_workday) workdays++; });
    var normHours = 0;
    days.forEach(function(dk) {
        var m = dm[dk] || {};
        if (typeof m.day_norm === 'number') normHours += m.day_norm;
        else if (m.is_workday) normHours += 8;
    });

    var taskSortMark = taskSort === 'name_asc' ? ' ↑' : (taskSort === 'name_desc' ? ' ↓' : '');
    var totalSortMark = totalSort === 'hours_desc' ? ' ↓' : (totalSort === 'hours_asc' ? ' ↑' : '');

    var head = '<tr><th class="emp-col">Сотрудник</th>'
        + '<th class="task-col sortable" data-sort="task" title="Клик — сортировка задач">Задача' + taskSortMark + '</th>';
    days.forEach(function(dk) {
        var m = dm[dk] || {}, cls = [];
        if (m.is_weekend) cls.push('weekend-col');
        if (m.is_holiday) cls.push('holiday-col');
        if (m.is_today || dk === today) cls.push('today-col');
        head += '<th' + (cls.length ? ' class="' + cls.join(' ') + '"' : '') + ' title="' + escapeHtml(dk) + '">'
            + escapeHtml(formatDateShort(dk)) + '</th>';
    });
    if (showTotals) {
        head += '<th class="total-col sortable" data-sort="total" title="Клик — сортировка сотрудников">Итого' + totalSortMark + '</th>';
    }
    head += '</tr>';

    var head2 = '';
    if (showTotals) {
        head2 = '<tr class="day-totals-head">'
            + '<td class="emp-cell" colspan="2"><div class="emp-cell-name" style="font-size:0.72rem;color:var(--trk-meta);font-weight:700;">Итого за день</div></td>';
        days.forEach(function(dk) {
            var v = d.day_totals[dk] || 0, m = dm[dk] || {}, cls = ['day-cell'];
            if (m.is_holiday) cls.push('holiday-day');
            else if (m.is_weekend) cls.push('weekend-day');
            head2 += '<td class="' + cls.join(' ') + '" style="font-weight:700;color:var(--trk-accent);text-align:center;">' + (v > 0 ? shortHours(v) : '—') + '</td>';
        });
        head2 += '<td class="total-cell" style="text-align:center;">' + formatHours(d.grand_total) + '</td></tr>';
    }

    var body = '';
    rowsSorted.forEach(function(r, ri) {
        var allTasks = (r.tasks || []).slice();
        if (taskSort === 'name_asc') allTasks.sort(function(a, b) { return (a.task_name || '').toLowerCase().localeCompare((b.task_name || '').toLowerCase()); });
        else if (taskSort === 'name_desc') allTasks.sort(function(a, b) { return (b.task_name || '').toLowerCase().localeCompare((a.task_name || '').toLowerCase()); });
        else allTasks.sort(function(a, b) {
            var ta = (a.task_tags && a.task_tags[0]) || 'zzz';
            var tb = (b.task_tags && b.task_tags[0]) || 'zzz';
            if (ta !== tb) return ta < tb ? -1 : 1;
            return (b.total_hours || 0) - (a.total_hours || 0);
        });

        var isCollapsed = !!collapsed[r.employee_id];
        var tasks;
        if (isCollapsed && allTasks.length) {
            var _aggCells = {};
            var _statusRank = { done: 4, in_progress: 3, blocked: 2, planned: 1 };
            allTasks.forEach(function(_t) {
                var _tCells = _t.cells || {};
                Object.keys(_tCells).forEach(function(_dk) {
                    var _c = _tCells[_dk];
                    if (!_c || !_c.hours) return;
                    var _a = _aggCells[_dk];
                    if (!_a) {
                        _aggCells[_dk] = {
                            hours: _c.hours,
                            status: _c.status || 'done',
                            entries: (_c.entries || []).slice()
                        };
                    } else {
                        _a.hours += _c.hours;
                        if ((_statusRank[_c.status] || 0) > (_statusRank[_a.status] || 0)) _a.status = _c.status;
                        if (_c.entries && _c.entries.length) _a.entries = _a.entries.concat(_c.entries);
                    }
                });
            });
            var _lbls = (typeof state !== 'undefined' && state.statusLabels) || {};
            Object.keys(_aggCells).forEach(function(_dk) {
                _aggCells[_dk].hours = Math.round(_aggCells[_dk].hours * 4) / 4;
                _aggCells[_dk].status_label = _lbls[_aggCells[_dk].status] || _aggCells[_dk].status;
            });
            tasks = [{
                task_id: '__collapsed__',
                task_name: '📦 ' + allTasks.length + ' задач свёрнуто · ' + formatHours(r.total_hours),
                task_icon: '',
                task_status: 'active',
                task_tags: [],
                overdue: false,
                cells: _aggCells,
                total_hours: r.total_hours,
                start_date: '',
                deadline: '',
                emp_completed_at: '',
                is_collapsed: true
            }];
        } else {
            tasks = allTasks;
        }

        var absMap = r.absence_days || {};
        var empExtra = _absenceBadgeForRow(r);

        var loadPct = normHours > 0 ? Math.round((r.total_hours / normHours) * 100) : 0;
        var loadCls = loadPct > 105 ? 'load-over' : (loadPct > 85 ? 'load-high' : (loadPct < 50 ? 'load-low' : 'load-ok'));
        var loadBar = '<div class="emp-load ' + loadCls + '" title="Загрузка: ' + loadPct + '% от нормы (' + workdays + '×8 = ' + normHours + 'ч)">'
            + '<div class="emp-load-fill" style="width:' + Math.min(loadPct, 100) + '%"></div>'
            + '</div>';

        var collapseBtn = allTasks.length > 1
            ? '<button class="emp-collapse-btn" data-emp="' + escapeHtml(r.employee_id) + '" title="' + (isCollapsed ? 'Развернуть' : 'Свернуть') + '" type="button">' + (isCollapsed ? '▶' : '▼') + '</button>'
            : '';

        var dept = r.employee_department ? '<div class="emp-dept">🏢 ' + escapeHtml(r.employee_department) + '</div>' : '';

        if (!tasks.length) {
            body += '<tr>'
                + '<td class="emp-cell" data-emp="' + escapeHtml(r.employee_id) + '">'
                + '<div class="emp-cell-inner">'
                +   '<div class="emp-cell-name">'
                +     '<span class="emp-dot" style="background:' + escapeHtml(r.employee_color) + ';box-shadow:0 0 6px ' + escapeHtml(r.employee_color) + ';"></span>'
                +     escName(r.employee_name) + collapseBtn
                +   '</div>'
                +   '<div class="emp-cell-stats">0 задач · 0 ч' + empExtra + '</div>'
                +   loadBar + dept
                + '</div></td>'
                + '<td class="task-cell empty">— нет задач —</td>'
                + days.map(function(dk) {
                    var m = dm[dk] || {}, abs = absMap[dk], cls = ['empty-cell'], content = '·';
                    if (abs) { cls.push('absence-' + abs); content = absenceIcon(abs); }
                    else if (m.is_holiday) cls.push('holiday-day');
                    else if (m.is_weekend) cls.push('weekend-day');
                    return '<td class="' + cls.join(' ') + '" title="' + escapeHtml(dk) + '">' + content + '</td>';
                }).join('')
                + (showTotals ? '<td class="total-cell">0 ч</td>' : '')
                + '</tr>';
            return;
        }

        var runningCount = 0;
        // PATCH 1.0.13: в свёрнутом виде tasks = [{task_id:'__collapsed__', task_status:'active'}],
        // поэтому считаем по allTasks, иначе счётчик всегда 1.
        allTasks.forEach(function(tt) {
            var st = (tt.task_status || 'active');
            if (st === 'active' || st === 'paused') runningCount++;
        });

        tasks.forEach(function(t, ti) {
            body += '<tr>';
            if (ti === 0) {
                body += '<td class="emp-cell" rowspan="' + tasks.length + '" data-emp="' + escapeHtml(r.employee_id) + '">'
                    + '<div class="emp-cell-inner">'
                    +   '<div class="emp-cell-name">'
                    +     '<span class="emp-dot" style="background:' + escapeHtml(r.employee_color) + ';box-shadow:0 0 6px ' + escapeHtml(r.employee_color) + ';"></span>'
                    +     escName(r.employee_name) + collapseBtn
                    +   '</div>'
                    +   '<div class="emp-cell-stats">'
                    +     '<span class="ecs-num">' + runningCount + '</span> в работе · '
                    +     '<span class="ecs-num">' + formatHours(r.total_hours) + '</span>'
                    +     empExtra
                    +   '</div>'
                    +   loadBar + dept
                    + '</div></td>';
            }
            var rowMode = state.sumTaskRowMode || 'full';
            var statusCls = 'st-' + (t.task_status || 'active');
            var dot = '<span class="task-status-dot" title="' + escapeHtml(t.task_status || 'active') + '"></span>';
            var period = '';
            if (t.start_date || t.deadline || t.emp_completed_at) {
                period = '<span class="task-period">'
                    + (t.start_date ? '🚀 ' + escapeHtml(formatDateShort(t.start_date)) : '')
                    + (t.start_date && t.deadline ? ' — ' : '')
                    + (t.deadline ? '⏰ ' + escapeHtml(formatDateShort(t.deadline)) : '')
                    + (t.emp_completed_at ? ' · ✅ ' + escapeHtml(formatDateShort(t.emp_completed_at)) : '')
                    + (t.overdue ? ' ⚠' : '') + '</span>';
            }
            var tagsChips = (t.task_tags && t.task_tags.length)
                ? t.task_tags.slice(0, 4).map(function(x) { return '<span class="task-tag-chip">#' + escapeHtml(x) + '</span>'; }).join('')
                : '';
            if (rowMode === 'compact') {
                body += '<td class="task-cell task-cell-compact ' + statusCls + (t.overdue ? ' overdue' : '') + '" data-task="' + escapeHtml(t.task_id) + '">'
                    + dot
                    + '<span class="task-ico">' + escapeHtml(t.task_icon) + '</span>'
                    + '<span class="task-name-str' + (t.overdue ? ' overdue' : '') + '" title="' + escapeHtml(t.task_name) + '">' + escapeHtml(t.task_name) + (t.overdue ? ' ⚠' : '') + '</span>'
                    + '</td>';
            } else {
                body += '<td class="task-cell task-cell-full ' + statusCls + (t.overdue ? ' overdue' : '') + '" data-task="' + escapeHtml(t.task_id) + '">'
                    + '<div class="task-cell-row1">' + dot
                    +   '<span class="task-ico">' + escapeHtml(t.task_icon) + '</span>'
                    +   '<span class="task-name-str' + (t.overdue ? ' overdue' : '') + '" title="' + escapeHtml(t.task_name) + '">' + escapeHtml(t.task_name) + (t.overdue ? ' ⚠' : '') + '</span>'
                    + '</div>'
                    + '<div class="task-cell-row2">'
                    +   '<span class="task-cell-dates">' + period + '</span>'
                    +   '<span class="task-cell-tags">' + tagsChips + '</span>'
                    + '</div>'
                    + '</td>';
            }
            days.forEach(function(dk) {
                var m = dm[dk] || {}, cell = t.cells[dk], abs = absMap[dk];
                if (!cell || !cell.hours) {
                    var cls = [], content = '·';
                    if (abs) { cls.push('absence-' + abs); content = absenceIcon(abs); }
                    else if (m.is_holiday) cls.push('holiday-day');
                    else if (m.is_weekend) cls.push('weekend-day');
                    else cls.push('empty-cell');
                    body += '<td class="day-cell ' + cls.join(' ') + '" title="' + escapeHtml(dk) + '">' + content + '</td>';
                    return;
                }
                var extraCls = '';
                if (abs && abs !== 'remote') extraCls = ' absence-' + abs;
                else if (m.is_holiday) extraCls = ' holiday-day';
                else if (m.is_weekend) extraCls = ' weekend-day';
                if (abs === 'remote') extraCls += ' has-remote';
                body += '<td class="day-cell status-' + escapeHtml(cell.status) + extraCls + '" '
                    + 'data-emp="' + escapeHtml(r.employee_id) + '" data-task="' + escapeHtml(t.task_id) + '" data-date="' + escapeHtml(dk) + '" '
                    + 'title="' + escapeHtml(formatHours(cell.hours) + ' · ' + (cell.status_label || '')) + '">'
                    + shortHours(cell.hours) + '</td>';
            });
            if (showTotals) {
                body += '<td class="total-cell">' + (t.total_hours ? formatHours(t.total_hours) : '—') + '</td>';
            }
            body += '</tr>';
        });
        if (ri < rowsSorted.length - 1) {
            body += '<tr class="emp-sep"><td colspan="' + (2 + days.length + (showTotals ? 1 : 0)) + '"></td></tr>';
        }
    });

    wrap.innerHTML = '<table class="sum-table grid-table"><thead>' + head + head2 + '</thead><tbody>' + body + '</tbody></table>';

    wrap.querySelectorAll('td.day-cell[data-emp]').forEach(function(td) {
        td.addEventListener('click', function(e) {
            e.stopPropagation();
            if (this.getAttribute('data-task') === '__collapsed__') {
                openEmpDayModal(this.getAttribute('data-emp'), this.getAttribute('data-date'));
                return;
            }
            openGridCellDetails(this.getAttribute('data-emp'), this.getAttribute('data-task'), this.getAttribute('data-date'));
        });
    });
    wrap.querySelectorAll('td.task-cell[data-task]').forEach(function(td) {
        td.style.cursor = 'pointer';
        td.addEventListener('click', function() { var _tid = this.getAttribute('data-task'); if (_tid === '__collapsed__') return; openTaskCardModal(_tid); });
    });
    wrap.querySelectorAll('td.emp-cell[data-emp]').forEach(function(td) {
        td.style.cursor = 'pointer';
        td.addEventListener('click', function(e) {
            if (e.target.closest('.emp-collapse-btn')) return;
            openEmpCardModal(this.getAttribute('data-emp'));
        });
    });

    wrap.querySelectorAll('th.sortable').forEach(function(th) {
        th.addEventListener('click', function() {
            var kind = this.getAttribute('data-sort');
            if (kind === 'task') {
                var cur = state.sumTaskSort || 'default';
                state.sumTaskSort = cur === 'name_asc' ? 'name_desc' : 'name_asc';
                try { localStorage.setItem('sum_task_sort', state.sumTaskSort); } catch (e) {}
            } else if (kind === 'total') {
                var cur2 = state.sumTotalSort || 'default';
                state.sumTotalSort = cur2 === 'hours_desc' ? 'hours_asc' : 'hours_desc';
                try { localStorage.setItem('sum_total_sort', state.sumTotalSort); } catch (e) {}
            }
            renderSummaryGrid();
        });
    });

    wrap.querySelectorAll('.emp-collapse-btn').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            var empId = this.getAttribute('data-emp');
            state.sumCollapsed = state.sumCollapsed || {};
            state.sumCollapsed[empId] = !state.sumCollapsed[empId];
            renderSummaryGrid();
        });
    });

    if (extras) extras.innerHTML = _summaryLegendHtml() + _summaryExtrasHtml(d);
    initSummaryResizers();
}

function openGridCellDetails(empId, taskId, dateStr) {
    var d = state.summary; if (!d || !d.rows) return;
    var row = d.rows.find(function(r) { return r.employee_id === empId; }); if (!row) return;
    var t = (row.tasks || []).find(function(x) { return x.task_id === taskId; }); if (!t) return;
    var cell = t.cells[dateStr]; if (!cell) return;
    var dd = $('dayModalDate'); if (dd) dd.textContent = formatDateHuman(dateStr) + ' — ' + maskName(row.employee_name);
    var dt = $('dayModalTotal'); if (dt) dt.textContent = formatHours(cell.hours) + ' · ' + (cell.status_label || '');
    var html = '';
    var full = [];
    cell.entries.forEach(function(e) {
        var f = {
            id: e.id, task_id: taskId, task_name: t.task_name, task_icon: t.task_icon,
            employee_id: row.employee_id,
            hours: e.hours, comment: e.comment, status: e.status, status_label: e.status_label,
            link: e.link, employee_name: row.employee_name, employee_color: row.employee_color,
            employee_department: row.employee_department || '', date: dateStr,
            task_start_date: t.start_date || '', task_deadline: t.deadline || '',
            overdue: t.overdue,
        };
        full.push(f);
        html += dayEntryCard(f, false);
    });
    var list = $('dayList'); if (list) list.innerHTML = html;
    bindDayEntryActions(list, full);
    var a = $('dayModalLeftActions'); if (a) a.style.display = 'none';
    var clr = $('dayClearBtn'); if (clr) clr.style.display = 'none';
    var m = $('dayModal'); if (m) m.classList.add('active');
}
function renderSummary() {
    var d = state.summary;
    var wrap = $('sumWrap'), extras = $('sumExtras');
    if (!wrap) return;
    if (!d || !d.rows.length) {
        wrap.innerHTML = '<div class="sum-empty">Нет данных за выбранный период.</div>';
        if (extras) extras.innerHTML = '';
        return;
    }
    var days = d.days, dm = d.day_meta || {}, today = todayISO();
    var view = state.sumViewMode || 'compact';
    var cls2 = view === 'full' ? 'sum-cell-full' : 'sum-cell-compact';
    var head = '<tr><th class="emp-col">Сотрудник</th>';
    days.forEach(function(dk) {
        var m = dm[dk] || {}, cls = [];
        if (m.is_weekend) cls.push('weekend-col');
        if (m.is_holiday) cls.push('holiday-col');
        if (m.is_today || dk === today) cls.push('today-col');
        head += '<th' + (cls.length ? ' class="' + cls.join(' ') + '"' : '') + '>' + escapeHtml(formatDateShort(dk)) + '</th>';
    });
    head += '<th class="total-col">Итого</th></tr>';
    var body = '';
    d.rows.forEach(function(r) {
        body += '<tr><td class="emp-cell">'
            + '<div class="emp-cell-inner">'
            +   '<div class="emp-cell-name">'
            +     '<span class="emp-dot" style="background:' + escapeHtml(r.employee_color) + ';box-shadow:0 0 6px ' + escapeHtml(r.employee_color) + ';"></span>'
            +     escName(r.employee_name)
            +   '</div>'
            +   '<div class="emp-cell-stats"><span class="ecs-num">' + formatHours(r.total_hours) + '</span></div>'
            + '</div></td>';
        days.forEach(function(dk) {
            var cell = r.cells[dk], m = dm[dk] || {}, extra = '';
            if (m.is_holiday) extra = ' holiday-day';
            else if (m.is_weekend) extra = ' weekend-day';
            if (!cell || !cell.hours) { body += '<td class="empty-cell' + extra + '">—</td>'; return; }
            var inner = '';
            if (view === 'full') {
                inner += '<div class="sum-hours-main">' + formatHours(cell.hours) + '</div>';
                cell.tasks.forEach(function(t) {
                    var stCls = t.entries.length ? t.entries[0].status : 'done';
                    inner += '<div class="sum-task-row ' + stCls + (t.overdue ? ' overdue' : '') + '">'
                        + '<span class="status-dot"></span><span>' + escapeHtml(t.task_icon) + '</span>'
                        + '<span class="task-name">' + escapeHtml(t.task_name) + '</span>'
                        + '<span class="task-hours">' + t.hours + '</span></div>';
                });
            } else {
                inner += '<div class="sum-hours-main">' + formatHours(cell.hours) + '</div>';
                inner += '<div class="sum-tasks-count">' + cell.tasks.length + ' задач</div>';
            }
            body += '<td class="has-data ' + cls2 + extra + '" data-emp="' + escapeHtml(r.employee_id) + '" data-date="' + escapeHtml(dk) + '">' + inner + '</td>';
        });
        body += '<td class="total-cell">' + formatHours(r.total_hours) + '</td></tr>';
    });
    var totalsRow = '<tr class="day-totals-row"><td class="emp-cell"><div class="emp-cell-name">Итого за день</div></td>';
    days.forEach(function(dk) {
        var v = d.day_totals[dk] || 0, m = dm[dk] || {}, cls = [];
        if (m.is_holiday) cls.push('holiday-day');
        else if (m.is_weekend) cls.push('weekend-day');
        totalsRow += '<td' + (cls.length ? ' class="' + cls.join(' ') + '"' : '') + '>' + (v > 0 ? formatHours(v) : '—') + '</td>';
    });
    totalsRow += '<td class="total-cell">' + formatHours(d.grand_total) + '</td></tr>';
    wrap.innerHTML = '<table class="sum-table"><thead>' + head + '</thead><tbody>' + body + totalsRow + '</tbody></table>';
    wrap.querySelectorAll('td.has-data').forEach(function(td) {
        td.addEventListener('click', function() { openSummaryCell(this.getAttribute('data-emp'), this.getAttribute('data-date')); });
    });
    if (extras) extras.innerHTML = _summaryLegendHtml() + _summaryExtrasHtml(d);
    initSummaryResizers();
}
function openSummaryCell(empId, dateStr) {
    var d = state.summary; if (!d) return;
    var row = d.rows.find(function(r) { return r.employee_id === empId; }); if (!row) return;
    var cell = row.cells[dateStr]; if (!cell) return;
    var dd = $('dayModalDate'); if (dd) dd.textContent = formatDateHuman(dateStr) + ' — ' + maskName(row.employee_name);
    var dt = $('dayModalTotal'); if (dt) dt.textContent = formatHours(cell.hours) + ' · ' + cell.tasks.length + ' задач';
    var html = '';
    var full = [];
    cell.tasks.forEach(function(t) {
        t.entries.forEach(function(e) {
            var f = {
                id: e.id, task_id: t.task_id, task_name: t.task_name, task_icon: t.task_icon,
                employee_id: row.employee_id,
                hours: e.hours, comment: e.comment, status: e.status, status_label: e.status_label,
                link: e.link, employee_name: row.employee_name, employee_color: row.employee_color,
                employee_department: row.employee_department || '', date: dateStr,
                task_start_date: '', task_deadline: '', overdue: t.overdue,
            };
            full.push(f);
            html += dayEntryCard(f, false);
        });
    });
    var list = $('dayList'); if (list) list.innerHTML = html;
    bindDayEntryActions(list, full);
    var a = $('dayModalLeftActions'); if (a) a.style.display = 'none';
    var clr = $('dayClearBtn'); if (clr) clr.style.display = 'none';
    var m = $('dayModal'); if (m) m.classList.add('active');
}
on('sumApplyBtn', 'click', loadSummary);
on('sumWeekBtn', 'click', function() { setDefaultWeekRange(); loadSummary(); });
on('sumMonthBtn', 'click', function() { setMonthRange(); loadSummary(); });
on('sumPrevWeekBtn', 'click', function() {
    var a = $('sumDateFrom'), b = $('sumDateTo');
    var from = (a && a.value) || getMondayISO();
    var to = (b && b.value) || getSundayISO();
    if (a) a.value = addDaysISO(from, -7);
    if (b) b.value = addDaysISO(to, -7);
    loadSummary();
});
on('sumNextWeekBtn', 'click', function() {
    var a = $('sumDateFrom'), b = $('sumDateTo');
    var from = (a && a.value) || getMondayISO();
    var to = (b && b.value) || getSundayISO();
    if (a) a.value = addDaysISO(from, 7);
    if (b) b.value = addDaysISO(to, 7);
    loadSummary();
});
on('sumPrevDayBtn', 'click', function() {
    var a = $('sumDateFrom'), b = $('sumDateTo');
    var from = (a && a.value) || getMondayISO();
    var to = (b && b.value) || getSundayISO();
    if (a) a.value = addDaysISO(from, -1);
    if (b) b.value = addDaysISO(to, -1);
    loadSummary();
});
on('sumNextDayBtn', 'click', function() {
    var a = $('sumDateFrom'), b = $('sumDateTo');
    var from = (a && a.value) || getMondayISO();
    var to = (b && b.value) || getSundayISO();
    if (a) a.value = addDaysISO(from, 1);
    if (b) b.value = addDaysISO(to, 1);
    loadSummary();
});
on('sumEmployeeFilter', 'change', loadSummary);
on('sumTaskFilter', 'change', loadSummary);
on('sumDeptFilter', 'change', loadSummary);
on('sumTeamFilter', 'change', loadSummary);
on('sumTagFilter', 'change', loadSummary);
(function() {
    var sdt = $('sumShowDayTotals');
    if (!sdt) return;
    sdt.checked = state.sumShowDayTotals;
    sdt.addEventListener('change', function() {
        state.sumShowDayTotals = this.checked;
        if (state.summary) {
            if (state.summaryIsGrid) renderSummaryGrid();
            else renderSummary();
        }
    });
})();

/* ============================================================
   КАРТОЧКА СОТРУДНИКА
   ============================================================ */
function openEmpCardModal(empId) {
    var from = $('sumDateFrom') ? $('sumDateFrom').value : '';
    var to = $('sumDateTo') ? $('sumDateTo').value : '';
    if (!from || !to) {
        var t = new Date();
        from = firstOfMonthISOFromDate(t);
        to = todayISO();
    }
    var qs = '?employee=' + encodeURIComponent(empId)
        + '&from=' + encodeURIComponent(from) + '&to=' + encodeURIComponent(to);
    apiJson('/api/tracker/employee/card' + qs)
        .then(function(d) {
            if (!d.success) throw new Error(d.error || 'Ошибка');
            renderEmpCardModal(d);
            var m = $('empCardModal'); if (m) m.classList.add('active');
        })
        .catch(function(err) { if (err && (err.message || '').indexOf('cancelled') !== -1) return; notify('❌ ' + (err.message || 'Ошибка'), 'error'); });
}
function _coverageBar(cov) {
    var cls = 'err';
    if (cov >= 70) cls = 'ok';
    else if (cov >= 40) cls = 'warn';
    var w = Math.max(0, Math.min(cov, 100));
    return '<div class="coverage-bar"><span class="coverage-bar-label">📊 Покрытие:</span>'
        + '<div class="coverage-bar-track"><div class="coverage-bar-fill ' + cls + '" style="width:' + w + '%;"></div></div>'
        + '<span class="coverage-bar-label">' + cov + '%</span></div>';
}
function renderEmpCardModal(d) {
    var emp = d.employee || {};
    var color = emp.color || '#00897b';
    var period = d.from ? (formatDateHuman(d.from) + ' — ' + formatDateHuman(d.to)) : '';
    var dept = emp.department ? ' · 🏢 ' + escapeHtml(emp.department) : '';
    var fired = emp.fired ? ' · 🚪 уволен ' + escapeHtml(emp.fired_date || '') : '';
    var head = $('empCardHead');
    if (head) head.innerHTML = '<div class="emp-day-avatar" style="background:' + escapeHtml(color) + ';box-shadow:0 0 12px ' + escapeHtml(color) + ';">'
        + escapeHtml(initials(emp.name)) + '</div>'
        + '<div class="emp-day-info"><div class="emp-day-name">' + escName(emp.name || '—') + '</div>'
        + '<div class="emp-day-role">' + escapeHtml(emp.role || '') + dept + fired + ' · ' + escapeHtml(period) + '</div></div>'
        + '<div class="emp-day-stats">'
        + '<div class="emp-day-stat"><span class="val">' + formatHours(d.total_hours) + '</span><span class="lbl">часов</span></div>'
        + '<div class="emp-day-stat"><span class="val">' + d.tasks.length + '</span><span class="lbl">задач</span></div>'
        + '</div>';
    var hm = $('empCardHeatmap'); if (hm) hm.innerHTML = renderMiniCells(d.cells);
    var list = $('empCardTasks');
    if (!list) return;
    if (!d.tasks.length) { list.innerHTML = '<div class="day-empty">За этот период отметок нет.</div>'; return; }
    var html = '';
    d.tasks.forEach(function(t) {
        var stLbl = state.taskStatusLabels[t.status] || t.status || '';
        var badge = '';
        if (t.completion_kind) {
            var cls = t.completion_kind;
            var txt = cls === 'early' ? '✅ Досрочно' : (cls === 'late' ? '⏰ С опозданием' : '✅ В срок');
            if (typeof t.days_delta === 'number') {
                if (t.days_delta < 0) txt += ' (' + Math.abs(t.days_delta) + ' дн. раньше)';
                else if (t.days_delta > 0) txt += ' (' + t.days_delta + ' дн. позже)';
            }
            if (t.completed_at) txt += ' · ' + t.completed_at;
            badge = '<div class="task-completion-badge ' + cls + '">' + escapeHtml(txt) + '</div>';
        }
        var rowCls = 'task-card-row';
        if (t.overdue) rowCls += ' overdue';
        else if (t.completion_kind === 'early') rowCls += ' early';
        else if (t.completion_kind === 'late') rowCls += ' late';
        html += '<div class="' + rowCls + '">'
            + '<div class="task-card-row-head">'
            +   '<span class="task-card-row-title' + (t.overdue ? ' overdue' : '') + '">'
            +     escapeHtml(t.task_icon) + ' ' + escapeHtml(t.task_name) + '</span>'
            +   '<span class="day-entry-hours">' + formatHours(t.total_hours) + '</span>'
            +   (stLbl ? '<span class="day-entry-status status-' + escapeHtml(t.status) + '">' + escapeHtml(stLbl) + '</span>' : '')
            + '</div>'
            + (t.task_tags && t.task_tags.length ? '<div style="margin-top:2px;">' + t.task_tags.map(function(x){return '<span class="task-tag-chip">#'+escapeHtml(x)+'</span>';}).join('') + '</div>' : '')
            + '<div class="task-card-row-meta">'
            +   (t.start_date ? '<span>🚀 ' + escapeHtml(formatDateHuman(t.start_date)) + '</span>' : '')
            +   (t.deadline ? '<span>⏰ ' + escapeHtml(formatDateHuman(t.deadline)) + '</span>' : '')
            +   '<span>📅 ' + t.active_days + ' из ' + t.possible_days + ' раб. дней</span>'
            + '</div>'
            + (badge ? '<div style="margin-top:4px;">' + badge + '</div>' : '')
            + _coverageBar(t.coverage)
            + '<div class="mini-heatmap">' + renderMiniCells(t.cells) + '</div></div>';
    });
    list.innerHTML = html;
}
function renderMiniCells(cells) {
    if (!cells || !cells.length) return '';
    var out = '';
    cells.forEach(function(c) {
        var cls = 'mini-cell', title = c.date, content = '';
        var abs = c.absence_type || (c.is_vacation ? 'vacation' : '');
        if (abs) {
            cls += ' ' + absenceClass(abs);
            content = absenceIcon(abs);
            title += ' — ' + absenceLabel(abs);
        } else if (c.hours > 0) {
            var col = cellLightGreen(c.hours);
            content = '<span class="mini-h">' + shortHours(c.hours) + '</span>';
            title += ' — ' + formatHours(c.hours);
            if (c.is_today) cls += ' today';
            out += '<div class="' + cls + '" style="background:' + col + ';color:#1a9c52;" title="' + escapeHtml(title) + '">' + content + '</div>';
            return;
        } else if (c.is_holiday) { cls += ' holiday'; content = '🎉'; title += ' — праздник'; }
        else if (c.is_weekend) { cls += ' weekend'; title += ' — выходной'; }
        else if (c.missing) { cls += ' missing'; content = '!'; title += ' — не заполнено'; }
        else if (c.is_workday) { cls += ' workday'; title += ' — не заполнено'; }
        if (c.is_today) cls += ' today';
        out += '<div class="' + cls + '" title="' + escapeHtml(title) + '">' + content + '</div>';
    });
    return out;
}

/* ============================================================
   КАРТОЧКА ЗАДАЧИ
   ============================================================ */
function openTaskCardModal(taskId) {
    var from = $('sumDateFrom') ? $('sumDateFrom').value : '';
    var to = $('sumDateTo') ? $('sumDateTo').value : '';
    if (!from || !to) {
        var t = new Date();
        from = firstOfMonthISOFromDate(t);
        to = todayISO();
    }
    var qs = '?task=' + encodeURIComponent(taskId)
        + '&from=' + encodeURIComponent(from) + '&to=' + encodeURIComponent(to);
    apiJson('/api/tracker/task/card' + qs)
        .then(function(d) {
            if (!d.success) throw new Error(d.error || 'Ошибка');
            // PATCH: сохраняем для PATCH 26/29
            state.__lastTaskCardData = d;
            renderTaskCardModal(d);
            if (window.__trkTaskFeedRender) { try { window.__trkTaskFeedRender(d); } catch(e){} }
            if (window.__trkRenderTaskCardEmployees) { try { window.__trkRenderTaskCardEmployees(d); } catch(e){} }
            if (window.__trkInjectTaskSummary) { setTimeout(function() { try { window.__trkInjectTaskSummary(); } catch(e){} }, 80); }
            var m = $('taskCardModal'); if (m) m.classList.add('active');
        })
        .catch(function(err) { if (err && (err.message || '').indexOf('cancelled') !== -1) return; notify('❌ ' + (err.message || 'Ошибка'), 'error'); });
}
function renderTaskCardModal(d) {
    var task = d.task || {};
    var period = d.from ? (formatDateHuman(d.from) + ' — ' + formatDateHuman(d.to)) : '';
    var badge = '';
    if (task.completion_kind) {
        var cls = task.completion_kind;
        var txt = cls === 'early' ? '✅ Админ-досрочно' : (cls === 'late' ? '⏰ Админ-с опозданием' : '✅ Админ-в срок');
        if (typeof task.days_delta === 'number') {
            if (task.days_delta < 0) txt += ' (' + Math.abs(task.days_delta) + ' дн. раньше)';
            else if (task.days_delta > 0) txt += ' (' + task.days_delta + ' дн. позже)';
        }
        if (task.completed_at) txt += ' · ' + task.completed_at;
        // PATCH v1.0.9: показываем точное время автозакрытия
        if (task.auto_closed_at) txt += ' · 🤖 автозакрытие ' + task.auto_closed_at;
        badge = '<div class="task-completion-badge ' + cls + '" style="margin-top:6px;">' + escapeHtml(txt) + '</div>';
    }
    var tagsHtml = '';
    if (task.tags && task.tags.length) {
        tagsHtml = '<div style="margin-top:6px;">'
            + task.tags.map(function(x) { return '<span class="task-tag-chip">#' + escapeHtml(x) + '</span>'; }).join('')
            + '</div>';
    }
    var head = $('taskCardHead');
    if (head) head.innerHTML = '<div class="emp-day-avatar" style="background:var(--trk-filter-active-bg);font-size:1.6rem;">'
        + escapeHtml(task.icon || '📋') + '</div>'
        + '<div class="emp-day-info"><div class="emp-day-name' + (task.overdue ? ' overdue' : '') + '">'
        + escapeHtml(task.name || '—') + (task.overdue ? ' ⚠' : '') + '</div>'
        + '<div class="emp-day-role">' + escapeHtml(period)
        + (task.start_date ? ' · 🚀 ' + escapeHtml(formatDateHuman(task.start_date)) : '')
        + (task.deadline ? ' · ⏰ ' + escapeHtml(formatDateHuman(task.deadline)) : '') + '</div>'
        + tagsHtml
        + badge + '</div>'
        + '<div class="emp-day-stats">'
        + '<div class="emp-day-stat"><span class="val">' + formatHours(d.total_hours) + '</span><span class="lbl">часов</span></div>'
        + '<div class="emp-day-stat"><span class="val">' + d.active_days + ' / ' + (d.possible_days || 0) + '</span><span class="lbl">дней</span></div>'
        + '</div>';
    var hm = $('taskCardHeatmap'); if (hm) hm.innerHTML = renderMiniCells(d.cells);
    var cov = (typeof d.coverage === 'number') ? _coverageBar(d.coverage) : '';
    var list = $('taskCardEmployees');
    if (!list) return;
    if (!d.employees.length) { list.innerHTML = cov + '<div class="day-empty">За этот период отметок нет.</div>'; return; }
    var html = cov;
    d.employees.forEach(function(e) {
        var extra = '';
        if (e.emp_completion_kind) {
            var cls = e.emp_completion_kind;
            var t2 = cls === 'early' ? '✅ Досрочно' : (cls === 'late' ? '⏰ Позже' : '✅ В срок');
            if (e.emp_completed_at) t2 += ' ' + e.emp_completed_at;
            extra = '<span class="task-completion-badge ' + cls + '" style="margin-left:6px;">' + escapeHtml(t2) + '</span>';
        } else if (e.overdue) {
            extra = '<span class="task-completion-badge late" style="margin-left:6px;">⚠ не закрыл</span>';
        }
        var empMini = '';
        if (e.cells && e.cells.length) {
            empMini = '<div class="mini-heatmap" style="margin-top:6px;">' + renderMiniCells(e.cells) + '</div>';
        }
        html += '<div class="day-entry' + (e.overdue ? ' overdue' : '') + '">'
            + '<div class="day-entry-avatar" style="background:' + escapeHtml(e.employee_color) + ';box-shadow:0 0 10px ' + escapeHtml(e.employee_color) + ';">'
            + escapeHtml(initials(e.employee_name)) + '</div>'
            + '<div class="day-entry-body"><div class="day-entry-head">'
            + '<span class="day-entry-task">' + escName(e.employee_name) + '</span>'
            + '<span class="day-entry-hours">' + formatHours(e.total_hours) + '</span>'
            + '<span class="day-entry-status status-in_progress">' + e.active_days + ' дн.</span>'
            + extra + '</div>'
            + '<div class="day-entry-employee-row">'
            + (e.employee_department ? '<span class="emp-dept">🏢 ' + escapeHtml(e.employee_department) + '</span>' : '')
            + '</div>'
            + empMini
            + '</div></div>';
    });
    list.innerHTML = html;
}

/* ============================================================
   СТАТИСТИКА
   ============================================================ */
function loadStats() {
    var from = $('stDateFrom') ? $('stDateFrom').value : '';
    var to = $('stDateTo') ? $('stDateTo').value : '';
    if (!from) { from = firstOfMonthISO(todayYM()); if ($('stDateFrom')) $('stDateFrom').value = from; }
    if (!to) { to = todayISO(); if ($('stDateTo')) $('stDateTo').value = to; }
    var emp = $('stEmployeeFilter') ? ($('stEmployeeFilter').value || '') : '';
    var dept = $('stDeptFilter') ? ($('stDeptFilter').value || '') : '';
    var team = $('stTeamFilter') ? ($('stTeamFilter').value || '') : '';
    var tagArr2 = (window.__trkSelectedTags && window.__trkSelectedTags.stTagFilter) || [];
    var tag = tagArr2.join(',');
    var stTagMode = (window.__trkTagMode && window.__trkTagMode.stTagFilter) || 'any';
    var qs = '?from=' + encodeURIComponent(from) + '&to=' + encodeURIComponent(to)
        + '&employee=' + encodeURIComponent(emp) + '&department=' + encodeURIComponent(dept)
        + '&team=' + encodeURIComponent(team) + '&tag=' + encodeURIComponent(tag)
        + '&tag_mode=' + encodeURIComponent(stTagMode);
    apiJson('/api/tracker/stats' + qs).then(function(d) {
        if (!d.success) throw new Error(d.error || 'Ошибка');
        renderStats(d);
    }).catch(function(err) {
        var ov = $('stOverall');
        if (ov) ov.innerHTML = '<div class="sum-empty" style="color:#e74c3c;">❌ ' + escapeHtml(err.message || 'Ошибка') + '</div>';
        var ex = $('stExtras'); if (ex) ex.innerHTML = '';
    });
}

function _buildBarChart(title, series, labelKey, valueKey, color) {
    var box = document.createElement('div');
    box.className = 'chart-block';
    if (!series || !series.length) {
        box.innerHTML = '<div class="chart-title">' + escapeHtml(title) + '</div>'
            + '<div class="dict-empty">Нет данных</div>';
        return box;
    }
    var maxV = 0;
    series.forEach(function(p) { maxV = Math.max(maxV, Number(p[valueKey]) || 0); });
    maxV = maxV || 1;
    var W = 560, H = 180, PAD = 28;
    var n = series.length;
    var stepX = n > 1 ? (W - PAD * 2) / (n - 1) : 0;
    var labelEvery = Math.max(1, Math.floor(n / 8));
    var bars = '';
    series.forEach(function(p, i) {
        var x = PAD + i * stepX;
        var v = Number(p[valueKey]) || 0;
        var h = (v / maxV) * (H - PAD * 2);
        var y = H - PAD - h;
        var bw = n > 1 ? Math.max(2, stepX * 0.7) : 20;
        bars += '<rect class="chart-bar" data-date="' + escapeHtml(p[labelKey]) + '" '
             + 'x="' + (x - bw / 2) + '" y="' + y
             + '" width="' + bw + '" height="' + Math.max(0, h)
             + '" rx="3" fill="' + color + '">'
             + '<title>' + escapeHtml(p[labelKey]) + ': ' + v + ' ч · клик → фильтр по этой дате</title></rect>';
        if (i % labelEvery === 0) {
            bars += '<text class="chart-label" x="' + x + '" y="' + (H - 8) + '">'
                 + escapeHtml(formatDateShort(p[labelKey])) + '</text>';
        }
    });
    var grid = '';
    for (var g = 0; g <= 3; g++) {
        var yy = PAD + (H - PAD * 2) * (g / 3);
        grid += '<line class="chart-grid-line" x1="' + PAD + '" x2="' + (W - PAD) + '" y1="' + yy + '" y2="' + yy + '"></line>';
    }
    box.innerHTML = '<div class="chart-title">' + escapeHtml(title) + ' · макс ' + maxV + ' ч</div>'
        + '<svg viewBox="0 0 ' + W + ' ' + H + '" class="chart-svg" preserveAspectRatio="none">'
        + grid + bars + '</svg>'
        + '<div class="assignees-hint">Клик по столбику — фильтр по этой дате</div>';
    box.querySelectorAll('rect.chart-bar').forEach(function(rect) {
        rect.addEventListener('click', function() {
            var dk = this.getAttribute('data-date');
            if (!dk) return;
            var a = $('stDateFrom'), b = $('stDateTo');
            if (a) a.value = dk;
            if (b) b.value = dk;
            notify('📅 Фильтр: ' + dk);
            loadStats();
        });
    });
    return box;
}
function _buildDonutChart(title, tags) {
    var box = document.createElement('div');
    box.className = 'chart-block';
    var total = tags.reduce(function(s, x) { return s + (Number(x.hours) || 0); }, 0);
    if (!total) {
        box.innerHTML = '<div class="chart-title">' + escapeHtml(title) + '</div>'
            + '<div class="dict-empty">Нет данных</div>';
        return box;
    }
    var colors = ['#f5d76e', '#e6a81a', '#4caf50', '#3498db', '#9b59b6',
                  '#e74c3c', '#00bcd4', '#ff5722', '#607d8b', '#8bc34a'];
    var cx = 100, cy = 100, r = 70, inner = 45;
    var ang = -Math.PI / 2;
    var svg = '<svg viewBox="0 0 200 200" class="chart-svg" style="height:180px;">';
    var legend = '<div class="donut-legend">';
    tags.slice(0, 10).forEach(function(t, i) {
        var v = Number(t.hours) || 0;
        var slice = (v / total) * Math.PI * 2;
        var a1 = ang, a2 = ang + slice;
        var color = colors[i % colors.length];
        var large = slice > Math.PI ? 1 : 0;
        var x1 = cx + r * Math.cos(a1), y1 = cy + r * Math.sin(a1);
        var x2 = cx + r * Math.cos(a2), y2 = cy + r * Math.sin(a2);
        var xi1 = cx + inner * Math.cos(a1), yi1 = cy + inner * Math.sin(a1);
        var xi2 = cx + inner * Math.cos(a2), yi2 = cy + inner * Math.sin(a2);
        // PATCH 1.0.13: один тег = полный круг. Path с a1===a2 (mod 2π) невидим,
        // поэтому рисуем <circle> с обводкой, толщина = (r - inner).
        if (slice >= Math.PI * 2 - 0.01) {
            var midR = (r + inner) / 2;
            var strokeW = r - inner;
            svg += '<circle class="chart-slice" data-tag="' + escapeHtml(t.tag) + '" '
                + 'cx="' + cx + '" cy="' + cy + '" r="' + midR + '" '
                + 'fill="none" stroke="' + color + '" stroke-width="' + strokeW + '">'
                + '<title>#' + escapeHtml(t.tag) + ': ' + v + ' ч · клик → фильтр по тегу</title></circle>';
        } else {
            svg += '<path class="chart-slice" data-tag="' + escapeHtml(t.tag) + '" '
                + 'd="M ' + x1.toFixed(2) + ' ' + y1.toFixed(2)
                + ' A ' + r + ' ' + r + ' 0 ' + large + ' 1 ' + x2.toFixed(2) + ' ' + y2.toFixed(2)
                + ' L ' + xi2.toFixed(2) + ' ' + yi2.toFixed(2)
                + ' A ' + inner + ' ' + inner + ' 0 ' + large + ' 0 ' + xi1.toFixed(2) + ' ' + yi1.toFixed(2)
                + ' Z" fill="' + color + '">'
                + '<title>#' + escapeHtml(t.tag) + ': ' + v + ' ч · клик → фильтр по тегу</title></path>';
        }
        legend += '<div class="donut-legend-item clickable" data-tag="' + escapeHtml(t.tag) + '">'
            + '<span class="dl-color" style="background:' + color + ';"></span>'
            + '<span class="dl-label">#' + escapeHtml(t.tag) + '</span>'
            + '<span class="dl-value">' + v + ' ч</span>'
            + '</div>';
        ang = a2;
    });
    svg += '</svg>';
    legend += '</div>';
    box.innerHTML = '<div class="chart-title">' + escapeHtml(title) + '</div>'
        + '<div style="display:grid;grid-template-columns:200px 1fr;gap:12px;align-items:center;">'
        + svg + legend + '</div>'
        + '<div class="assignees-hint">Клик по сектору или легенде — фильтр по тегу</div>';
    box.querySelectorAll('.chart-slice, .donut-legend-item.clickable').forEach(function(el) {
        el.addEventListener('click', function() {
            var tag = this.getAttribute('data-tag');
            if (!tag) return;
            window.__trkSelectedTags = window.__trkSelectedTags || {};
            window.__trkSelectedTags.stTagFilter = [tag];
            if (window.__trkRenderTagPills) window.__trkRenderTagPills();
            notify('🏷 Фильтр: #' + tag);
            loadStats();
        });
    });
    return box;
}
function renderStats(d) {
    var o = d.overall || {};
    var ov = $('stOverall');
    if (ov) ov.innerHTML =
        '<div class="stat-card"><span class="stat-label">Сотрудников</span><span class="stat-value">' + (o.employees_count || 0) + '</span></div>'
        + '<div class="stat-card"><span class="stat-label">Всего задач</span><span class="stat-value">' + (o.tasks_total || 0) + '</span></div>'
        + '<div class="stat-card"><span class="stat-label">Закрыто</span><span class="stat-value" style="color:#2ecc71;">' + (o.tasks_done || 0) + '</span></div>'
        + '<div class="stat-card"><span class="stat-label">В работе</span><span class="stat-value" style="color:#3498db;">' + (o.tasks_active || 0) + '</span></div>'
        + '<div class="stat-card"><span class="stat-label">Просрочено</span><span class="stat-value" style="color:#e74c3c;">' + (o.tasks_overdue || 0) + '</span></div>'
        + '<div class="stat-card"><span class="stat-label">Досрочно</span><span class="stat-value" style="color:#9b59b6;">' + (o.early_done || 0) + '</span></div>'
        + '<div class="stat-card"><span class="stat-label">С опозданием</span><span class="stat-value" style="color:#e67e22;">' + (o.late_done || 0) + '</span></div>'
        + '<div class="stat-card"><span class="stat-label">Часов всего</span><span class="stat-value">' + formatHours(o.hours_total || 0) + '</span></div>';

    var chartsEl = $('stCharts');
    if (chartsEl) {
        chartsEl.innerHTML = '';
        if (d.hours_series && d.hours_series.length) {
            chartsEl.appendChild(_buildBarChart(
                'Часы по дням', d.hours_series, 'date', 'hours', '#5bc0de'));
        }
        if (d.tags_summary && d.tags_summary.length) {
            chartsEl.appendChild(_buildDonutChart(
                'Распределение часов по тегам', d.tags_summary));
        }
    }

    var ov2 = $('stOverdue');
    if (ov2) {
        var det = d.overdue_details || [];
        if (!det.length) { ov2.style.display = 'none'; ov2.innerHTML = ''; }
        else {
            ov2.style.display = '';
            var h = '<div class="sum-extra-title" style="color:#e74c3c;">⚠ Просроченные задачи (' + det.length + ')</div>'
                + '<div class="sum-table-wrap scroll-block"><table class="sum-table grid-table"><thead><tr>'
                + '<th class="task-col">Задача</th><th>Дедлайн</th><th>Просрочка</th><th>Не закрыли</th>'
                + '</tr></thead><tbody>';
            det.forEach(function(t) {
                var ass = (t.assignees || []).map(function(a) {
                    return '<span class="emp-dot" style="display:inline-block;width:8px;height:8px;border-radius:50%;background:' + escapeHtml(a.color) + ';margin-right:4px;"></span>' + escName(a.name);
                }).join(', ') || '—';
                h += '<tr><td class="task-cell overdue" style="text-align:left;">'
                    + '<span class="task-ico">' + escapeHtml(t.task_icon) + '</span>' + escapeHtml(t.task_name) + '</td>'
                    + '<td>' + escapeHtml(t.deadline) + '</td>'
                    + '<td style="color:#e74c3c;font-weight:700;">' + t.days_overdue + ' дн.</td>'
                    + '<td style="text-align:left;font-size:0.78rem;">' + ass + '</td></tr>';
            });
            h += '</tbody></table></div>';
            ov2.innerHTML = h;
        }
    }

    var tb = $('stTagsBlock');
    if (tb) {
        var ts = d.tags_summary || [];
        if (!ts.length) { tb.style.display = 'none'; tb.innerHTML = ''; }
        else {
            tb.style.display = '';
            var th = '<div class="sum-extra-title">🏷 Сводка по тегам</div>'
                + '<div class="sum-table-wrap scroll-block"><table class="sum-table grid-table"><thead><tr>'
                + '<th class="task-col">Тег</th><th>Задач</th><th>Закрыто</th><th>Просрочено</th><th>Часов</th>'
                + '</tr></thead><tbody>';
            ts.forEach(function(t) {
                th += '<tr>'
                    + '<td style="text-align:left;"><span class="task-tag-chip clickable" data-tag="' + escapeHtml(t.tag) + '" style="cursor:pointer;">#' + escapeHtml(t.tag) + '</span></td>'
                    + '<td>' + t.tasks + '</td>'
                    + '<td style="color:#2ecc71;font-weight:700;">' + t.done + '</td>'
                    + '<td style="color:#e74c3c;font-weight:700;">' + t.overdue + '</td>'
                    + '<td class="total-cell">' + formatHours(t.hours) + '</td>'
                    + '</tr>';
            });
            th += '</tbody></table></div>';
            tb.innerHTML = th;
            tb.querySelectorAll('.task-tag-chip.clickable').forEach(function(el) {
                el.addEventListener('click', function() {
                    var tag = this.getAttribute('data-tag');
                    window.__trkSelectedTags = window.__trkSelectedTags || {};
                    window.__trkSelectedTags.stTagFilter = [tag];
                    if (window.__trkRenderTagPills) window.__trkRenderTagPills();
                    loadStats();
                });
            });
        }
    }

    var extras = '';
    extras += '<div class="sum-extra-block" style="margin-bottom:14px;">'
        + '<div class="sum-extra-title">👥 По сотрудникам</div>'
        + '<div class="sum-table-wrap scroll-block"><table class="sum-table grid-table"><thead><tr>'
        + '<th class="emp-col">Сотрудник</th><th>Отдел</th><th>Часов</th><th>Задач</th>'
        + '<th>Закрыто</th><th>В работе</th><th>Просроч.</th><th>Досрочно</th><th>Позже</th>'
        + '<th>🏖/🤒/✈️</th></tr></thead><tbody>';
    (d.by_employee || []).forEach(function(r) {
        var fired = r.employee_fired ? ' <span class="emp-fired" title="уволен ' + escapeHtml(r.employee_fired_date) + '">🚪</span>' : '';
        extras += '<tr>'
            + '<td class="emp-cell"><div class="emp-cell-inner"><div class="emp-cell-name"><span class="emp-dot" style="background:' + escapeHtml(r.employee_color) + ';"></span>' + escName(r.employee_name) + fired + '</div></div></td>'
            + '<td>' + escapeHtml(r.employee_department || '—') + '</td>'
            + '<td class="total-cell">' + formatHours(r.hours) + '</td>'
            + '<td>' + r.total_tasks + '</td>'
            + '<td style="color:#2ecc71;font-weight:700;">' + r.done_tasks + '</td>'
            + '<td style="color:#3498db;font-weight:700;">' + r.active_tasks + '</td>'
            + '<td style="color:#e74c3c;font-weight:700;">' + r.overdue_tasks + '</td>'
            + '<td style="color:#9b59b6;">' + r.early_done + '</td>'
            + '<td style="color:#e67e22;">' + (r.late_done || 0) + '</td>'
            + '<td>' + (r.vacation_days || 0) + ' / ' + (r.sick_days || 0) + ' / ' + (r.business_trip_days || 0) + '</td></tr>';
    });
    extras += '</tbody></table></div></div>';
    extras += '<div class="sum-extra-block">'
        + '<div class="sum-extra-title">📋 По задачам</div>'
        + '<div class="sum-table-wrap scroll-block"><table class="sum-table grid-table"><thead><tr>'
        + '<th class="task-col">Задача</th><th>Теги</th><th>Статус</th><th>Дедлайн</th><th>Завершена</th>'
        + '<th>Закрыли</th><th>Назначено</th><th>Работали</th><th>Часов</th></tr></thead><tbody>';
    (d.by_task || []).forEach(function(t) {
        var st = ({'active':'Активна','done':'✅ Выполнена','paused':'Пауза','archived':'Архив'})[t.status] || t.status;
        var ovMark = t.overdue ? ' <span style="color:#e74c3c;">⚠</span>' : '';
        var comp = t.completed_at || '—';
        if (t.completion_kind === 'early') comp += ' <span style="color:#2ecc71;">✓</span>';
        else if (t.completion_kind === 'late') comp += ' <span style="color:#e67e22;">⌛</span>';
        var tagsHtml = (t.task_tags && t.task_tags.length)
            ? t.task_tags.slice(0, 4).map(function(x) { return '<span class="task-tag-chip">#' + escapeHtml(x) + '</span>'; }).join('')
            : '—';
        extras += '<tr>'
            + '<td class="task-cell' + (t.overdue ? ' overdue' : '') + '" style="text-align:left;">'
            + '<span class="task-ico">' + escapeHtml(t.task_icon) + '</span>' + escapeHtml(t.task_name) + ovMark + '</td>'
            + '<td style="text-align:left;">' + tagsHtml + '</td>'
            + '<td>' + escapeHtml(st) + '</td>'
            + '<td>' + escapeHtml(t.deadline || '—') + '</td>'
            + '<td>' + comp + '</td>'
            + '<td>' + (t.closed_by_count || 0) + ' / ' + t.assigned_count + '</td>'
            + '<td>' + t.assigned_count + '</td>'
            + '<td>' + t.workers_count + '</td>'
            + '<td class="total-cell">' + formatHours(t.hours) + '</td></tr>';
    });
    extras += '</tbody></table></div></div>';
    var ex = $('stExtras'); if (ex) ex.innerHTML = extras;
}
on('stApplyBtn', 'click', loadStats);
on('stMonthBtn', 'click', function() {
    if ($('stDateFrom')) $('stDateFrom').value = firstOfMonthISO(todayYM());
    if ($('stDateTo')) $('stDateTo').value = todayISO();
    loadStats();
});
on('stDeptFilter', 'change', loadStats);
on('stTeamFilter', 'change', loadStats);
on('stEmployeeFilter', 'change', loadStats);
on('stTagFilter', 'change', loadStats);

/* ============================================================
   HEATMAP
   ============================================================ */
function loadHeatmap() {
    var qs = '';
    if (state.hmDateFrom && state.hmDateTo) {
        qs = '?from=' + encodeURIComponent(state.hmDateFrom) + '&to=' + encodeURIComponent(state.hmDateTo);
    } else {
        if (!state.hmPeriod) state.hmPeriod = 'month';
        if (!state.hmAnchor) state.hmAnchor = todayISO();
        qs = '?period=' + encodeURIComponent(state.hmPeriod) + '&anchor=' + encodeURIComponent(state.hmAnchor);
    }
    if (typeof renderHmDeptPills === 'function') renderHmDeptPills();
    var dept = (window.__trkHmDepts || []).join(',');
    var team = $('hmTeamFilter') ? ($('hmTeamFilter').value || '') : '';
    if (dept) qs += '&department=' + encodeURIComponent(dept);
    if (team) qs += '&team=' + encodeURIComponent(team);
    var wrap = $('hmWrap');
    if (wrap) wrap.innerHTML = '<div class="sum-empty">Загрузка...</div>';
    apiJson('/api/tracker/heatmap' + qs)
        .then(function(d) { state.heatmap = d; renderHeatmap(); })
        .catch(function(err) {
            if (wrap) wrap.innerHTML = '<div class="sum-empty" style="color:#e74c3c;">❌ ' + escapeHtml(err.message || 'Ошибка') + '</div>';
        });
}
function renderHeatmap() {
    var d = state.heatmap;
    var wrap = $('hmWrap');
    if (!wrap) return;
    if (!d || !d.rows.length) {
        wrap.innerHTML = '<div class="sum-empty">Нет сотрудников или данных за период.</div>';
        return;
    }
    var title = $('hmMonthTitle');
    if (title) title.textContent = d.from ? (formatDateHuman(d.from) + ' — ' + formatDateHuman(d.to)) : '';
    var today = todayISO();
    var head = '<tr><th class="emp-col">Сотрудник</th>';
    d.days.forEach(function(dk) {
        var wd = new Date(dk + 'T00:00:00').getDay();
        var cls = [];
        if (wd === 0 || wd === 6) cls.push('weekend-col');
        if (dk === today) cls.push('today-col');
        head += '<th' + (cls.length ? ' class="' + cls.join(' ') + '"' : '') + ' title="' + escapeHtml(dk) + '">' + escapeHtml(formatDateShort(dk)) + '</th>';
    });
    head += '<th class="total-col">Итого</th></tr>';
    var body = '';
    d.rows.forEach(function(r) {
        body += '<tr>';
        var fired = r.employee_fired ? ' 🚪' : '';
        body += '<td class="emp-cell" data-emp="' + escapeHtml(r.employee_id) + '">'
            + '<span class="emp-dot" style="background:' + escapeHtml(r.employee_color) + ';box-shadow:0 0 6px ' + escapeHtml(r.employee_color) + ';"></span>'
            + escName(r.employee_name) + fired + '</td>';
        r.cells.forEach(function(c) {
            var cls = [], content = '', titleArr = [c.date];
            var abs = c.absence_type || (c.is_vacation ? 'vacation' : '');
            if (abs) { cls.push(absenceClass(abs) + '-cell'); titleArr.push(absenceLabel(abs)); content = absenceIcon(abs); }
            else if (c.is_holiday) { cls.push('holiday-cell'); titleArr.push('🎉 Праздник'); content = '🎉'; }
            else if (c.missing) { cls.push('missing-cell'); titleArr.push('⚠ Не заполнено'); content = '!'; }
            else if (c.is_weekend) { cls.push('weekend-cell'); titleArr.push('Выходной'); }
            else if (c.hours > 0) {
                var col = cellLightGreen(c.hours);
                titleArr.push(formatHours(c.hours));
                if (c.is_today) cls.push('today-cell');
                if (c.is_remote) cls.push('has-remote');
                var cl = cls.length ? ' class="' + cls.join(' ') + '"' : '';
                body += '<td' + cl + ' style="background:' + col + ';color:#1a9c52;font-weight:700;" '
                    + 'data-emp="' + escapeHtml(r.employee_id) + '" data-date="' + escapeHtml(c.date) + '" '
                    + 'title="' + escapeHtml(titleArr.join(' · ')) + '">' + c.hours + '</td>';
                return;
            } else { titleArr.push('—'); }
            if (c.is_today) cls.push('today-cell');
            var cl2 = cls.length ? ' class="' + cls.join(' ') + '"' : '';
            body += '<td' + cl2 + ' data-emp="' + escapeHtml(r.employee_id) + '" data-date="' + escapeHtml(c.date) + '" '
                + 'title="' + escapeHtml(titleArr.join(' · ')) + '">' + content + '</td>';
        });
        body += '<td class="total-cell">' + formatHours(r.total_hours) + '</td></tr>';
    });
    wrap.innerHTML = '<table class="hm-table"><thead>' + head + '</thead><tbody>' + body + '</tbody></table>';
    wrap.querySelectorAll('td[data-emp][data-date]').forEach(function(td) {
        if (td.classList.contains('total-cell')) return;
        if (td.classList.contains('emp-cell')) {
            td.addEventListener('click', function() {
                var empId = this.getAttribute('data-emp');
                var emp = state.employees.find(function(x) { return x.id === empId; });
                if (!emp) return;
                if (confirm('Показать календарь сотрудника «' + maskName(emp.name) + '»?')) {
                    var tabBtn = document.querySelector('.tracker-tab[data-tab="calendar"]');
                    if (tabBtn) tabBtn.click();
                    var cf = $('calEmployeeFilter');
                    if (cf) cf.value = empId;
                    state.currentEmployee = empId;
                    loadCalendar();
                }
            });
            return;
        }
        td.addEventListener('click', function() {
            openEmpDayModal(this.getAttribute('data-emp'), this.getAttribute('data-date'));
        });
    });
    var legend = $('hmLegendBar');
    if (legend) {
        var stops = [
            { label: '0',       color: 'rgba(128,128,128,0.15)' },
            { label: '2',       color: heatmapColor(2) },
            { label: '4',       color: heatmapColor(4) },
            { label: '6',       color: heatmapColor(6) },
            { label: '8',       color: heatmapColor(8) },
            { label: '10',      color: heatmapColor(10) },
            { label: '12+',     color: heatmapColor(12) }
        ];
        legend.innerHTML =
            '<div class="hm-legend-bar-row">' +
                stops.map(function(s) {
                    return '<span class="hm-legend-cell" style="background:' + s.color + ';" title="' + s.label + ' ч"></span>';
                }).join('') +
            '</div>' +
            '<div class="hm-legend-bar-labels">' +
                stops.map(function(s) {
                    return '<span class="hm-legend-bar-label">' + s.label + '</span>';
                }).join('') +
            '</div>';
    }
}
function _shiftHmPeriod(delta) {
    var anchor = state.hmAnchor || todayISO();
    var d = parseISO(anchor);
    var p = state.hmPeriod || 'month';
    if (p === 'year') d.setFullYear(d.getFullYear() + delta);
    else if (p === 'quarter') d.setMonth(d.getMonth() + delta * 3);
    else if (p === 'week') d.setDate(d.getDate() + delta * 7);
    else d.setMonth(d.getMonth() + delta);
    state.hmAnchor = isoFromDate(d);
    state.hmDateFrom = ''; state.hmDateTo = '';
    loadHeatmap();
}
on('hmPrevBtn', 'click', function() { _shiftHmPeriod(-1); });
on('hmNextBtn', 'click', function() { _shiftHmPeriod(1); });
on('hmTodayBtn', 'click', function() {
    state.hmDateFrom = ''; state.hmDateTo = '';
    if ($('hmDateFrom')) $('hmDateFrom').value = '';
    if ($('hmDateTo')) $('hmDateTo').value = '';
    state.hmAnchor = todayISO();
    loadHeatmap();
});
on('hmPeriodSeg', 'click', function(e) {
    var b = e.target.closest('button'); if (!b) return;
    this.querySelectorAll('button').forEach(function(x) { x.classList.remove('active'); });
    b.classList.add('active');
    state.hmPeriod = b.getAttribute('data-p') || 'month';
    state.hmDateFrom = ''; state.hmDateTo = '';
    if ($('hmDateFrom')) $('hmDateFrom').value = '';
    if ($('hmDateTo')) $('hmDateTo').value = '';
    loadHeatmap();
});
on('hmApplyBtn', 'click', function() {
    var f = $('hmDateFrom') ? $('hmDateFrom').value : '';
    var t = $('hmDateTo') ? $('hmDateTo').value : '';
    if (!f || !t) { notify('❌ Укажите обе даты', 'error'); return; }
    state.hmDateFrom = f; state.hmDateTo = t;
    loadHeatmap();
});
on('hmMonthBtn', 'click', function() {
    state.hmDateFrom = ''; state.hmDateTo = '';
    var t = new Date();
    var y = t.getFullYear(), m = t.getMonth() + 1;
    var last = new Date(y, m, 0).getDate();
    state.hmDateFrom = y + '-' + String(m).padStart(2, '0') + '-01';
    state.hmDateTo = y + '-' + String(m).padStart(2, '0') + '-' + String(last).padStart(2, '0');
    if ($('hmDateFrom')) $('hmDateFrom').value = state.hmDateFrom;
    if ($('hmDateTo')) $('hmDateTo').value = state.hmDateTo;
    loadHeatmap();
});
on('hmDeptFilter', 'change', loadHeatmap);
on('hmTeamFilter', 'change', loadHeatmap);

/* ============================================================
   КАРТОЧКА СОТРУДНИКА ЗА ДЕНЬ
   ============================================================ */
function openEmpDayModal(empId, dateStr) {
    apiJson('/api/tracker/employee/day?employee=' + encodeURIComponent(empId) + '&date=' + encodeURIComponent(dateStr))
        .then(function(d) {
            if (!d.success) throw new Error(d.error || 'Ошибка');
            renderEmpDayModal(d);
            var m = $('empDayModal'); if (m) m.classList.add('active');
        })
        .catch(function(err) { if (err && (err.message || '').indexOf('cancelled') !== -1) return; notify('❌ ' + (err.message || 'Ошибка'), 'error'); });
}
function renderEmpDayModal(d) {
    var emp = d.employee || {}, entries = d.entries || [];
    var badge = '';
    var abs = d.absence_type || (d.in_vacation ? 'vacation' : '');
    if (abs) {
        var cls = 'vac';
        if (abs === 'sick_leave') cls = 'sick';
        else if (abs === 'business_trip') cls = 'trip';
        else if (abs === 'remote') cls = 'remote';
        badge = '<span class="emp-day-badge ' + cls + '">' + escapeHtml(absenceLabel(abs)) + '</span>';
    } else if (d.is_workday && entries.length === 0) {
        badge = '<span class="emp-day-badge warn">⚠ Не заполнено</span>';
    } else if (entries.length > 0) {
        badge = '<span class="emp-day-badge ok">✓ Заполнено</span>';
    }
    var dept = emp.department ? ' · 🏢 ' + escapeHtml(emp.department) : '';
    var head = $('empDayHead');
    if (head) head.innerHTML = '<div class="emp-day-avatar" style="background:' + escapeHtml(emp.color || '#00897b') + ';box-shadow:0 0 12px ' + escapeHtml(emp.color || '#00897b') + ';">'
        + escapeHtml(initials(emp.name)) + '</div>'
        + '<div class="emp-day-info"><div class="emp-day-name">' + escName(emp.name || '—') + '</div>'
        + '<div class="emp-day-role">' + escapeHtml(emp.role || '') + dept + ' · ' + escapeHtml(formatDateHuman(d.date)) + '</div></div>'
        + '<div class="emp-day-stats">'
        + '<div class="emp-day-stat"><span class="val">' + formatHours(d.total_hours) + '</span><span class="lbl">часов</span></div>'
        + '<div class="emp-day-stat"><span class="val">' + entries.length + '</span><span class="lbl">задач</span></div>'
        + '</div>' + badge;
    var list = $('empDayList'); if (!list) return;
    if (!entries.length) { list.innerHTML = '<div class="day-empty">За этот день отметок нет.</div>'; return; }
    var html = '';
    var full = [];
    entries.forEach(function(en) {
        var f = Object.assign({}, en);
        f.employee_id = emp.id || '';
        f.employee_name = emp.name; f.employee_color = emp.color;
        f.employee_department = emp.department; f.date = d.date;
        full.push(f);
        html += dayEntryCard(f, false);
    });
    list.innerHTML = html;
    bindDayEntryActions(list, full);
}

/* ============================================================
   ФИЛЬТРЫ ЗАДАЧ
   ============================================================ */
on('tskDeptFilter', 'change', renderTasksFull);
on('tskTeamFilter', 'change', renderTasksFull);
on('tskEmployeeFilter', 'change', renderTasksFull);
on('tskTagFilter', 'change', renderTasksFull);
on('tskSortSelect', 'change', renderTasksFull);

on('tskGridCols', 'change', function() {
    var v = parseInt(this.value, 10) || 3;
    if (v < 1) v = 1;
    if (v > 5) v = 5;
    state.tskGridCols = v;
    try { localStorage.setItem('tracker_tsk_cols', String(v)); } catch (e) {}
    renderTasksFull();
});
(function initTskDisplay() {
    var cols = 3;
    var legacyMode = 'grid';
    try {
        legacyMode = localStorage.getItem('tracker_tsk_display') || 'grid';
        cols = parseInt(localStorage.getItem('tracker_tsk_cols') || '3', 10) || 3;
    } catch (e) {}
    if (legacyMode === 'list') cols = 1;
    if (cols < 1 || cols > 5) cols = 3;
    state.tskDisplayMode = 'grid';
    state.tskGridCols = cols;
    var wrap = $('tskColsWrap');
    if (wrap) wrap.style.display = '';
    var sel = $('tskGridCols');
    if (sel) sel.value = String(cols);
})();

/* ============================================================
   ЗАКРЫТИЕ МОДАЛОК
   ============================================================ */
document.querySelectorAll('[data-close]').forEach(function(btn) {
    btn.addEventListener('click', function() {
        var id = this.getAttribute('data-close');
        var m = $(id);
        if (m) m.classList.remove('active');
        if (id === 'dayModal') {
            var a = $('dayModalLeftActions'); if (a) a.style.display = '';
            var c = $('dayClearBtn'); if (c) c.style.display = '';
        }
    });
});
// PATCH 1.0.12: не закрываем по клику вне для ключевых модалок
var _trkNoClickClose = { dayModal: 1, logModal: 1, taskModal: 1 };
document.querySelectorAll('.modal').forEach(function(m) {
    m.addEventListener('click', function(e) {
        if (e.target === m) {
            if (_trkNoClickClose[m.id]) return;
            m.classList.remove('active');
            if (m.id === 'dayModal') {
                var a = $('dayModalLeftActions'); if (a) a.style.display = '';
                var c = $('dayClearBtn'); if (c) c.style.display = '';
            }
        }
    });
});
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal.active').forEach(function(m) { m.classList.remove('active'); });
        var a = $('dayModalLeftActions'); if (a) a.style.display = '';
        var c = $('dayClearBtn'); if (c) c.style.display = '';
    }
});

/* ============================================================
   SEGMENTED
   ============================================================ */
(function initCalViewMode() {
    var saved = 'tasks';
    try { saved = localStorage.getItem('tracker_cal_view') || 'tasks'; } catch (e) {}
    if (saved !== 'tasks' && saved !== 'employees') saved = 'tasks';
    state.calViewMode = saved;
    var wrap = $('calViewMode');
    if (wrap) {
        wrap.querySelectorAll('button').forEach(function(b) {
            b.classList.toggle('active', b.getAttribute('data-mode') === saved);
        });
    }
})();
setupSegmented('calViewMode', state.calViewMode, function(mode) {
    state.calViewMode = mode;
    try { localStorage.setItem('tracker_cal_view', mode); } catch (e) {}
    renderCalendar();
});
setupSegmented('sumViewMode', state.sumViewMode, function(mode) { state.sumViewMode = mode; loadSummary(); });
setupSegmented('sumTaskRowMode', state.sumTaskRowMode || 'full', function(mode) {
    state.sumTaskRowMode = mode;
    try { localStorage.setItem('tracker_sum_row_mode', mode); } catch (e) {}
    if (state.summaryIsGrid && state.summary) renderSummaryGrid();
});
setupSegmented('tskViewMode', state.tskViewMode, function(mode) { state.tskViewMode = mode; renderTasksFull(); });

/* ============================================================
   СТАРТ
   ============================================================ */
state.currentYM = todayYM();
state.hmYM = todayYM();
setDefaultWeekRange();
if ($('stDateFrom') && !$('stDateFrom').value) {
    $('stDateFrom').value = firstOfMonthISO(todayYM());
    $('stDateTo').value = todayISO();
}
applyPermsToUI();
if (typeof applySummaryColWidths === 'function') applySummaryColWidths();
try {
    var _rm = localStorage.getItem('tracker_sum_row_mode');
    if (_rm === 'compact' || _rm === 'full') state.sumTaskRowMode = _rm;
} catch (e) {}

loadState().then(function() {
    fillDepartmentFilters();
    fillTeamFilters();
    fillEmployeeFilter();
    if (hasPerm('tab.calendar')) loadCalendar();
});

})();
/* ============================================================
   PATCH 2026-10-06 — мультитеги, автосортировка по тегам
   ============================================================ */
(function() {
    function _initTagFilterUI() {
        ['tskTagFilter', 'sumTagFilter', 'stTagFilter'].forEach(function(id) {
            var sel = document.getElementById(id);
            if (!sel) return;
            if (document.getElementById(id + 'Pills')) return;
            var wrap = document.createElement('div');
            wrap.className = 'tag-filter-pills';
            wrap.id = id + 'Pills';
            wrap.setAttribute('data-target', id);
            sel.parentNode.insertBefore(wrap, sel);
            sel.style.display = 'none';
        });
    }
    function _renderTagPills() {
        ['tskTagFilter', 'sumTagFilter', 'stTagFilter'].forEach(function(id) {
            var wrap = document.getElementById(id + 'Pills');
            if (!wrap) return;
            var cur = (window.__trkSelectedTags && window.__trkSelectedTags[id]) || [];
            var all = Object.keys(window.__trkAllTags || {}).sort();
            if (!all.length) { wrap.innerHTML = '<span style="color:var(--trk-meta);font-size:0.72rem;">—</span>'; return; }
            var html = '';
            all.forEach(function(t) {
                var act = cur.indexOf(t) !== -1 ? ' active' : '';
                html += '<button type="button" class="tag-chip' + act + '" data-tag="' + t + '">#' + t + '</button>';
            });
            if (cur.length) {
                html += '<button type="button" class="tag-clear" title="Очистить">✕</button>';
            }
            if (cur.length > 1) {
                var mode = (window.__trkTagMode && window.__trkTagMode[id]) || 'any';
                html += '<button type="button" class="tag-mode" data-target="' + id + '" title="Логика фильтра: И (все теги) / ИЛИ (любой тег)">'
                    + (mode === 'all' ? 'И' : 'ИЛИ') + '</button>';
            }
            wrap.innerHTML = html;
            wrap.querySelectorAll('.tag-chip').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    var t = this.getAttribute('data-tag');
                    var arr = window.__trkSelectedTags[id] = window.__trkSelectedTags[id] || [];
                    var i = arr.indexOf(t);
                    if (i === -1) arr.push(t); else arr.splice(i, 1);
                    _renderTagPills();
                    var ev = { tsk: 'renderTasksFull', sum: 'loadSummary', st: 'loadStats' };
                    var pre = id.slice(0, 3);
                    if (ev[pre] && typeof window[ev[pre]] === 'function') window[ev[pre]]();
                    else if (typeof window.__trkLoadSummary === 'function') window.__trkLoadSummary();
                });
            });
            var clr = wrap.querySelector('.tag-clear');
            if (clr) clr.addEventListener('click', function() {
                window.__trkSelectedTags[id] = [];
                _renderTagPills();
                if (id.indexOf('tsk') === 0) renderTasksFull();
                else if (id.indexOf('sum') === 0 && window.__trkLoadSummary) window.__trkLoadSummary();
                else if (typeof loadStats === 'function') loadStats();
            });
            var modeBtn = wrap.querySelector('.tag-mode');
            if (modeBtn) modeBtn.addEventListener('click', function() {
                window.__trkTagMode = window.__trkTagMode || {};
                window.__trkTagMode[id] = (window.__trkTagMode[id] === 'all') ? 'any' : 'all';
                _renderTagPills();
                if (id.indexOf('tsk') === 0) renderTasksFull();
                else if (id.indexOf('sum') === 0 && window.__trkLoadSummary) window.__trkLoadSummary();
                else if (typeof loadStats === 'function') loadStats();
            });
        });
    }
    window.__trkRenderTagPills = _renderTagPills;
    window.__trkInitTagFilterUI = _initTagFilterUI;
    window.__trkSelectedTags = { tskTagFilter: [], sumTagFilter: [], stTagFilter: [] };
    window.__trkTagMode = { tskTagFilter: 'any', sumTagFilter: 'any', stTagFilter: 'any' };
    window.__trkAllTags = {};
})();
/* ============================================================
   PATCH 2026-10-06 — Свод: тулбар в 2 ряда
   ============================================================ */
(function() {
    'use strict';

    function reorganize() {
        var toolbar = document.querySelector('#panel-summary .sum-toolbar');
        if (!toolbar || toolbar.classList.contains('sum-toolbar-v2')) return;

        var $id = function(id) { return document.getElementById(id); };

        var arrowsL = toolbar.querySelectorAll('.period-arrows')[0];
        var arrowsR = toolbar.querySelectorAll('.period-arrows')[1];
        var sumGroup = toolbar.querySelector('.sum-group');
        var weekBtn = $id('sumWeekBtn');
        var monthBtn = $id('sumMonthBtn');
        var applyBtn = $id('sumApplyBtn');
        var showTotalsLabel = toolbar.querySelector('label.sum-toggle');
        var viewModeSeg = $id('sumViewMode');
        var taskRowModeSeg = $id('sumTaskRowMode');

        var filterLabels = [];
        ['sumDeptFilter', 'sumTeamFilter', 'sumEmployeeFilter', 'sumTaskFilter', 'sumTagFilter'].forEach(function(fid) {
            var el = $id(fid);
            if (!el) return;
            var lbl = el.closest('.sum-filter');
            if (lbl) filterLabels.push(lbl);
        });

        var row1 = document.createElement('div');
        row1.className = 'sum-row sum-row-1';
        var row2 = document.createElement('div');
        row2.className = 'sum-row sum-row-2';

        if (arrowsL) row1.appendChild(arrowsL);
        if (sumGroup) row1.appendChild(sumGroup);
        if (arrowsR) row1.appendChild(arrowsR);

        if (weekBtn || monthBtn || applyBtn) {
            var sep1 = document.createElement('span');
            sep1.className = 'sum-sep';
            row1.appendChild(sep1);
        }
        if (weekBtn) row1.appendChild(weekBtn);
        if (monthBtn) row1.appendChild(monthBtn);
        if (applyBtn) row1.appendChild(applyBtn);

        if (showTotalsLabel || viewModeSeg || taskRowModeSeg) {
            var sep2 = document.createElement('span');
            sep2.className = 'sum-sep';
            row1.appendChild(sep2);
        }
        if (showTotalsLabel) row1.appendChild(showTotalsLabel);
        if (viewModeSeg) row1.appendChild(viewModeSeg);
        if (taskRowModeSeg) row1.appendChild(taskRowModeSeg);

        var spacer = document.createElement('div');
        spacer.className = 'sum-spacer';
        row1.appendChild(spacer);

        filterLabels.forEach(function(lbl) { row2.appendChild(lbl); });

        toolbar.innerHTML = '';
        toolbar.appendChild(row1);
        toolbar.appendChild(row2);
        toolbar.classList.add('sum-toolbar-v2');

        var observer = new MutationObserver(function() {
            var eb = $id('excelExportBtn');
            if (eb && eb.parentNode !== row1) {
                row1.insertBefore(eb, spacer);
            }
        });
        observer.observe(toolbar, { childList: true, subtree: true });
    }

    function boot() {
        setTimeout(reorganize, 200);
        setTimeout(reorganize, 900);
        setTimeout(reorganize, 2000);
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

    document.addEventListener('click', function(e) {
        if (e.target && e.target.closest && e.target.closest('.tracker-tab[data-tab="summary"]')) {
            setTimeout(reorganize, 150);
        }
    });
})();
/* ============================================================
   PATCH 2026-10-06 — Задачи: живой поиск
   ============================================================ */
(function() {
    'use strict';

    var KEY = 'tracker_tsk_search';
    var input, clearBtn, countEl, list;
    var _t = null;

    function getQuery() {
        return input ? (input.value || '').trim().toLowerCase() : '';
    }

    function haystack(t) {
        if (!t) return '';
        var parts = [
            t.name || '',
            t.description || '',
            t.folder || '',
            t.order_ref || '',
            (t.tags || []).join(' '),
            t.id || ''
        ];
        return parts.join(' \u0001 ').toLowerCase();
    }

    function matches(hay, query) {
        if (!query) return true;
        var terms = query.split(/\s+/).filter(Boolean);
        for (var i = 0; i < terms.length; i++) {
            if (hay.indexOf(terms[i]) === -1) return false;
        }
        return true;
    }

    function getTasksMap() {
        var st = window.__trkState;
        var map = {};
        if (st && st.tasks) {
            for (var i = 0; i < st.tasks.length; i++) map[st.tasks[i].id] = st.tasks[i];
        }
        return map;
    }

    function apply() {
        if (!list) list = document.getElementById('tasksFullList');
        if (!list) return;
        var query = getQuery();
        if (clearBtn) clearBtn.style.display = query ? '' : 'none';

        var cards = list.querySelectorAll('.task-card, .dict-item');
        if (!cards.length) {
            if (countEl) countEl.textContent = '';
            return;
        }

        if (!query) {
            for (var i = 0; i < cards.length; i++) cards[i].style.display = '';
            if (countEl) countEl.textContent = '';
            return;
        }

        var map = getTasksMap();
        var shown = 0, total = cards.length;
        for (var j = 0; j < cards.length; j++) {
            var c = cards[j];
            var id = c.getAttribute('data-id');
            var t = map[id];
            if (matches(haystack(t), query)) {
                c.style.display = '';
                shown++;
            } else {
                c.style.display = 'none';
            }
        }
        if (countEl) {
            countEl.textContent = shown + ' из ' + total;
            countEl.classList.toggle('no-match', shown === 0);
        }
    }

    function onChange() {
        var v = input ? (input.value || '') : '';
        try { localStorage.setItem(KEY, v); } catch (e) {}
        if (_t) clearTimeout(_t);
        _t = setTimeout(apply, 120);
    }

    function hookList() {
        var l = document.getElementById('tasksFullList');
        if (!l || l === list) return;
        list = l;
        var obs = new MutationObserver(function() { apply(); });
        obs.observe(list, { childList: true });
        apply();
    }

    function boot() {
        input = document.getElementById('tskSearchInput');
        clearBtn = document.getElementById('tskSearchClear');
        countEl = document.getElementById('tskSearchCount');
        if (!input) return;

        try {
            var saved = localStorage.getItem(KEY);
            if (saved) input.value = saved;
        } catch (e) {}

        input.addEventListener('input', onChange);

        input.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                e.preventDefault();
                this.value = '';
                onChange();
                this.blur();
            }
        });

        if (clearBtn) clearBtn.addEventListener('click', function() {
            input.value = '';
            onChange();
            input.focus();
        });

        hookList();

        document.addEventListener('click', function(e) {
            if (e.target && e.target.closest && e.target.closest('.tracker-tab[data-tab="tasks"]')) {
                setTimeout(function() { hookList(); apply(); }, 200);
            }
        });

        document.addEventListener('keydown', function(e) {
            if (e.key !== '/' || e.ctrlKey || e.metaKey || e.altKey) return;
            var t = e.target;
            if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
            var panel = document.getElementById('panel-tasks');
            if (!panel || !panel.classList.contains('active')) return;
            e.preventDefault();
            input.focus();
            input.select();
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() { setTimeout(boot, 300); });
    } else {
        setTimeout(boot, 300);
    }
})();
/* ============================================================
   PATCH 2026-10-06 — Свод: свернуть всё / развернуть всё (v2)
   ============================================================ */
(function() {
    'use strict';

    var STORAGE = 'sum_collapsed';

    function _st() { return window.__trkState || null; }
    function _render() {
        if (window.__trkRenderSummaryGrid) window.__trkRenderSummaryGrid();
    }

    function loadCollapsed() {
        try {
            var raw = localStorage.getItem(STORAGE);
            var obj = raw ? JSON.parse(raw) : {};
            if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return {};
            return obj;
        } catch (e) { return {}; }
    }

    function saveCollapsed() {
        var st = _st();
        if (!st) return;
        try { localStorage.setItem(STORAGE, JSON.stringify(st.sumCollapsed || {})); } catch (e) {}
    }

    function initCollapsed() {
        var st = _st();
        if (!st) return;
        var saved = loadCollapsed();
        var cur = st.sumCollapsed || {};
        st.sumCollapsed = Object.assign({}, cur, saved);
    }

    function isAllCollapsed() {
        var st = _st();
        if (st && st.summary && (st.summary.rows || []).length) {
            var rows = st.summary.rows;
            var c = st.sumCollapsed || {};
            for (var i = 0; i < rows.length; i++) {
                if (!c[rows[i].employee_id]) return false;
            }
            return true;
        }
        var btns = document.querySelectorAll('#sumWrap .emp-collapse-btn');
        if (!btns.length) return false;
        var domAll = true;
        btns.forEach(function(b) { if (b.textContent.trim() !== '▶') domAll = false; });
        return domAll;
    }

    function toggleAll(force) {
        var st = _st();
        if (!st || !st.summary) return;
        var rows = st.summary.rows || [];
        if (!rows.length) return;
        var target = (typeof force === 'boolean') ? force : !isAllCollapsed();
        if (target) {
            if (!st.sumCollapsed) st.sumCollapsed = {};
            rows.forEach(function(r) {
                if (r && r.employee_id) st.sumCollapsed[r.employee_id] = true;
            });
        } else {
            st.sumCollapsed = {};
        }
        saveCollapsed();
        _render();
    }

    function updateBtn() {
        var btn = document.getElementById('sumCollapseAllBtn');
        if (!btn) return;
        var st = _st();
        var isGrid = st ? !!st.summaryIsGrid : true;
        btn.style.display = isGrid ? '' : 'none';
        var all = isAllCollapsed();
        btn.textContent = all ? '▶ Развернуть все' : '▼ Свернуть все';
        btn.title = all ? 'Развернуть все блоки сотрудников' : 'Свернуть все блоки сотрудников';
    }

    function ensureBtn() {
        var toolbar = document.querySelector('#panel-summary .sum-toolbar');
        if (!toolbar) return;
        var container = toolbar.querySelector('.sum-row-1') || toolbar;
        var btn = document.getElementById('sumCollapseAllBtn');
        if (btn && btn.getAttribute('data-v2') !== '1') {
            btn.parentNode.removeChild(btn);
            btn = null;
        }
        if (!btn) {
            btn = document.createElement('button');
            btn.id = 'sumCollapseAllBtn';
            btn.type = 'button';
            btn.setAttribute('data-v2', '1');
            btn.className = 'btn btn-secondary sum-collapse-all-btn';
            btn.addEventListener('click', function() { toggleAll(); });
            var spacer = container.querySelector('.sum-spacer');
            if (spacer) container.insertBefore(btn, spacer);
            else container.appendChild(btn);
        }
        updateBtn();
    }

    window.__trkOnSummaryRender = function() { ensureBtn(); };

    document.addEventListener('click', function(e) {
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('.emp-collapse-btn')) {
            setTimeout(saveCollapsed, 30);
            setTimeout(updateBtn, 60);
        }
        if (e.target.closest('#sumViewMode button')) {
            setTimeout(updateBtn, 150);
        }
    }, true);

    function boot() {
        initCollapsed();
        setTimeout(ensureBtn, 700);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

    window.__trkCollapseAll = { toggle: toggleAll, save: saveCollapsed, load: loadCollapsed, isAll: isAllCollapsed };
})();
/* ============================================================
   PATCH 2026-10-06 — Свод: ресайз колонки «Задача» (v2)
   ============================================================ */
(function() {
    'use strict';

    function attachTaskColResize(th) {
        if (!th || th._rszHooked) return;
        th._rszHooked = true;

        th.addEventListener('mousemove', function(e) {
            var rect = th.getBoundingClientRect();
            var dx = rect.right - e.clientX;
            th.style.cursor = (dx >= 0 && dx <= 8) ? 'col-resize' : '';
        });

        th.addEventListener('mouseleave', function() {
            th.style.cursor = '';
        });

        th.addEventListener('mousedown', function(e) {
            var rect = th.getBoundingClientRect();
            var dx = rect.right - e.clientX;
            if (dx < 0 || dx > 8) return;
            e.preventDefault();
            e.stopPropagation();

            var startX = e.clientX;
            var cs = getComputedStyle(document.documentElement);
            var startW = parseInt(cs.getPropertyValue('--sum-task-w'), 10);
            if (!isFinite(startW) || startW < 40) startW = th.offsetWidth;

            document.body.style.cursor = 'col-resize';
            document.body.style.userSelect = 'none';

            function onMove(ev) {
                var w = Math.max(120, Math.min(1200, startW + ev.clientX - startX));
                document.documentElement.style.setProperty('--sum-task-w', w + 'px');
            }
            function onUp() {
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
                document.body.style.cursor = '';
                document.body.style.userSelect = '';
                var cur = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--sum-task-w'), 10);
                if (isFinite(cur)) { try { localStorage.setItem('sum_task_w', String(cur)); } catch (er) {} }
            }
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        });
    }

    function hook() {
        var th = document.querySelector('#sumWrap thead th.task-col');
        if (th) attachTaskColResize(th);
    }

    function installObserver() {
        var wrap = document.getElementById('sumWrap');
        if (!wrap || wrap._rszObserver) return;
        wrap._rszObserver = new MutationObserver(function() { hook(); });
        wrap._rszObserver.observe(wrap, { childList: true, subtree: true });
    }

    function boot() {
        installObserver();
        setTimeout(hook, 500);
        setTimeout(hook, 1500);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

    document.addEventListener('click', function(e) {
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('.tracker-tab[data-tab="summary"]')) {
            setTimeout(function() { installObserver(); hook(); }, 250);
        }
        if (e.target.closest('#sumViewMode button')) {
            setTimeout(hook, 350);
        }
    });

    window.__trkResizeTaskCol = hook;
})();
/* ============================================================
   PATCH 2026-10-06 — Публичные helper'ы маскирования для плагинов
   ============================================================ */
(function() {
    'use strict';
    function maskFn(name) {
        var st = window.__trkState;
        if (!st || !st.maskNames) return String(name == null ? '' : name);
        var s = String(name == null ? '' : name);
        if (!s) return s;
        return s.split(/\s+/).map(function(w) {
            if (w.length <= 1) return w;
            return w[0] + new Array(w.length).join('*');
        }).join(' ');
    }
    window.__trkMaskName = maskFn;
    window.__trkMaskNames = false;
    window.__trkEscName = function(name) {
        var s = maskFn(name);
        return String(s).replace(/[&<>"']/g, function(c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
        });
    };
})();
/* ============================================================
   PATCH 2026-10-06 — Триггер перезагрузки после клика по пилюлям тегов
   ============================================================ */
(function() {
    'use strict';
    document.addEventListener('click', function(e) {
        if (!e.target || !e.target.closest) return;
        var chip = e.target.closest('.tag-filter-pills .tag-chip, .tag-filter-pills .tag-clear, .tag-filter-pills .tag-mode');
        if (!chip) return;
        var wrap = chip.closest('.tag-filter-pills');
        var target = wrap ? wrap.getAttribute('data-target') : '';
        setTimeout(function() {
            if (target === 'sumTagFilter' && window.__trkLoadSummary) window.__trkLoadSummary();
            else if (target === 'stTagFilter' && window.__trkLoadStats) window.__trkLoadStats();
            else if (target === 'tskTagFilter' && window.__trkRenderTasksFull) window.__trkRenderTasksFull();
        }, 40);
    }, true);
})();
/* ============================================================
   PATCH 2026-10-06 — Дневная карточка: вид «По сотрудникам» (плитки)
   ============================================================ */
(function() {
    'use strict';

    function _esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
        });
    }
    function _initials(name) {
        var parts = String(name || '').trim().split(/\s+/);
        if (!parts.length) return '?';
        if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
        return (parts[0][0] + (parts[1][0] || '')).toUpperCase();
    }
    function _fmtH(h) {
        h = Number(h) || 0;
        if (h === Math.floor(h)) return h + ' ч';
        return h.toFixed(2).replace(/0+$/, '').replace(/\.$/, '') + ' ч';
    }
    function _mask(name) {
        var st = window.__trkState;
        if (!st || !st.maskNames) return name;
        return String(name == null ? '' : name).split(/\s+/).map(function(w) {
            if (w.length <= 1) return w;
            return w[0] + new Array(w.length).join('*');
        }).join(' ');
    }

    window.__trkRenderDayByEmployee = function(entries, totalHours, day) {
        var listEl = document.getElementById('dayList');
        if (!listEl) return false;
        if (!entries || !entries.length) return false;

        var byEmp = {};
        entries.forEach(function(en) {
            var eid = en.employee_id || '?';
            if (!byEmp[eid]) {
                byEmp[eid] = {
                    id: eid,
                    name: en.employee_name || '',
                    color: en.employee_color || '#888',
                    dept: en.employee_department || '',
                    tasks: [],
                    total: 0
                };
            }
            byEmp[eid].tasks.push(en);
            byEmp[eid].total += parseFloat(en.hours) || 0;
        });

        var emps = Object.keys(byEmp).map(function(k) { return byEmp[k]; });
        emps.sort(function(a, b) { return b.total - a.total; });

        var html = '<div class="day-emp-tiles">';
        emps.forEach(function(e) {
            var bg = _esc(e.color);
            html += '<div class="day-emp-tile" style="--det-accent:' + bg + ';">'
                + '<div class="det-head">'
                +   '<div class="det-avatar" style="background:' + bg + ';">' + _esc(_initials(e.name)) + '</div>'
                +   '<div class="det-meta">'
                +     '<div class="det-name">' + _esc(_mask(e.name)) + '</div>'
                +     (e.dept ? '<div class="det-dept">🏢 ' + _esc(e.dept) + '</div>' : '')
                +   '</div>'
                +   '<div class="det-total">' + _fmtH(e.total) + '</div>'
                + '</div>'
                + '<div class="det-tasks">';
            e.tasks.sort(function(a, b) { return (parseFloat(b.hours) || 0) - (parseFloat(a.hours) || 0); });
            e.tasks.forEach(function(t) {
                html += '<div class="det-task" data-id="' + t.id + '">'
                    + '<span class="det-task-ico">' + _esc(t.task_icon || '📋') + '</span>'
                    + '<span class="det-task-name' + (t.overdue ? ' overdue' : '') + '" title="' + _esc(t.comment || '') + '">' + _esc(t.task_name || '') + '</span>'
                    + '<span class="det-task-hours">' + _fmtH(t.hours) + '</span>'
                    + '</div>';
            });
            html += '</div></div>';
        });
        html += '</div>';
        listEl.innerHTML = html;
        return true;
    };

    document.addEventListener('click', function(e) {
        if (!e.target || !e.target.closest) return;
        var btn = e.target.closest('#dayViewMode button');
        if (!btn) return;
        var mode = btn.getAttribute('data-mode');
        if (mode !== 'task' && mode !== 'employee') return;
        var st = window.__trkState;
        if (!st) return;
        st.dayViewMode = mode;
        if (mode === 'employee') {
            st.dayViewEmployeeId = (st.currentUser && st.currentUser.employee_id) || '';
        } else {
            st.dayViewEmployeeId = '';
        }
        try { localStorage.setItem('tracker_day_view', mode); } catch (er) {}
        var wrap = document.getElementById('dayViewMode');
        if (wrap) wrap.querySelectorAll('button').forEach(function(b) {
            b.classList.toggle('active', b.getAttribute('data-mode') === mode);
        });
        if (window.__trkOpenDayModal && st.currentDay) {
            window.__trkOpenDayModal(st.currentDay);
        }
    });

    setTimeout(function() {
        var st = window.__trkState;
        var wrap = document.getElementById('dayViewMode');
        if (!wrap || !st) return;
        var m = st.dayViewMode || 'task';
        wrap.querySelectorAll('button').forEach(function(b) {
            b.classList.toggle('active', b.getAttribute('data-mode') === m);
        });
    }, 400);
})();
/* ============================================================
   PATCH 2026-10-06 — Создать задачу из карточки дня
   ============================================================ */
(function() {
    'use strict';

    function looksLikeCreateTask(btn) {
        if (!btn) return false;
        var id = (btn.id || '').toLowerCase();
        if (id === 'daycreatetaskbtn' || id === 'dayaddtaskbtn' || id === 'daynewtaskbtn' || id === 'createtaskfromday') return true;
        if (btn.getAttribute && btn.getAttribute('data-act') === 'new-task-from-day') return true;
        var t = (btn.textContent || '').trim().toLowerCase();
        if (!t) return false;
        if (/новая\s*задач|создать\s*задач|\+\s*задач|добавить\s*задач/.test(t)) return true;
        return false;
    }

    document.addEventListener('click', function(e) {
    if (window.__trkLogTaskFromLogV3) return;
    if (!e.target || !e.target.closest) return;
    var dayModal = document.getElementById('dayModal');
    if (!dayModal || !dayModal.classList.contains('active')) return;
        var btn = e.target.closest('button');
        if (!btn) return;
        if (btn.id === 'addTaskBtn' || btn.id === 'addTaskBtn2') return;
        if (!looksLikeCreateTask(btn)) return;

        e.preventDefault();
        e.stopPropagation();

        var st = window.__trkState;
        var dk = st && st.currentDay;

        dayModal.classList.remove('active');

        if (typeof window.__trkOpenTaskModal === 'function') {
            window.__trkOpenTaskModal(null);
        } else {
            var alt = document.getElementById('addTaskBtn2') || document.getElementById('addTaskBtn');
            if (alt) alt.click();
        }
        if (dk) window.__trkPendingDayReopen = dk;
    }, true);

    function attachObserver() {
        var taskModal = document.getElementById('taskModal');
        if (!taskModal || taskModal._reopenHooked) return;
        taskModal._reopenHooked = true;
        var obs = new MutationObserver(function() {
            var isOpen = taskModal.classList.contains('active');
            if (isOpen) return;
            if (!window.__trkPendingDayReopen) return;
            var dk = window.__trkPendingDayReopen;
            window.__trkPendingDayReopen = null;
            setTimeout(function() {
                if (typeof window.__trkOpenDayModal === 'function') {
                    window.__trkOpenDayModal(dk);
                }
            }, 800);
        });
        obs.observe(taskModal, { attributes: true, attributeFilter: ['class'] });
    }

    function boot() { setTimeout(attachObserver, 400); }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
/* ============================================================
   PATCH 2026-10-06 — Кнопка «Новая задача» в карточке отметки
   ============================================================ */
(function() {
    'use strict';

    function hasPerm(k) {
        return !!(window.REESTR_PERMS && window.REESTR_PERMS[k]);
    }

    function looksLikeCreateTask(btn) {
        if (!btn || !btn.closest) return false;
        if (btn.id === 'logCreateTaskBtn') return true;
        if (btn.classList.contains('log-create-task-btn')) return true;
        var t = (btn.textContent || '').trim().toLowerCase();
        if (!t) return false;
        return /новая\s*задач|создать\s*задач|\+\s*задач|добавить\s*задач/.test(t);
    }

    function ensureButton() {
        var logModal = document.getElementById('logModal');
        if (!logModal) return;
        var btn = logModal.querySelector('.log-create-task-btn, #logCreateTaskBtn');
        if (!btn) {
            var select = document.getElementById('log_task');
            if (!select) return;
            btn = document.createElement('button');
            btn.type = 'button';
            btn.id = 'logCreateTaskBtn';
            btn.className = 'log-create-task-btn';
            btn.textContent = '➕ Новая задача';
            btn.title = 'Создать задачу и вернуться к заполнению отметки';
            if (select.parentNode) {
                select.parentNode.insertBefore(btn, select.nextSibling);
            }
        }
        btn.style.display = hasPerm('action.task.create') ? '' : 'none';
    }

    function captureLogState() {
        var g = function(id) { var el = document.getElementById(id); return el ? el.value : ''; };
        return {
            id: g('log_id'),
            date: g('log_date'),
            hours: g('log_hours'),
            employee_id: g('log_employee'),
            status: g('log_status'),
            comment: g('log_comment'),
            link: g('log_link'),
            task_id: g('log_task')
        };
    }

    function reopenLogFrom(s, newTaskId) {
        if (!s) return;
        var fake = {
            id: s.id || null,
            employee_id: s.employee_id || '',
            task_id: newTaskId || s.task_id || '',
            date: s.date || '',
            hours: parseFloat(s.hours) || (window.__trkGetDayNorm ? window.__trkGetDayNorm(s.date) : 8),
            status: s.status || 'in_progress',
            comment: s.comment || '',
            link: s.link || ''
        };
        if (typeof window.__trkOpenLogModal === 'function') {
            window.__trkOpenLogModal(fake);
            setTimeout(function() {
                var t = document.getElementById('log_task');
                if (t && newTaskId) t.value = newTaskId;
                var h = document.getElementById('log_hours');
                if (h) h.focus();
            }, 80);
        }
    }

    function setupTaskModalObserver() {
        var taskModal = document.getElementById('taskModal');
        if (!taskModal || taskModal._logReopenHooked) return;
        taskModal._logReopenHooked = true;
        var obs = new MutationObserver(function() {
            if (taskModal.classList.contains('active')) return;
            if (!window.__trkPendingLogState) return;
            var s = window.__trkPendingLogState;
            var beforeIds = window.__trkPendingLogTaskIdsBefore || [];
            window.__trkPendingLogState = null;
            window.__trkPendingLogTaskIdsBefore = null;

            var waited = 0;
            var step = 200;
            var timer = setInterval(function() {
                waited += step;
                var st = window.__trkState;
                var tasks = (st && st.tasks) || [];
                var afterIds = tasks.map(function(t) { return t.id; });
                var newId = null;
                var seen = {};
                beforeIds.forEach(function(x) { seen[x] = true; });
                for (var i = 0; i < afterIds.length; i++) {
                    if (!seen[afterIds[i]]) { newId = afterIds[i]; break; }
                }
                if (newId || waited >= 2500) {
                    clearInterval(timer);
                    reopenLogFrom(s, newId);
                }
            }, step);
        });
        obs.observe(taskModal, { attributes: true, attributeFilter: ['class'] });
    }

    document.addEventListener('click', function(e) {
    if (window.__trkLogTaskFromLogV3) return;
    if (!e.target || !e.target.closest) return;
    var logModal = document.getElementById('logModal');
    if (!logModal || !logModal.classList.contains('active')) return;
        var btn = e.target.closest('button');
        if (!btn) return;
        if (!looksLikeCreateTask(btn)) return;
        if (!hasPerm('action.task.create')) {
            e.preventDefault();
            e.stopPropagation();
            return;
        }

        e.preventDefault();
        e.stopPropagation();

        var st = window.__trkState;
        var beforeIds = st && st.tasks ? st.tasks.map(function(t) { return t.id; }) : [];
        window.__trkPendingLogState = captureLogState();
        window.__trkPendingLogTaskIdsBefore = beforeIds;

        logModal.classList.remove('active');

        if (typeof window.__trkOpenTaskModal === 'function') {
            window.__trkOpenTaskModal(null);
        } else {
            var alt = document.getElementById('addTaskBtn2') || document.getElementById('addTaskBtn');
            if (alt) alt.click();
        }
    }, true);

    function boot() {
        ensureButton();
        setupTaskModalObserver();
        setTimeout(ensureButton, 700);
        setTimeout(setupTaskModalObserver, 800);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

    document.addEventListener('click', function(e) {
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('#dayAddBtn')) {
            setTimeout(ensureButton, 200);
        }
    });

    window.__trkEnsureLogTaskBtn = ensureButton;
})();
/* ============================================================
   PATCH 2026-10-06 — Чистка дублей кнопки «Новая задача» в карточке отметки
   v2: расширен regex — теперь удаляем также «➕ Задача» (старая формулировка).
   ============================================================ */
(function() {
    'use strict';

    // PATCH: расширенный regex — добавлен вариант «задача» без слова «нов»
    function looksLikeCreateTask(text) {
        var t = String(text || '').trim().toLowerCase();
        if (!t) return false;
        return /новая\s*задач|создать\s*задач|\+\s*задач|➕\s*задач|добавить\s*задач|задача/i.test(t);
    }

    function cleanup() {
        var logModal = document.getElementById('logModal');
        if (!logModal) return;
        logModal.querySelectorAll('button').forEach(function(b) {
            if (b.id === 'logCreateTaskBtn') return;
            if (b.classList.contains('log-create-task-btn')) return;
            if (!looksLikeCreateTask(b.textContent)) return;
            // Не трогаем кнопки в modal-actions (Отмена/Сохранить)
            if (b.closest('.modal-actions')) return;
            b.remove();
        });
    }

    function attachObserver() {
        var logModal = document.getElementById('logModal');
        if (!logModal || logModal._cleanupHooked) return;
        logModal._cleanupHooked = true;
        var obs = new MutationObserver(function() { cleanup(); });
        obs.observe(logModal, { childList: true, subtree: true });
        cleanup();
    }

    function boot() {
        attachObserver();
        setTimeout(cleanup, 500);
        setTimeout(cleanup, 1500);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

    document.addEventListener('click', function(e) {
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('#dayAddBtn')) setTimeout(cleanup, 200);
    });

    window.__trkCleanupLogTaskBtns = cleanup;
})();
/* ============================================================
   PATCH 2026-10-06 — V3: единый обработчик «Новая задача» из карточки отметки
   v2: расширен regex — подхватывает также «➕ Задача».
   ============================================================ */
(function() {
    'use strict';

    var V3_FLAG = '__trkLogTaskFromLogV3';
    var _state = null;
    var _beforeIds = [];
    var _pollTimer = null;
    var _restoreTimer = null;

    function hasPerm(k) {
        return !!(window.REESTR_PERMS && window.REESTR_PERMS[k]);
    }

    // PATCH: расширен regex — подхватывает «➕ Задача»
    function looksLikeCreateTask(text) {
        var t = String(text || '').trim().toLowerCase();
        if (!t) return false;
        return /новая\s*задач|создать\s*задач|\+\s*задач|➕\s*задач|добавить\s*задач|нов(ая|ую)\s*задач|задача/i.test(t);
    }

    function isOurButton(b) {
        return b.id === 'logCreateTaskBtn' || (b.classList && b.classList.contains('log-create-task-btn'));
    }

    function cleanupButtons() {
        var logModal = document.getElementById('logModal');
        if (!logModal) return;
        logModal.querySelectorAll('button').forEach(function(b) {
            if (isOurButton(b)) return;
            if (!looksLikeCreateTask(b.textContent)) return;
            if (b.closest('.modal-actions')) return;
            b.remove();
        });
    }

    function ensureButton() {
        var logModal = document.getElementById('logModal');
        if (!logModal) return;
        var btn = logModal.querySelector('#logCreateTaskBtn');
        if (!btn) {
            // PATCH: если в HTML уже есть #logCreateTaskBtn (новый tracker.html) — не пересоздаём
            // Если нет — создаём рядом с .log-task-wrap
            var wrap = logModal.querySelector('.log-task-wrap');
            var select = document.getElementById('log_task');
            var anchor = wrap || (select ? select.parentNode : null);
            if (!anchor) return;
            btn = document.createElement('button');
            btn.type = 'button';
            btn.id = 'logCreateTaskBtn';
            btn.className = 'log-create-task-btn';
            btn.textContent = '➕ Новая задача';
            btn.title = 'Создать задачу и вернуться к заполнению отметки';
            if (anchor.parentNode) {
                anchor.parentNode.insertBefore(btn, anchor.nextSibling);
            }
        }
        btn.style.display = hasPerm('action.task.create') ? '' : 'none';
        cleanupButtons();
    }

    function captureLogState() {
        var g = function(id) { var el = document.getElementById(id); return el ? el.value : ''; };
        return {
            id: g('log_id'),
            date: g('log_date'),
            hours: g('log_hours'),
            employee_id: g('log_employee'),
            status: g('log_status'),
            comment: g('log_comment'),
            link: g('log_link'),
            task_id: g('log_task')
        };
    }

    function reopenLogFrom(s, newTaskId) {
        if (!s) return;
        var fake = {
            id: s.id || null,
            employee_id: s.employee_id || '',
            task_id: newTaskId || s.task_id || '',
            date: s.date || '',
            hours: parseFloat(s.hours) || (window.__trkGetDayNorm ? window.__trkGetDayNorm(s.date) : 8),
            status: s.status || 'in_progress',
            comment: s.comment || '',
            link: s.link || ''
        };
        if (typeof window.__trkOpenLogModal === 'function') {
            window.__trkOpenLogModal(fake);
            setTimeout(function() {
                var t = document.getElementById('log_task');
                if (t && newTaskId) t.value = newTaskId;
                var h = document.getElementById('log_hours');
                if (h) h.focus();
                ensureButton();
                if (window.__trkDayWasOpenForLogV3) {
                    var _dm = document.getElementById('dayModal');
                    if (_dm) _dm.classList.add('active');
                    window.__trkDayWasOpenForLogV3 = false;
                }
            }, 80);
        }
    }

    function findNewTaskId(beforeIds) {
        var st = window.__trkState;
        var tasks = (st && st.tasks) || [];
        var seen = {};
        beforeIds.forEach(function(x) { seen[x] = true; });
        for (var i = 0; i < tasks.length; i++) {
            if (!seen[tasks[i].id]) return tasks[i].id;
        }
        return null;
    }

    function tryRestore(ctx) {
        if (_restoreTimer) { clearInterval(_restoreTimer); _restoreTimer = null; }
        var waited = 0;
        var step = 150;
        _restoreTimer = setInterval(function() {
            waited += step;
            var newId = findNewTaskId(ctx.beforeIds);
            if (newId || waited >= 2500) {
                clearInterval(_restoreTimer); _restoreTimer = null;
                reopenLogFrom(ctx.state, newId);
            }
        }, step);
    }

    function startWaiting(logState, beforeIds) {
        if (_pollTimer) { clearInterval(_pollTimer); _pollTimer = null; }
        if (_restoreTimer) { clearInterval(_restoreTimer); _restoreTimer = null; }
        _state = logState;
        _beforeIds = beforeIds;

        var taskModal = document.getElementById('taskModal');
        if (!taskModal) return;

        var sawActive = false;
        var startedAt = Date.now();

        _pollTimer = setInterval(function() {
            var isActive = taskModal.classList.contains('active');
            if (!sawActive) {
                if (isActive) {
                    sawActive = true;
                } else if (Date.now() - startedAt > 3000) {
                    clearInterval(_pollTimer); _pollTimer = null;
                    var s = _state; _state = null; _beforeIds = [];
                    if (s) reopenLogFrom(s, null);
                }
                return;
            }
            if (!isActive) {
                clearInterval(_pollTimer); _pollTimer = null;
                var ctxState = _state;
                var ctxIds = _beforeIds;
                _state = null; _beforeIds = [];
                setTimeout(function() { tryRestore({ state: ctxState, beforeIds: ctxIds }); }, 400);
            } else if (Date.now() - startedAt > 5 * 60000) {
                clearInterval(_pollTimer); _pollTimer = null;
                _state = null; _beforeIds = [];
            }
        }, 200);
    }

    window.addEventListener('click', function(e) {
        if (!e.target || !e.target.closest) return;
        var logModal = document.getElementById('logModal');
        if (!logModal || !logModal.classList.contains('active')) return;
        var btn = e.target.closest('button');
        if (!btn) return;
        if (!isOurButton(btn) && !looksLikeCreateTask(btn.textContent)) return;

        if (!hasPerm('action.task.create')) {
            window[V3_FLAG] = true;
            setTimeout(function() { window[V3_FLAG] = false; }, 500);
            e.preventDefault();
            e.stopPropagation();
            return;
        }

        window[V3_FLAG] = true;
        setTimeout(function() { window[V3_FLAG] = false; }, 500);

        e.preventDefault();
        e.stopPropagation();

        if (window.__trkOpeningTaskFromLogV3) return;
        window.__trkOpeningTaskFromLogV3 = true;
        setTimeout(function() { window.__trkOpeningTaskFromLogV3 = false; }, 800);

        window.__trkPendingLogState = null;
        window.__trkPendingDayReopen = null;

        var st = window.__trkState;
        var beforeIds = st && st.tasks ? st.tasks.map(function(t) { return t.id; }) : [];
        var logState = captureLogState();

        var _dayModal = document.getElementById('dayModal');
        var _dayWasOpen = _dayModal && _dayModal.classList.contains('active');
        window.__trkDayWasOpenForLogV3 = _dayWasOpen;
        if (_dayWasOpen) _dayModal.classList.remove('active');

        logModal.classList.remove('active');

        if (typeof window.__trkOpenTaskModal === 'function') {
            window.__trkOpenTaskModal(null);
        } else {
            var alt = document.getElementById('addTaskBtn2') || document.getElementById('addTaskBtn');
            if (alt) alt.click();
        }

        startWaiting(logState, beforeIds);
    }, true);

    function attachObserver() {
        var logModal = document.getElementById('logModal');
        if (!logModal || logModal._v3Hooked) return;
        logModal._v3Hooked = true;
        var obs = new MutationObserver(function() {
            if (logModal.classList.contains('active')) {
                ensureButton();
            }
        });
        obs.observe(logModal, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
    }

    function boot() {
        attachObserver();
        setTimeout(ensureButton, 400);
        setTimeout(ensureButton, 1200);
        setTimeout(cleanupButtons, 2000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

    document.addEventListener('click', function(e) {
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('#dayAddBtn')) {
            setTimeout(ensureButton, 200);
            setTimeout(cleanupButtons, 400);
        }
    });

    window.__trkEnsureLogTaskBtnV3 = ensureButton;
})();
/* ============================================================
   PATCH 05 — Минимум 0.5 ч. Диалог переработки полностью 
   удалён — его заменяет PATCH 07. Раньше перехват fetch здесь 
   стоял выше в цепочке и перекрывал улучшенный диалог PATCH 07.
   ============================================================ */
(function() {
    'use strict';

    function setMin() {
        var h = document.getElementById('log_hours');
        if (h) { h.min = '0.5'; h.step = '0.25'; }
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', setMin);
    } else {
        setMin();
    }
    setTimeout(setMin, 500);
    setTimeout(setMin, 1500);
})();
/* ============================================================
   PATCH 07 — Модалка переработки v2 (единственный перехватчик 
   fetch для log/save — PATCH 05 уже удалён).
   PATCH v3: inline z-index 9000 для гарантии поверх logModal 
   независимо от CSS-каскада и кеша.
   ============================================================ */
(function() {
    'use strict';

    var SESSION_KEY = 'tracker_overflow_choice_v2';

    function getStored() {
        try { return sessionStorage.getItem(SESSION_KEY) || ''; }
        catch (e) { return ''; }
    }
    function setStored(v) {
        try {
            if (v) sessionStorage.setItem(SESSION_KEY, v);
            else sessionStorage.removeItem(SESSION_KEY);
        } catch (e) {}
    }

    function setMin() {
        var h = document.getElementById('log_hours');
        if (h) { h.min = '0.5'; h.step = '0.25'; }
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', setMin);
    } else { setMin(); }
    setTimeout(setMin, 400);
    setTimeout(setMin, 1200);

    function getModal() {
        var m = document.getElementById('trkOverflowModal');
        if (m) return m;
        m = document.createElement('div');
        m.id = 'trkOverflowModal';
        m.className = 'modal trk-overflow-modal';
        // PATCH v3: inline z-index 9000 с !important — гарантированно 
        // поверх любой модалки (logModal = 5000, taskModal = 5500, карточки = 5300).
        m.style.setProperty('z-index', '9000', 'important');
        m.innerHTML = [
            '<div class="modal-content ov-modal">',
            '  <div class="ov-head">',
            '    <span class="ov-icon">⚠</span>',
            '    <div class="ov-title-block">',
            '      <div class="ov-title">Превышение 8 часов за день</div>',
            '      <div class="ov-sub" id="trkOvSub"></div>',
            '    </div>',
            '  </div>',
            '  <div class="ov-numbers" id="trkOvNumbers"></div>',
            '  <div class="ov-note">',
            '    <b>Принять</b> — сохранить как введено. <b>Распределить</b> — поделить 8 часов между всеми задачами дня поровну.',
            '  </div>',
            '  <label class="ov-remember">',
            '    <input type="checkbox" id="trkOvRemember">',
            '    <span>Запомнить выбор на эту сессию</span>',
            '  </label>',
            '  <div class="ov-forget" id="trkOvForgetWrap" style="display:none;">',
            '    Сохранено: <b id="trkOvForgetVal"></b> · <a href="#" id="trkOvForget">забыть</a>',
            '  </div>',
            '  <div class="ov-actions">',
            '    <button type="button" class="btn btn-secondary" data-ov="cancel">Закрыть</button>',
            '    <button type="button" class="btn btn-secondary" data-ov="distribute">Распределить поровну</button>',
            '    <button type="button" class="btn btn-primary" data-ov="accept">Принять переработку</button>',
            '  </div>',
            '</div>'
        ].join('');
        document.body.appendChild(m);
		m.style.setProperty('z-index', '9000', 'important');
        return m;
    }

    function syncForget(m) {
        var stored = getStored();
        var wrap = m.querySelector('#trkOvForgetWrap');
        var valEl = m.querySelector('#trkOvForgetVal');
        if (!wrap || !valEl) return;
        if (stored) {
            wrap.style.display = '';
            valEl.textContent = stored === 'accept' ? 'принять переработку' : 'распределить поровну';
        } else {
            wrap.style.display = 'none';
        }
    }

    function showDialog(info) {
        return new Promise(function(resolve) {
            var m = getModal();
            // PATCH v3: при каждом показе гарантируем inline z-index (вдруг кто-то перезаписал)
            m.style.setProperty('z-index', '9000', 'important');
            var sub = m.querySelector('#trkOvSub');
            var nums = m.querySelector('#trkOvNumbers');
            var remember = m.querySelector('#trkOvRemember');

            if (sub) sub.textContent = (info.employee_name || 'Сотрудник') + ' · ' + (info.date || '');

            var over = info.total - 8;
            var fh = function(x) {
                var v = Math.round(x * 100) / 100;
                return (v === Math.floor(v) ? v : v.toFixed(2).replace(/0+$/, '').replace(/\.$/, '')) + ' ч';
            };
            nums.innerHTML = [
                '<div class="ov-num-row"><span class="ov-num-label">Уже за день</span><span class="ov-num-val">' + fh(info.sum_existing) + '</span></div>',
                '<div class="ov-num-row"><span class="ov-num-label">Новая отметка</span><span class="ov-num-val">' + fh(info.new_hours) + '</span></div>',
                '<div class="ov-num-sep"></div>',
                '<div class="ov-num-row ov-num-total"><span class="ov-num-label">Итого будет</span><span class="ov-num-val ov-danger">' + fh(info.total) + '</span></div>',
                '<div class="ov-num-row ov-num-warn"><span class="ov-num-label">Переработка</span><span class="ov-num-val">' + fh(over) + '</span></div>'
            ].join('');

            syncForget(m);
            if (remember) remember.checked = !!getStored();

            var forget = m.querySelector('#trkOvForget');
            if (forget) forget.onclick = function(ev) {
                ev.preventDefault();
                setStored('');
                syncForget(m);
                if (remember) remember.checked = false;
            };

            m.classList.add('active');
            var resolved = false;
            function finish(choice) {
                if (resolved) return;
                resolved = true;
                m.classList.remove('active');
                m.removeEventListener('click', onClick);
                if (choice !== 'cancel' && remember && remember.checked) {
                    setStored(choice);
                } else if (remember && !remember.checked) {
                    setStored('');
                }
                resolve(choice);
            }
            function onClick(e) {
                if (e.target === m) { finish('cancel'); return; }
                var b = e.target.closest && e.target.closest('[data-ov]');
                if (!b) return;
                finish(b.getAttribute('data-ov'));
            }
            m.addEventListener('click', onClick);
        });
    }

    function parseErr(status, body, wantHours) {
        if (!body) return null;
        if (status === 409 && body.error === 'daily_overflow') return body;
        if (status === 400 && typeof body.error === 'string' && body.error.indexOf('Лимит 8') !== -1) {
            var m1 = body.error.match(/Уже занято:\s*([\d.,]+)/);
            var se = m1 ? parseFloat(m1[1]) : 0;
            return {
                error: 'daily_overflow',
                sum_existing: se,
                new_hours: wantHours,
                total: se + wantHours,
                employee_name: '',
                date: ''
            };
        }
        return null;
    }

    // PATCH v3: единственный перехватчик fetch для log/save.
    // Никакого _prevFetch — используем только нативный fetch.
    var _nativeFetch = window.fetch;
    if (_nativeFetch && !window.__trkOverflowModalV2) {
        window.__trkOverflowModalV2 = true;
        window.fetch = function(url, opts) {
            if (typeof url !== 'string' || url.indexOf('/api/tracker/log/save') === -1) {
                return _nativeFetch.apply(this, arguments);
            }
            if (!opts || (opts.method || 'GET').toUpperCase() !== 'POST') {
                return _nativeFetch.apply(this, arguments);
            }
            var wantHours = 0;
            try { wantHours = parseFloat(JSON.parse(opts.body || '{}').hours) || 0; } catch (e) {}

            var self = this;
            return _nativeFetch.apply(this, arguments).then(function(resp) {
                if (resp.status !== 409 && resp.status !== 400) return resp;
                return resp.clone().json().then(function(d) {
                    var info = parseErr(resp.status, d, wantHours);
                    if (!info) {
                        return new Response(JSON.stringify(d || {success:false}), {
                            status: resp.status,
                            headers: {'Content-Type': 'application/json'}
                        });
                    }
                    if (!info.employee_name) {
                        try {
                            var st = window.__trkState;
                            var body = JSON.parse(opts.body || '{}');
                            if (st && st.employees && body.employee_id) {
                                var emp = st.employees.find(function(e) { return e.id === body.employee_id; });
                                if (emp) info.employee_name = emp.name;
                            }
                            if (!info.date) info.date = body.date || '';
                        } catch (e) {}
                    }

                    var stored = getStored();
                    var choiceP = (stored === 'accept' || stored === 'distribute')
                        ? Promise.resolve(stored)
                        : showDialog(info);

                    return choiceP.then(function(choice) {
                        if (choice === 'cancel') {
                            return new Response(JSON.stringify({
                                success: false,
                                error: 'cancelled'
                            }), { status: 200, headers: {'Content-Type': 'application/json'} });
                        }
                        var payload;
                        try { payload = JSON.parse(opts.body || '{}'); } catch (e) { payload = {}; }
                        payload.overflow_action = (choice === 'accept') ? 'accept' : 'distribute';
                        var newOpts = Object.assign({}, opts, { body: JSON.stringify(payload) });
                        return _nativeFetch.call(self, url, newOpts);
                    });
                });
            });
        };
    }
})();
/* ============================================================
   PATCH 08 — Удаление отметки с перераспределением часов
   ============================================================ */
(function() {
    'use strict';

    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
        });
    }
    function fmtH(x) {
        var v = Math.round((Number(x) || 0) * 100) / 100;
        if (v === Math.floor(v)) return v + ' ч';
        return v.toFixed(2).replace(/0+$/, '').replace(/\.$/, '') + ' ч';
    }

    function getModal() {
        var m = document.getElementById('trkDeleteLogModal');
        if (m) return m;
        m = document.createElement('div');
        m.id = 'trkDeleteLogModal';
        m.className = 'modal trk-del-log-modal';
        // PATCH v3: inline z-index — гарантированно поверх logModal
        m.style.setProperty('z-index', '9000', 'important');
        m.innerHTML = [
            '<div class="modal-content dl-modal">',
            '  <div class="dl-head">',
            '    <span class="dl-icon">🗑</span>',
            '    <div class="dl-title-block">',
            '      <div class="dl-title">Удалить отметку?</div>',
            '      <div class="dl-sub" id="trkDlSub"></div>',
            '    </div>',
            '  </div>',
            '  <div class="dl-info" id="trkDlInfo"></div>',
            '  <div class="dl-question" id="trkDlQuestion"></div>',
            '  <div class="dl-actions">',
            '    <button type="button" class="btn btn-secondary" data-dl="cancel">Закрыть</button>',
            '    <button type="button" class="btn btn-secondary" data-dl="keep">Оставить как есть</button>',
            '    <button type="button" class="btn btn-primary" data-dl="redistribute">Перераспределить поровну</button>',
            '  </div>',
            '</div>'
        ].join('');
        document.body.appendChild(m);
		m.style.setProperty('z-index', '9000', 'important');
        return m;
    }

    function showDialog(info) {
        return new Promise(function(resolve) {
            var m = getModal();
            var sub = m.querySelector('#trkDlSub');
            var infoEl = m.querySelector('#trkDlInfo');
            var qEl = m.querySelector('#trkDlQuestion');
            if (sub) sub.textContent = (info.employee_name || '') + ' · ' + (info.date || '');
            if (infoEl) {
                infoEl.innerHTML = [
                    '<div class="dl-row"><span class="dl-label">Задача</span><span class="dl-val">' + esc(info.task_name || '') + '</span></div>',
                    '<div class="dl-row"><span class="dl-label">Часы</span><span class="dl-val dl-danger">' + fmtH(info.hours) + '</span></div>'
                ].join('');
            }
            if (qEl) {
                qEl.innerHTML = 'У сотрудника остаётся <b>' + info.remaining.length + '</b> задач(и) на <b>' +
                    fmtH(info.remaining_hours) + '</b>.<br>' +
                    'Что сделать с освободившимися <b>' + fmtH(info.hours) + '</b>?';
            }
			m.style.setProperty('z-index', '9000', 'important');
            m.classList.add('active');
            var resolved = false;
            function finish(choice) {
                if (resolved) return;
                resolved = true;
                m.classList.remove('active');
                m.removeEventListener('click', onClick);
                resolve(choice);
            }
            function onClick(e) {
                if (e.target === m) { finish('cancel'); return; }
                var b = e.target.closest && e.target.closest('[data-dl]');
                if (!b) return;
                finish(b.getAttribute('data-dl'));
            }
            m.addEventListener('click', onClick);
        });
    }

    function findInfo(logId) {
        var st = window.__trkState;
        if (!st || !st.calendar || !st.calendar.days) return null;
        for (var i = 0; i < st.calendar.days.length; i++) {
            var day = st.calendar.days[i];
            var entries = day.entries || [];
            var target = null;
            for (var j = 0; j < entries.length; j++) {
                if (entries[j].id === logId) { target = entries[j]; break; }
            }
            if (!target) continue;
            var empId = target.employee_id;
            var same = entries.filter(function(e) {
                return e.employee_id === empId && e.id !== logId;
            });
            var remH = same.reduce(function(s, e) { return s + (parseFloat(e.hours) || 0); }, 0);
            var totalB = remH + (parseFloat(target.hours) || 0);
            return {
                entry: target,
                date: day.date,
                employee_id: empId,
                employee_name: target.employee_name,
                task_name: target.task_name,
                hours: parseFloat(target.hours) || 0,
                remaining: same,
                remaining_hours: remH,
                total_before: totalB
            };
        }
        return null;
    }

    function distribute(total, n) {
        if (n < 1) return [];
        var each = Math.floor((total / n) * 4) / 4;
        if (each < 0.25) each = 0.25;
        var out = [];
        for (var i = 0; i < n - 1; i++) out.push(each);
        var last = Math.round((total - each * (n - 1)) * 4) / 4;
        if (last < 0.25) last = 0.25;
        out.push(last);
        return out;
    }

    var _nativeFetch = window.fetch;
    if (_nativeFetch && !window.__trkDeleteLogModalV1) {
        window.__trkDeleteLogModalV1 = true;
        window.fetch = function(url, opts) {
            if (typeof url !== 'string' || url.indexOf('/api/tracker/log/delete') === -1) {
                return _nativeFetch.apply(this, arguments);
            }
            if (!opts || (opts.method || 'GET').toUpperCase() !== 'POST') {
                return _nativeFetch.apply(this, arguments);
            }
            var logId = 0;
            try { logId = parseInt(JSON.parse(opts.body || '{}').id, 10); } catch (e) {}
            if (!logId) return _nativeFetch.apply(this, arguments);

            var info = findInfo(logId);
            if (!info || !info.remaining.length) {
                return _nativeFetch.apply(this, arguments);
            }

            var self = this;
            return showDialog(info).then(function(choice) {
                if (choice === 'cancel') {
                    return new Response(JSON.stringify({
                        success: false,
                        error: 'cancelled'
                    }), { status: 200, headers: {'Content-Type': 'application/json'} });
                }
                return _nativeFetch.call(self, url, opts).then(function(r) {
                    if (!r.ok) return r;
                    if (choice !== 'redistribute') return r;
                    var ids = info.remaining.map(function(e) { return e.id; });
                    var vals = distribute(info.total_before, ids.length);
                    var chain = Promise.resolve();
                    info.remaining.forEach(function(e, i) {
                        chain = chain.then(function() {
                            var newH = vals[i];
                            if (Math.abs(newH - (parseFloat(e.hours) || 0)) < 0.01) return null;
                            var hdrs = Object.assign({}, opts.headers || {}, {'Content-Type': 'application/json'});
                            return _nativeFetch('/api/tracker/log/save', {
                                method: 'POST',
                                headers: hdrs,
                                credentials: 'same-origin',
                                body: JSON.stringify({
                                    id: e.id,
                                    employee_id: e.employee_id,
                                    task_id: e.task_id,
                                    date: e.date,
                                    hours: newH,
                                    status: e.status || 'in_progress',
                                    comment: e.comment || '',
                                    link: e.link || '',
                                    overflow_action: 'accept'
                                })
                            });
                        });
                    });
                    return chain.then(function() { return r; });
                });
            });
        };
    }
})();
/* ============================================================
   PATCH 10 — удалён в v1.2.0: функциональность перенесена
   в блок «PATCH v1.2.0» (конец файла).
   ============================================================ */
/* ============================================================
   PATCH 14 — Вид «Сотрудники» v2: missing + редактирование + многострочность
   ============================================================ */
(function() {
    'use strict';

    function _esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
        });
    }
    function _initials(name) {
        var parts = String(name || '').trim().split(/\s+/);
        if (!parts.length) return '?';
        if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
        return (parts[0][0] + (parts[1][0] || '')).toUpperCase();
    }
    function _fmtH(h) {
        h = Number(h) || 0;
        if (h === Math.floor(h)) return h + ' ч';
        return h.toFixed(2).replace(/0+$/, '').replace(/\.$/, '') + ' ч';
    }
    function _maskName(name) {
        var st = window.__trkState;
        if (!st || !st.maskNames) return name;
        return String(name == null ? '' : name).split(/\s+/).map(function(w) {
            if (w.length <= 1) return w;
            return w[0] + new Array(w.length).join('*');
        }).join(' ');
    }
    function _isMine(en) {
        var st = window.__trkState;
        var me = (st && st.currentUser) || {};
        if (!me.employee_id) return false;
        return en.employee_id === me.employee_id;
    }
    function _canEdit(en) {
        if (window.REESTR_PERMS && window.REESTR_PERMS['action.log.edit.any']) return true;
        if (window.REESTR_PERMS && window.REESTR_PERMS['action.log.edit.own'] && _isMine(en)) return true;
        return false;
    }
    function _canDelete(en) {
        if (window.REESTR_PERMS && window.REESTR_PERMS['action.log.delete.any']) return true;
        if (window.REESTR_PERMS && window.REESTR_PERMS['action.log.delete.own'] && _isMine(en)) return true;
        return false;
    }

    function _renderMissing(day) {
        var mb = document.getElementById('dayMissingBlock');
        if (!mb) return;
        if (day && day.missing && day.missing.length) {
            mb.style.display = 'block';
            var items = day.missing.map(function(m) {
                return '<span class="dm-item">'
                    + '<span class="dm-dot" style="background:' + _esc(m.color) + '; box-shadow:0 0 6px ' + _esc(m.color) + ';"></span>'
                    + _esc(_maskName(m.name))
                    + (m.department ? ' <span style="opacity:0.7;font-size:0.72rem;">(' + _esc(m.department) + ')</span>' : '')
                    + '</span>';
            }).join('');
            mb.innerHTML = '<div class="dm-title">⚠ Не заполнили день (' + day.missing.length + '):</div>'
                + '<div class="dm-list">' + items + '</div>';
        } else {
            mb.style.display = 'none';
            mb.innerHTML = '';
        }
    }

    window.__trkRenderDayByEmployee = function(entries, totalHours, day) {
        var listEl = document.getElementById('dayList');
        if (!listEl) return false;

        _renderMissing(day);

        if (!entries || !entries.length) {
            listEl.innerHTML = '<div class="day-empty">За этот день отметок нет.</div>';
            return true;
        }

        var byEmp = {};
        entries.forEach(function(en) {
            var eid = en.employee_id || '?';
            if (!byEmp[eid]) {
                byEmp[eid] = {
                    id: eid,
                    name: en.employee_name || '',
                    color: en.employee_color || '#888',
                    dept: en.employee_department || '',
                    tasks: [],
                    total: 0
                };
            }
            byEmp[eid].tasks.push(en);
            byEmp[eid].total += parseFloat(en.hours) || 0;
        });

        var emps = Object.keys(byEmp).map(function(k) { return byEmp[k]; });
        emps.sort(function(a, b) { return b.total - a.total; });

        var html = '<div class="day-emp-tiles">';
        emps.forEach(function(e) {
            var bg = _esc(e.color);
            html += '<div class="day-emp-tile" style="--det-accent:' + bg + ';">'
                + '<div class="det-head">'
                +   '<div class="det-avatar" style="background:' + bg + ';">' + _esc(_initials(e.name)) + '</div>'
                +   '<div class="det-meta">'
                +     '<div class="det-name">' + _esc(_maskName(e.name)) + '</div>'
                +     (e.dept ? '<div class="det-dept">🏢 ' + _esc(e.dept) + '</div>' : '')
                +   '</div>'
                +   '<div class="det-total">' + _fmtH(e.total) + '</div>'
                + '</div>'
                + '<div class="det-tasks">';

            e.tasks.sort(function(a, b) { return (parseFloat(b.hours) || 0) - (parseFloat(a.hours) || 0); });
            e.tasks.forEach(function(en) {
                var ed = _canEdit(en);
                var dl = _canDelete(en);
                html += '<div class="det-task" data-id="' + en.id + '">'
                    + '<span class="det-task-ico">' + _esc(en.task_icon || '📋') + '</span>'
                    + '<div class="det-task-body">'
                    +   '<div class="det-task-name' + (en.overdue ? ' overdue' : '') + '">' + _esc(en.task_name || '') + '</div>'
                    +   (en.comment ? '<div class="det-task-comment">' + _esc(en.comment) + '</div>' : '')
                    + '</div>'
                    + '<span class="det-task-hours">' + _fmtH(en.hours) + '</span>'
                    + '<span class="det-task-actions">'
                    +   (ed ? '<button type="button" class="dict-action-btn" data-act="edit" title="Редактировать">✏️</button>' : '')
                    +   (dl ? '<button type="button" class="dict-action-btn danger" data-act="delete" title="Удалить">🗑</button>' : '')
                    + '</span>'
                    + '</div>';
            });
            html += '</div></div>';
        });
        html += '</div>';
        listEl.innerHTML = html;

        if (typeof window.__trkBindDayEntryActions === 'function') {
            try { window.__trkBindDayEntryActions(listEl, entries); } catch (e) { console.error('[day-view-v2]', e); }
        }
        return true;
    };
})();
/* ============================================================
   PATCH 15 — Дневная карточка: выбор числа колонок I/II
   ============================================================ */
(function() {
    'use strict';

    var KEY = 'tracker_day_cols';

    function getSaved() {
        try {
            var v = parseInt(localStorage.getItem(KEY), 10);
            if (v >= 1 && v <= 4) return v;
        } catch (e) {}
        return 1;
    }

    function syncPicker(cols) {
        var p = document.getElementById('dayColsPicker');
        if (!p) return;
        p.querySelectorAll('button').forEach(function(b) {
            b.classList.toggle('active', parseInt(b.getAttribute('data-cols'), 10) === cols);
        });
    }

    function apply(cols) {
        if (!(cols >= 1 && cols <= 4)) cols = 1;
        var st = window.__trkState;
        if (st) st.dayCols = cols;
        try { localStorage.setItem(KEY, String(cols)); } catch (e) {}
        var list = document.getElementById('dayList');
        if (list) {
            list.setAttribute('data-cols', String(cols));
            list.style.setProperty('--day-cols', String(cols));
        }
        syncPicker(cols);
    }

    document.addEventListener('click', function(e) {
        if (!e.target || !e.target.closest) return;
        var b = e.target.closest('#dayColsPicker button');
        if (!b) return;
        e.preventDefault();
        e.stopPropagation();
        var cols = parseInt(b.getAttribute('data-cols'), 10) || 1;
        apply(cols);
    }, true);

    function hookOpen() {
        if (!window.__trkOpenDayModal || window.__trkOpenDayModal._colPickHooked) return;
        var orig = window.__trkOpenDayModal;
        var wrapped = function() {
            var r = orig.apply(this, arguments);
            setTimeout(function() { apply(getSaved()); }, 40);
            return r;
        };
        wrapped._colPickHooked = true;
        window.__trkOpenDayModal = wrapped;
    }

    function boot() {
        hookOpen();
        setTimeout(hookOpen, 800);
        setTimeout(function() { apply(getSaved()); }, 600);
        var l = document.getElementById('dayList');
        if (l) apply(getSaved());
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

    setTimeout(function() {
        var m = document.getElementById('dayModal');
        if (!m) return;
        new MutationObserver(function() {
            if (m.classList.contains('active')) {
                setTimeout(function() { apply(getSaved()); }, 30);
            }
        }).observe(m, { attributes: true, attributeFilter: ['class'] });
    }, 600);
})();
/* ============================================================
   PATCH 16 — Фикс колонок вида «Сотрудники»
   ============================================================ */
(function() {
    'use strict';

    function markEmployees() {
        var l = document.getElementById('dayList');
        if (l) l.classList.add('day-list--employees');
    }
    function unmarkEmployees() {
        var l = document.getElementById('dayList');
        if (l) l.classList.remove('day-list--employees');
    }

    function wrapRenderEmp() {
        var orig = window.__trkRenderDayByEmployee;
        if (typeof orig !== 'function' || orig._empClassHooked) return;
        var wrapped = function() {
            var r = orig.apply(this, arguments);
            markEmployees();
            return r;
        };
        wrapped._empClassHooked = true;
        window.__trkRenderDayByEmployee = wrapped;
    }

    function wrapOpenDay() {
        var orig = window.__trkOpenDayModal;
        if (typeof orig !== 'function' || orig._empClassHooked) return;
        var wrapped = function() {
            unmarkEmployees();
            return orig.apply(this, arguments);
        };
        wrapped._empClassHooked = true;
        window.__trkOpenDayModal = wrapped;
    }

    function tick() {
        wrapRenderEmp();
        wrapOpenDay();
    }

    tick();
    setTimeout(tick, 500);
    setTimeout(tick, 1500);
    setTimeout(tick, 3000);

    document.addEventListener('click', function(e) {
        if (!e.target || !e.target.closest) return;
        var b = e.target.closest('#dayViewMode button');
        if (!b) return;
        var mode = b.getAttribute('data-mode');
        setTimeout(function() {
            if (mode === 'employee') markEmployees();
            else unmarkEmployees();
        }, 120);
    });
})();
/* ============================================================
   PATCH 17 — Вид «Сотрудники» v3: маркер статуса + уменьшенный шрифт
   ============================================================ */
(function() {
    'use strict';

    function _esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
        });
    }
    function _initials(name) {
        var parts = String(name || '').trim().split(/\s+/);
        if (!parts.length) return '?';
        if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
        return (parts[0][0] + (parts[1][0] || '')).toUpperCase();
    }
    function _fmtH(h) {
        h = Number(h) || 0;
        if (h === Math.floor(h)) return h + ' ч';
        return h.toFixed(2).replace(/0+$/, '').replace(/\.$/, '') + ' ч';
    }
    function _maskName(name) {
        var st = window.__trkState;
        if (!st || !st.maskNames) return name;
        return String(name == null ? '' : name).split(/\s+/).map(function(w) {
            if (w.length <= 1) return w;
            return w[0] + new Array(w.length).join('*');
        }).join(' ');
    }
    function _isMine(en) {
        var st = window.__trkState;
        var me = (st && st.currentUser) || {};
        if (!me.employee_id) return false;
        return en.employee_id === me.employee_id;
    }
    function _canEdit(en) {
        if (window.REESTR_PERMS && window.REESTR_PERMS['action.log.edit.any']) return true;
        if (window.REESTR_PERMS && window.REESTR_PERMS['action.log.edit.own'] && _isMine(en)) return true;
        return false;
    }
    function _canDelete(en) {
        if (window.REESTR_PERMS && window.REESTR_PERMS['action.log.delete.any']) return true;
        if (window.REESTR_PERMS && window.REESTR_PERMS['action.log.delete.own'] && _isMine(en)) return true;
        return false;
    }
    function _statusInfo(en) {
        var st = (en && en.status) || 'in_progress';
        var lbl = (en && en.status_label) || '';
        if (!lbl) {
            var map = {
                done:        '✅ Готово',
                in_progress: '🔵 В работе',
                planned:     '📝 Запланировано',
                blocked:     '🔴 Заблокировано'
            };
            lbl = map[st] || st;
        }
        return { key: st, label: lbl };
    }

    function _renderMissing(day) {
        var mb = document.getElementById('dayMissingBlock');
        if (!mb) return;
        if (day && day.missing && day.missing.length) {
            mb.style.display = 'block';
            var items = day.missing.map(function(m) {
                return '<span class="dm-item">'
                    + '<span class="dm-dot" style="background:' + _esc(m.color) + '; box-shadow:0 0 6px ' + _esc(m.color) + ';"></span>'
                    + _esc(_maskName(m.name))
                    + (m.department ? ' <span style="opacity:0.7;font-size:0.72rem;">(' + _esc(m.department) + ')</span>' : '')
                    + '</span>';
            }).join('');
            mb.innerHTML = '<div class="dm-title">⚠ Не заполнили день (' + day.missing.length + '):</div>'
                + '<div class="dm-list">' + items + '</div>';
        } else {
            mb.style.display = 'none';
            mb.innerHTML = '';
        }
    }

    window.__trkRenderDayByEmployee = function(entries, totalHours, day) {
        var listEl = document.getElementById('dayList');
        if (!listEl) return false;

        _renderMissing(day);

        if (!entries || !entries.length) {
            listEl.innerHTML = '<div class="day-empty">За этот день отметок нет.</div>';
            return true;
        }

        var byEmp = {};
        entries.forEach(function(en) {
            var eid = en.employee_id || '?';
            if (!byEmp[eid]) {
                byEmp[eid] = {
                    id: eid,
                    name: en.employee_name || '',
                    color: en.employee_color || '#888',
                    dept: en.employee_department || '',
                    tasks: [],
                    total: 0
                };
            }
            byEmp[eid].tasks.push(en);
            byEmp[eid].total += parseFloat(en.hours) || 0;
        });

        var emps = Object.keys(byEmp).map(function(k) { return byEmp[k]; });
        emps.sort(function(a, b) { return b.total - a.total; });

        var html = '<div class="day-emp-tiles">';
        emps.forEach(function(e) {
            var bg = _esc(e.color);
            html += '<div class="day-emp-tile" style="--det-accent:' + bg + ';">'
                + '<div class="det-head">'
                +   '<div class="det-avatar" style="background:' + bg + ';">' + _esc(_initials(e.name)) + '</div>'
                +   '<div class="det-meta">'
                +     '<div class="det-name">' + _esc(_maskName(e.name)) + '</div>'
                +     (e.dept ? '<div class="det-dept">🏢 ' + _esc(e.dept) + '</div>' : '')
                +   '</div>'
                +   '<div class="det-total">' + _fmtH(e.total) + '</div>'
                + '</div>'
                + '<div class="det-tasks">';

            e.tasks.sort(function(a, b) { return (parseFloat(b.hours) || 0) - (parseFloat(a.hours) || 0); });
            e.tasks.forEach(function(en) {
                var ed = _canEdit(en);
                var dl = _canDelete(en);
                var st = _statusInfo(en);
                html += '<div class="det-task" data-id="' + en.id + '">'
                    + '<span class="det-task-ico">' + _esc(en.task_icon || '📋') + '</span>'
                    + '<div class="det-task-body">'
                    +   '<div class="det-task-title">'
                    +     '<span class="det-task-status st-' + _esc(st.key) + '" title="' + _esc(st.label) + '"></span>'
                    +     '<span class="det-task-name' + (en.overdue ? ' overdue' : '') + '">' + _esc(en.task_name || '') + '</span>'
                    +   '</div>'
                    +   (en.comment ? '<div class="det-task-comment">' + _esc(en.comment) + '</div>' : '')
                    + '</div>'
                    + '<span class="det-task-hours">' + _fmtH(en.hours) + '</span>'
                    + '<span class="det-task-actions">'
                    +   (ed ? '<button type="button" class="dict-action-btn" data-act="edit" title="Редактировать">✏️</button>' : '')
                    +   (dl ? '<button type="button" class="dict-action-btn danger" data-act="delete" title="Удалить">🗑</button>' : '')
                    + '</span>'
                    + '</div>';
            });
            html += '</div></div>';
        });
        html += '</div>';
        listEl.innerHTML = html;

        if (typeof window.__trkBindDayEntryActions === 'function') {
            try { window.__trkBindDayEntryActions(listEl, entries); } catch (e) { console.error('[day-view-v3]', e); }
        }
        return true;
    };
})();
/* PATCH 18 — ЗАМЕНЁН патчем v1.1.4 (log-task-search). 
   PATCH v2: пустой IIFE удалён — он всё равно ничего не делал. */
/* ============================================================
   PATCH 19 — Проверка дубликатов имён задач (клиент)
   ============================================================ */
(function() {
    'use strict';

    function _esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
        });
    }

    function getModal() {
        var m = document.getElementById('trkDupTaskModal');
        if (m) return m;
        m = document.createElement('div');
        m.id = 'trkDupTaskModal';
        m.className = 'modal trk-dup-task-modal';
        m.innerHTML = [
            '<div class="modal-content dt-modal">',
            '  <div class="dt-head">',
            '    <span class="dt-icon">⚠</span>',
            '    <div class="dt-title-block">',
            '      <div class="dt-title">Похожая задача уже есть</div>',
            '      <div class="dt-sub">Проверьте, не дубликат ли это</div>',
            '    </div>',
            '  </div>',
            '  <div class="dt-body" id="trkDupBody"></div>',
            '  <div class="dt-actions">',
            '    <button type="button" class="btn btn-secondary" data-dt="cancel">Закрыть</button>',
            '    <button type="button" class="btn btn-secondary" data-dt="open">Открыть существующую</button>',
            '    <button type="button" class="btn btn-primary" data-dt="force">Всё равно создать</button>',
            '  </div>',
            '</div>'
        ].join('');
        document.body.appendChild(m);
		m.style.setProperty('z-index', '9000', 'important');
        return m;
    }

    function showDupDialog(data) {
        return new Promise(function(resolve) {
            var m = getModal();
            var body = m.querySelector('#trkDupBody');
            var html = '';
            if (data.exact) {
                html += '<div class="dt-exact">'
                     + '<div class="dt-exact-lbl">Точное совпадение:</div>'
                     + '<div class="dt-exact-name">' + _esc(data.exact.name) + '</div>'
                     + '</div>';
            }
            if (data.similar && data.similar.length) {
                html += '<div class="dt-similar">'
                     + '<div class="dt-sim-lbl">Похожие задачи:</div>'
                     + data.similar.map(function(t) {
                         return '<div class="dt-sim-row"><span class="dt-sim-name">' + _esc(t.name) + '</span>'
                              + '<button type="button" class="dt-sim-open" data-id="' + _esc(t.id) + '">открыть</button></div>';
                     }).join('')
                     + '</div>';
            }
            body.innerHTML = html;

            m.classList.add('active');
            var resolved = false;
            function finish(choice, tid) {
                if (resolved) return;
                resolved = true;
                m.classList.remove('active');
                m.removeEventListener('click', onClick);
                resolve({ choice: choice, id: tid || '' });
            }
            function onClick(e) {
                if (e.target === m) { finish('cancel'); return; }
                var openBtn = e.target.closest && e.target.closest('.dt-sim-open');
                if (openBtn) {
                    finish('open', openBtn.getAttribute('data-id'));
                    return;
                }
                var b = e.target.closest && e.target.closest('[data-dt]');
                if (!b) return;
                finish(b.getAttribute('data-dt'));
            }
            m.addEventListener('click', onClick);
        });
    }

    var _nativeFetch = window.fetch;
    if (_nativeFetch && !window.__trkDupTaskModalV1) {
        window.__trkDupTaskModalV1 = true;
        window.fetch = function(url, opts) {
            if (typeof url !== 'string' || url.indexOf('/api/tracker/task/save') === -1) {
                return _nativeFetch.apply(this, arguments);
            }
            if (!opts || (opts.method || 'GET').toUpperCase() !== 'POST') {
                return _nativeFetch.apply(this, arguments);
            }
            var self = this;
            return _nativeFetch.apply(this, arguments).then(function(r) {
                if (r.status !== 409) return r;
                return r.clone().json().then(function(d) {
                    if (!d || d.error !== 'duplicate_name') return r;
                    return showDupDialog(d).then(function(res) {
                        if (res.choice === 'cancel') {
                            return new Response(JSON.stringify({
                                success: false, error: 'cancelled'
                            }), { status: 200, headers: {'Content-Type': 'application/json'} });
                        }
                        if (res.choice === 'open') {
                            var tid = res.id || (d.exact && d.exact.id) || (d.similar && d.similar[0] && d.similar[0].id);
                            var _st = window.__trkState;
                            var _t = _st && _st.tasks ? _st.tasks.find(function(x) { return x.id === tid; }) : null;
                            if (_t && typeof window.__trkOpenTaskModal === 'function') {
                                window.__trkOpenTaskModal(_t);
                            } else if (window.__trackerNotify) {
                                window.__trackerNotify('Не удалось открыть задачу: не найдена в текущем списке', 'error');
                            }
                            return new Response(JSON.stringify({ success: true, opened: tid }), {
                                status: 200, headers: {'Content-Type': 'application/json'}
                            });
                        }
                        var payload;
                        try { payload = JSON.parse(opts.body || '{}'); } catch (e) { payload = {}; }
                        payload.force_duplicate = 1;
                        var newOpts = Object.assign({}, opts, { body: JSON.stringify(payload) });
                        return _nativeFetch.call(self, url, newOpts);
                    });
                });
            });
        };
    }
})();
/* ============================================================
   PATCH 20 — Кнопка «Добавить меня» в дневной карточке
   ============================================================ */
(function() {
    'use strict';

    function _norm(s) {
        return String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
    }

    function currentDay() {
        var st = window.__trkState;
        if (!st || !st.calendar || !st.currentDay) return null;
        return st.calendar.days.find(function(d) { return d.date === st.currentDay; }) || null;
    }

    function hasPerm(k) {
        return !!(window.REESTR_PERMS && window.REESTR_PERMS[k]);
    }

    function decorate() {
        var st = window.__trkState;
        if (!st) return;
        if (st.dayViewMode === 'employee') return;
        var me = st.currentUser && st.currentUser.employee_id;
        if (!me) return;
        if (!hasPerm('action.log.create')) return;

        var day = currentDay();
        if (!day) return;

        var myTaskIds = {};
        (day.entries || []).forEach(function(en) {
            if (en.employee_id === me) myTaskIds[en.task_id] = true;
        });

        var list = document.getElementById('dayList');
        if (!list) return;
        list.querySelectorAll('.day-task-group').forEach(function(g) {
            if (g.querySelector('.day-task-addme')) return;
            var titleEl = g.querySelector('.day-task-group-title');
            if (!titleEl) return;
            var txt = _norm(titleEl.textContent || '');
            var matched = null;
            (st.tasks || []).forEach(function(t) {
                if (!t || !t.name) return;
                var nm = _norm(t.name);
                if (nm && txt.indexOf(nm) !== -1) matched = t;
            });
            if (!matched) return;
            if (myTaskIds[matched.id]) return;
            if (matched.status !== 'active' && matched.status !== 'paused') return;

            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'day-task-addme';
            btn.textContent = '➕ Добавить меня';
            btn.title = 'Отметиться по этой задаче на этот день';
            btn.setAttribute('data-task-id', matched.id);
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                addMe(matched.id);
            });
            var head = g.querySelector('.day-task-group-head');
            if (head) head.appendChild(btn);
        });
    }

    function addMe(taskId) {
        var st = window.__trkState;
        if (!st) return;
        var me = st.currentUser && st.currentUser.employee_id;
        var dk = st.currentDay;
        if (!me || !dk) return;

        var day = currentDay();
        var n = 0;
        (day && day.entries || []).forEach(function(en) {
            if (en.employee_id === me) n++;
        });
        var hrs = Math.round((((window.__trkGetDayNorm ? window.__trkGetDayNorm(dk) : 8) || 8) / (n + 1)) * 4) / 4;
        if (hrs < 0.5) hrs = 0.5;
        if (hrs > 24) hrs = 24;

        var hdrs = { 'Content-Type': 'application/json' };
        if (window.REESTR_CSRF) hdrs['X-CSRF-Token'] = window.REESTR_CSRF;

        fetch('/api/tracker/log/save', {
            method: 'POST',
            headers: hdrs,
            credentials: 'same-origin',
            body: JSON.stringify({
                employee_id: me,
                task_id: taskId,
                date: dk,
                hours: hrs,
                status: 'in_progress',
                comment: 'Добавлено из карточки дня',
                link: ''
            })
        }).then(function(r) {
            return r.json().then(function(d) { return { ok: r.ok, d: d }; });
        }).then(function(res) {
            if (!res.ok || !res.d || !res.d.success) {
                if (res.d && res.d.error && res.d.error !== 'cancelled') {
                    if (typeof window.__trackerNotify === 'function') {
                        window.__trackerNotify('❌ ' + res.d.error, 'error');
                    }
                }
                return;
            }
            var dm = document.getElementById('dayModal');
            if (dm) dm.classList.remove('active');
            // PATCH v1.0.6: обновляем активную вкладку, не только календарь
            var _refresh = (typeof window.__trkRefreshAll === 'function')
                ? window.__trkRefreshAll
                : (typeof window.__trkRenderCalendar === 'function' ? window.__trkRenderCalendar : null);
            if (_refresh) {
                Promise.resolve(_refresh()).then(function() {
                    if (typeof window.__trkOpenDayModal === 'function') {
                        window.__trkOpenDayModal(dk);
                    }
                });
            } else if (typeof window.__trkOpenDayModal === 'function') {
                window.__trkOpenDayModal(dk);
            }
        }).catch(function(err) {
            if (err && err.message && err.message.indexOf('cancelled') !== -1) return;
            if (typeof window.__trackerNotify === 'function') {
                window.__trackerNotify('❌ ' + (err.message || 'Ошибка'), 'error');
            }
        });
    }

    function attachObserver() {
        var m = document.getElementById('dayModal');
        if (!m || m._addMeHooked) return;
        m._addMeHooked = true;
        var obs = new MutationObserver(function() {
            if (m.classList.contains('active')) {
                setTimeout(decorate, 60);
                setTimeout(decorate, 250);
            }
        });
        obs.observe(m, { attributes: true, attributeFilter: ['class'] });
        var list = document.getElementById('dayList');
        if (list) {
            var lobs = new MutationObserver(function() { setTimeout(decorate, 30); });
            lobs.observe(list, { childList: true });
        }
    }

    function boot() {
        attachObserver();
        setTimeout(attachObserver, 800);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

    window.__trkDecorateDayAddMe = decorate;
})();
/* ============================================================
   PATCH 21 — Модалка «Задача завершена» при сохранении done
   ============================================================ */
(function() {
    'use strict';

    var PERIODIC_TAG = 'pereodic';
    var _shown = {};

    function _esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
        });
    }
    function hasPerm(k) {
        return !!(window.REESTR_PERMS && window.REESTR_PERMS[k]);
    }
    function _isPeriodic(t) {
        if (!t || !t.tags) return false;
        return t.tags.indexOf(PERIODIC_TAG) !== -1;
    }

    function analyze(taskId) {
        var st = window.__trkState;
        if (!st || !st.tasks) return null;
        var t = st.tasks.find(function(x) { return x.id === taskId; });
        if (!t) return null;

        var assignees = t.assignees || [];
        var lastByEmp = {};
        (st.log || []).forEach(function(l) {
            if (l.task_id !== taskId) return;
            var eid = l.employee_id;
            if (!eid) return;
            var cur = lastByEmp[eid];
            var ld = l.date || '';
            var cd = cur ? (cur.date || '') : '';
            if (!cur || ld > cd || (ld === cd && (l.id || 0) > (cur.id || 0))) {
                lastByEmp[eid] = l;
            }
        });

        var closed = [], open = [];
        assignees.forEach(function(eid) {
            var e = (st.employees || []).find(function(x) { return x.id === eid; });
            var name = e ? e.name : eid;
            var color = e ? (e.color || '#888') : '#888';
            var rec = lastByEmp[eid];
            if (rec && rec.status === 'done') {
                closed.push({ id: eid, name: name, color: color, date: rec.date });
            } else {
                open.push({
                    id: eid, name: name, color: color,
                    status: rec ? (rec.status || 'in_progress') : 'none',
                    date: rec ? (rec.date || '') : ''
                });
            }
        });

        return { task: t, assignees: assignees, closed: closed, open: open, periodic: _isPeriodic(t) };
    }

    function statusLabel(s) {
        return {
            done:        'готово',
            in_progress: 'в работе',
            planned:     'запланировано',
            blocked:     'заблокировано',
            none:        'нет отметок'
        }[s] || s;
    }

    function getModal() {
        var m = document.getElementById('trkDoneModal');
        if (m) return m;
        m = document.createElement('div');
        m.id = 'trkDoneModal';
        m.className = 'modal trk-done-modal';
        m.innerHTML = [
            '<div class="modal-content dm-modal">',
            '  <div class="dm-head">',
            '    <span class="dm-icon" id="trkDmIcon">✅</span>',
            '    <div class="dm-title-block">',
            '      <div class="dm-title" id="trkDmTitle">Задача завершена</div>',
            '      <div class="dm-sub" id="trkDmSub"></div>',
            '    </div>',
            '  </div>',
            '  <div class="dm-body" id="trkDmBody"></div>',
            '  <div class="dm-actions" id="trkDmActions"></div>',
            '</div>'
        ].join('');
        document.body.appendChild(m);
		m.style.setProperty('z-index', '9000', 'important');
        return m;
    }

    function renderInfo(a) {
        var html = '';
        html += '<div class="dm-task-name">' + _esc((a.task.icon || '📋') + ' ' + a.task.name) + '</div>';

        if (a.periodic) {
            html += '<div class="dm-note">Это <b>периодическая</b> задача — статус не меняется автоматически.</div>';
            return html;
        }

        if (a.open.length === 0) {
            html += '<div class="dm-all-done">Все исполнители закрыли задачу:</div>';
            html += '<div class="dm-people">';
            a.closed.forEach(function(p) {
                html += '<div class="dm-person dm-closed">'
                     + '<span class="dm-dot" style="background:' + _esc(p.color) + ';"></span>'
                     + '<span class="dm-name">' + _esc(p.name) + '</span>'
                     + '<span class="dm-status">✅ готово ' + _esc(p.date || '') + '</span>'
                     + '</div>';
            });
            html += '</div>';
            if (a.task.status === 'done' || a.task.status === 'archived') {
                html += '<div class="dm-note dm-note-ok">Задача уже помечена как выполненная.</div>';
            } else {
                html += '<div class="dm-note dm-note-ok">Все отметки закрыты. Пометить задачу как <b>выполненную</b>?</div>';
            }
        } else {
            html += '<div class="dm-partial">Ваша отметка сохранена. У задачи ещё есть незакрытые исполнители:</div>';
            html += '<div class="dm-people">';
            a.open.forEach(function(p) {
                html += '<div class="dm-person dm-open">'
                     + '<span class="dm-dot" style="background:' + _esc(p.color) + ';"></span>'
                     + '<span class="dm-name">' + _esc(p.name) + '</span>'
                     + '<span class="dm-status">' + _esc(statusLabel(p.status)) + (p.date ? ' · ' + _esc(p.date) : '') + '</span>'
                     + '</div>';
            });
            html += '</div>';
            if (a.task.status === 'done' || a.task.status === 'archived') {
                html += '<div class="dm-note">Задача уже отмечена как выполненная, но не все закрыли отметки.</div>';
            }
        }
        return html;
    }

    function show(a, onCloseChoice) {
        var m = getModal();
        var icon = m.querySelector('#trkDmIcon');
        var title = m.querySelector('#trkDmTitle');
        var sub = m.querySelector('#trkDmSub');
        var body = m.querySelector('#trkDmBody');
        var actions = m.querySelector('#trkDmActions');

        var allClosed = a.open.length === 0;
        var alreadyDone = a.task.status === 'done' || a.task.status === 'archived';

        if (a.periodic) {
            if (icon) icon.textContent = '🔄';
            if (title) title.textContent = 'Задача периодическая';
            if (sub) sub.textContent = 'Отметка сохранена';
        } else if (allClosed) {
            if (icon) icon.textContent = '✅';
            if (title) title.textContent = alreadyDone ? 'Задача уже выполнена' : 'Все исполнители закрыли задачу';
            if (sub) sub.textContent = 'Отметка сохранена';
        } else {
            if (icon) icon.textContent = '📝';
            if (title) title.textContent = 'Отметка сохранена';
            if (sub) sub.textContent = 'Осталось ' + a.open.length + ' незакрытых исполнителей';
        }

        if (body) body.innerHTML = renderInfo(a);

        var btns = [];
        if (!a.periodic && allClosed && !alreadyDone && hasPerm('action.task.edit')) {
            btns.push('<button type="button" class="btn btn-primary" data-dm="close">✅ Завершить задачу</button>');
        }
        btns.push('<button type="button" class="btn btn-secondary" data-dm="ok">Закрыть</button>');
        if (actions) actions.innerHTML = btns.join('');

        m.classList.add('active');
        var resolved = false;
        function finish(choice) {
            if (resolved) return;
            resolved = true;
            m.classList.remove('active');
            m.removeEventListener('click', onClick);
            if (typeof onCloseChoice === 'function') onCloseChoice(choice);
        }
        function onClick(e) {
            if (e.target === m) { finish('ok'); return; }
            var b = e.target.closest && e.target.closest('[data-dm]');
            if (!b) return;
            finish(b.getAttribute('data-dm'));
        }
        m.addEventListener('click', onClick);
    }

    function closeTask(task, onDone) {
        var st = window.__trkState;
        if (!st) return;
        var today = (st.today || '').slice(0, 10);
        var payload = {
            id: task.id,
            name: task.name,
            icon: task.icon || '📋',
            description: task.description || '',
            status: 'done',
            start_date: task.start_date || '',
            deadline: task.deadline || '',
            completed_at: today,
            folder: task.folder || '',
            order_ref: task.order_ref || '',
            tags: task.tags || [],
            assignees: task.assignees || [],
            department_ids: task.department_ids || []
        };
        var hdrs = { 'Content-Type': 'application/json' };
        if (window.REESTR_CSRF) hdrs['X-CSRF-Token'] = window.REESTR_CSRF;
        fetch('/api/tracker/task/save', {
            method: 'POST',
            headers: hdrs,
            credentials: 'same-origin',
            body: JSON.stringify(payload)
        }).then(function(r) { return r.json(); }).then(function(d) {
            if (!d || !d.success) {
                if (typeof window.__trackerNotify === 'function') {
                    window.__trackerNotify('❌ ' + ((d && d.error) || 'Не удалось закрыть задачу'), 'error');
                }
                return;
            }
            if (typeof window.__trackerNotify === 'function') {
                window.__trackerNotify('✅ Задача закрыта', 'success');
            }
            if (typeof window.__trkLoadState === 'function') {
                try { window.__trkLoadState(); } catch (e) {}
            }
            if (typeof onDone === 'function') onDone();
        }).catch(function(err) {
            if (typeof window.__trackerNotify === 'function') {
                window.__trackerNotify('❌ ' + (err.message || 'Ошибка'), 'error');
            }
        });
    }

    window.__trkCheckAndShowDone = function(taskId) {
        if (!taskId) return;
        var key = taskId + '|' + ((window.__trkState && window.__trkState.today) || '');
        if (_shown[key]) return;
        _shown[key] = true;
        setTimeout(function() { _shown[key] = false; }, 5000);

        var a = analyze(taskId);
        if (!a) return;
        show(a, function(choice) {
            if (choice === 'close') {
                closeTask(a.task, function() {
                    var dm = document.getElementById('dayModal');
                    if (dm && dm.classList.contains('active') && typeof window.__trkOpenDayModal === 'function') {
                        var st = window.__trkState;
                        if (st && st.currentDay) window.__trkOpenDayModal(st.currentDay);
                    }
                });
            }
        });
    };

    var _nativeFetch = window.fetch;
    if (_nativeFetch && !window.__trkDoneModalV1) {
        window.__trkDoneModalV1 = true;
        window.fetch = function(url, opts) {
            if (typeof url !== 'string' || url.indexOf('/api/tracker/log/save') === -1) {
                return _nativeFetch.apply(this, arguments);
            }
            if (!opts || (opts.method || 'GET').toUpperCase() !== 'POST') {
                return _nativeFetch.apply(this, arguments);
            }
            var payload = {};
            try { payload = JSON.parse(opts.body || '{}'); } catch (e) {}
            if (payload.id) return _nativeFetch.apply(this, arguments);
            if (payload.status !== 'done') return _nativeFetch.apply(this, arguments);
            if (!payload.task_id) return _nativeFetch.apply(this, arguments);

            var self = this;
            return _nativeFetch.apply(this, arguments).then(function(r) {
                if (r.status !== 200) return r;
                return r.clone().json().then(function(d) {
                    if (!d || !d.success) return r;
                    setTimeout(function() {
                        try { window.__trkCheckAndShowDone(payload.task_id); } catch (e) {}
                    }, 400);
                    return r;
                });
            });
        };
    }
})();
/* ============================================================
   PATCH 22 — Свод: штриховка «назначено, не отмечено»
   ============================================================ */
(function() {
    'use strict';

    function _st() { return window.__trkState || null; }

    function decorateLegend() {
        var legend = document.querySelector('#sumExtras .grid-legend');
        if (!legend) return;
        if (legend.querySelector('.trk-legend-missing')) return;
        var s = document.createElement('span');
        s.className = 'grid-legend-item trk-legend-missing';
        s.innerHTML = '<span class="grid-legend-swatch" style="background: repeating-linear-gradient(45deg, rgba(128,128,128,0.10) 0, rgba(128,128,128,0.10) 3px, rgba(128,128,128,0.28) 3px, rgba(128,128,128,0.28) 6px);"></span>🩶 Назначено, не отмечено';
        legend.appendChild(s);
        if (legend.querySelector('.trk-legend-overdue')) return;
        var s2 = document.createElement('span');
        s2.className = 'grid-legend-item trk-legend-overdue';
        s2.innerHTML = '<span class="grid-legend-swatch" style="background: repeating-linear-gradient(45deg, rgba(231,76,60,0.12) 0, rgba(231,76,60,0.12) 3px, rgba(231,76,60,0.32) 3px, rgba(231,76,60,0.32) 6px);"></span>⚠ Просрочено без отметок';
        legend.appendChild(s2);
    }

    function decorateMissing() {
        var wrap = document.getElementById('sumWrap');
        var table = wrap ? wrap.querySelector('table.grid-table') : null;
        if (!table) return;
        var st = _st();
        if (!st || !st.summary) return;
        var d = st.summary;
        var days = d.days || [];
        var meta = d.day_meta || {};
        var today = st.today || '';
        if (!days.length || !today) return;

        var rowByEmp = {};
        (d.rows || []).forEach(function(r) { rowByEmp[r.employee_id] = r; });

        var trs = table.querySelectorAll('tbody > tr');
        var lastEmpId = '';

        trs.forEach(function(tr) {
            if (tr.classList.contains('emp-sep')) return;
            if (tr.classList.contains('day-totals-row')) return;

            var empCell = tr.querySelector('td.emp-cell[data-emp]');
            if (empCell) lastEmpId = empCell.getAttribute('data-emp');
            if (!lastEmpId) return;

            var taskCell = tr.querySelector('td.task-cell[data-task]');
            if (!taskCell) return;
            var taskId = taskCell.getAttribute('data-task');
            if (!taskId || taskId === '__collapsed__') return;

            var rowData = rowByEmp[lastEmpId];
            if (!rowData) return;
            var taskData = (rowData.tasks || []).find(function(x) { return x.task_id === taskId; });
            if (!taskData) return;

            var taskFull = (st.tasks || []).find(function(x) { return x.id === taskId; });
            if (!taskFull) return;
            var tstatus = taskFull.status || 'active';
            if (tstatus !== 'active' && tstatus !== 'paused') return;
            if ((taskFull.assignees || []).indexOf(lastEmpId) === -1) return;

            var startD = taskFull.start_date || '';
            var endD = taskFull.deadline || '';
            var anyCells = taskData.cells && Object.keys(taskData.cells).length > 0;
            var overdueNoWork = !!(endD && endD < today && !anyCells);

            var absMap = rowData.absence_days || {};

            var dayCells = tr.querySelectorAll('td.day-cell');
            for (var i = 0; i < days.length && i < dayCells.length; i++) {
                var dk = days[i];
                var td = dayCells[i];
                if (td.hasAttribute('data-emp') || td.hasAttribute('data-task')) continue;
                if (absMap[dk]) continue;
                if (td.classList.contains('absence-vacation') ||
                    td.classList.contains('absence-sick_leave') ||
                    td.classList.contains('absence-business_trip') ||
                    td.classList.contains('absence-remote')) continue;
                if (startD && dk < startD) continue;
                if (endD && dk > endD) continue;
                if (dk > today) continue;
                var m = meta[dk] || {};
                if (!m.is_workday) continue;

                var cls = overdueNoWork ? 'day-cell--missing-overdue' : 'day-cell--missing-assigned';
                td.classList.add(cls);
                var ttl = overdueNoWork ? '⚠ Просрочено без отметок' : '🩶 Назначено, не отмечено';
                td.title = (td.title ? td.title + ' · ' : '') + ttl;
            }
        });

        decorateLegend();
    }

    var _prev = window.__trkOnSummaryRender;
    window.__trkOnSummaryRender = function() {
        if (typeof _prev === 'function') {
            try { _prev(); } catch (e) {}
        }
        try { decorateMissing(); } catch (e) { console.error('[missing-shading]', e); }
    };

    setTimeout(function() { try { decorateMissing(); } catch (e) {} }, 700);
    setTimeout(function() { try { decorateMissing(); } catch (e) {} }, 1800);

    window.__trkDecorateMissing = decorateMissing;
})();
/* ============================================================
   PATCH 23 — Глобальная связь задач и отметок
   ============================================================ */
(function() {
    'use strict';

    function _st() { return window.__trkState || null; }
    function _esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
        });
    }
    function _fmtH(h) {
        h = Number(h) || 0;
        if (h === Math.floor(h)) return h + ' ч';
        return h.toFixed(2).replace(/0+$/, '').replace(/\.$/, '') + ' ч';
    }
    function _mask(name) {
        var st = _st();
        if (!st || !st.maskNames) return name;
        return String(name == null ? '' : name).split(/\s+/).map(function(w) {
            if (w.length <= 1) return w;
            return w[0] + new Array(w.length).join('*');
        }).join(' ');
    }

    function _meEmpId() {
        var st = _st();
        return st && st.currentUser ? (st.currentUser.employee_id || '') : '';
    }

    function _isWorkday(dayMeta) {
        return !!(dayMeta && dayMeta.is_workday);
    }

    function _inInterval(t, dk) {
        var s = t.start_date || '';
        var e = t.deadline || '';
        if (s && dk < s) return false;
        if (e && dk > e) return false;
        return true;
    }

    function _absenceOf(emp, dk) {
        if (!emp) return '';
        var vs = emp.vacations || [];
        for (var i = 0; i < vs.length; i++) {
            var v = vs[i];
            if (v.from && v.to && v.from <= dk && dk <= v.to) return v.type || 'vacation';
        }
        return '';
    }

    function _missingTasksFor(empId, dk) {
        var st = _st();
        if (!st || !st.tasks || !st.calendar) return [];
        var day = st.calendar.days.find(function(d) { return d.date === dk; });
        if (!day) return [];
        var meta = (st.calendar.days.find(function(x) { return x.date === dk; }) || {});
        var today = st.today || '';
        if (dk > today) return [];
        if (!_isWorkday(meta)) return [];
        var emp = (st.employees || []).find(function(e) { return e.id === empId; });
        if (_absenceOf(emp, dk)) return [];
        var doneTask = {};
        (day.entries || []).forEach(function(en) {
            if (en.employee_id === empId) doneTask[en.task_id] = true;
        });
        var out = [];
        (st.tasks || []).forEach(function(t) {
            if (t.status !== 'active' && t.status !== 'paused') return;
            if ((t.assignees || []).indexOf(empId) === -1) return;
            if (!_inInterval(t, dk)) return;
            if (doneTask[t.id]) return;
            out.push(t);
        });
        return out;
    }

    function _decorateDayModal() {
        var st = _st();
        if (!st) return;
        if (st.dayViewMode === 'employee') return;
        var empId = _meEmpId();
        if (!empId) return;
        var dk = st.currentDay;
        if (!dk) return;
        var list = document.getElementById('dayList');
        if (!list) return;
        var missing = _missingTasksFor(empId, dk);
        var old = list.querySelector('.day-assigned-block');
        if (old) old.remove();
        if (!missing.length) return;

        var block = document.createElement('div');
        block.className = 'day-assigned-block';
        var head = '<div class="dab-head">'
                 + '<span class="dab-icon">🩶</span>'
                + '<span class="dab-title">Назначено на этот день</span>'
                + '<span class="dab-count">' + missing.length + '</span>'
                + '</div>';
        var tiles = missing.map(function(t) {
            var cls = t.status === 'paused' ? ' dab-paused' : '';
            return '<div class="dab-tile' + cls + '" data-task-id="' + _esc(t.id) + '">'
                 +   '<span class="dab-ico">' + _esc(t.icon || '📋') + '</span>'
                 +   '<div class="dab-body">'
                 +     '<div class="dab-name">' + _esc(t.name) + '</div>'
                 +     '<div class="dab-meta">'
                 +       (t.deadline ? '⏰ ' + _esc(t.deadline) : '')
                 +       (t.status === 'paused' ? ' · ⚠ Приостановлена' : '')
                 +     '</div>'
                 +   '</div>'
                 +   '<button type="button" class="dab-add" title="Отметиться по этой задаче">➕</button>'
                 + '</div>';
        }).join('');
        block.innerHTML = head + '<div class="dab-tiles">' + tiles + '</div>';
        list.insertBefore(block, list.firstChild);

        block.querySelectorAll('.dab-tile').forEach(function(el) {
            el.addEventListener('click', function(e) {
                var tid = this.getAttribute('data-task-id');
                if (!tid) return;
                if (e.target.closest('.dab-add') || !e.target.closest('button')) {
                    _activateTask(tid);
                }
            });
        });
    }

    function _activateTask(taskId) {
        var st = _st();
        if (!st) return;
        var t = (st.tasks || []).find(function(x) { return x.id === taskId; });
        if (!t) return;

        if (t.status === 'done' || t.status === 'archived') {
            var map = { done: 'выполнена', archived: 'в архиве' };
            _showNotice(
                '🔒 Задача закрыта',
                'Задача <b>' + _esc(t.name) + '</b> — ' + map[t.status] + '.',
                'Измените её статус во вкладке «Задачи», чтобы отметить по ней работу.'
            );
            return;
        }
        if (t.status === 'paused') {
            _confirmNotice(
                '⚠ Задача приостановлена',
                'Задача <b>' + _esc(t.name) + '</b> имеет статус «Приостановлена».',
                'Всё равно отметить по ней работу?',
                'Отметить',
                function() { _doAdd(t.id); }
            );
            return;
        }
        _doAdd(t.id);
    }

    function _doAdd(taskId) {
        var st = _st();
        if (!st) return;
        var empId = _meEmpId();
        var dk = st.currentDay;
        if (!empId || !dk) return;
        var day = st.calendar && st.calendar.days ? st.calendar.days.find(function(d) { return d.date === dk; }) : null;
        var n = 0;
        (day && day.entries || []).forEach(function(en) { if (en.employee_id === empId) n++; });
        var hrs = Math.round((((window.__trkGetDayNorm ? window.__trkGetDayNorm(dk) : 8) || 8) / (n + 1)) * 4) / 4;
        if (hrs < 0.5) hrs = 0.5;
        if (hrs > 24) hrs = 24;
        var hdrs = { 'Content-Type': 'application/json' };
        if (window.REESTR_CSRF) hdrs['X-CSRF-Token'] = window.REESTR_CSRF;
        fetch('/api/tracker/log/save', {
            method: 'POST',
            headers: hdrs,
            credentials: 'same-origin',
            body: JSON.stringify({
                employee_id: empId,
                task_id: taskId,
                date: dk,
                hours: hrs,
                status: 'in_progress',
                comment: 'Назначенная задача, активирована из календаря',
                link: ''
            })
        }).then(function(r) { return r.json().then(function(d) { return { ok: r.ok, d: d }; }); })
        .then(function(res) {
            if (!res.ok || !res.d || !res.d.success) {
                if (res.d && res.d.error && res.d.error !== 'cancelled' && typeof window.__trackerNotify === 'function') {
                    window.__trackerNotify('❌ ' + res.d.error, 'error');
                }
                return;
            }
            var dm = document.getElementById('dayModal');
            if (dm) dm.classList.remove('active');
            // PATCH v1.0.6: обновляем активную вкладку
            var _refresh = (typeof window.__trkRefreshAll === 'function')
                ? window.__trkRefreshAll
                : (typeof window.__trkRenderCalendar === 'function' ? window.__trkRenderCalendar : null);
            if (_refresh) {
                Promise.resolve(_refresh()).then(function() {
                    if (typeof window.__trkOpenDayModal === 'function') {
                        window.__trkOpenDayModal(dk);
                    }
                });
            }
        }).catch(function(err) {
            if (err && err.message && err.message.indexOf('cancelled') !== -1) return;
            if (typeof window.__trackerNotify === 'function') {
                window.__trackerNotify('❌ ' + (err.message || 'Ошибка'), 'error');
            }
        });
    }

    function _getNoticeModal() {
        var m = document.getElementById('trkNoticeModal');
        if (m) return m;
        m = document.createElement('div');
        m.id = 'trkNoticeModal';
        m.className = 'modal trk-notice-modal';
        m.innerHTML = '<div class="modal-content nm-modal">'
            + '<div class="nm-head"><span class="nm-icon" id="nmIcon">🔒</span>'
            + '<div class="nm-title" id="nmTitle"></div></div>'
            + '<div class="nm-body"><div id="nmLine1"></div><div id="nmLine2" class="nm-sub"></div></div>'
            + '<div class="nm-actions" id="nmActions"></div>'
            + '</div>';
        document.body.appendChild(m);
		m.style.setProperty('z-index', '9000', 'important');
        return m;
    }

    function _showNotice(title, line1, line2) {
        var m = _getNoticeModal();
        var t = m.querySelector('#nmTitle'); if (t) t.textContent = title;
        var i = m.querySelector('#nmIcon'); if (i) i.textContent = title.indexOf('🔒') === 0 ? '🔒' : 'ℹ';
        var l1 = m.querySelector('#nmLine1'); if (l1) l1.innerHTML = line1;
        var l2 = m.querySelector('#nmLine2'); if (l2) l2.innerHTML = line2 || '';
        var a = m.querySelector('#nmActions');
        if (a) a.innerHTML = '<button type="button" class="btn btn-primary" data-nm="ok">Закрыть</button>';
        m.classList.add('active');
        var onClick = function(e) {
            if (e.target === m || (e.target.closest && e.target.closest('[data-nm="ok"]'))) {
                m.classList.remove('active');
                m.removeEventListener('click', onClick);
            }
        };
        m.addEventListener('click', onClick);
    }

    // PATCH v2: в _confirmNotice была синтаксическая ошибка — запятая вместо +, 
    // из-за чего в модалке появлялась только кнопка Отмена.
    function _confirmNotice(title, line1, line2, okLabel, onOk) {
        var m = _getNoticeModal();
        var t = m.querySelector('#nmTitle'); if (t) t.textContent = title;
        var i = m.querySelector('#nmIcon'); if (i) i.textContent = '⚠';
        var l1 = m.querySelector('#nmLine1'); if (l1) l1.innerHTML = line1;
        var l2 = m.querySelector('#nmLine2'); if (l2) l2.innerHTML = line2 || '';
        var a = m.querySelector('#nmActions');
        if (a) a.innerHTML = '<button type="button" class="btn btn-secondary" data-nm="cancel">Закрыть</button>'
                          + '<button type="button" class="btn btn-primary" data-nm="ok">' + _esc(okLabel) + '</button>';
        m.classList.add('active');
        var onClick = function(e) {
            var b = e.target.closest && e.target.closest('[data-nm]');
            if (e.target === m) b = { getAttribute: function() { return 'cancel'; } };
            if (!b) return;
            m.classList.remove('active');
            m.removeEventListener('click', onClick);
            if (b.getAttribute('data-nm') === 'ok' && typeof onOk === 'function') onOk();
        };
        m.addEventListener('click', onClick);
    }

    function _decorateCalendar() {
        var st = _st();
        if (!st || !st.calendar) return;
        var empId = _meEmpId();
        if (!empId) return;
        var grid = document.getElementById('calGrid');
        if (!grid) return;
        var cells = grid.querySelectorAll('.cal-cell');
        cells.forEach(function(cell) {
            var dk = cell.getAttribute('data-date');
            if (!dk) return;
            var old = cell.querySelector('.cal-assigned-dot');
            if (old) old.remove();
            var missing = _missingTasksFor(empId, dk);
            if (!missing.length) return;
            var dot = document.createElement('span');
            dot.className = 'cal-assigned-dot';
            dot.title = missing.length + ' назначенных задач(и) без отметки';
            dot.textContent = '●';
            cell.appendChild(dot);
        });
    }

    function _autoCheckInTaskModal() {
        var st = _st();
        if (!st) return;
        var me = _meEmpId();
        if (!me) return;
        var taskIdField = document.getElementById('task_id');
        if (!taskIdField || taskIdField.value) return;
        var list = document.getElementById('taskAssigneesList');
        if (!list) return;
        var cb = list.querySelector('input[type="checkbox"][value="' + me + '"]');
        if (cb && !cb.checked) cb.checked = true;
    }

    function _attachObservers() {
        var dm = document.getElementById('dayModal');
        if (dm && !dm._linksHooked) {
            dm._linksHooked = true;
            new MutationObserver(function() {
                if (dm.classList.contains('active')) {
                    setTimeout(_decorateDayModal, 80);
                    setTimeout(_decorateDayModal, 300);
                }
            }).observe(dm, { attributes: true, attributeFilter: ['class'] });
            var dl = document.getElementById('dayList');
            if (dl) {
                new MutationObserver(function() { setTimeout(_decorateDayModal, 40); }).observe(dl, { childList: true });
            }
        }
        var grid = document.getElementById('calGrid');
        if (grid && !grid._assignedHooked) {
            grid._assignedHooked = true;
            new MutationObserver(function() { setTimeout(_decorateCalendar, 60); }).observe(grid, { childList: true });
        }
        var tm = document.getElementById('taskModal');
        if (tm && !tm._autoHooked) {
            tm._autoHooked = true;
            new MutationObserver(function() {
                if (tm.classList.contains('active')) {
                    setTimeout(_autoCheckInTaskModal, 150);
                    setTimeout(_autoCheckInTaskModal, 400);
                }
            }).observe(tm, { attributes: true, attributeFilter: ['class'] });
        }
    }

    function boot() {
        _attachObservers();
        setTimeout(_attachObservers, 800);
        setTimeout(_attachObservers, 2000);
        setTimeout(_decorateCalendar, 1000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else { boot(); }

    window.__trkDecorateAssigned = _decorateDayModal;
    window.__trkDecorateCalendarAssigned = _decorateCalendar;
})();
/* ============================================================
   PATCH 24 — фиксы: загрузчик не перекрывает модалки, число колонок
   ============================================================ */
(function() {
    'use strict';

    function hideLoader() {
        var l = document.getElementById('globalLoader');
        if (l) l.classList.remove('active');
        try { window.__trkLoaderPending = 0; } catch (e) {}
    }
    var _modalObserver = new MutationObserver(function(muts) {
        for (var i = 0; i < muts.length; i++) {
            var el = muts[i].target;
            if (el && el.classList && el.classList.contains('modal') && el.classList.contains('active')) {
                hideLoader();
                return;
            }
        }
    });
    function watchModals() {
        document.querySelectorAll('.modal').forEach(function(m) {
            if (m._loaderWatchHooked) return;
            m._loaderWatchHooked = true;
            _modalObserver.observe(m, { attributes: true, attributeFilter: ['class'] });
        });
    }
    watchModals();
    setTimeout(watchModals, 800);
    setTimeout(watchModals, 2000);

    var KEY = 'tracker_tsk_cols';
    function readCols() {
        try {
            var v = parseInt(localStorage.getItem(KEY), 10);
            if (v >= 1 && v <= 5) return v;
        } catch (e) {}
        return 3;
    }
    function applyCols() {
        var st = window.__trkState;
        var cols = readCols();
        if (st) st.tskGridCols = cols;
        var list = document.getElementById('tasksFullList');
        if (list && list.classList.contains('tasks-grid')) {
            list.setAttribute('data-cols', String(cols));
        }
        var sel = document.getElementById('tskGridCols');
        if (sel && String(sel.value) !== String(cols)) sel.value = String(cols);
    }
    window.addEventListener('load', applyCols);
    setTimeout(applyCols, 500);
    setTimeout(applyCols, 1500);

    document.addEventListener('click', function(e) {
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('.tracker-tab[data-tab="tasks"]')) {
            setTimeout(applyCols, 250);
        }
    });

    document.addEventListener('change', function(e) {
        if (!e.target || e.target.id !== 'tskGridCols') return;
        try { localStorage.setItem(KEY, String(e.target.value)); } catch (er) {}
        setTimeout(applyCols, 60);
    }, true);

    var wrap = document.getElementById('tasksFullList');
    if (wrap && !wrap._colsHooked) {
        wrap._colsHooked = true;
        new MutationObserver(function() { setTimeout(applyCols, 30); }).observe(wrap, { childList: true });
    } else if (!wrap) {
        setTimeout(function() {
            var w2 = document.getElementById('tasksFullList');
            if (w2 && !w2._colsHooked) {
                w2._colsHooked = true;
                new MutationObserver(function() { setTimeout(applyCols, 30); }).observe(w2, { childList: true });
            }
        }, 900);
    }

    window.__trkApplyTskCols = applyCols;
})();
/* ============================================================
   PATCH 25 — Подсветка задач без исполнителей
   ============================================================ */
(function() {
    'use strict';

    function decorate() {
        var st = window.__trkState;
        if (!st || !st.tasks) return;
        var list = document.getElementById('tasksFullList');
        if (!list) return;
        list.querySelectorAll('.task-card, .dict-item').forEach(function(card) {
            var id = card.getAttribute('data-id');
            if (!id) return;
            var t = st.tasks.find(function(x) { return x.id === id; });
            if (!t) return;
            var noAssignees = !((t.assignees || []).length);
            var badge = card.querySelector('.task-card-no-assignees-badge');
            if (noAssignees) {
                card.classList.add('task-card--no-assignees');
                if (!badge) {
                    var b = document.createElement('span');
                    b.className = 'task-card-no-assignees-badge';
                    b.textContent = '⚠ Нет исполнителей';
                    b.title = 'Задача ни на кого не назначена — её никто не увидит в календаре';
                    var head = card.querySelector('.task-card-head') || card.querySelector('.dict-item-body');
                    if (head) head.appendChild(b);
                }
            } else {
                card.classList.remove('task-card--no-assignees');
                if (badge) badge.remove();
            }
        });
    }

    var wrap = document.getElementById('tasksFullList');
    function observe(el) {
        if (!el || el._noAsgHooked) return;
        el._noAsgHooked = true;
        new MutationObserver(function() { setTimeout(decorate, 30); }).observe(el, { childList: true });
        decorate();
    }
    observe(wrap);
    setTimeout(function() { observe(document.getElementById('tasksFullList')); }, 800);
    setTimeout(function() { observe(document.getElementById('tasksFullList')); }, 2000);
    document.addEventListener('click', function(e) {
        if (e.target && e.target.closest && e.target.closest('.tracker-tab[data-tab="tasks"]')) {
            setTimeout(decorate, 250);
        }
    });

    window.__trkDecorateNoAssignees = decorate;
})();
/* ============================================================
   PATCH 26 — Расширенная карточка задачи: все исполнители
   v2: сохранение __lastTaskCardData делается в обёртке openTaskCardModal 
   из основной части файла — здесь только рендер.
   ============================================================ */
(function() {
    'use strict';

    function _esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
        });
    }
    function _initials(name) {
        var parts = String(name || '').trim().split(/\s+/);
        if (!parts.length) return '?';
        if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
        return (parts[0][0] + (parts[1][0] || '')).toUpperCase();
    }
    function _fmtH(h) {
        h = Number(h) || 0;
        if (h === Math.floor(h)) return h + ' ч';
        return h.toFixed(2).replace(/0+$/, '').replace(/\.$/, '') + ' ч';
    }
    function _statusLbl(s) {
        return ({ done:'✅ готово', in_progress:'🔵 в работе', planned:'📝 план', blocked:'🔴 блок' })[s] || '';
    }

    function coverageBar(cov) {
        var cls = cov >= 70 ? 'ok' : (cov >= 40 ? 'warn' : 'err');
        var w = Math.max(0, Math.min(cov, 100));
        return '<div class="cov-bar"><div class="cov-bar-track"><div class="cov-bar-fill ' + cls + '" style="width:' + w + '%"></div></div><span class="cov-bar-pct">' + cov + '%</span></div>';
    }

    window.__trkRenderTaskCardEmployees = function(d) {
        var wrap = document.getElementById('taskCardEmployees');
        if (!wrap) return;
        var rows = d.employees || [];
        if (!rows.length) {
            wrap.innerHTML = '<div class="day-empty">Нет ни назначенных, ни отметок за этот период.</div>';
            return;
        }
        var worked = [], idle = [];
        rows.forEach(function(e) {
            if (e.worked) worked.push(e); else idle.push(e);
        });
        var html = '';

        if (worked.length) {
            html += '<div class="tc-sec-title"><span>👥</span><span>Исполнители (' + worked.length + ')</span></div>';
            html += '<div class="tc-list">';
            worked.forEach(function(e) {
                html += _rowHtml(e, false);
            });
            html += '</div>';
        }

        if (idle.length) {
            html += '<div class="tc-sec-title tc-sec-idle"><span>⚠</span><span>Не приступили (' + idle.length + ')</span></div>';
            html += '<div class="tc-list">';
            idle.forEach(function(e) {
                html += _rowHtml(e, true);
            });
            html += '</div>';
        }

        wrap.innerHTML = html;
    };

    function _rowHtml(e, idle) {
        var cls = 'tc-row' + (idle ? ' tc-idle' : '') + (e.overdue ? ' tc-overdue' : '');
        var bg = _esc(e.employee_color || '#888');
        var st = e.last_status ? _statusLbl(e.last_status) : '';
        var cov = (typeof e.coverage === 'number') ? e.coverage : 0;
        var badge = '';
        if (idle) badge = '<span class="tc-badge tc-badge-idle">не работал</span>';
        else if (e.emp_completion_kind === 'early') badge = '<span class="tc-badge tc-badge-ok">✅ досрочно</span>';
        else if (e.emp_completion_kind === 'on_time') badge = '<span class="tc-badge tc-badge-ok">✅ в срок</span>';
        else if (e.emp_completion_kind === 'late') badge = '<span class="tc-badge tc-badge-warn">⏰ с опозданием</span>';
        else if (e.overdue) badge = '<span class="tc-badge tc-badge-err">⚠ просрочено</span>';
        return '<div class="' + cls + '">'
             +   '<div class="tc-avatar" style="background:' + bg + ';">' + _esc(_initials(e.employee_name)) + '</div>'
             +   '<div class="tc-body">'
             +     '<div class="tc-name">' + _esc(e.employee_name)
             +       (e.employee_department ? ' <span class="tc-dept">🏢 ' + _esc(e.employee_department) + '</span>' : '')
             +     '</div>'
             +     '<div class="tc-meta">'
             +       (st ? '<span>' + _esc(st) + '</span>' : '')
             +       (e.active_days ? '<span>· ' + e.active_days + ' дн.</span>' : '')
             +       (e.emp_completed_at ? '<span>· ✅ ' + _esc(e.emp_completed_at) + '</span>' : '')
             +       badge
             +     '</div>'
             +     (idle ? '' : coverageBar(cov))
             +   '</div>'
             +   '<div class="tc-hours">' + _fmtH(e.total_hours) + '</div>'
             + '</div>';
    }
})();
/* ============================================================
   PATCH 27 — Защита при удалении задачи
   ============================================================ */
(function() {
    'use strict';

    function _esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
        });
    }

    function getModal() {
        var m = document.getElementById('trkDelTaskModal');
        if (m) return m;
        m = document.createElement('div');
        m.id = 'trkDelTaskModal';
        m.className = 'modal trk-del-task-modal';
        m.innerHTML = [
            '<div class="modal-content dlm-modal">',
            '  <div class="dlm-head">',
            '    <span class="dlm-icon">🗑</span>',
            '    <div class="dlm-title-block">',
            '      <div class="dlm-title">Удалить задачу?</div>',
            '      <div class="dlm-sub" id="trkDlmSub"></div>',
            '    </div>',
            '  </div>',
            '  <div class="dlm-warn" id="trkDlmWarn" style="display:none;"></div>',
            '  <div class="dlm-actions">',
            '    <button type="button" class="btn btn-secondary" data-dl="cancel">Закрыть</button>',
            '    <button type="button" class="btn btn-danger" data-dl="force">Удалить задачу и все отметки</button>',
            '  </div>',
            '</div>'
        ].join('');
        document.body.appendChild(m);
		m.style.setProperty('z-index', '9000', 'important');
        return m;
    }

    function showDlg(data) {
        return new Promise(function(resolve) {
            var m = getModal();
            var sub = m.querySelector('#trkDlmSub');
            var warn = m.querySelector('#trkDlmWarn');
            if (sub) sub.textContent = 'Задача: ' + (data.taskName || '');
            if (warn) {
                var emps = (data.employees || []).map(function(e) {
                    return '<span class="dlm-emp">' + _esc(e.name) + '</span>';
                }).join(' ');
                warn.innerHTML = [
                    '<div class="dlm-warn-title">⚠ В задаче есть отметки</div>',
                    '<div class="dlm-warn-line">Отметок: <b>' + data.logs_count + '</b> · Участников: <b>' + (data.employees || []).length + '</b> · Дней: <b>' + data.dates_count + '</b></div>',
                    data.first_date ? '<div class="dlm-warn-line">Период: ' + _esc(data.first_date) + ' — ' + _esc(data.last_date) + '</div>' : '',
                    emps ? '<div class="dlm-warn-line dlm-emps">' + emps + '</div>' : '',
                    '<div class="dlm-warn-line dlm-danger">При удалении задачи <b>все отметки будут удалены безвозвратно</b>.</div>'
                ].join('');
                warn.style.display = 'block';
            }
            m.classList.add('active');
            var resolved = false;
            function finish(choice) {
                if (resolved) return;
                resolved = true;
                m.classList.remove('active');
                m.removeEventListener('click', onClick);
                resolve(choice);
            }
            function onClick(e) {
                if (e.target === m) { finish('cancel'); return; }
                var b = e.target.closest && e.target.closest('[data-dl]');
                if (!b) return;
                finish(b.getAttribute('data-dl'));
            }
            m.addEventListener('click', onClick);
        });
    }

    function taskNameById(tid) {
        var st = window.__trkState;
        if (!st || !st.tasks) return '';
        var t = st.tasks.find(function(x) { return x.id === tid; });
        return t ? (t.name || '') : '';
    }

    var _nativeFetch = window.fetch;
    if (_nativeFetch && !window.__trkDelTaskModalV1) {
        window.__trkDelTaskModalV1 = true;
        window.fetch = function(url, opts) {
            if (typeof url !== 'string' || url.indexOf('/api/tracker/task/delete') === -1) {
                return _nativeFetch.apply(this, arguments);
            }
            if (!opts || (opts.method || 'GET').toUpperCase() !== 'POST') {
                return _nativeFetch.apply(this, arguments);
            }
            var payload = {};
            try { payload = JSON.parse(opts.body || '{}'); } catch (e) {}
            if (payload.force) return _nativeFetch.apply(this, arguments);
            var self = this;
            return _nativeFetch.apply(this, arguments).then(function(r) {
                if (r.status !== 409) return r;
                return r.clone().json().then(function(d) {
                    if (!d || d.error !== 'task_has_logs') return r;
                    d.taskName = taskNameById(payload.id);
                    return showDlg(d).then(function(choice) {
                        if (choice === 'cancel') {
                            return new Response(JSON.stringify({
                                success: false, error: 'cancelled'
                            }), { status: 200, headers: {'Content-Type': 'application/json'} });
                        }
                        var newPayload = Object.assign({}, payload, { force: 1 });
                        var newOpts = Object.assign({}, opts, { body: JSON.stringify(newPayload) });
                        return _nativeFetch.call(self, url, newOpts);
                    });
                });
            });
        };
    }
})();
/* ============================================================
   PATCH 28 — Фильтр «Требуют внимания» на вкладке Задачи
   ============================================================ */
(function() {
    'use strict';
    var KEY = 'tracker_tsk_attention';
    var STALE_DAYS = 3;

    function isOn() {
        try { return localStorage.getItem(KEY) === '1'; } catch (e) { return false; }
    }
    function setOn(v) { try { localStorage.setItem(KEY, v ? '1' : '0'); } catch (e) {} }

    function daysSince(iso) {
        if (!iso) return null;
        try {
            var d = new Date(iso + 'T00:00:00');
            var t = new Date();
            t.setHours(0, 0, 0, 0);
            return Math.floor((t - d) / 86400000);
        } catch (e) { return null; }
    }

    function taskProblem(t, logsByTask) {
        if (t.status === 'done' || t.status === 'archived') return null;
        var reasons = [];
        if (!(t.assignees || []).length) reasons.push('нет исполнителей');
        if (t.deadline) {
            var dk = t.deadline;
            var st = (window.__trkState && window.__trkState.today) || '';
            if (st && dk < st) reasons.push('просрочена');
        }
        if (t.start_date) {
            var ds = daysSince(t.start_date);
            if (ds !== null && ds >= STALE_DAYS && !(logsByTask[t.id] || 0)) reasons.push('нет отметок ' + ds + ' дн.');
        }
        return reasons.length ? reasons : null;
    }

    function countProblems() {
        var st = window.__trkState;
        if (!st) return { n: 0, byId: {} };
        var logsByTask = {};
        (st.log || []).forEach(function(l) { logsByTask[l.task_id] = (logsByTask[l.task_id] || 0) + 1; });
        var byId = {};
        var n = 0;
        (st.tasks || []).forEach(function(t) {
            var r = taskProblem(t, logsByTask);
            if (r) { byId[t.id] = r; n++; }
        });
        return { n: n, byId: byId };
    }

    function decorate() {
        var list = document.getElementById('tasksFullList');
        if (!list) return;
        var c = countProblems();
        list.querySelectorAll('.task-card, .dict-item').forEach(function(el) {
            var id = el.getAttribute('data-id');
            if (!id) return;
            var badge = el.querySelector('.task-att-badge');
            if (c.byId[id]) {
                el.classList.add('task-card--attention');
                if (!badge) {
                    badge = document.createElement('span');
                    badge.className = 'task-att-badge';
                    badge.textContent = '🚨 ' + c.byId[id].join(' · ');
                    var head = el.querySelector('.task-card-head') || el.querySelector('.dict-item-body');
                    if (head) head.appendChild(badge);
                } else {
                    badge.textContent = '🚨 ' + c.byId[id].join(' · ');
                }
            } else {
                el.classList.remove('task-card--attention');
                if (badge) badge.remove();
            }
        });
    }

    function hookRender() {
        if (typeof window.__trkRenderTasksFull !== 'function') return;
        if (window.__trkRenderTasksFull._attHooked) return;
        var orig = window.__trkRenderTasksFull;
        var wrapped = function() {
            var r = orig.apply(this, arguments);
            setTimeout(function() { decorate(); }, 20);
            return r;
        };
        wrapped._attHooked = true;
        window.__trkRenderTasksFull = wrapped;
    }

    function filterAttention(tasks) {
        if (!isOn()) return tasks;
        var c = countProblems();
        return tasks.filter(function(t) { return !!c.byId[t.id]; });
    }

    function boot() {
        hookRender();
        setTimeout(function() { hookRender(); decorate(); }, 900);
        setTimeout(function() { hookRender(); decorate(); }, 2000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else { boot(); }

    document.addEventListener('click', function(e) {
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('.tracker-tab[data-tab="tasks"]')) {
            setTimeout(boot, 250);
        }
    });

    window.__trkFilterAttention = filterAttention;
    window.__trkAttentionCount = countProblems;
})();
/* ============================================================
   PATCH 29 — Карточка задачи: сводка по исполнителям
   v2: работает через __lastTaskCardData, который заполняется в 
   обёртке openTaskCardModal основной части файла.
   ============================================================ */
(function() {
    'use strict';
    function _fmtH(h) {
        h = Number(h) || 0;
        if (h === Math.floor(h)) return h + ' ч';
        return h.toFixed(2).replace(/0+$/, '').replace(/\.$/, '') + ' ч';
    }
    function buildSummary(d) {
        var rows = d.employees || [];
        var worked = rows.filter(function(e) { return e.worked; });
        var idle = rows.filter(function(e) { return !e.worked; });
        var cov = (typeof d.coverage === 'number') ? d.coverage : 0;
        var cls = cov >= 70 ? 'ok' : (cov >= 40 ? 'warn' : 'err');
        return [
            '<div class="tc-summary">',
            '  <div class="tc-summary-card">',
            '    <div class="tc-summary-val">' + _fmtH(d.total_hours || 0) + '</div>',
            '    <div class="tc-summary-lbl">Всего часов</div>',
            '  </div>',
            '  <div class="tc-summary-card">',
            '    <div class="tc-summary-val">' + worked.length + ' / ' + rows.length + '</div>',
            '    <div class="tc-summary-lbl">Работали / назначено</div>',
            '  </div>',
            '  <div class="tc-summary-card">',
            '    <div class="tc-summary-val">' + (d.active_days || 0) + ' / ' + (d.possible_days || 0) + '</div>',
            '    <div class="tc-summary-lbl">Дней активно</div>',
            '  </div>',
            '  <div class="tc-summary-card tc-summary-cov ' + cls + '">',
            '    <div class="tc-summary-val">' + cov + '%</div>',
            '    <div class="tc-summary-lbl">Покрытие</div>',
            '  </div>',
            '</div>'
        ].join('');
    }
    window.__trkInjectTaskSummary = function() {
        var head = document.getElementById('taskCardHead');
        var list = document.getElementById('taskCardEmployees');
        if (!head || !list) return;
        var existing = document.getElementById('taskCardSummary');
        if (existing) existing.remove();
        var st = window.__trkState;
        var d = st && st.__lastTaskCardData;
        if (!d) return;
        var html = buildSummary(d);
        if (!html) return;
        var el = document.createElement('div');
        el.id = 'taskCardSummary';
        el.innerHTML = html;
        var container = head.parentNode;
        if (container) container.insertBefore(el, list);
    };
})();
/* ============================================================
   PATCH 33 — FAB «Новая задача» в правом нижнем углу
   ============================================================ */
(function() {
    'use strict';
    function ensureFab() {
        if (!window.REESTR_PERMS || !window.REESTR_PERMS['action.task.create']) return;
        if (document.getElementById('tskFabBtn')) { updateFab(); return; }
        var b = document.createElement('button');
        b.id = 'tskFabBtn';
        b.type = 'button';
        b.className = 'tsk-fab';
        b.title = 'Новая задача';
        b.setAttribute('aria-label', 'Новая задача');
        b.textContent = '➕';
        b.addEventListener('click', function(e) {
            e.preventDefault();
            if (typeof window.__trkOpenTaskModal === 'function') {
                window.__trkOpenTaskModal(null);
            } else {
                var alt = document.getElementById('addTaskBtn2') || document.getElementById('addTaskBtn');
                if (alt) alt.click();
            }
        });
        document.body.appendChild(b);
        updateFab();
    }
    function updateFab() {
        var b = document.getElementById('tskFabBtn');
        if (!b) return;
        var onTasks = !!document.querySelector('.tracker-tab[data-tab="tasks"].active');
        b.style.display = onTasks ? '' : 'none';
    }
    document.addEventListener('click', function(e) {
        if (e.target && e.target.closest && e.target.closest('.tracker-tab')) {
            setTimeout(updateFab, 60);
        }
    });
    setTimeout(ensureFab, 700);
    setTimeout(ensureFab, 1800);
    setTimeout(updateFab, 900);
    window.__trkEnsureFab = ensureFab;
})();
/* ============================================================
   PATCH 41 — В карточке отметки: назначенные, но не заведённые
   ============================================================ */
(function() {
    'use strict';

    function _esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
        });
    }
    function _isWorkday(meta) { return !!(meta && meta.is_workday); }
    function _inInterval(t, dk) {
        var s = t.start_date || '';
        var e = t.deadline || '';
        if (s && dk < s) return false;
        if (e && dk > e) return false;
        return true;
    }
    function _absenceOf(emp, dk) {
        if (!emp) return '';
        var vs = emp.vacations || [];
        for (var i = 0; i < vs.length; i++) {
            var v = vs[i];
            if (v.from && v.to && v.from <= dk && dk <= v.to) return v.type || 'vacation';
        }
        return '';
    }
    function _missing(empId, dk) {
        var st = window.__trkState;
        if (!st || !st.tasks || !st.calendar) return [];
        var day = st.calendar.days.find(function(d) { return d.date === dk; });
        if (!day) return [];
        var today = st.today || '';
        if (dk > today) return [];
        if (!_isWorkday(day)) return [];
        var emp = (st.employees || []).find(function(e) { return e.id === empId; });
        if (_absenceOf(emp, dk)) return [];
        var done = {};
        (day.entries || []).forEach(function(en) {
            if (en.employee_id === empId) done[en.task_id] = true;
        });
        var arr = (st.tasks || []).filter(function(t) {
            if (t.status !== 'active' && t.status !== 'paused') return false;
            if ((t.assignees || []).indexOf(empId) === -1) return false;
            if (!_inInterval(t, dk)) return false;
            if (done[t.id]) return false;
            return true;
        });
        // PATCH v1.0.18: очень срочные — в самое начало
        arr.sort(function(a, b) {
            var au = a.is_urgent ? 1 : 0;
            var bu = b.is_urgent ? 1 : 0;
            if (au !== bu) return bu - au;
            return 0;
        });
        return arr;
    }
    function _mode() {
        var t = document.querySelector('#logExistingTabs .log-existing-tab.active');
        return t ? (t.getAttribute('data-mode') || 'me') : 'me';
    }
    function _removeBlock() {
        var wrap = document.getElementById('logDayExisting');
        if (!wrap) return;
        var old = wrap.querySelector('.log-assigned-block');
        if (old) old.remove();
    }
    function _showNotice(title, line1, line2) {
        var m = document.getElementById('trkLogNotice');
        if (!m) {
            m = document.createElement('div');
            m.id = 'trkLogNotice';
            m.className = 'modal trk-log-notice';
            m.innerHTML = '<div class="modal-content lgn-modal">'
                + '<div class="lgn-head"><span class="lgn-icon" id="lgnIcon">🔒</span>'
                + '<div class="lgn-title" id="lgnTitle"></div></div>'
                + '<div class="lgn-body"><div id="lgnL1"></div><div id="lgnL2" class="lgn-sub"></div></div>'
                + '<div class="lgn-actions"><button type="button" class="btn btn-primary" data-lgn="ok">Закрыть</button></div>'
                + '</div>';
            document.body.appendChild(m);
			m.style.setProperty('z-index', '9000', 'important');
        }
        var t = m.querySelector('#lgnTitle'); if (t) t.textContent = title;
        var i = m.querySelector('#lgnIcon'); if (i) i.textContent = title.indexOf('🔒') === 0 ? '🔒' : (title.indexOf('⚠') === 0 ? '⚠' : 'ℹ');
        var l1 = m.querySelector('#lgnL1'); if (l1) l1.innerHTML = line1 || '';
        var l2 = m.querySelector('#lgnL2'); if (l2) l2.innerHTML = line2 || '';
        m.classList.add('active');
        var onClick = function(e) {
            if (e.target === m || (e.target.closest && e.target.closest('[data-lgn="ok"]'))) {
                m.classList.remove('active');
                m.removeEventListener('click', onClick);
            }
        };
        m.addEventListener('click', onClick);
    }
    function _applyTaskToForm(task) {
        var inp = document.getElementById('log_task_input');
        var hid = document.getElementById('log_task');
        if (!inp || !hid) return;
        inp.value = task.name || '';
        hid.value = task.id || '';
        var warn = document.getElementById('log_task_warn');
        if (warn) warn.style.display = 'none';
        var hours = document.getElementById('log_hours');
        if (hours) { try { hours.focus(); } catch (e) {} }
    }
    function _onPick(task) {
        if (task.status === 'done' || task.status === 'archived') {
            var map = { done: 'выполнена', archived: 'в архиве' };
            _showNotice('🔒 Задача закрыта',
                'Задача <b>' + _esc(task.name) + '</b> — ' + map[task.status] + '.',
                'Измените её статус во вкладке «Задачи», чтобы отметить работу.');
            return;
        }
        if (task.status === 'paused') {
            _showNotice('⚠ Задача приостановлена',
                'Задача <b>' + _esc(task.name) + '</b> имеет статус «Приостановлена».',
                'Проверьте, нужна ли по ней отметка сегодня, прежде чем сохранить.');
        }
        _applyTaskToForm(task);
    }
    function decorate() {
        var modal = document.getElementById('logModal');
        if (!modal || !modal.classList.contains('active')) return;
        var wrap = document.getElementById('logDayExisting');
        var list = document.getElementById('logDayExistingList');
        if (!wrap || !list) return;
        if (_mode() !== 'me') { _removeBlock(); return; }
        var empSel = document.getElementById('log_employee');
        var dt = document.getElementById('log_date');
        var empId = empSel ? empSel.value : '';
        var dk = dt ? dt.value : '';
        if (!empId || !dk) { _removeBlock(); return; }
        var tasks = _missing(empId, dk);
        var old = wrap.querySelector('.log-assigned-block');
        if (!tasks.length) {
            if (old) old.remove();
            return;
        }
        if (old) old.remove();

        var block = document.createElement('div');
        block.className = 'log-assigned-block';
        var head = '<div class="lab-head">'
                 + '<span class="lab-icon">🩶</span>'
                 + '<span class="lab-title">Назначено, но не заведено</span>'
                 + '<span class="lab-count">' + tasks.length + '</span>'
                 + '</div>';
        var tiles = tasks.map(function(t) {
            var cls = 'lab-tile'
                + (t.status === 'paused' ? ' lab-paused' : '')
                + (t.is_urgent ? ' lab-urgent' : '');
            // PATCH v1.0.18: 🚨 для очень срочных
            var _ico = t.is_urgent ? '🚨' : _esc(t.icon || '📋');
            return '<div class="' + cls + '" data-task-id="' + _esc(t.id) + '">'
                 +   '<span class="lab-ico">' + _ico + '</span>'
                 +   '<div class="lab-body">'
                 +     '<div class="lab-name">' + _esc(t.name) + '</div>'
                 +     (t.deadline ? '<div class="lab-meta">⏰ ' + _esc(t.deadline) + '</div>' : '')
                 +   '</div>'
                 +   '<button type="button" class="lab-add" title="Подставить в поле «Задача»">➕</button>'
                 + '</div>';
        }).join('');
        block.innerHTML = head + '<div class="lab-tiles">' + tiles + '</div>';

        var tabs = document.getElementById('logExistingTabs');
        if (tabs && tabs.parentNode === wrap) wrap.insertBefore(block, tabs);
        else wrap.insertBefore(block, wrap.firstChild);

        block.querySelectorAll('.lab-tile').forEach(function(el) {
            el.addEventListener('click', function(e) {
                var tid = this.getAttribute('data-task-id');
                if (!tid) return;
                var st = window.__trkState;
                var t = (st && st.tasks) ? st.tasks.find(function(x) { return x.id === tid; }) : null;
                if (!t) return;
                _onPick(t);
            });
        });
    }

    function attach() {
        var wrap = document.getElementById('logDayExisting');
        if (wrap) wrap._labHooked = true;
        var modal = document.getElementById('logModal');
        if (modal && !modal._labHooked) {
            modal._labHooked = true;
            new MutationObserver(function() {
                if (modal.classList.contains('active')) {
                    setTimeout(decorate, 60);
                    setTimeout(decorate, 300);
                    setTimeout(decorate, 700);
                }
            }).observe(modal, { attributes: true, attributeFilter: ['class'] });
        }
    }
    function boot() {
        attach();
        setTimeout(attach, 700);
        setTimeout(attach, 1800);
        setTimeout(decorate, 1500);
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else { boot(); }

    document.addEventListener('click', function(e) {
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('.log-existing-tab')) setTimeout(decorate, 60);
        if (e.target.closest('#dayAddBtn')) {
            setTimeout(decorate, 250);
            setTimeout(decorate, 700);
        }
    });
    document.addEventListener('change', function(e) {
        if (!e.target) return;
        if (e.target.id === 'log_employee' || e.target.id === 'log_date') setTimeout(decorate, 80);
    }, true);

    window.__trkLogAssignedDecorate = decorate;
})();
/* ============================================================
   v1.0.9 — поведение плиток в блоке «Назначено, но не заведено»
   ============================================================ */
(function () {
    'use strict';
    if (window.__trkLabTileV109) return;
    window.__trkLabTileV109 = true;

    function openTaskForEdit(tid) {
        var st = window.__trkState;
        var t = (st && st.tasks) ? st.tasks.find(function (x) { return x.id === tid; }) : null;
        if (!t) return;
        var lm = document.getElementById('logModal');
        if (lm) lm.classList.remove('active');
        setTimeout(function () {
            if (typeof window.__trkOpenTaskModal === 'function') {
                window.__trkOpenTaskModal(t);
            }
        }, 100);
    }

    function addLogImmediately(tid) {
        var st = window.__trkState;
        if (!st) return;
        var empSel = document.getElementById('log_employee');
        var dt = document.getElementById('log_date');
        if (!empSel || !dt) return;
        var empId = empSel.value;
        var dk = dt.value;
        if (!empId || !dk) return;

        var day = (st.calendar && st.calendar.days)
            ? st.calendar.days.find(function (d) { return d.date === dk; })
            : null;
        var n = 0;
        (day && day.entries || []).forEach(function (en) {
            if (en.employee_id === empId) n++;
        });
        var hrs = Math.round((((window.__trkGetDayNorm ? window.__trkGetDayNorm(dk) : 8) || 8) / (n + 1)) * 4) / 4;
        if (hrs < 0.5) hrs = 0.5;
        if (hrs > 24) hrs = 24;

        var hdrs = { 'Content-Type': 'application/json' };
        if (window.REESTR_CSRF) hdrs['X-CSRF-Token'] = window.REESTR_CSRF;

        fetch('/api/tracker/log/save', {
            method: 'POST',
            headers: hdrs,
            credentials: 'same-origin',
            body: JSON.stringify({
                employee_id: empId,
                task_id: tid,
                date: dk,
                hours: hrs,
                status: 'in_progress',
                comment: 'Добавлено из блока «Назначено»',
                link: ''
            })
        }).then(function (r) { return r.json().then(function (j) { return { ok: r.ok, d: j }; }); })
        .then(function (res) {
            if (!res.ok || !res.d || !res.d.success) {
                if (typeof window.__trackerNotify === 'function') {
                    window.__trackerNotify('❌ ' + ((res.d && res.d.error) || 'Ошибка'), 'error');
                }
                return;
            }
            var lm = document.getElementById('logModal');
            if (lm) lm.classList.remove('active');
            var dm = document.getElementById('dayModal');
            if (dm) dm.classList.remove('active');
            // PATCH v1.0.6: обновляем активную вкладку
            var _refresh = (typeof window.__trkRefreshAll === 'function')
                ? window.__trkRefreshAll
                : (typeof window.__trkRenderCalendar === 'function' ? window.__trkRenderCalendar : null);
            if (_refresh) {
                Promise.resolve(_refresh()).then(function () {
                    if (typeof window.__trkOpenDayModal === 'function') {
                        window.__trkOpenDayModal(dk);
                    }
                });
            }
        })
        .catch(function (err) {
            if (typeof window.__trackerNotify === 'function') {
                window.__trackerNotify('❌ ' + (err.message || 'Ошибка'), 'error');
            }
        });
    }

    document.addEventListener('click', function (e) {
        if (!e.target || !e.target.closest) return;
        var tile = e.target.closest('.log-assigned-block .lab-tile');
        if (!tile) return;
        var tid = tile.getAttribute('data-task-id');
        if (!tid) return;

        e.stopImmediatePropagation();
        e.preventDefault();

        var st = window.__trkState;
        var t = (st && st.tasks) ? st.tasks.find(function (x) { return x.id === tid; }) : null;
        if (!t) return;

        if (t.status === 'done' || t.status === 'archived') {
            if (typeof window.__trackerNotify === 'function') {
                window.__trackerNotify('🔒 Задача закрыта — измените статус во вкладке «Задачи»', 'error');
            }
            return;
        }

        if (e.target.closest('.lab-add')) {
            addLogImmediately(tid);
        } else {
            openTaskForEdit(tid);
        }
    }, true);

    window.__trkLabAddNow = addLogImmediately;
})();
/* v1.1.0 — статус новой отметки по умолчанию: «В работе» */
(function () {
    'use strict';
    if (window.__trkLogStatusDefaultV110) return;
    window.__trkLogStatusDefaultV110 = true;

    function forceStatus() {
        var lm = document.getElementById('logModal');
        if (!lm || !lm.classList.contains('active')) return;
        var idField = document.getElementById('log_id');
        if (idField && idField.value) return;
        var sel = document.getElementById('log_status');
        if (!sel) return;
        if (sel._userTouchedForV110) return;
        sel.value = 'in_progress';
    }

    function bindUserTouch() {
        var sel = document.getElementById('log_status');
        if (!sel || sel._v110Touched) return;
        sel._v110Touched = true;
        sel.addEventListener('change', function () { sel._userTouchedForV110 = true; }, true);
    }

    function attachObserver() {
        var m = document.getElementById('logModal');
        if (!m || m._statusObsV110) return;
        m._statusObsV110 = true;
        var obs = new MutationObserver(function () {
            if (!m.classList.contains('active')) return;
            var sel = document.getElementById('log_status');
            if (sel) sel._userTouchedForV110 = false;
            setTimeout(forceStatus, 50);
            setTimeout(forceStatus, 200);
            setTimeout(forceStatus, 500);
            bindUserTouch();
        });
        obs.observe(m, { attributes: true, attributeFilter: ['class'] });
    }

    function boot() {
        attachObserver();
        setTimeout(attachObserver, 500);
        setTimeout(attachObserver, 1500);
        bindUserTouch();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else { boot(); }

    document.addEventListener('click', function (e) {
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('#dayAddBtn') || e.target.closest('#logCreateTaskBtn')) {
            setTimeout(function () {
                var sel = document.getElementById('log_status');
                if (sel) sel._userTouchedForV110 = false;
                forceStatus();
            }, 100);
        }
    }, true);
})();
/* ============================================================
   v1.1.2 — Выпадающее меню пользователя
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkUserMenuV112) return;
    window.__trkUserMenuV112 = true;
    function boot(){
        var chip = document.getElementById('userChip');
        var dd = document.getElementById('userDropdown');
        if (!chip || !dd || chip._v112Hooked) return;
        chip._v112Hooked = true;
        chip.addEventListener('click', function(e){
            e.stopPropagation();
            var active = dd.classList.toggle('active');
            chip.setAttribute('aria-expanded', active ? 'true' : 'false');
        });
        document.addEventListener('click', function(e){
            if (!dd.contains(e.target) && e.target !== chip && !chip.contains(e.target)) {
                dd.classList.remove('active');
                chip.setAttribute('aria-expanded', 'false');
            }
        });
        document.addEventListener('keydown', function(e){
            if (e.key === 'Escape') {
                dd.classList.remove('active');
                chip.setAttribute('aria-expanded', 'false');
            }
        });
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else { boot(); }
    setTimeout(boot, 800);
})();
/* ============================================================
   v1.1.3 — Проверка дублей названия задачи (расширенный поиск)
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkDupV113Final) return;
    window.__trkDupV113Final = true;

    var LOG = '[dup v1.1.3]';

    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){
        return { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c];
    }); }
    function norm(s) { return String(s == null ? '' : s).trim().toLowerCase().replace(/\s+/g, ' '); }

    function words(s) {
        return String(s || '').toLowerCase()
            .split(/[\s\-_.:,;!?/\\|]+/)
            .map(function(w){ return w.trim(); })
            .filter(function(w){ return w.length >= 2; });
    }

    function lev(a, b) {
        if (a === b) return 0;
        var la = a.length, lb = b.length;
        if (la === 0) return lb;
        if (lb === 0) return la;
        var prev = [], cur = [];
        for (var j = 0; j <= lb; j++) prev[j] = j;
        for (var i = 1; i <= la; i++) {
            cur[0] = i;
            for (var k = 1; k <= lb; k++) {
                var cost = a[i - 1] === b[k - 1] ? 0 : 1;
                cur[k] = Math.min(cur[k - 1] + 1, prev[k] + 1, prev[k - 1] + cost);
            }
            prev = cur.slice();
        }
        return prev[lb];
    }

    function matchWords(qWords, tWords) {
        var hits = 0;
        var hitWords = [];
        for (var i = 0; i < qWords.length; i++) {
            var qw = qWords[i];
            for (var j = 0; j < tWords.length; j++) {
                var tw = tWords[j];
                if (tw === qw) { hits += 1; hitWords.push(qw); break; }
                if (tw.length >= 4 && qw.length >= 4 && tw.indexOf(qw) !== -1) { hits += 1; hitWords.push(qw); break; }
                if (tw.length >= 4 && qw.length >= 4 && qw.indexOf(tw) !== -1) { hits += 1; hitWords.push(qw); break; }
                if (tw.length >= 5 && qw.length >= 5 && lev(tw, qw) <= 1) { hits += 1; hitWords.push(qw); break; }
            }
        }
        return { hits: hits, hitWords: hitWords };
    }

    function highlightWords(name, hitWords) {
        if (!hitWords || !hitWords.length) return esc(name);
        var escaped = esc(name);
        var uniq = [];
        var seen = {};
        for (var i = 0; i < hitWords.length; i++) {
            var w = hitWords[i];
            if (!seen[w.toLowerCase()]) {
                seen[w.toLowerCase()] = true;
                uniq.push(w);
            }
        }
        uniq.sort(function(a, b){ return b.length - a.length; });
        for (var k = 0; k < uniq.length; k++) {
            var raw = uniq[k];
            var rx = new RegExp('(' + raw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'ig');
            escaped = escaped.replace(rx, '<mark>$1</mark>');
        }
        return escaped;
    }

    function findSimilar(q) {
        var st = window.__trkState;
        var tasks = (st && Array.isArray(st.tasks)) ? st.tasks : [];
        var curId = document.getElementById('task_id');
        var skipId = curId ? curId.value : '';
        var qn = norm(q);
        if (qn.length < 3 || !tasks.length) return [];

        var qWords = words(qn);

        var out = [];
        for (var i = 0; i < tasks.length; i++) {
            var t = tasks[i];
            if (!t || t.id === skipId) continue;
            var tn = norm(t.name);
            if (!tn) continue;

            var reason = '', score = 999, hitWords = [];

            if (tn === qn) {
                reason = 'точное совпадение'; score = 0;
                hitWords = qWords.slice();
            } else if (qn.length >= 4 && tn.indexOf(qn) !== -1) {
                reason = 'содержит весь ваш текст'; score = 1;
                hitWords = qWords.slice();
            } else if (tn.length >= 4 && qn.indexOf(tn) !== -1) {
                reason = 'входит в ваш текст'; score = 1;
                hitWords = qWords.slice();
            } else if (qWords.length >= 2) {
                var mw = matchWords(qWords, words(tn));
                if (mw.hits === qWords.length) {
                    reason = 'совпадают все слова'; score = 2;
                    hitWords = mw.hitWords;
                } else if (mw.hits >= 2 && mw.hits >= Math.ceil(qWords.length / 2)) {
                    reason = 'совпадают ' + mw.hits + ' из ' + qWords.length + ' слов'; score = 3;
                    hitWords = mw.hitWords;
                }
            } else if (qWords.length === 1) {
                var mw1 = matchWords(qWords, words(tn));
                if (mw1.hits === 1) {
                    reason = 'совпадает ключевое слово'; score = 3;
                    hitWords = mw1.hitWords;
                }
            }

            if (score === 999 && qn.length >= 5 && tn.length >= 5 && lev(qn, tn) <= 2) {
                reason = 'очень похоже (опечатка?)'; score = 4;
            }

            if (score !== 999) out.push({ t: t, reason: reason, score: score, hitWords: hitWords });
        }

        out.sort(function(a, b){ return a.score - b.score; });

        var seen2 = {};
        var uniq = [];
        for (var j = 0; j < out.length && uniq.length < 6; j++) {
            if (!seen2[out[j].t.id]) {
                seen2[out[j].t.id] = true;
                uniq.push(out[j]);
            }
        }
        return uniq;
    }

    function renderHint(hint, q) {
        var inp = document.getElementById('task_name');
        if (!inp || !hint) return;
        var found = findSimilar(q);
        if (!found.length) {
            hint.setAttribute('hidden', '');
            hint.innerHTML = '';
            return;
        }
        hint.removeAttribute('hidden');
        var html = '<div class="tdh-title">⚠ Найдены похожие задачи (' + found.length + '):</div><div class="tdh-list">';
        found.forEach(function(x){
            html += '<div class="tdh-row" data-tid="' + esc(x.t.id) + '">'
                 +  '<span class="tdh-ico">' + esc(x.t.icon || '📋') + '</span>'
                 +  '<span class="tdh-name">' + highlightWords(x.t.name, x.hitWords) + '</span>'
                 +  '<span class="tdh-reason">' + esc(x.reason) + '</span>'
                 +  '<button type="button" class="tdh-open">Открыть</button>'
                 +  '</div>';
        });
        html += '</div>';
        hint.innerHTML = html;
        hint.querySelectorAll('.tdh-open').forEach(function(b){
            b.addEventListener('click', function(e){
                e.preventDefault(); e.stopPropagation();
                var row = this.closest('.tdh-row');
                var tid = row ? row.getAttribute('data-tid') : '';
                if (!tid) return;
                var st = window.__trkState;
                var t = null;
                var tasks = (st && Array.isArray(st.tasks)) ? st.tasks : [];
                for (var i = 0; i < tasks.length; i++) {
                    if (tasks[i].id === tid) { t = tasks[i]; break; }
                }
                if (!t) return;
                if (!confirm('Открыть существующую задачу «' + t.name + '»?\n\nТекущая форма будет закрыта.')) return;
                var m = document.getElementById('taskModal');
                if (m) m.classList.remove('active');
                if (typeof window.__trkOpenTaskModal === 'function') {
                    setTimeout(function(){ window.__trkOpenTaskModal(t); }, 120);
                }
            });
        });
    }

    function ensure() {
        var inp = document.getElementById('task_name');
        var hint = document.getElementById('taskDupHint');
        if (!inp) return false;
        if (!hint) {
            hint = document.createElement('div');
            hint.className = 'task-dup-hint';
            hint.id = 'taskDupHint';
            hint.setAttribute('hidden', '');
            inp.parentNode.insertBefore(hint, inp.nextSibling);
        }
        if (inp._dupV113Final) return true;
        inp._dupV113Final = true;
        var handler = function() {
            var q = inp.value || '';
            if (q.trim().length < 3) {
                hint.setAttribute('hidden', '');
                hint.innerHTML = '';
                return;
            }
            renderHint(hint, q);
        };
        inp.addEventListener('input', handler);
        inp.addEventListener('change', handler);
        inp.addEventListener('keyup', handler);
        inp.addEventListener('paste', function(){ setTimeout(handler, 50); });
        return true;
    }

    function watchModal() {
        var m = document.getElementById('taskModal');
        if (!m || m._dupV113FinalObs) return;
        m._dupV113FinalObs = true;
        var obs = new MutationObserver(function(){
            if (m.classList.contains('active')) {
                setTimeout(ensure, 30);
                setTimeout(ensure, 200);
                setTimeout(ensure, 500);
            }
        });
        obs.observe(m, { attributes: true, attributeFilter: ['class'] });
    }

    function boot() {
        watchModal();
        setTimeout(watchModal, 500);
        setTimeout(watchModal, 1500);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else { boot(); }

    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('#addTaskBtn') || e.target.closest('#addTaskBtn2')) {
            setTimeout(ensure, 60);
            setTimeout(ensure, 250);
            setTimeout(ensure, 600);
        }
    }, true);

    window.__trkDupCheck = ensure;
})();
/* ============================================================
   v1.1.5 — Очистка блоков похожих задач при закрытии карточек
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkDupCleanupV115) return;
    window.__trkDupCleanupV115 = true;

    function clearHint(id) {
        var h = document.getElementById(id);
        if (!h) return;
        h.setAttribute('hidden', '');
        h.innerHTML = '';
    }

    function attach(modalId, hintId, inputId) {
        var m = document.getElementById(modalId);
        if (!m || m._dupCleanupV115) return;
        m._dupCleanupV115 = true;
        var obs = new MutationObserver(function(){
            if (!m.classList.contains('active')) {
                clearHint(hintId);
            }
        });
        obs.observe(m, { attributes: true, attributeFilter: ['class'] });
    }

    function boot() {
        attach('taskModal', 'taskDupHint', 'task_name');
        attach('logModal', 'logTaskDupHint', 'log_task_input');
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else { boot(); }
    setTimeout(boot, 700);
    setTimeout(boot, 1800);
})();
/* ============================================================
   v1.1.4 — Расширенный поиск задачи в карточке отметки
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkLogTaskSearchV114) return;
    window.__trkLogTaskSearchV114 = true;

    function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });}
    function norm(s){return String(s==null?'':s).trim().toLowerCase().replace(/\s+/g,' ');}
    function words(s){
        return String(s||'').toLowerCase()
            .split(/[\s\-_.:,;!?/\\|]+/)
            .map(function(w){return w.trim();})
            .filter(function(w){return w.length>=2;});
    }
    function lev(a,b){
        if (a===b) return 0;
        var la=a.length, lb=b.length;
        if (la===0) return lb; if (lb===0) return la;
        var prev=[], cur=[];
        for (var j=0;j<=lb;j++) prev[j]=j;
        for (var i=1;i<=la;i++){
            cur[0]=i;
            for (var k=1;k<=lb;k++){
                var cost=a[i-1]===b[k-1]?0:1;
                cur[k]=Math.min(cur[k-1]+1,prev[k]+1,prev[k-1]+cost);
            }
            prev=cur.slice();
        }
        return prev[lb];
    }
    function matchWords(qw, tw){
        var hits=0, hitWords=[];
        for (var i=0;i<qw.length;i++){
            var q=qw[i];
            for (var j=0;j<tw.length;j++){
                var w=tw[j];
                if (w===q){hits++;hitWords.push(q);break;}
                if (w.length>=4&&q.length>=4&&w.indexOf(q)!==-1){hits++;hitWords.push(q);break;}
                if (w.length>=4&&q.length>=4&&q.indexOf(w)!==-1){hits++;hitWords.push(q);break;}
                if (w.length>=5&&q.length>=5&&lev(w,q)<=1){hits++;hitWords.push(q);break;}
            }
        }
        return {hits:hits, hitWords:hitWords};
    }
    function highlight(name, hitWords){
        if (!hitWords||!hitWords.length) return esc(name);
        var out=esc(name), uniq=[], seen={};
        for (var i=0;i<hitWords.length;i++){
            var w=hitWords[i];
            if (!seen[w.toLowerCase()]){seen[w.toLowerCase()]=true;uniq.push(w);}
        }
        uniq.sort(function(a,b){return b.length-a.length;});
        for (var k=0;k<uniq.length;k++){
            var raw=uniq[k];
            var rx=new RegExp('('+raw.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')','ig');
            out=out.replace(rx,'<mark>$1</mark>');
        }
        return out;
    }
    function allTasks(){
        var st=window.__trkState;
        return (st&&Array.isArray(st.tasks))?st.tasks:[];
    }
    function statusHint(t){
        var s=t&&t.status;
        if (s==='done') return ' · готово';
        if (s==='archived') return ' · архив';
        if (s==='paused') return ' · пауза';
        return '';
    }
    function findSimilar(q){
        var tasks=allTasks();
        var qn=norm(q);
        if (qn.length<3||!tasks.length) return [];
        var qWords=words(qn);
        var out=[];
        for (var i=0;i<tasks.length;i++){
            var t=tasks[i];
            var tn=norm(t.name);
            if (!tn) continue;
            var reason='', score=999, hitWords=[];
            if (tn===qn){reason='точное совпадение';score=0;hitWords=qWords.slice();}
            else if (qn.length>=4&&tn.indexOf(qn)!==-1){reason='содержит весь ваш текст';score=1;hitWords=qWords.slice();}
            else if (tn.length>=4&&qn.indexOf(tn)!==-1){reason='входит в ваш текст';score=1;hitWords=qWords.slice();}
            else if (qWords.length>=2){
                var mw=matchWords(qWords, words(tn));
                if (mw.hits===qWords.length){reason='совпадают все слова';score=2;hitWords=mw.hitWords;}
                else if (mw.hits>=2&&mw.hits>=Math.ceil(qWords.length/2)){reason='совпадают '+mw.hits+' из '+qWords.length+' слов';score=3;hitWords=mw.hitWords;}
            } else if (qWords.length===1){
                var mw1=matchWords(qWords, words(tn));
                if (mw1.hits===1){reason='совпадает ключевое слово';score=3;hitWords=mw1.hitWords;}
            }
            if (score===999&&qn.length>=5&&tn.length>=5&&lev(qn,tn)<=2){
                reason='очень похоже (опечатка?)';score=4;
            }
            if (score!==999) out.push({t:t, reason:reason, score:score, hitWords:hitWords});
        }
        out.sort(function(a,b){return a.score-b.score;});
        var seen={}, uniq=[];
        for (var j=0;j<out.length&&uniq.length<8;j++){
            if (!seen[out[j].t.id]){seen[out[j].t.id]=true;uniq.push(out[j]);}
        }
        return uniq;
    }
    function findExact(q){
        var tasks=allTasks();
        var qn=norm(q);
        if (!qn) return null;
        var qn2 = qn.replace(/\s*\(архив\)\s*/g,'').replace(/\s*⚠\s*/g,'').trim();
        for (var i=0;i<tasks.length;i++){
            var tn=norm(tasks[i].name);
            if (tn===qn||tn===qn2) return tasks[i];
        }
        return null;
    }
    function getHint(){
        var h=document.getElementById('logTaskHint');
        if (h) return h;
        var inp=document.getElementById('log_task_input');
        if (!inp) return null;
        var wrap=inp.closest('.form-group')||inp.closest('.log-task-wrap')||inp.parentNode;
        h=document.createElement('div');
        h.className='log-task-hint';
        h.id='logTaskHint';
        h.setAttribute('hidden','');
        if (wrap&&wrap.parentNode) wrap.parentNode.insertBefore(h,wrap.nextSibling);
        return h;
    }
    function clearHint(){
        var h=document.getElementById('logTaskHint');
        if (!h) return;
        h.setAttribute('hidden','');
        h.innerHTML='';
    }
    function pickTask(t){
        var inp=document.getElementById('log_task_input');
        var hid=document.getElementById('log_task');
        var label = t.name + (t.status==='done'||t.status==='archived'?' (архив)':'');
        if (inp) inp.value=label;
        if (hid) hid.value=t.id;
        clearHint();
        var warn=document.getElementById('log_task_warn');
        if (warn) warn.style.display='none';
        var hours=document.getElementById('log_hours');
        if (hours) try{hours.focus();}catch(e){}
        if (typeof window.__trkUpdateLogTaskHidden === 'function') {
            try { window.__trkUpdateLogTaskHidden(); } catch(e){}
        }
    }
    function renderHint(hint, q){
        var found=findSimilar(q);
        if (!found.length){
            clearHint();
            return;
        }
        hint.removeAttribute('hidden');
        var html='<div class="lth-title">⚠ Похожие задачи ('+found.length+') — нажмите «Выбрать»:</div><div class="lth-list">';
        found.forEach(function(x){
            html+='<div class="lth-row" data-tid="'+esc(x.t.id)+'">'
                +  '<span class="lth-ico">'+esc(x.t.icon||'📋')+'</span>'
                +  '<span class="lth-name">'+highlight(x.t.name,x.hitWords)+'</span>'
                +  '<span class="lth-reason">'+esc(x.reason+statusHint(x.t))+'</span>'
                +  '<button type="button" class="lth-pick">Выбрать</button>'
                +  '</div>';
        });
        html+='</div>';
        hint.innerHTML=html;
        hint.querySelectorAll('.lth-pick').forEach(function(b){
            b.addEventListener('click',function(e){
                e.preventDefault(); e.stopPropagation();
                var row=this.closest('.lth-row');
                var tid=row?row.getAttribute('data-tid'):'';
                if (!tid) return;
                var tasks=allTasks();
                var t=null;
                for (var i=0;i<tasks.length;i++) if (tasks[i].id===tid){t=tasks[i];break;}
                if (!t) return;
                pickTask(t);
            });
        });
    }
    function handler(){
        var inp=document.getElementById('log_task_input');
        if (!inp) return;
        var hid=document.getElementById('log_task');
        var q=inp.value||'';
        if (!q.trim()){
            if (hid) hid.value='';
            clearHint();
            return;
        }
        var exact=findExact(q);
        if (exact){
            if (hid) hid.value=exact.id;
            clearHint();
            return;
        }
        // PATCH v3: НЕ обнуляем #log_task при редактировании текста — 
        // оставляем последнее валидное значение, пока пользователь не 
        // выберет другую задачу через подсказки. Раньше при вводе/правке 
        // текста после выбора задачи значение сбрасывалось и сервер 
        // возвращал «Выберите задачу».
        if (q.trim().length < 3){ clearHint(); return; }
        renderHint(getHint(), q);
    }
    function ensure(){
        var inp=document.getElementById('log_task_input');
        if (!inp) return false;
        getHint();
        if (inp._logTaskSearchV114) return true;
        inp._logTaskSearchV114=true;
        inp.addEventListener('input',handler);
        inp.addEventListener('change',handler);
        inp.addEventListener('keyup',handler);
        inp.addEventListener('paste',function(){setTimeout(handler,50);});
        return true;
    }
    function watchModal(){
        var m=document.getElementById('logModal');
        if (!m||m._logTaskSearchV114Obs) return;
        m._logTaskSearchV114Obs=true;
        var obs=new MutationObserver(function(){
            if (m.classList.contains('active')){
                clearHint();
                setTimeout(ensure,40);
                setTimeout(ensure,200);
                setTimeout(ensure,600);
            } else {
                clearHint();
            }
        });
        obs.observe(m,{attributes:true,attributeFilter:['class']});
    }
    function boot(){
        watchModal();
        setTimeout(watchModal,500);
        setTimeout(watchModal,1500);
    }
    if (document.readyState==='loading'){
        document.addEventListener('DOMContentLoaded',boot);
    } else { boot(); }

    document.addEventListener('click',function(e){
        if (!e.target||!e.target.closest) return;
        if (e.target.closest('#dayAddBtn')){
            setTimeout(clearHint,30);
            setTimeout(ensure,100);
            setTimeout(ensure,400);
        }
    },true);

    window.__trkLogTaskSearch = { ensure: ensure, handler: handler };
})();
/* ============================================================
   v1.1.6 — Переключение порядка модалок taskModal / logModal
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkModalStackV116) return;
    window.__trkModalStackV116 = true;

    var LOWER = ['logModal', 'dayModal', 'employeeModal', 'departmentModal', 'teamModal', 'userModal'];

    function anyLowerActive() {
        for (var i = 0; i < LOWER.length; i++) {
            var el = document.getElementById(LOWER[i]);
            if (el && el.classList.contains('active')) return true;
        }
        return false;
    }

    function updateStack() {
        var tm = document.getElementById('taskModal');
        if (!tm) return;
        if (tm.classList.contains('active')) {
            tm.style.zIndex = '3500';
        } else if (anyLowerActive()) {
            tm.style.removeProperty('z-index');
        }
    }

    function watch() {
        var ids = ['taskModal'].concat(LOWER);
        for (var i = 0; i < ids.length; i++) {
            var el = document.getElementById(ids[i]);
            if (!el || el._zstackV116) continue;
            el._zstackV116 = true;
            new MutationObserver(updateStack).observe(el, {
                attributes: true,
                attributeFilter: ['class']
            });
        }
        updateStack();
    }

    watch();
    setTimeout(watch, 500);
    setTimeout(watch, 1500);
})();
/* ============================================================
   v1.2.3 — Быстрое добавление назначенной задачи из logModal
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkQuickAddAssigned) return;
    window.__trkQuickAddAssigned = true;

    function toast(msg, kind){
        var n = document.getElementById('trackerNotif');
        if (!n) { alert(msg); return; }
        n.textContent = msg;
        n.className = 'tracker-notification show' + (kind === 'error' ? ' error' : '');
        clearTimeout(n._t);
        n._t = setTimeout(function(){ n.classList.remove('show'); }, 3500);
    }

    function doQuickAdd(tile) {
        var logModal = document.getElementById('logModal');
        if (!logModal) return;
        var tid = tile.getAttribute('data-task-id');
        if (!tid) return;

        var empEl = document.getElementById('log_employee');
        var dtEl = document.getElementById('log_date');
        var empId = empEl ? empEl.value : '';
        var dk = dtEl ? dtEl.value : '';
        if (!empId) { toast('❌ Выберите сотрудника', 'error'); return; }
        if (!dk) { toast('❌ Некорректная дата', 'error'); return; }

        var st = window.__trkState || {};
        var day = null;
        if (st.calendar && st.calendar.days) {
            day = st.calendar.days.find(function(d){ return d.date === dk; });
        }
        var n = 0;
        if (day && day.entries) {
            day.entries.forEach(function(en){
                if (en.employee_id === empId) n++;
            });
        }
        var hrs = Math.round((((window.__trkGetDayNorm ? window.__trkGetDayNorm(dk) : 8) || 8) / (n + 1)) * 4) / 4;
        if (hrs < 0.5) hrs = 0.5;
        if (hrs > 24) hrs = 24;

        var hdrs = { 'Content-Type': 'application/json' };
        if (window.REESTR_CSRF) hdrs['X-CSRF-Token'] = window.REESTR_CSRF;

        var btn = tile.querySelector('.lab-add');
        if (btn) btn.disabled = true;
        tile.style.opacity = '0.5';

        fetch('/api/tracker/log/save', {
            method: 'POST',
            headers: hdrs,
            credentials: 'same-origin',
            body: JSON.stringify({
                employee_id: empId,
                task_id: tid,
                date: dk,
                hours: hrs,
                status: 'in_progress',
                comment: 'Назначенная задача, добавлена из карточки отметки',
                link: ''
            })
        })
        .then(function(r){ return r.json().then(function(j){ return { ok: r.ok, d: j }; }); })
        .then(function(res){
            if (!res.ok || !res.d || !res.d.success) {
                if (btn) btn.disabled = false;
                tile.style.opacity = '';
                var err = (res.d && res.d.error) || ('HTTP ' + res.ok);
                if (err === 'cancelled' || err === 'Отменено пользователем') return;
                toast('❌ ' + err, 'error');
                return;
            }
            logModal.classList.remove('active');
            toast('✅ Задача добавлена в день', 'success');
            // PATCH v1.0.6: обновляем активную вкладку, не только календарь
            var _refresh = (typeof window.__trkRefreshAll === 'function')
                ? window.__trkRefreshAll
                : (typeof window.__trkRenderCalendar === 'function' ? window.__trkRenderCalendar : null);
            if (_refresh) { Promise.resolve(_refresh()); }
        })
        .catch(function(e){
            if (btn) btn.disabled = false;
            tile.style.opacity = '';
            if (e && e.message && e.message.indexOf('cancelled') !== -1) return;
            toast('❌ ' + (e.message || 'Ошибка'), 'error');
        });
    }

    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        var tile = e.target.closest('#logModal .lab-tile');
        if (!tile) return;
        e.preventDefault();
        e.stopPropagation();
        if (e.stopImmediatePropagation) e.stopImmediatePropagation();
        doQuickAdd(tile);
    }, true);
})();
/* ============================================================
   v1.2.6 — История работы в карточке задачи
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkTaskFeedRender) return;
    function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
    function initials(n){var p=String(n||'').trim().split(/\s+/);if(!p.length)return'?';if(p.length===1)return p[0].slice(0,2).toUpperCase();return (p[0][0]+(p[1][0]||'')).toUpperCase();}
    function fh(h){h=Number(h)||0;if(h===Math.floor(h))return h+' ч';return h.toFixed(2).replace(/0+$/,'').replace(/\.$/,'')+' ч';}
    function fd(iso){if(!iso)return '';var p=iso.split('-');if(p.length!==3)return iso;return p[2]+'.'+p[1]+'.'+p[0];}

    window.__trkTaskFeedRender = function(d){
        if (!document.getElementById('tcfStyleV19')) {
            var _s = document.createElement('style');
            _s.id = 'tcfStyleV19';
            _s.textContent = [
                '.tcf-wrap{margin:12px 0 8px}',
                '.tcf-block{background:rgba(255,255,255,0.03);border:1px solid rgba(245,215,110,0.12);border-radius:12px;padding:12px 14px}',
                '.tcf-head{display:flex;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap}',
                '.tcf-title{font-weight:700;font-size:0.95rem}',
                '.tcf-meta{opacity:0.55;font-size:0.8rem;margin-left:auto}',
                '.tcf-feed{display:flex;flex-direction:column;gap:8px;max-height:320px;overflow:auto;padding-right:4px}',
                '.tcf-item{display:flex;gap:10px;padding:8px 10px;border-radius:10px;background:rgba(0,0,0,0.18);border-left:3px solid rgba(245,215,110,0.35)}',
                '.tcf-item--done{border-left-color:#2ecc71}',
                '.tcf-item--blocked{border-left-color:#e74c3c}',
                '.tcf-item--planned{border-left-color:#95a5a6}',
                '.tcf-item--in_progress{border-left-color:#3498db}',
                '.tcf-av{width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.7rem;font-weight:700;color:#111;flex-shrink:0}',
                '.tcf-body{flex:1;min-width:0}',
                '.tcf-line1{display:flex;flex-wrap:wrap;gap:6px 10px;align-items:center;font-size:0.82rem}',
                '.tcf-name{font-weight:600}',
                '.tcf-date{opacity:0.55}',
                '.tcf-st{font-size:0.75rem;padding:1px 6px;border-radius:6px;background:rgba(255,255,255,0.06)}',
                '.tcf-st-done{color:#2ecc71}',
                '.tcf-st-blocked{color:#e74c3c}',
                '.tcf-h{font-weight:700;color:#f5d76e}',
                '.tcf-text{margin-top:4px;font-size:0.85rem;line-height:1.35;white-space:pre-wrap;word-break:break-word}',
                '.tcf-text-muted{opacity:0.4;font-style:italic}',
                '.tcf-empty{opacity:0.45;padding:8px 0;font-size:0.85rem}',
                '.tcf-links-head{margin-top:10px;font-weight:600;font-size:0.85rem}',
                '.tcf-links{display:flex;flex-direction:column;gap:4px;margin-top:6px}',
                '.tcf-link{display:flex;gap:8px;font-size:0.8rem;color:#7ec8ff;text-decoration:none}',
                '.tcf-link:hover{text-decoration:underline}'
            ].join('');
            document.head.appendChild(_s);
        }

        var wrap = document.getElementById('taskCardFeed');
        if (!wrap) {
            var modal = document.getElementById('taskCardModal');
            var content = modal ? modal.querySelector('.modal-content') : null;
            if (!content) return;
            var list = document.getElementById('taskCardEmployees');
            if (!list || !list.parentNode) return;
            wrap = document.createElement('div');
            wrap.id = 'taskCardFeed';
            wrap.className = 'tcf-wrap';
            list.parentNode.insertBefore(wrap, list.nextSibling);
        }
        var feed = d.feed || [];
        var links = d.links || [];
        var first_log = d.first_log || '';
        var last_log = d.last_log || '';

        var h = '<div class="tcf-block">';
        h += '<div class="tcf-head">';
        h += '<span class="tcf-icon">📖</span>';
        h += '<span class="tcf-title">История работы</span>';
        h += '<span class="tcf-meta">';
        if (first_log) h += fd(first_log);
        if (first_log && last_log && first_log !== last_log) h += ' — ' + fd(last_log);
        h += ' · ' + feed.length + ' коммент.' + (links.length ? ' · ' + links.length + ' ссылок' : '');
        h += '</span>';
        h += '</div>';
        if (!feed.length && !links.length) {
            h += '<div class="tcf-empty">Пока нет отметок по этой задаче</div>';
        } else {
            if (feed.length) {
                h += '<div class="tcf-feed">';
                feed.forEach(function(x){
                    var bg = esc(x.employee_color || '#888');
                    var st = String(x.status || '');
                    var stCls = st === 'done' ? 'tcf-st-done' : (st === 'blocked' ? 'tcf-st-blocked' : (st === 'planned' ? 'tcf-st-planned' : 'tcf-st-work'));
                    h += '<div class="tcf-item tcf-item--' + esc(st || 'log') + '">';
                    h += '<div class="tcf-av" style="background:' + bg + ';">' + esc(initials(x.employee_name)) + '</div>';
                    h += '<div class="tcf-body">';
                    h += '<div class="tcf-line1">';
                    h += '<span class="tcf-name">' + esc(x.employee_name) + '</span>';
                    h += '<span class="tcf-date">' + esc(fd(x.date)) + '</span>';
                    if (x.status_label) h += '<span class="tcf-st ' + stCls + '">' + esc(x.status_label) + '</span>';
                    if (x.hours) h += '<span class="tcf-h">' + esc(fh(x.hours)) + '</span>';
                    h += '</div>';
                    if (x.comment) {
                        h += '<div class="tcf-text">' + esc(x.comment) + '</div>';
                    } else {
                        h += '<div class="tcf-text tcf-text-muted">отметка без комментария</div>';
                    }
                    h += '</div></div>';
                });
                h += '</div>';
            }
            if (links.length) {
                h += '<div class="tcf-links-head">🔗 Ссылки</div>';
                h += '<div class="tcf-links">';
                links.forEach(function(x){
                    h += '<a class="tcf-link" href="' + esc(x.link) + '" target="_blank" rel="noopener">';
                    h += '<span class="tcf-link-date">' + esc(fd(x.date)) + '</span>';
                    h += '<span class="tcf-link-url">' + esc(x.link) + '</span>';
                    h += '</a>';
                });
                h += '</div>';
            }
        }
        h += '</div>';
        wrap.innerHTML = h;
    };
})();
/* ============================================================
   v1.2.7 — Объединение задач
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkTaskMerge) return;
    window.__trkTaskMerge = true;

    function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
    function selected(){ var out=[]; document.querySelectorAll('.task-merge-cb:checked').forEach(function(cb){ out.push(cb.getAttribute('data-task-id')); }); return out; }
    function updateBar(){
        var bar = document.getElementById('taskMergeBar');
        if (!bar) return;
        var n = selected().length;
        bar.style.display = n >= 2 ? '' : 'none';
        var c = document.getElementById('taskMergeCount');
        if (c) c.textContent = n;
    }
    function addCbs(){
        var list = document.getElementById('tasksFullList');
        if (!list) return;
        list.querySelectorAll('.task-card').forEach(function(card){
            if (card.querySelector('.task-merge-cb')) return;
            var id = card.getAttribute('data-id');
            if (!id) return;
            var cb = document.createElement('input');
            cb.type = 'checkbox';
            cb.className = 'task-merge-cb';
            cb.setAttribute('data-task-id', id);
            cb.title = 'Выбрать для объединения';
            cb.addEventListener('click', function(e){ e.stopPropagation(); });
            cb.addEventListener('change', updateBar);
            card.insertBefore(cb, card.firstChild);
        });
        var wrap = document.getElementById('panel-tasks');
        if (wrap && !document.getElementById('taskMergeBar')) {
            var toolbar = wrap.querySelector('.sum-toolbar');
            if (toolbar) {
                var bar = document.createElement('div');
                bar.id = 'taskMergeBar';
                bar.className = 'task-merge-bar';
                bar.style.display = 'none';
                bar.innerHTML = '<span>🔗 Выбрано <b id="taskMergeCount">0</b> задач</span>'
                    + '<button type="button" class="btn btn-primary" id="taskMergeBtn">Объединить</button>'
                    + '<button type="button" class="btn btn-secondary" id="taskMergeClear">Сбросить</button>';
                toolbar.parentNode.insertBefore(bar, toolbar.nextSibling);
                document.getElementById('taskMergeBtn').addEventListener('click', openModal);
                document.getElementById('taskMergeClear').addEventListener('click', function(){
                    document.querySelectorAll('.task-merge-cb:checked').forEach(function(cb){ cb.checked = false; });
                    updateBar();
                });
            }
        }
    }

    function openModal(){
        var ids = selected();
        if (ids.length < 2) return;
        var st = window.__trkState || {};
        var tasks = (st.tasks || []).filter(function(t){ return ids.indexOf(t.id) !== -1; });
        if (tasks.length < 2) return;

        var h = '';
        h += '<div class="tmm-hint">Все поля будут собраны автоматически:</div>';
        h += '<ul class="tmm-rules">';
        h += '<li><b>Название, иконка, статус, даты</b> — от выбранной (radio) задачи</li>';
        h += '<li><b>Теги, отделы, исполнители</b> — объединятся со всех задач</li>';
        h += '<li><b>Описание, папки, приказы</b> — склеятся, по одному значению на строку</li>';
        h += '</ul>';
        h += '<div class="tmm-list-title">Клик — сделать выбранную основной (остальные удалятся):</div>';
        h += '<div class="tmm-list">';
        tasks.forEach(function(t, i){
            var desc = (t.description||'').replace(/\s+/g,' ').trim();
            var folder = (t.folder||'').trim();
            var order = (t.order_ref||'').trim();
            var empsN = (t.assignees||[]).length;
            var tagsN = (t.tags||[]).length;
            var depsN = (t.department_ids||[]).length;
            h += '<label class="tmm-card' + (i===0?' selected':'') + '">';
            h += '<input type="radio" name="tmm_survivor" value="' + esc(t.id) + '"' + (i===0?' checked':'') + '>';
            h += '<span class="tmm-ico">' + esc(t.icon||'📋') + '</span>';
            h += '<div class="tmm-body">';
            h += '<div class="tmm-name">' + esc(t.name) + '</div>';
            h += '<div class="tmm-meta">';
            h += '<span>📅 ' + (t.start_date||'—') + ' → ' + (t.deadline||'—') + '</span>';
            h += '<span>🏷 ' + tagsN + '</span>';
            h += '<span>👥 ' + empsN + '</span>';
            h += '<span>🏢 ' + depsN + '</span>';
            h += '</div>';
            if (desc) h += '<div class="tmm-desc">' + esc(desc.slice(0, 140)) + (desc.length>140?'…':'') + '</div>';
            if (folder) h += '<div class="tmm-fold">📁 ' + esc(folder.split('\n').filter(Boolean).slice(0,2).join(' · ')) + (folder.split('\n').length>2?'…':'') + '</div>';
            if (order) h += '<div class="tmm-ord">📄 ' + esc(order.split('\n').filter(Boolean).slice(0,2).join(' · ')) + (order.split('\n').length>2?'…':'') + '</div>';
            h += '</div></label>';
        });
        h += '</div>';
        h += '<div class="modal-actions"><button class="btn btn-secondary" data-close="taskMergeModal">Закрыть</button>';
        h += '<button class="btn btn-primary" id="tmm_submit">🔗 Объединить</button></div>';

        var modal = document.getElementById('taskMergeModal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'taskMergeModal';
            modal.className = 'modal';
            modal.innerHTML = '<div class="modal-content"><h2>🔗 Объединение задач</h2><div id="tmm_body"></div></div>';
            document.body.appendChild(modal);
            modal.addEventListener('click', function(e){ if (e.target === modal) modal.classList.remove('active'); });
        }
        document.getElementById('tmm_body').innerHTML = h;
        var body = document.getElementById('tmm_body');
        body.querySelectorAll('[data-close]').forEach(function(b){
            b.onclick = function(){ modal.classList.remove('active'); };
        });
        body.querySelectorAll('.tmm-card').forEach(function(card){
            card.addEventListener('click', function(){
                body.querySelectorAll('.tmm-card').forEach(function(c){ c.classList.remove('selected'); });
                card.classList.add('selected');
            });
        });
        document.getElementById('tmm_submit').onclick = function(){ submit(ids); };
        modal.classList.add('active');
    }

    function submit(ids){
        var survivor = '';
        document.querySelectorAll('input[name="tmm_survivor"]').forEach(function(r){ if (r.checked) survivor = r.value; });
        var payload = {
            task_ids: ids,
            survivor_id: survivor,
        };
        var hdrs = { 'Content-Type': 'application/json' };
        if (window.REESTR_CSRF) hdrs['X-CSRF-Token'] = window.REESTR_CSRF;
        fetch('/api/tracker/task/merge', {
            method: 'POST', headers: hdrs, credentials: 'same-origin',
            body: JSON.stringify(payload),
        })
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (!d.success) { alert('Ошибка: ' + (d.error || 'неизвестная')); return; }
            var modal = document.getElementById('taskMergeModal');
            if (modal) modal.classList.remove('active');
            document.querySelectorAll('.task-merge-cb:checked').forEach(function(cb){ cb.checked = false; });
            updateBar();
            if (typeof window.__trkLoadState === 'function') window.__trkLoadState();
            alert('✅ Объединено задач: ' + (1 + (d.merged_ids || []).length));
        })
        .catch(function(e){ alert('Ошибка: ' + e.message); });
    }

    function boot(){ addCbs(); setTimeout(addCbs, 500); setTimeout(addCbs, 1500); }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
    else boot();

    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('.tracker-tab[data-tab="tasks"]')) setTimeout(addCbs, 250);
    });
})();
/* ============================================================
   v1.2.12 — Watchdog лоадера: автозакрытие через 8 секунд
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkLoaderWatchdog) return;
    window.__trkLoaderWatchdog = true;

    function setup(el) {
        if (!el || el._watchdogHooked) return;
        el._watchdogHooked = true;
        el._shownAt = 0;
        new MutationObserver(function(){
            if (el.classList.contains('active')) {
                if (!el._shownAt) el._shownAt = Date.now();
            } else {
                el._shownAt = 0;
            }
        }).observe(el, { attributes: true, attributeFilter: ['class'] });
        setInterval(function(){
            if (!el.classList.contains('active')) return;
            if (!el._shownAt) { el._shownAt = Date.now(); return; }
            if (Date.now() - el._shownAt > 8000) {
                el.classList.remove('active');
                el._shownAt = 0;
                console.warn('[loader] автоскрытие: 8s');
            }
        }, 1000);
    }

    function find(){
        var el = document.getElementById('globalLoader');
        if (el) setup(el);
        else setTimeout(find, 500);
    }
    find();
})();
/* ============================================================
   v1.2.17 — Раздельные столбцы для Задач/Сотрудников,
   фикс column-count в «Сотрудниках», версия в шапке
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkFixesV1217) return;
    window.__trkFixesV1217 = true;

    var LS_TASKS = 'tracker_day_cols';
    var LS_EMP   = 'tracker_day_cols_emp';

    function readNum(key, def){
        try { var v = parseInt(localStorage.getItem(key), 10); if (v >= 1 && v <= 4) return v; } catch(e){}
        return def;
    }
    function writeNum(key, v){ try { localStorage.setItem(key, String(v)); } catch(e){} }

    function currentMode(){
        var list = document.getElementById('dayList');
        return list && list.classList.contains('day-list--employees') ? 'emp' : 'tasks';
    }
    function colsFor(mode){
        if (mode === 'emp') return readNum(LS_EMP, 1);
        return readNum(LS_TASKS, 1);
    }
    function saveFor(mode, v){
        if (mode === 'emp') writeNum(LS_EMP, v);
        else writeNum(LS_TASKS, v);
    }

    function pickerMax(mode){
        return mode === 'emp' ? 2 : 2;
    }

    function updatePickerVisibility(){
        var p = document.getElementById('dayColsPicker');
        if (!p) return;
        var mode = currentMode();
        var max = pickerMax(mode);
        p.querySelectorAll('button').forEach(function(b){
            var v = parseInt(b.getAttribute('data-cols'), 10);
            b.style.display = (v <= max) ? '' : 'none';
        });
    }

    function syncPicker(){
        var p = document.getElementById('dayColsPicker');
        if (!p) return;
        var v = colsFor(currentMode());
        p.querySelectorAll('button').forEach(function(b){
            b.classList.toggle('active', parseInt(b.getAttribute('data-cols'), 10) === v);
        });
    }

    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        var b = e.target.closest('#dayColsPicker button');
        if (!b) return;
        e.preventDefault();
        e.stopPropagation();
        if (e.stopImmediatePropagation) e.stopImmediatePropagation();
        var v = parseInt(b.getAttribute('data-cols'), 10);
        var mode = currentMode();
        var max = pickerMax(mode);
        if (!(v >= 1)) v = 1;
        if (v > max) v = max;
        saveFor(mode, v);
        if (typeof window.__trkApplyDayLayout === 'function') {
            setTimeout(window.__trkApplyDayLayout, 30);
        }
        setTimeout(syncPicker, 40);
    }, true);

    function applyAll(){
        var dayM = document.getElementById('dayModal');
        if (!dayM || !dayM.classList.contains('active')) return;
        var lm = document.getElementById('logModal');
        if (lm && lm.classList.contains('active')) return;
        var list = document.getElementById('dayList');
        if (!list) return;
        var mode = currentMode();
        var v = colsFor(mode);
        if (mode === 'emp') {
            list.style.setProperty('display', 'block', 'important');
            list.style.setProperty('column-count', 'auto', 'important');
            var tiles = list.querySelector('.day-emp-tiles');
            if (tiles) {
                tiles.style.setProperty('display', 'grid', 'important');
                tiles.style.setProperty('grid-template-columns',
                    v === 1 ? 'minmax(0, 1fr)' : 'repeat(2, minmax(0, 1fr))', 'important');
                tiles.style.setProperty('gap', '12px', 'important');
                tiles.style.setProperty('width', '100%', 'important');
                tiles.style.setProperty('align-items', 'stretch', 'important');
            }
        } else {
            list.style.removeProperty('column-count');
            list.style.removeProperty('display');
            list.setAttribute('data-cols', String(v));
        }
        list.setAttribute('data-cols', String(v));
        updatePickerVisibility();
        syncPicker();
    }

    window.__trkApplyDayLayout = applyAll;

    // PATCH v2: убран setInterval — вызывает перерисовку layout каждые 1.5 сек.
    // Теперь только по событиям: открытие dayModal, смена вида, смена кол-ва колонок.

    function ensureVersionBadge(){
        if (document.getElementById('trkVersionBadge')) return;
        var header = document.querySelector('.tracker-header');
        if (!header) return;
        var a = document.createElement('a');
        a.id = 'trkVersionBadge';
        a.className = 'theme-toggle-btn trk-version-badge';
        a.href = '/plugins/updater/';
        a.title = 'Версия программы и обновления';
        a.innerHTML = '<span class="tvb-ico">📦</span><span class="tvb-ver" id="trkVersionNum">—</span><span class="tvb-dot" id="trkVersionDot" style="display:none;"></span>';
        var userMenu = header.querySelector('.user-menu');
        if (userMenu) header.insertBefore(a, userMenu);
        else header.appendChild(a);
    }

    function checkVersion(){
        fetch('/api/plugins/updater/version', {credentials: 'same-origin'})
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (!d || !d.success) return;
                var vEl = document.getElementById('trkVersionNum');
                var dot = document.getElementById('trkVersionDot');
                if (vEl) vEl.textContent = 'v' + (d.version || '?');
                if (dot) {
                    if (d.has_update) {
                        dot.style.display = '';
                        dot.title = 'Доступно обновление ' + (d.remote_version || '');
                    } else {
                        dot.style.display = 'none';
                    }
                }
                var b = document.getElementById('trkVersionBadge');
                if (b) {
                    b.classList.toggle('has-update', !!d.has_update);
                    b.classList.toggle('has-gaps', !!d.has_gaps);
                    if (d.has_gaps) {
                        b.title = 'Цепочка патчей разорвана. Версия: ' + (d.version || '?') + '. Пропущено: ' + (d.missing_ids || []).join(', ');
                    } else {
                        b.title = 'Версия программы: ' + (d.version || '?');
                    }
                }
            })
            .catch(function(){});
    }

    ensureVersionBadge();
    setTimeout(ensureVersionBadge, 500);
    setTimeout(ensureVersionBadge, 1500);
    setTimeout(checkVersion, 900);
    setInterval(checkVersion, 5 * 60 * 1000);

    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('.tracker-tab')) setTimeout(ensureVersionBadge, 200);
    });

    // PATCH v2: layout применяем по событиям вместо интервала
    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('#dayViewMode button') ||
            e.target.closest('#dayColsPicker button')) {
            setTimeout(applyAll, 100);
            setTimeout(applyAll, 300);
        }
    }, true);

    // При открытии dayModal
    setTimeout(function(){
        var m = document.getElementById('dayModal');
        if (!m) return;
        new MutationObserver(function(){
            if (m.classList.contains('active')) {
                setTimeout(applyAll, 60);
                setTimeout(applyAll, 250);
            }
        }).observe(m, { attributes: true, attributeFilter: ['class'] });
    }, 600);
})();
/* ============================================================
   v1.2.21 — Дополнительная информация в карточках Задач
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkTaskExtraInfo) return;
    window.__trkTaskExtraInfo = true;

    function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
    function trunc(s, n){ s = String(s||''); return s.length > n ? s.slice(0, n - 1) + '…' : s; }

    function linksByTask(){
        var st = window.__trkState || {};
        var out = {};
        var logs = st.log || [];
        var cutoff = '';
        try {
            var d = new Date();
            d.setDate(d.getDate() - 90);
            cutoff = d.toISOString().slice(0, 10);
        } catch(e) {}
        for (var i = 0; i < logs.length; i++) {
            var l = logs[i];
            var tid = l.task_id;
            var lk = (l.link || '').trim();
            if (!tid || !lk) continue;
            if (cutoff && (l.date || '') < cutoff) continue;
            var arr = out[tid] || (out[tid] = []);
            var seen = false;
            for (var k = 0; k < arr.length; k++) if (arr[k] === lk) { seen = true; break; }
            if (!seen) arr.push(lk);
            if (arr.length >= 5) continue;
        }
        return out;
    }

    function buildExtraHtml(t, links) {
        var h = '';
        var desc = (t.description || '').trim();
        if (desc) {
            h += '<div class="txi txi-desc" title="' + esc(desc) + '">' + esc(trunc(desc.replace(/\s+/g, ' '), 220)) + '</div>';
        }
        var folders = (t.folder || '').split(/\r?\n/).map(function(x){ return x.trim(); }).filter(Boolean);
        var orders = (t.order_ref || '').split(/\r?\n/).map(function(x){ return x.trim(); }).filter(Boolean);
        if (orders.length) {
            var showO = orders.slice(0, 2).map(esc).join(' · ');
            var restO = orders.length > 2 ? ' <span class="txi-more">+' + (orders.length - 2) + '</span>' : '';
            h += '<div class="txi txi-ord" title="' + esc(orders.join('\n')) + '">📄 ' + showO + restO + '</div>';
        }
        if (folders.length) {
            var showF = folders.slice(0, 2).map(esc).join(' · ');
            var restF = folders.length > 2 ? ' <span class="txi-more">+' + (folders.length - 2) + '</span>' : '';
            h += '<div class="txi txi-fold" title="' + esc(folders.join('\n')) + '">📁 ' + showF + restF + '</div>';
        }
        if (links && links.length) {
            h += '<div class="txi txi-links">';
            links.slice(0, 3).forEach(function(lk){
                h += '<a class="txi-link" href="' + esc(lk) + '" target="_blank" rel="noopener" title="' + esc(lk) + '">🔗 ' + esc(trunc(lk, 60)) + '</a>';
            });
            if (links.length > 3) h += '<span class="txi-more">+' + (links.length - 3) + '</span>';
            h += '</div>';
        }
        if (!h) return '';
        return '<div class="task-card-extra">' + h + '</div>';
    }

    function injectForList() {
        var list = document.getElementById('tasksFullList');
        if (!list) return;
        var st = window.__trkState || {};
        var tasks = {};
        (st.tasks || []).forEach(function(t){ tasks[t.id] = t; });
        var links = linksByTask();
        list.querySelectorAll('.task-card, .dict-item').forEach(function(card){
            var id = card.getAttribute('data-id');
            if (!id) return;
            var t = tasks[id];
            if (!t) return;
            var old = card.querySelector('.task-card-extra');
            if (old) old.remove();
            var html = buildExtraHtml(t, links[id] || []);
            if (!html) return;
            var head = card.querySelector('.task-card-head');
            if (head && head.parentNode) {
                head.parentNode.insertBefore(htmlToNode(html), head.nextSibling);
                return;
            }
            var body = card.querySelector('.dict-item-body');
            if (body) body.appendChild(htmlToNode(html));
        });
    }

    function htmlToNode(html) {
        var w = document.createElement('div');
        w.innerHTML = html;
        return w.firstElementChild;
    }

    function boot(){
        injectForList();
        setTimeout(injectForList, 400);
        setTimeout(injectForList, 1000);
        setTimeout(injectForList, 2000);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
    else boot();

    setInterval(function(){
        var panel = document.getElementById('panel-tasks');
        if (!panel || !panel.classList.contains('active')) return;
        injectForList();
    }, 2000);

    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('.tracker-tab[data-tab="tasks"]') ||
            e.target.closest('#tskDisplayMode button') ||
            e.target.closest('.sum-filter')) {
            setTimeout(injectForList, 350);
        }
    });

    window.__trkInjectTaskExtra = injectForList;
})();
/* ============================================================
   v1.0.2 — Пересчёт часов в карточке дня (клиентская страховка)
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkDayTotalFixV102) return;
    window.__trkDayTotalFixV102 = true;

    function fmtH(h){
        h = Number(h) || 0;
        if (h === Math.floor(h)) return h + ' ч';
        return h.toFixed(2).replace(/0+$/, '').replace(/\.$/, '') + ' ч';
    }

    function recalc() {
        var st = window.__trkState;
        if (!st || !st.currentDay || !st.calendar) return;
        var day = (st.calendar.days || []).find(function(d){ return d.date === st.currentDay; });
        if (!day) return;
        var entries = day.entries || [];
        var sum = 0;
        entries.forEach(function(en){
            var h = parseFloat(en.hours);
            if (!isNaN(h)) sum += h;
        });
        sum = Math.round(sum * 4) / 4;
        var el = document.getElementById('dayModalTotal');
        if (!el) return;
        var txt = fmtH(sum) + ' · ' + entries.length + ' записей';
        if (day.missing && day.missing.length) txt += ' · не заполнено: ' + day.missing.length;
        if (el.textContent !== txt) el.textContent = txt;
    }

    function wrapOpen() {
        var orig = window.__trkOpenDayModal;
        if (typeof orig !== 'function' || orig._totalFixHooked) return;
        var w = function() {
            var r = orig.apply(this, arguments);
            setTimeout(recalc, 40);
            setTimeout(recalc, 180);
            setTimeout(recalc, 400);
            return r;
        };
        w._totalFixHooked = true;
        window.__trkOpenDayModal = w;
    }

    wrapOpen();
    setTimeout(wrapOpen, 500);
    setTimeout(wrapOpen, 1500);
    setInterval(function(){
        var m = document.getElementById('dayModal');
        if (m && m.classList.contains('active')) recalc();
    }, 700);

    window.__trkRecalcDayTotal = recalc;
})();
/* ============================================================
   v1.0.4 — Автовыбор отделов по выбранным сотрудникам
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkAutoDepsV104) return;
    window.__trkAutoDepsV104 = true;

    function empDept(empId) {
        var st = window.__trkState;
        if (!st || !st.employees) return '';
        var e = st.employees.find(function(x){ return x.id === empId; });
        return (e && e.department_id) ? e.department_id : '';
    }

    function selectDept(deptId) {
        if (!deptId) return false;
        var list = document.getElementById('taskDepartmentsList');
        if (!list) return false;
        var cb = list.querySelector('input[type="checkbox"][value="' + deptId + '"]');
        if (!cb) return false;
        if (cb.checked) return false;
        cb.checked = true;
        try { cb.dispatchEvent(new Event('change', { bubbles: true })); } catch(e) {}
        return true;
    }

    function autoSelectAll() {
        var list = document.getElementById('taskAssigneesList');
        if (!list) return;
        var ids = [];
        list.querySelectorAll('input[type="checkbox"]:checked').forEach(function(cb){
            ids.push(cb.value);
        });
        ids.forEach(function(eid){ selectDept(empDept(eid)); });
    }

    document.addEventListener('change', function(e){
        if (!e.target || e.target.type !== 'checkbox') return;
        var list = e.target.closest('#taskAssigneesList');
        if (!list) return;
        if (!e.target.checked) return;
        var deptId = empDept(e.target.value);
        selectDept(deptId);
    }, true);

    function wrapOpenTaskModal() {
        var orig = window.__trkOpenTaskModal;
        if (typeof orig !== 'function' || orig._autoDepsHooked) return;
        var wrapped = function() {
            var r = orig.apply(this, arguments);
            setTimeout(autoSelectAll, 60);
            setTimeout(autoSelectAll, 200);
            return r;
        };
        wrapped._autoDepsHooked = true;
        window.__trkOpenTaskModal = wrapped;
    }

    wrapOpenTaskModal();
    setTimeout(wrapOpenTaskModal, 500);
    setTimeout(wrapOpenTaskModal, 1500);

    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('#addTaskBtn') || e.target.closest('#addTaskBtn2')) {
            setTimeout(autoSelectAll, 200);
            setTimeout(autoSelectAll, 500);
        }
    });

    window.__trkAutoSelectDepts = autoSelectAll;
})();
/* ============================================================
   v1.0.6 — Стабильный блок «Назначено, но не начато»
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkDayNSStableV106) return;
    window.__trkDayNSStableV106 = true;

    var CTX_ID = 'dayNotStartedWrap';
    var _lastSig = '';

    function esc(s){
        return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
        });
    }

    function fmtD(iso){
        if (!iso) return '';
        var p = iso.split('-');
        if (p.length !== 3) return iso;
        return p[2] + '.' + p[1];
    }

    function getWrap() {
        var wrap = document.getElementById(CTX_ID);
        if (wrap) return wrap;
        var list = document.getElementById('dayList');
        if (!list || !list.parentNode) return null;
        wrap = document.createElement('div');
        wrap.id = CTX_ID;
        wrap.className = 'day-notstarted-wrap';
        list.parentNode.insertBefore(wrap, list);
        return wrap;
    }

    function currentDay() {
        var st = window.__trkState;
        if (!st || !st.calendar || !st.currentDay) return null;
        return st.calendar.days.find(function(d){ return d.date === st.currentDay; }) || null;
    }

    function buildHtml(day) {
        var ns = day && day.not_started ? day.not_started : [];
        if (!ns.length) return '';
        var h = '<div class="day-notstarted-block">';
        h += '<div class="dns-head">';
        h += '<span class="dns-icon">🩶</span>';
        h += '<span class="dns-title">Назначено, но не начато</span>';
        h += '<span class="dns-count">' + ns.length + '</span>';
        h += '</div>';
        h += '<div class="dns-list">';
        ns.forEach(function(x){
            h += '<div class="dns-row">';
            h += '<span class="dns-emp-dot" style="background:' + esc(x.employee_color || '#888') + ';"></span>';
            h += '<span class="dns-task">' + esc(x.task_icon || '📋') + ' ' + esc(x.task_name || '') + '</span>';
            h += '<span class="dns-emp">' + esc(x.employee_name || '') + '</span>';
            h += '<span class="dns-dl">' + (x.deadline ? '⏰ ' + esc(fmtD(x.deadline)) : '') + '</span>';
            h += '</div>';
        });
        h += '</div></div>';
        return h;
    }

    function signature(day) {
        if (!day) return 'none';
        var ns = day.not_started || [];
        var parts = [day.date, String(ns.length)];
        for (var i = 0; i < ns.length; i++) {
            parts.push(ns[i].employee_id + ':' + ns[i].task_id);
        }
        return parts.join('|');
    }

    function render() {
        var modal = document.getElementById('dayModal');
        if (!modal || !modal.classList.contains('active')) return;
        var st = window.__trkState || {};
        var day = currentDay();
        if (day) {
            var _perms = window.REESTR_PERMS || {};
            var _meId = (st.currentUser && st.currentUser.employee_id) || '';
            var _isAdmin = !!(_perms['action.log.edit.any'] || _perms['block.calendar.other_employees']);
            var _ns = (day.not_started || []).slice();
            if (!_isAdmin) {
                var _targetEid = st.dayViewEmployeeId
                               || (st.currentUser && st.currentUser.employee_id) || '';
                if (st.dayViewMode === 'employee' && _targetEid) {
                    _ns = _ns.filter(function(x){ return x.employee_id === _targetEid; });
                } else if (_meId) {
                    _ns = _ns.filter(function(x){ return x.employee_id === _meId; });
                } else {
                    _ns = [];
                }
            }
            day = Object.assign({}, day, { not_started: _ns });
        }
        var sig = signature(day);
        if (sig === _lastSig) return;
        _lastSig = sig;
        var wrap = getWrap();
        if (!wrap) return;
        var html = buildHtml(day);
        if (!html) {
            if (wrap.innerHTML) wrap.innerHTML = '';
            return;
        }
        if (wrap.innerHTML !== html) wrap.innerHTML = html;
    }

    function attach() {
        var list = document.getElementById('dayList');
        if (!list || list._nsStableV106) return;
        list._nsStableV106 = true;
        new MutationObserver(function(){ render(); })
            .observe(list, { childList: true });
    }

    function wrapOpen() {
        var orig = window.__trkOpenDayModal;
        if (typeof orig !== 'function' || orig._nsStableV106) return;
        var w = function() {
            _lastSig = '';
            var r = orig.apply(this, arguments);
            setTimeout(render, 60);
            setTimeout(render, 220);
            return r;
        };
        w._nsStableV106 = true;
        window.__trkOpenDayModal = w;
    }

    function boot() {
        attach();
        wrapOpen();
        setTimeout(function(){ attach(); wrapOpen(); }, 700);
        setTimeout(function(){ attach(); wrapOpen(); }, 1800);
        setTimeout(render, 300);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else { boot(); }

    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('#dayViewMode button')) {
            _lastSig = '';
            setTimeout(render, 120);
        }
        if (e.target.closest('#dayAddBtn')) {
            _lastSig = '';
        }
    });

    window.__trkRenderDayNotStarted = render;
})();
/* ============================================================
   PATCH 1.0.11 — Динамический padding у logModal (закомментировано)
   PATCH v2: полностью удалён — PATCH 1.0.19 в CSS уже обнуляет 
   padding для всех вариантов #logModal .modal-content. 
   Динамический padding измерял высоту шапки и футера, но не 
   применял её (был закомментирован).
   ============================================================ */
/* ============================================================
   PATCH 1.0.16 — Log modal: обёртка тела для корректного скролла
   PATCH v2: в новом tracker.html .log-modal-body уже есть сразу, 
   поэтому функция wrapBody становится no-op (нечего оборачивать).
   Оставляю как безопасный fallback для старого HTML.
   ============================================================ */
(function() {
    'use strict';

    function wrapBody() {
        var modal = document.getElementById('logModal');
        if (!modal) return false;
        var content = modal.querySelector('.modal-content');
        if (!content) return false;
        // PATCH v2: если обёртка уже есть — выходим (нечего делать)
        if (content.querySelector('.log-modal-body')) return true;

        var h2 = null, foot = null;
        var kids = content.children;
        for (var i = 0; i < kids.length; i++) {
            var k = kids[i];
            if (k.tagName === 'H2' || k.id === 'logModalTitle') h2 = h2 || k;
            if (k.classList && k.classList.contains('modal-actions')) foot = foot || k;
        }
        if (!h2 || !foot) return false;

        var body = document.createElement('div');
        body.className = 'log-modal-body';

        var started = false;
        var toMove = [];
        for (var j = 0; j < kids.length; j++) {
            var ch = kids[j];
            if (ch === h2) { started = true; continue; }
            if (ch === foot) { started = false; continue; }
            if (started) toMove.push(ch);
        }
        toMove.forEach(function(ch) { body.appendChild(ch); });
        content.insertBefore(body, foot);

        content.style.removeProperty('padding-top');
        content.style.removeProperty('padding-bottom');
        content.style.removeProperty('padding-left');
        content.style.removeProperty('padding-right');
        return true;
    }

    function boot() {
        wrapBody();
        setTimeout(wrapBody, 300);
        setTimeout(wrapBody, 1000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else { boot(); }

    document.addEventListener('click', function(e) {
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('#dayAddBtn')) setTimeout(wrapBody, 30);
        if (e.target.closest('#dayModal .dict-action-btn[data-act="edit"]')) setTimeout(wrapBody, 30);
    }, true);

    setTimeout(function() {
        var modal = document.getElementById('logModal');
        if (!modal) return;
        new MutationObserver(function() {
            if (modal.classList.contains('active')) wrapBody();
        }).observe(modal, { attributes: true, attributeFilter: ['class'] });
    }, 600);

    window.__trkWrapLogBody = wrapBody;
})();
/* ============================================================
   PATCH 1.0.18 — Меряем высоту sticky-шапки
   ============================================================ */
(function() {
    'use strict';

    function measureHeader() {
        var header = document.querySelector('.tracker-header');
        if (!header) return;
        var h = Math.ceil(header.getBoundingClientRect().height);
        if (h > 0) {
            document.documentElement.style.setProperty('--tracker-header-h', h + 'px');
        }
    }

    window.addEventListener('load', measureHeader);
    window.addEventListener('resize', measureHeader);
    setTimeout(measureHeader, 100);
    setTimeout(measureHeader, 400);
    setTimeout(measureHeader, 1500);

    var header = document.querySelector('.tracker-header');
    if (header) {
        try {
            new MutationObserver(measureHeader).observe(header, {
                childList: true, subtree: true
            });
        } catch (e) {}
    }

    window.__trkMeasureHeader = measureHeader;
})();

/* ============================================================
   PATCH 44 — Отметки на будущие даты: коричневая штриховка
   Без MutationObserver с attributes — циклы исключены.
   ============================================================ */
(function() {
    'use strict';

    function _st() { return window.__trkState || null; }

    function decorateCalendar() {
        var st = _st();
        if (!st) return;
        var today = st.today || '';
        var grid = document.getElementById('calGrid');
        if (!grid) return;
        grid.querySelectorAll('.cal-cell').forEach(function(cell) {
            var dk = cell.getAttribute('data-date');
            var hasEntries = !!cell.querySelector('.cal-entry');
            var isFuture = !!(dk && today && dk > today);
            cell.classList.toggle('cal-future', isFuture && hasEntries);
        });
    }

    function decorateSummary() {
        var st = _st();
        if (!st) return;
        var today = st.today || '';
        var wrap = document.getElementById('sumWrap');
        if (!wrap) return;
        wrap.querySelectorAll('td.day-cell').forEach(function(td) {
            td.classList.remove('cell-future');
            var dk = td.getAttribute('data-date');
            if (!dk || !today || dk <= today) return;
            if (td.classList.contains('empty-cell')) return;
            var txt = (td.textContent || '').replace(/\s+/g, ' ').trim();
            if (!txt || txt === '·' || txt === '—') return;
            td.classList.add('cell-future');
        });
    }

    function decorateDayModal() {
        var st = _st();
        if (!st) return;
        var modal = document.getElementById('dayModal');
        if (!modal) return;
        var today = st.today || '';
        var dk = st.currentDay || '';
        modal.classList.toggle('day-modal-future', !!(dk && today && dk > today));
    }

    var _prev = window.__trkOnSummaryRender;
    window.__trkOnSummaryRender = function() {
        if (typeof _prev === 'function') { try { _prev(); } catch (e) {} }
        try { decorateSummary(); } catch (e) { console.error('[future-markers]', e); }
    };

    function observeCalendar() {
        var grid = document.getElementById('calGrid');
        if (!grid || grid._futureObserved) return;
        grid._futureObserved = true;
        new MutationObserver(function() { setTimeout(decorateCalendar, 20); })
            .observe(grid, { childList: true });
    }

    function observeDayModal() {
        var list = document.getElementById('dayList');
        if (list && !list._futureObserved) {
            list._futureObserved = true;
            new MutationObserver(function() { setTimeout(decorateDayModal, 20); })
                .observe(list, { childList: true });
        }
        var modal = document.getElementById('dayModal');
        if (modal && !modal._futureClassHooked) {
            modal._futureClassHooked = true;
            new MutationObserver(function() {
                if (modal.classList.contains('active')) {
                    setTimeout(decorateDayModal, 60);
                    setTimeout(decorateDayModal, 250);
                }
            }).observe(modal, { attributes: true, attributeFilter: ['class'] });
        }
    }

    function markLogSummary() {
        var summary = document.getElementById('logDaySummary');
        var dt = document.getElementById('log_date');
        if (!summary || !dt) return;
        var st = _st();
        var today = (st && st.today) || '';
        var v = dt.value || '';
        summary.classList.toggle('log-day-summary-future', !!(v && today && v > today));
    }

    document.addEventListener('change', function(e) {
        if (e.target && e.target.id === 'log_date') setTimeout(markLogSummary, 30);
    }, true);

    function boot() {
        observeCalendar();
        observeDayModal();
        setTimeout(decorateCalendar, 700);
        setTimeout(decorateSummary, 700);
        setTimeout(function() { observeCalendar(); observeDayModal(); }, 1500);
        setTimeout(function() { observeCalendar(); observeDayModal(); }, 3000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else { boot(); }

    document.addEventListener('click', function(e) {
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('.tracker-tab[data-tab="calendar"]')) {
            setTimeout(function() { observeCalendar(); decorateCalendar(); }, 300);
        }
        if (e.target.closest('.cal-nav-btn')) {
            setTimeout(decorateCalendar, 500);
            setTimeout(decorateCalendar, 1200);
        }
        if (e.target.closest('#dayAddBtn')) {
            setTimeout(markLogSummary, 300);
        }
    });

    window.__trkDecorateFuture = { calendar: decorateCalendar, summary: decorateSummary, day: decorateDayModal };
})();


/* ============================================================
   PATCH 2026-10-08 — Горизонтальная карточка новой отметки
   v2: в новом tracker.html .log-row-4 и .log-row-2 уже есть, 
   функция restructure становится no-op (проверка idempotence).
   Оставляю как fallback для старого HTML.
   ============================================================ */
(function() {
    'use strict';

    function restructure() {
        var m = document.getElementById('logModal');
        if (!m) return;
        var content = m.querySelector('.modal-content');
        if (!content) return;

        // PATCH v2: если уже размечено — выходим
        if (content.classList.contains('log-modal-wide') && 
            content.querySelector('.log-row-4')) {
            return;
        }

        var rows = content.querySelectorAll('.form-row');
        var rowDate = null, rowEmp = null;
        for (var i = 0; i < rows.length; i++) {
            if (rows[i].querySelector('#log_date')) rowDate = rows[i];
            if (rows[i].querySelector('#log_employee')) rowEmp = rows[i];
        }
        if (rowDate && rowEmp && !rowDate.classList.contains('log-row-4')) {
            while (rowEmp.firstChild) rowDate.appendChild(rowEmp.firstChild);
            rowEmp.parentNode.removeChild(rowEmp);
            rowDate.classList.remove('form-row');
            rowDate.classList.add('log-row-4');
        }

        var groups = content.querySelectorAll('.form-group');
        var gComment = null, gLink = null;
        for (var j = 0; j < groups.length; j++) {
            if (groups[j].querySelector('#log_comment')) gComment = groups[j];
            if (groups[j].querySelector('#log_link')) gLink = groups[j];
        }
        if (gComment && gLink && !gComment.parentNode.classList.contains('log-row-2')) {
            var wrap = document.createElement('div');
            wrap.className = 'log-row-2';
            gComment.parentNode.insertBefore(wrap, gComment);
            wrap.appendChild(gComment);
            wrap.appendChild(gLink);
        }

        content.classList.add('log-modal-wide');
    }

    document.addEventListener('click', function(e) {
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('#dayAddBtn') ||
            e.target.closest('#dayModal .dict-action-btn[data-act="edit"]')) {
            setTimeout(restructure, 80);
            setTimeout(restructure, 300);
        }
    }, true);

    setTimeout(restructure, 800);

    window.__trkLogModalRestructure = restructure;
})();



/* ============================================================
   v1.2.7-merge-v2 — Объединение задач с чекбоксами при наведении
   Guard: window.__trkTaskMerge — повторный запуск блока ничего не делает.
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkTaskMerge) return;
    window.__trkTaskMerge = true;

    function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}

    function selected(){
        var out = [];
        document.querySelectorAll('.task-merge-cb:checked').forEach(function(cb){
            out.push(cb.getAttribute('data-task-id'));
        });
        return out;
    }

    function updateBar(){
        var bar = document.getElementById('taskMergeBar');
        if (!bar) return;
        var n = selected().length;
        bar.style.display = n >= 2 ? '' : 'none';
        var c = document.getElementById('taskMergeCount');
        if (c) c.textContent = n;
    }

    function ensureBar(){
        var panel = document.getElementById('panel-tasks');
        if (!panel) return;
        if (document.getElementById('taskMergeBar')) return;
        var toolbar = panel.querySelector('.sum-toolbar');
        if (!toolbar) return;
        var bar = document.createElement('div');
        bar.id = 'taskMergeBar';
        bar.className = 'task-merge-bar';
        bar.style.display = 'none';
        bar.innerHTML = '<span>🔗 Выбрано <b id="taskMergeCount">0</b> задач</span>'
            + '<button type="button" class="btn btn-primary" id="taskMergeBtn">Объединить</button>'
            + '<button type="button" class="btn btn-secondary" id="taskMergeClear">Сбросить</button>';
        toolbar.parentNode.insertBefore(bar, toolbar.nextSibling);
        document.getElementById('taskMergeBtn').addEventListener('click', openModal);
        document.getElementById('taskMergeClear').addEventListener('click', function(){
            document.querySelectorAll('.task-merge-cb:checked').forEach(function(cb){ cb.checked = false; });
            document.querySelectorAll('.task-card').forEach(function(c){ c.classList.remove('task-card--merge-selected'); });
            updateBar();
        });
    }

    function addCbs(){
        var list = document.getElementById('tasksFullList');
        if (!list) return;
        list.querySelectorAll('.task-card').forEach(function(card){
            if (card.querySelector('.task-merge-cb')) return;
            var id = card.getAttribute('data-id');
            if (!id) return;
            var cb = document.createElement('input');
            cb.type = 'checkbox';
            cb.className = 'task-merge-cb';
            cb.setAttribute('data-task-id', id);
            cb.title = 'Выбрать для объединения';
            cb.addEventListener('click', function(e){ e.stopPropagation(); });
            cb.addEventListener('change', function(){
                if (this.checked) card.classList.add('task-card--merge-selected');
                else card.classList.remove('task-card--merge-selected');
                updateBar();
            });
            card.insertBefore(cb, card.firstChild);
        });
        ensureBar();
        updateBar();
    }

    function openModal(){
        var ids = selected();
        if (ids.length < 2) return;
        var st = window.__trkState || {};
        var tasks = (st.tasks || []).filter(function(t){ return ids.indexOf(t.id) !== -1; });
        if (tasks.length < 2) return;

        var h = '';
        h += '<div class="tmm-hint">Все поля будут собраны автоматически:</div>';
        h += '<ul class="tmm-rules">';
        h += '<li><b>Название, иконка, статус, даты</b> — от выбранной (radio) задачи</li>';
        h += '<li><b>Теги, отделы, исполнители</b> — объединятся со всех задач</li>';
        h += '<li><b>Описание, папки, приказы</b> — склеятся, по одному значению на строку</li>';
        h += '</ul>';
        h += '<div class="tmm-list-title">Клик — сделать выбранную основной (остальные удалятся):</div>';
        h += '<div class="tmm-list">';
        tasks.forEach(function(t, i){
            var desc = (t.description||'').replace(/\s+/g,' ').trim();
            var folder = (t.folder||'').trim();
            var order = (t.order_ref||'').trim();
            var empsN = (t.assignees||[]).length;
            var tagsN = (t.tags||[]).length;
            var depsN = (t.department_ids||[]).length;
            h += '<label class="tmm-card' + (i===0?' selected':'') + '">';
            h += '<input type="radio" name="tmm_survivor" value="' + esc(t.id) + '"' + (i===0?' checked':'') + '>';
            h += '<span class="tmm-ico">' + esc(t.icon||'📋') + '</span>';
            h += '<div class="tmm-body">';
            h += '<div class="tmm-name">' + esc(t.name) + '</div>';
            h += '<div class="tmm-meta">';
            h += '<span>📅 ' + (t.start_date||'—') + ' → ' + (t.deadline||'—') + '</span>';
            h += '<span>🏷 ' + tagsN + '</span>';
            h += '<span>👥 ' + empsN + '</span>';
            h += '<span>🏢 ' + depsN + '</span>';
            h += '</div>';
            if (desc) h += '<div class="tmm-desc">' + esc(desc.slice(0, 140)) + (desc.length>140?'…':'') + '</div>';
            if (folder) h += '<div class="tmm-fold">📁 ' + esc(folder.split('\n').filter(Boolean).slice(0,2).join(' · ')) + (folder.split('\n').length>2?'…':'') + '</div>';
            if (order) h += '<div class="tmm-ord">📄 ' + esc(order.split('\n').filter(Boolean).slice(0,2).join(' · ')) + (order.split('\n').length>2?'…':'') + '</div>';
            h += '</div></label>';
        });
        h += '</div>';
        h += '<div class="modal-actions"><button class="btn btn-secondary" data-close="taskMergeModal">Закрыть</button>';
        h += '<button class="btn btn-primary" id="tmm_submit">🔗 Объединить</button></div>';

        var modal = document.getElementById('taskMergeModal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'taskMergeModal';
            modal.className = 'modal';
            modal.style.setProperty('z-index', '9000', 'important');
            modal.innerHTML = '<div class="modal-content"><h2>🔗 Объединение задач</h2><div id="tmm_body"></div></div>';
            document.body.appendChild(modal);
            modal.addEventListener('click', function(e){ if (e.target === modal) modal.classList.remove('active'); });
        }
        modal.style.setProperty('z-index', '9000', 'important');
        document.getElementById('tmm_body').innerHTML = h;
        var body = document.getElementById('tmm_body');
        body.querySelectorAll('[data-close]').forEach(function(b){
            b.onclick = function(){ modal.classList.remove('active'); };
        });
        body.querySelectorAll('.tmm-card').forEach(function(card){
            card.addEventListener('click', function(){
                body.querySelectorAll('.tmm-card').forEach(function(c){ c.classList.remove('selected'); });
                card.classList.add('selected');
            });
        });
        document.getElementById('tmm_submit').onclick = function(){ submit(ids); };
        modal.classList.add('active');
    }

    function submit(ids){
        var survivor = '';
        document.querySelectorAll('input[name="tmm_survivor"]').forEach(function(r){ if (r.checked) survivor = r.value; });
        var payload = { task_ids: ids, survivor_id: survivor };
        var hdrs = { 'Content-Type': 'application/json' };
        if (window.REESTR_CSRF) hdrs['X-CSRF-Token'] = window.REESTR_CSRF;
        fetch('/api/tracker/task/merge', {
            method: 'POST', headers: hdrs, credentials: 'same-origin',
            body: JSON.stringify(payload)
        })
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (!d.success) { alert('Ошибка: ' + (d.error || 'неизвестная')); return; }
            var modal = document.getElementById('taskMergeModal');
            if (modal) modal.classList.remove('active');
            document.querySelectorAll('.task-merge-cb:checked').forEach(function(cb){ cb.checked = false; });
            document.querySelectorAll('.task-card--merge-selected').forEach(function(c){ c.classList.remove('task-card--merge-selected'); });
            updateBar();
            if (typeof window.__trkLoadState === 'function') window.__trkLoadState();
            if (typeof window.__trackerNotify === 'function') window.__trackerNotify('✅ Объединено задач: ' + (1 + (d.merged_ids || []).length), 'success');
            else alert('✅ Объединено задач: ' + (1 + (d.merged_ids || []).length));
        })
        .catch(function(e){ alert('Ошибка: ' + e.message); });
    }

    // MutationObserver на #tasksFullList: восстанавливаем чекбоксы после каждой перерисовки
    function hookList(){
        var list = document.getElementById('tasksFullList');
        if (!list || list._mergeHooked) return;
        list._mergeHooked = true;
        new MutationObserver(function(){
            addCbs();
        }).observe(list, { childList: true });
        addCbs();
    }

    function boot(){
        addCbs();
        ensureBar();
        hookList();
        setTimeout(function(){ addCbs(); hookList(); }, 500);
        setTimeout(function(){ addCbs(); hookList(); }, 1500);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('.tracker-tab[data-tab="tasks"]')) {
            setTimeout(function(){ hookList(); addCbs(); }, 250);
        }
    });

    window.__trkTaskMergeOpen = openModal;
})();


/* PATCH v1.0.10: централизованный стек модалок по порядку открытия */
(function(){
'use strict';
if (window.__trkModalZStack) return;
window.__trkModalZStack = true;
var BASE = 2000, STEP = 100, _stack = [];
function _recompute() {
    _stack.forEach(function(id, i) {
        var m = document.getElementById(id);
        if (!m || m._zstackForeign) return;
        if (!m._zstackSetByUs && m.style.zIndex) { m._zstackForeign = true; return; }
        m.style.setProperty('z-index', String(BASE + (i + 1) * STEP), 'important');
        m._zstackSetByUs = true;
    });
}
function _onClassChange(el) {
    if (!el || !el.classList || !el.classList.contains('modal')) return;
    var id = el.id; if (!id) return;
    var isActive = el.classList.contains('active');
    var idx = _stack.indexOf(id);
    if (isActive && idx === -1) { _stack.push(id); }
    else if (!isActive && idx !== -1) { _stack.splice(idx, 1); }
    else { return; }
    _recompute();
}
function _scan() {
    document.querySelectorAll('.modal').forEach(function(m) {
        if (!m.id || m._zstackHooked) return;
        m._zstackHooked = true;
        new MutationObserver(function(){ _onClassChange(m); })
            .observe(m, { attributes: true, attributeFilter: ['class'] });
        if (m.classList.contains('active') && _stack.indexOf(m.id) === -1) _stack.push(m.id);
    });
    _recompute();
}
function boot() { _scan(); setTimeout(_scan, 500); setTimeout(_scan, 1500); setTimeout(_scan, 3000); }
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
document.addEventListener('click', function(){ setTimeout(_scan, 120); });
})();


/* PATCH v1.0.11: поиск в списках выбора */
(function(){
'use strict';
if (window.__trkSearchInLists) return;
window.__trkSearchInLists = true;
function _setupFilter(listId) {
    var list = document.getElementById(listId);
    if (!list || list._searchBox) return;
    var wrap = list.parentNode; if (!wrap) return;
    var box = document.createElement('div');
    box.className = 'assignees-search-wrap';
    box.innerHTML =
        '<span class="assignees-search-icon">🔍</span>' +
        '<input type="text" class="assignees-search" placeholder="Поиск по ФИО…" autocomplete="off">' +
        '<button type="button" class="assignees-search-clear" style="display:none;" title="Очистить">×</button>';
    wrap.insertBefore(box, list);
    list._searchBox = box;
    var input = box.querySelector('input');
    var clearBtn = box.querySelector('.assignees-search-clear');
    function applyFilter() {
        var q = (input.value || '').trim().toLowerCase();
        clearBtn.style.display = q ? '' : 'none';
        list.querySelectorAll('.assignees-item, .dept-multi-item').forEach(function(item) {
            var txt = (item.textContent || '').toLowerCase();
            item.style.display = (!q || txt.indexOf(q) !== -1) ? '' : 'none';
        });
        list.querySelectorAll('.assignees-group').forEach(function(grp) {
            var hasVisible = false;
            grp.querySelectorAll('.assignees-item').forEach(function(it) {
                if (it.style.display !== 'none') hasVisible = true;
            });
            grp.style.display = hasVisible ? '' : 'none';
        });
    }
    input.addEventListener('input', applyFilter);
    clearBtn.addEventListener('click', function() { input.value = ''; applyFilter(); input.focus(); });
    input.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') { e.preventDefault(); input.value = ''; applyFilter(); }
    });
    new MutationObserver(applyFilter).observe(list, { childList: true });
}
function setup() {
    _setupFilter('taskAssigneesList');
    _setupFilter('taskDepartmentsList');
    _setupFilter('teamMembersList');
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function(){ setTimeout(setup, 400); }); else setTimeout(setup, 400);
setTimeout(setup, 1200);
setTimeout(setup, 2500);
window.__trkSetupListSearch = setup;
})();


/* PATCH v1.0.11: авто-title у кнопок действий */
(function(){
'use strict';
if (window.__trkBtnTitleDecorator) return;
window.__trkBtnTitleDecorator = true;
var TITLES = { edit: 'Редактировать', delete: 'Удалить', card: 'Карточка задачи', copy: 'Копировать', close: 'Закрыть' };
function decorate(root) {
    var scope = (root && root.querySelectorAll) ? root : document;
    scope.querySelectorAll('.dict-action-btn[data-act]').forEach(function(btn) {
        if (btn.title) return;
        var act = btn.getAttribute('data-act');
        if (TITLES[act]) btn.title = TITLES[act];
    });
}
function boot() {
    decorate(document);
    new MutationObserver(function(muts) {
        muts.forEach(function(m) {
            if (!m.addedNodes) return;
            m.addedNodes.forEach(function(n) { if (n.nodeType === 1) decorate(n); });
        });
    }).observe(document.body, { childList: true, subtree: true });
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();


/* PATCH v1.0.12: подсветка совпадений в поиске задач */
(function(){
'use strict';
if (window.__trkSearchHighlightV112) return;
window.__trkSearchHighlightV112 = true;
function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}
function highlightCards() {
    var inp = document.getElementById('tskSearchInput');
    var list = document.getElementById('tasksFullList');
    if (!inp || !list) return;
    var q = (inp.value || '').trim();
    list.querySelectorAll('.task-card').forEach(function(card) {
        var titleEl = card.querySelector('.task-card-title');
        if (!titleEl) return;
        if (!card._origTitleHtml) card._origTitleHtml = titleEl.innerHTML;
        if (!q) {
            if (titleEl.innerHTML !== card._origTitleHtml) titleEl.innerHTML = card._origTitleHtml;
            return;
        }
        var rx = new RegExp('(' + q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'ig');
        var html = esc(titleEl.textContent || '').replace(rx, '<mark>$1</mark>');
        if (titleEl.innerHTML !== html) titleEl.innerHTML = html;
    });
}
function attachObserver() {
    var list = document.getElementById('tasksFullList');
    if (!list || list._hlV112Hooked) return;
    list._hlV112Hooked = true;
    new MutationObserver(function() {
        list.querySelectorAll('.task-card').forEach(function(c) { delete c._origTitleHtml; });
        highlightCards();
    }).observe(list, { childList: true });
}
function boot() {
    attachObserver();
    setTimeout(attachObserver, 800);
    setTimeout(attachObserver, 2000);
    var inp = document.getElementById('tskSearchInput');
    if (inp && !inp._hlV112Hooked) {
        inp._hlV112Hooked = true;
        inp.addEventListener('input', function(){ setTimeout(highlightCards, 60); });
    }
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
setTimeout(boot, 1200);
window.__trkSearchHighlight = highlightCards;
})();


/* PATCH v1.0.12: переключатель компактного режима плитки задач */
(function(){
'use strict';
if (window.__trkCompactModeV112) return;
window.__trkCompactModeV112 = true;
var KEY = 'tracker_tsk_compact';
function readState() { try { return localStorage.getItem(KEY) === '1'; } catch (e) { return false; } }
function writeState(v) { try { localStorage.setItem(KEY, v ? '1' : '0'); } catch (e) {} }
function ensureButton() {
    var panel = document.getElementById('panel-tasks');
    if (!panel) return;
    if (document.getElementById('tskCompactToggle')) return;
    var cols = document.getElementById('tskColsWrap');
    var anchor = cols || panel.querySelector('.sum-toolbar');
    if (!anchor) return;
    var b = document.createElement('button');
    b.type = 'button';
    b.id = 'tskCompactToggle';
    b.className = 'btn btn-secondary tsk-compact-toggle';
    b.title = 'Компактные карточки (меньше высота)';
    b.textContent = '☰ Компактно';
    b.addEventListener('click', function() {
        var on = !readState();
        writeState(on);
        var st = window.__trkState;
        if (st) st.tskCompactMode = on;
        b.classList.toggle('active', on);
        b.textContent = on ? '☰ Компактно ✓' : '☰ Компактно';
        if (typeof window.__trkRenderTasksFull === 'function') window.__trkRenderTasksFull();
    });
    if (anchor.parentNode) anchor.parentNode.insertBefore(b, anchor.nextSibling);
    var on = readState();
    b.classList.toggle('active', on);
    b.textContent = on ? '☰ Компактно ✓' : '☰ Компактно';
}
function applyState() {
    var st = window.__trkState;
    if (st) st.tskCompactMode = readState();
}
function boot() { applyState(); ensureButton(); setTimeout(ensureButton, 800); setTimeout(ensureButton, 2000); }
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
document.addEventListener('click', function(e) {
    if (e.target && e.target.closest && e.target.closest('.tracker-tab[data-tab="tasks"]')) {
        setTimeout(ensureButton, 250);
    }
});
})();


/* ============================================================
   PATCH v1.0.17 — гарантированный рефреш списка задач после save.
   Оборачивает fetch: как только /api/tracker/task/save вернул 2xx,
   принудительно перерисовываем текущую вкладку (если это «Задачи»).
   Идемпотентно к trkRefreshAll — двойной рендер не вредит.
   ============================================================ */
(function(){
'use strict';
if (window.__trkSaveTaskRefreshHook) return;
window.__trkSaveTaskRefreshHook = true;

var _nativeFetch = window.fetch;
if (typeof _nativeFetch !== 'function') return;

window.fetch = function(url, opts) {
    var isTaskSave = (typeof url === 'string' && url.indexOf('/api/tracker/task/save') !== -1);
    var isPost = !!(opts && (opts.method || 'GET').toUpperCase() === 'POST');
    var promise = _nativeFetch.apply(this, arguments);
    if (!isTaskSave || !isPost) return promise;
    return promise.then(function(r) {
        if (r && r.ok) {
            setTimeout(function() {
                var tabBtn = document.querySelector('.tracker-tab.active');
                var tabId = tabBtn ? tabBtn.getAttribute('data-tab') : '';
                if (tabId === 'tasks' && typeof window.__trkRenderTasksFull === 'function') {
                    try { window.__trkRenderTasksFull(); } catch (e) { console.error('[save-refresh]', e); }
                } else if (tabId === 'calendar' && typeof window.__trkRenderCalendar === 'function') {
                    try { window.__trkRenderCalendar(); } catch (e) { console.error('[save-refresh-cal]', e); }
                }
            }, 250);
        }
        return r;
    });
};
})();


/* ============================================================
   PATCH v1.0.19 — много ссылок в задаче
   Каждая ссылка: {url, description}. Локальные пути (\\server, C:\,
   /, file://) копируются в буфер по клику, внешние (http/https/ftp)
   открываются в новой вкладке.
   ============================================================ */
var _taskLinksDraft = [];
function _isExternalUrl(u) {
    return /^(https?|ftp):\/\//i.test(String(u || ''));
}
function _escapeAttr(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}
function renderTaskLinksDraft() {
    var box = document.getElementById('taskLinksList');
    if (!box) return;
    if (!_taskLinksDraft.length) {
        box.innerHTML = '<div class="task-links-empty">Пока нет ссылок</div>';
        return;
    }
    var h = '';
    _taskLinksDraft.forEach(function(lk, i) {
        var url = (lk && lk.url) || '';
        var desc = (lk && lk.description) || '';
        h += '<div class="task-link-row" data-i="' + i + '">'
          +  '<input type="text" class="task-link-desc" placeholder="Описание" value="' + _escapeAttr(desc) + '" maxlength="200">'
          +  '<input type="text" class="task-link-url" placeholder="https://… или \\\\server\\share\\file" value="' + _escapeAttr(url) + '" maxlength="1000">'
          +  '<button type="button" class="task-link-del" title="Удалить">×</button>'
          +  '</div>';
    });
    box.innerHTML = h;
    box.querySelectorAll('.task-link-row').forEach(function(row) {
        var i = parseInt(row.getAttribute('data-i'), 10);
        var dEl = row.querySelector('.task-link-desc');
        var uEl = row.querySelector('.task-link-url');
        if (dEl) dEl.addEventListener('input', function() { _taskLinksDraft[i].description = this.value; });
        if (uEl) uEl.addEventListener('input', function() { _taskLinksDraft[i].url = this.value; });
        var xb = row.querySelector('.task-link-del');
        if (xb) xb.addEventListener('click', function() {
            _taskLinksDraft.splice(i, 1);
            renderTaskLinksDraft();
        });
    });
}
(function(){
    'use strict';
    if (window.__trkTaskLinksInit) return;
    window.__trkTaskLinksInit = true;
    document.addEventListener('click', function(e) {
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('#taskLinkAddBtn')) {
            e.preventDefault();
            _taskLinksDraft = _taskLinksDraft || [];
            _taskLinksDraft.push({ url: '', description: '' });
            renderTaskLinksDraft();
            var box = document.getElementById('taskLinksList');
            if (box) {
                var rows = box.querySelectorAll('.task-link-row');
                var last = rows[rows.length - 1];
                if (last) {
                    var f = last.querySelector('.task-link-desc');
                    if (f) f.focus();
                }
            }
        }
    }, true);
})();

/* Копирование/открытие ссылок в карточке задачи (в расширенной модалке) */
function _handleLinkClick(url) {
    if (!url) return;
    if (_isExternalUrl(url)) {
        window.open(url, '_blank', 'noopener,noreferrer');
        return;
    }
    try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(url).then(function() {
                if (typeof notify === 'function') notify('📋 Скопировано: ' + url);
            }, function() { _fallbackCopy(url); });
        } else {
            _fallbackCopy(url);
        }
    } catch (e) {
        _fallbackCopy(url);
    }
}
function _fallbackCopy(text) {
    try {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.left = '-9999px';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        if (typeof notify === 'function') notify('📋 Скопировано: ' + text);
    } catch (e) {
        if (typeof notify === 'function') notify('❌ Не удалось скопировать', 'error');
    }
}

/* Показ ссылок в карточке задачи — подключаемся к openTaskCardModal */
(function(){
    'use strict';
    if (window.__trkTaskLinksDisplay) return;
    window.__trkTaskLinksDisplay = true;
    var _renderCards = function() {
        var list = document.getElementById('tasksFullList');
        if (!list) return;
        var st = window.__trkState || {};
        var map = {};
        (st.tasks || []).forEach(function(t) { map[t.id] = t; });
        list.querySelectorAll('.task-card').forEach(function(card) {
            var id = card.getAttribute('data-id');
            if (!id) return;
            var t = map[id];
            if (!t) return;
            var extra = card.querySelector('.task-card-extra');
            var links = Array.isArray(t.links) ? t.links : [];
            if (!links.length) return;
            if (extra) {
                var oldLinks = extra.querySelector('.txi-links-block');
                if (oldLinks) oldLinks.remove();
            } else {
                var head = card.querySelector('.task-card-head');
                if (!head) return;
                extra = document.createElement('div');
                extra.className = 'task-card-extra';
                head.parentNode.insertBefore(extra, head.nextSibling);
            }
            var blk = document.createElement('div');
            blk.className = 'txi-links-block';
            var html = '<div class="txi-links-head">🔗 ' + links.length + ' ' + (links.length === 1 ? 'ссылка' : 'ссылок') + '</div><div class="txi-links">';
            links.slice(0, 4).forEach(function(lk, i) {
                var u = (lk && lk.url) || '';
                var d = (lk && lk.description) || '';
                if (!u) return;
                var ext = _isExternalUrl(u);
                html += '<a class="txi-link" href="javascript:void(0)" data-link-url="' + _escapeAttr(u) + '" title="' + _escapeAttr(u) + '">';
                html += ext ? '🌐 ' : '📁 ';
                html += _escapeAttr(d || (u.length > 55 ? u.slice(0, 54) + '…' : u));
                html += '</a>';
            });
            if (links.length > 4) html += '<span class="txi-more">+' + (links.length - 4) + '</span>';
            html += '</div>';
            blk.innerHTML = html;
            extra.appendChild(blk);
        });
        list.querySelectorAll('.txi-link[data-link-url]').forEach(function(a) {
            if (a._linkHook) return;
            a._linkHook = true;
            a.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                var u = this.getAttribute('data-link-url');
                if (u) _handleLinkClick(u);
            });
        });
    };
    function boot() {
        setTimeout(_renderCards, 400);
        setTimeout(_renderCards, 1500);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
    document.addEventListener('click', function(e) {
        if (e.target && e.target.closest && e.target.closest('.tracker-tab[data-tab="tasks"]')) {
            setTimeout(_renderCards, 300);
        }
    });
    window.__trkRenderTaskCardLinks = _renderCards;
})();


/* ============================================================
   PATCH v1.0.20 — колокольчик уведомлений
   ============================================================ */
(function(){
'use strict';
if (window.__trkBellV120) return;
window.__trkBellV120 = true;

function _esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}

function _ensureDrop() {
    var d = document.getElementById('trkBellDrop');
    if (d) return d;
    d = document.createElement('div');
    d.id = 'trkBellDrop';
    d.className = 'trk-bell-drop';
    d.style.display = 'none';
    document.body.appendChild(d);
    return d;
}

function _fmtTs(ts) {
    if (!ts) return '';
    return String(ts).slice(0, 16);
}

function _renderList(items) {
    var d = _ensureDrop();
    if (!items.length) {
        d.innerHTML = '<div class="trk-bell-head">Уведомления</div><div class="trk-bell-empty">Нет уведомлений</div>';
        return;
    }
    var _isAdminBell = !!(window.__trkState && window.__trkState.currentUser && window.__trkState.currentUser.role === 'admin');
    var h = '<div class="trk-bell-head">Уведомления'
          + '<button type="button" class="trk-bell-markall" id="trkBellMarkAll">Прочитать все</button>'
          + (_isAdminBell ? '<button type="button" class="trk-bell-markall trk-bell-markall--global" id="trkBellMarkAllGlobal" title="Пометить прочитанными у всех">Сбросить всем</button>' : '')
          + '</div>';
    items.forEach(function(it) {
        if (it.kind === 'reminder') {
            var _r = it._reminder || {};
            var _rIco = _r.kind === 'overdue' ? '⚠' : (_r.kind === 'today' ? '🔥' : '⏰');
            h += '<div class="trk-bell-item trk-bell-item--reminder" data-nid="' + it.id + '" data-tid="' + _esc(it.task_id) + '" data-kind="reminder" data-reminder-kind="' + _esc(_r.kind || '') + '">'
              +   '<span class="trk-bell-ico">' + _rIco + '</span>'
              +   '<div class="trk-bell-body">'
              +     '<div class="trk-bell-name">' + _esc(it.message) + '</div>'
              +     '<div class="trk-bell-meta">' + _esc(_r.label || '') + '</div>'
              +   '</div>'
              + '</div>';
            return;
        }
        var status = it.status || 'new';
        var statusCls = status === 'confirmed' ? 'confirmed' : (status === 'rejected' ? 'rejected' : '');
        var _msgText = String(it.message || 'Закрыта задача');
        try {
            var _st = window.__trkState || {};
            if (_st.maskNames && typeof window.__trkMaskName === 'function') {
                var _empN = (_st.employees || []).find(function(x) { return x.id === it.employee_id; });
                if (_empN && _empN.name) {
                    var _rn = _empN.name;
                    var _mn = window.__trkMaskName(_rn);
                    if (_rn && _mn && _rn !== _mn) {
                        _msgText = _msgText.split(_rn).join(_mn);
                    }
                }
            }
        } catch (e) { console.error('[bell-mask]', e); }
        var _kind = it.kind || 'task_done';
        var _ico = (_kind === 'task_created') ? '🆕' : '✅';
        var _needConfirm = (_kind === 'task_done' && status === 'new');
        var _badge = '';
        if (status === 'confirmed') _badge = '<div class="trk-bell-badge ok">принято</div>';
        else if (status === 'rejected') _badge = '<div class="trk-bell-badge err">отклонено</div>';
        else if (status === 'info' || _kind === 'task_created') _badge = '<div class="trk-bell-badge trk-bell-badge-info">инфо</div>';
        h += '<div class="trk-bell-item trk-bell-item--' + _esc(_kind) + ' ' + statusCls + '" data-nid="' + it.id + '" data-tid="' + _esc(it.task_id) + '" data-kind="' + _esc(_kind) + '">'
          +   '<span class="trk-bell-ico">' + _ico + '</span>'
          +   '<div class="trk-bell-body">'
          +     '<div class="trk-bell-name">' + _esc(_msgText) + '</div>'
          +     '<div class="trk-bell-meta">' + _esc(_fmtTs(it.ts)) + (it.from_username ? ' · ' + _esc(it.from_username) : '') + '</div>'
          +     (_needConfirm ? '<div class="trk-bell-actions">'
          +         '<button type="button" class="trk-bell-act ok" data-act="accept">✓ Принять</button>'
          +         '<button type="button" class="trk-bell-act err" data-act="reject">✗ Отклонить</button>'
          +       '</div>' : _badge)
          +   '</div>'
          + '</div>';
    });
    d.innerHTML = h;

    d.querySelectorAll('.trk-bell-item').forEach(function(el) {
        var nid = parseInt(el.getAttribute('data-nid'), 10);
        var tid = el.getAttribute('data-tid');
        var kind = el.getAttribute('data-kind');
        var remKind = el.getAttribute('data-reminder-kind');
        var nameEl = el.querySelector('.trk-bell-name');
        if (nameEl) nameEl.addEventListener('click', function() {
            if (kind === 'reminder') {
                if (typeof window.__trkReminderGoToTask === 'function') {
                    window.__trkReminderGoToTask(tid, remKind);
                } else if (typeof window.__trkOpenTaskCardModal === 'function' && tid) {
                    window.__trkOpenTaskCardModal(tid);
                }
                var dr = document.getElementById('trkBellDrop');
                if (dr) dr.style.display = 'none';
                return;
            }
            if (typeof window.__trkOpenTaskCardModal === 'function' && tid) {
                window.__trkOpenTaskCardModal(tid);
            }
        });
        el.querySelectorAll('.trk-bell-act').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                e.preventDefault();
                var act = this.getAttribute('data-act');
                fetch('/api/notifications/action', {
                    method: 'POST',
                    headers: Object.assign({'Content-Type': 'application/json'}, window.REESTR_CSRF ? {'X-CSRF-Token': window.REESTR_CSRF} : {}),
                    credentials: 'same-origin',
                    body: JSON.stringify({ id: nid, action: act }),
                }).then(function(r) { return r.json(); }).then(function(res) {
                    if (res && res.success) {
                        refresh();
                        if (typeof window.__trkLoadState === 'function') window.__trkLoadState();
                    }
                }).catch(function(){});
            });
        });
    });
    var markAll = d.querySelector('#trkBellMarkAll');
    if (markAll) markAll.addEventListener('click', function() {
        fetch('/api/notifications/read', {
            method: 'POST',
            headers: Object.assign({'Content-Type': 'application/json'}, window.REESTR_CSRF ? {'X-CSRF-Token': window.REESTR_CSRF} : {}),
            credentials: 'same-origin',
            body: JSON.stringify({}),
        }).then(function() { refresh(); });
    });
    var markAllGlobal = d.querySelector('#trkBellMarkAllGlobal');
    if (markAllGlobal) markAllGlobal.addEventListener('click', function() {
        if (!confirm('Пометить ПРОЧИТАННЫМИ все уведомления у ВСЕХ пользователей?')) return;
        fetch('/api/notifications/read_all', {
            method: 'POST',
            headers: Object.assign({'Content-Type': 'application/json'}, window.REESTR_CSRF ? {'X-CSRF-Token': window.REESTR_CSRF} : {}),
            credentials: 'same-origin',
            body: JSON.stringify({}),
        }).then(function(r) { return r.json(); }).then(function(res) {
            if (res && res.success) {
                if (typeof notify === 'function') notify('✅ Сброшено: ' + (res.cleared || 0));
                refresh();
            } else if (typeof notify === 'function') {
                notify('❌ ' + ((res && res.error) || 'Ошибка'), 'error');
            }
        }).catch(function(){});
    });
}

function refresh() {
    Promise.all([
        fetch('/api/notifications', {credentials: 'same-origin'}).then(function(r) { return r.json(); }).catch(function() { return null; }),
        fetch('/api/plugins/reminders/me', {credentials: 'same-origin'}).then(function(r) { return r.json(); }).catch(function() { return null; })
    ]).then(function(results) {
        var notif = results[0] || {};
        var rem = results[1] || {};
        var items = (notif.items || []).slice();
        var remItems = (rem.success && rem.items) ? rem.items : [];
        remItems.forEach(function(it) {
            items.unshift({
                id: 'rem_' + it.task_id + '_' + it.kind,
                kind: 'reminder', task_id: it.task_id,
                message: it.task_name, status: 'info',
                read_at: '', ts: '', _reminder: it
            });
        });
        var cnt = document.getElementById('trkBellCount');
        var total = (notif.unread || 0) + remItems.length;
        if (cnt) {
            if (total > 0) { cnt.style.display = ''; cnt.textContent = total > 99 ? '99+' : String(total); }
            else cnt.style.display = 'none';
        }
        var drop = document.getElementById('trkBellDrop');
        if (drop && drop.style.display !== 'none') {
            _renderList(items);
        } else {
            _ensureDrop();
            _renderList(items);
            var dd = document.getElementById('trkBellDrop');
            if (dd) dd.style.display = 'none';
        }
    }).catch(function(){});
}

function toggleDrop() {
    var d = _ensureDrop();
    if (d.style.display === 'none') {
        var bell = document.getElementById('trkBell');
        if (bell) {
            var rect = bell.getBoundingClientRect();
            d.style.right = (window.innerWidth - rect.right) + 'px';
            d.style.top = (rect.bottom + 8) + 'px';
        }
        d.style.display = '';
    } else {
        d.style.display = 'none';
    }
}

function boot() {
    var bell = document.getElementById('trkBell');
    if (!bell || bell._bellHooked) return;
    bell._bellHooked = true;
    bell.addEventListener('click', function(e) {
        e.stopPropagation();
        toggleDrop();
    });
    document.addEventListener('click', function(e) {
        var d = document.getElementById('trkBellDrop');
        if (!d || d.style.display === 'none') return;
        if (e.target && (d.contains(e.target) || (e.target.closest && e.target.closest('#trkBell')))) return;
        d.style.display = 'none';
    });
    refresh();
    setInterval(refresh, 30000);
    window.addEventListener('focus', function(){ try { refresh(); } catch(e){} });
    document.addEventListener('visibilitychange', function(){
        if (!document.hidden) { try { refresh(); } catch(e){} }
    });
}
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
} else {
    setTimeout(boot, 300);
}
})();


/* ============================================================
   PATCH v1.0.22 — фиксы UI
   ============================================================ */
(function(){
'use strict';

/* --- 1. emoji-пикер поверх карточки задачи --- */
if (!window.__trkEmojiZFix) {
    window.__trkEmojiZFix = true;
    function _forceEmojiZ(m) {
        if (!m) return;
        m._zstackForeign = true;
        m.style.setProperty('z-index', '9000', 'important');
    }
    function _emojiHook() {
        var m = document.getElementById('emojiModal');
        if (!m) return;
        // Всегда помечаем как «чужой» — JS-стек v1.0.10 её не трогает
        m._zstackForeign = true;
        if (m._zfixHooked) { _forceEmojiZ(m); return; }
        m._zfixHooked = true;
        new MutationObserver(function(){
            if (m.classList.contains('active')) _forceEmojiZ(m);
        }).observe(m, { attributes: true, attributeFilter: ['class'] });
        if (m.classList.contains('active')) _forceEmojiZ(m);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', _emojiHook);
    else _emojiHook();
    setTimeout(_emojiHook, 300);
    setTimeout(_emojiHook, 1000);
    setTimeout(_emojiHook, 2500);
    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('#taskIconPickBtn')) {
            _emojiHook();
            setTimeout(function(){
                var m = document.getElementById('emojiModal');
                if (m && m.classList.contains('active')) _forceEmojiZ(m);
            }, 30);
            setTimeout(function(){
                var m = document.getElementById('emojiModal');
                if (m && m.classList.contains('active')) _forceEmojiZ(m);
            }, 200);
        }
    }, true);
}

})();


/* --- 2. Блок ссылок на плитке задачи (отдельный контейнер) --- */
(function(){
'use strict';
if (window.__trkTaskLinksBlockV122) return;
window.__trkTaskLinksBlockV122 = true;

function _esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}
function _isExt(u) { return /^(https?|ftp):\/\//i.test(String(u || '')); }

function _copy(text) {
    try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(function(){
                if (typeof window.__trackerNotify === 'function') window.__trackerNotify('📋 Скопировано: ' + text);
            }, function(){ _fallback(text); });
        } else { _fallback(text); }
    } catch (e) { _fallback(text); }
}
function _fallback(text) {
    try {
        var ta = document.createElement('textarea');
        ta.value = text; ta.style.position = 'fixed'; ta.style.left = '-9999px';
        document.body.appendChild(ta); ta.select(); document.execCommand('copy');
        document.body.removeChild(ta);
        if (typeof window.__trackerNotify === 'function') window.__trackerNotify('📋 Скопировано: ' + text);
    } catch (e) {
        if (typeof window.__trackerNotify === 'function') window.__trackerNotify('❌ Не удалось скопировать', 'error');
    }
}

function _renderLinksOnList() {
    var list = document.getElementById('tasksFullList');
    if (!list) return;
    var st = window.__trkState || {};
    var map = {};
    (st.tasks || []).forEach(function(t){ map[t.id] = t; });
    list.querySelectorAll('.task-card').forEach(function(card){
        var id = card.getAttribute('data-id');
        if (!id) return;
        var t = map[id];
        var old = card.querySelector('.task-card-links-block');
        var links = (t && Array.isArray(t.links)) ? t.links : [];
        if (!links.length) { if (old) old.remove(); return; }
        var block = old || document.createElement('div');
        block.className = 'task-card-links-block';
        var h = '<span class="tcl-label">🔗 ' + links.length + '</span>';
        links.slice(0, 3).forEach(function(lk){
            var u = (lk && lk.url) || '';
            var d = (lk && lk.description) || '';
            if (!u) return;
            var ext = _isExt(u);
            var label = d || (u.length > 40 ? u.slice(0, 39) + '…' : u);
            h += '<a class="tcl-link" href="javascript:void(0)" data-lu="' + _esc(u) + '" title="' + _esc(u) + '">'
               + (ext ? '🌐 ' : '📁 ') + _esc(label) + '</a>';
        });
        if (links.length > 3) h += '<span class="tcl-more">+' + (links.length - 3) + '</span>';
        block.innerHTML = h;
        if (!old) {
            // вставляем в самый низ карточки — после .task-card-foot или в конец
            var foot = card.querySelector('.task-card-foot');
            if (foot && foot.parentNode) foot.parentNode.insertBefore(block, foot.nextSibling);
            else card.appendChild(block);
        }
        block.querySelectorAll('.tcl-link[data-lu]').forEach(function(a){
            if (a._linkHook) return;
            a._linkHook = true;
            a.addEventListener('click', function(e){
                e.preventDefault(); e.stopPropagation();
                var u = this.getAttribute('data-lu');
                if (!u) return;
                if (_isExt(u)) window.open(u, '_blank', 'noopener,noreferrer');
                else _copy(u);
            });
        });
    });
}

// хукаем рендер списка задач
(function(){
    function _hook() {
        if (typeof window.__trkRenderTasksFull !== 'function') return;
        if (window.__trkRenderTasksFull._linksV122) return;
        var orig = window.__trkRenderTasksFull;
        var w = function(){
            var r = orig.apply(this, arguments);
            setTimeout(_renderLinksOnList, 30);
            return r;
        };
        w._linksV122 = true;
        window.__trkRenderTasksFull = w;
    }
    _hook();
    setTimeout(_hook, 500);
    setTimeout(_hook, 1500);
})();

// и наблюдаем за списком на случай прямых манипуляций
(function(){
    function _obs() {
        var list = document.getElementById('tasksFullList');
        if (!list || list._linksV122Obs) return;
        list._linksV122Obs = true;
        new MutationObserver(function(){ setTimeout(_renderLinksOnList, 40); }).observe(list, { childList: true });
        setTimeout(_renderLinksOnList, 100);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function(){ setTimeout(_obs, 600); });
    else setTimeout(_obs, 600);
    setTimeout(_obs, 1500);
})();

window.__trkRenderTaskCardLinks = _renderLinksOnList;
})();


/* --- 3. Блок «🔗 Ссылки» в расширенной карточке задачи (📊) --- */
(function(){
'use strict';
if (window.__trkTaskCardLinksModalV122) return;
window.__trkTaskCardLinksModalV122 = true;

function _esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}
function _isExt(u) { return /^(https?|ftp):\/\//i.test(String(u || '')); }

function _renderModal() {
    var modal = document.getElementById('taskCardModal');
    if (!modal || !modal.classList.contains('active')) return;
    var content = modal.querySelector('.modal-content');
    if (!content) return;
    var st = window.__trkState || {};
    var d = st.__lastTaskCardData;
    if (!d || !d.task) return;
    var links = Array.isArray(d.task.links) ? d.task.links : [];
    var old = document.getElementById('taskCardLinksModalBlock');
    if (old) old.remove();
    if (!links.length) return;

    var block = document.createElement('div');
    block.id = 'taskCardLinksModalBlock';
    block.className = 'tcf-links-block';
    var h = '<div class="tcf-links-title"><span>🔗</span><span>Ссылки (' + links.length + ')</span></div>';
    links.forEach(function(lk){
        var u = (lk && lk.url) || '';
        var desc = (lk && lk.description) || '';
        if (!u) return;
        var ext = _isExt(u);
        var actionLabel = ext ? '🌐 Открыть' : '📋 Копировать';
        h += '<div class="tcf-link-row" data-lu="' + _esc(u) + '">'
           +   '<span class="tcf-link-ico">' + (ext ? '🌐' : '📁') + '</span>'
           +   '<div>'
           +     (desc ? '<div class="tcf-link-desc">' + _esc(desc) + '</div>' : '')
           +     '<div class="tcf-link-url">' + _esc(u) + '</div>'
           +   '</div>'
           +   '<button type="button" class="tcf-link-action">' + actionLabel + '</button>'
           + '</div>';
    });
    block.innerHTML = h;

    // вставляем после блока «История работы» или в конце, перед actions
    var actions = content.querySelector(':scope > .modal-actions');
    if (actions && actions.parentNode === content) content.insertBefore(block, actions);
    else content.appendChild(block);

    block.querySelectorAll('.tcf-link-action').forEach(function(btn){
        btn.addEventListener('click', function(e){
            e.preventDefault(); e.stopPropagation();
            var row = this.closest('.tcf-link-row');
            var u = row ? row.getAttribute('data-lu') : '';
            if (!u) return;
            if (_isExt(u)) window.open(u, '_blank', 'noopener,noreferrer');
            else {
                try {
                    if (navigator.clipboard && navigator.clipboard.writeText) {
                        navigator.clipboard.writeText(u).then(function(){
                            if (typeof window.__trackerNotify === 'function') window.__trackerNotify('📋 Скопировано: ' + u);
                        }, function(){
                            var ta = document.createElement('textarea');
                            ta.value = u; ta.style.position = 'fixed'; ta.style.left = '-9999px';
                            document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta);
                            if (typeof window.__trackerNotify === 'function') window.__trackerNotify('📋 Скопировано: ' + u);
                        });
                    }
                } catch (err) {
                    if (typeof window.__trackerNotify === 'function') window.__trackerNotify('❌ Не удалось скопировать', 'error');
                }
            }
        });
    });
}

// Хукаем открытие карточки задачи
(function(){
    function _hookOpen() {
        if (typeof window.__trkOpenTaskCardModal !== 'function') return;
        if (window.__trkOpenTaskCardModal._linksV122) return;
        var orig = window.__trkOpenTaskCardModal;
        var w = function(){
            var r = orig.apply(this, arguments);
            setTimeout(_renderModal, 200);
            setTimeout(_renderModal, 500);
            return r;
        };
        w._linksV122 = true;
        window.__trkOpenTaskCardModal = w;
    }
    _hookOpen();
    setTimeout(_hookOpen, 500);
    setTimeout(_hookOpen, 1500);
})();

// И просто наблюдаем за модалкой на случай, если патч-обёртка не сработала
setTimeout(function(){
    var modal = document.getElementById('taskCardModal');
    if (!modal) return;
    new MutationObserver(function(){
        if (modal.classList.contains('active')) {
            setTimeout(_renderModal, 200);
            setTimeout(_renderModal, 600);
        }
    }).observe(modal, { attributes: true, attributeFilter: ['class'] });
}, 700);

window.__trkRenderTaskCardModalLinks = _renderModal;
})();


/* ============================================================
   PATCH v1.0.29 — гарантированно вставляем «Мой профиль»
   в выпадающее меню пользователя. Шаблонный вариант был под
   {% if current_user.employee_id %}, у admin он пустой — потому
   ссылка не отрисовывалась.
   ============================================================ */
(function(){
'use strict';
if (window.__trkMyProfileMenuV129) return;
window.__trkMyProfileMenuV129 = true;

function _ensure() {
    var dd = document.getElementById('userDropdown');
    if (!dd) return;
    if (dd.querySelector('a[href="/plugins/my_profile/"]')) return;
    var link = document.createElement('a');
    link.className = 'ud-item';
    link.href = '/plugins/my_profile/';
    link.innerHTML = '<span class="ud-icon">👤</span><span class="ud-label">Мой профиль</span>';
    dd.insertBefore(link, dd.firstChild);
    // Разделитель сразу после ссылки, если его нет
    var next = link.nextSibling;
    var hasSep = next && next.classList && next.classList.contains('ud-sep');
    if (!hasSep) {
        var sep = document.createElement('div');
        sep.className = 'ud-sep';
        dd.insertBefore(sep, link.nextSibling);
    }
}

function boot() {
    _ensure();
    setTimeout(_ensure, 400);
    setTimeout(_ensure, 1200);
    setTimeout(_ensure, 2500);
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();

// Если меню перерисовывается — вставим ещё раз
setTimeout(function(){
    var chip = document.getElementById('userChip');
    if (!chip) return;
    chip.addEventListener('click', function(){ setTimeout(_ensure, 30); });
}, 800);
})();


/* ============================================================
   PATCH v1.0.32 — приказы/распоряжения как список + перестановка блоков
   ============================================================ */
var _taskOrdersDraft = [];
function _isExtUrl2(u) { return /^(https?|ftp):\/\//i.test(String(u || '')); }
function _escAttr2(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}
function renderTaskOrdersDraft() {
    var box = document.getElementById('taskOrdersList');
    if (!box) return;
    if (!_taskOrdersDraft.length) {
        box.innerHTML = '<div class="task-links-empty">Пока нет распоряжений</div>';
        return;
    }
    var h = '';
    _taskOrdersDraft.forEach(function(o, i) {
        var desc = (o && o.description) || '';
        var val = (o && o.value) || '';
        h += '<div class="task-link-row" data-i="' + i + '">'
          +  '<input type="text" class="task-order-desc" placeholder="Описание (Приказ № 235 о переносе)" value="' + _escAttr2(desc) + '" maxlength="200">'
          +  '<input type="text" class="task-order-val" placeholder="Номер / путь / URL" value="' + _escAttr2(val) + '" maxlength="1000">'
          +  '<button type="button" class="task-link-del" title="Удалить">×</button>'
          +  '</div>';
    });
    box.innerHTML = h;
    box.querySelectorAll('.task-link-row').forEach(function(row) {
        var i = parseInt(row.getAttribute('data-i'), 10);
        var dEl = row.querySelector('.task-order-desc');
        var vEl = row.querySelector('.task-order-val');
        if (dEl) dEl.addEventListener('input', function() { _taskOrdersDraft[i].description = this.value; });
        if (vEl) vEl.addEventListener('input', function() { _taskOrdersDraft[i].value = this.value; });
        var xb = row.querySelector('.task-link-del');
        if (xb) xb.addEventListener('click', function() {
            _taskOrdersDraft.splice(i, 1);
            renderTaskOrdersDraft();
        });
    });
}
(function(){
    'use strict';
    if (window.__trkTaskOrdersInit) return;
    window.__trkTaskOrdersInit = true;
    document.addEventListener('click', function(e) {
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('#taskOrderAddBtn')) {
            e.preventDefault();
            _taskOrdersDraft = _taskOrdersDraft || [];
            _taskOrdersDraft.push({ description: '', value: '' });
            renderTaskOrdersDraft();
        }
    }, true);
})();

/* Перестановка блоков в карточке задачи */
(function(){
'use strict';
if (window.__trkTaskModalReorderV132) return;
window.__trkTaskModalReorderV132 = true;
function _reorder() {
    var modal = document.getElementById('taskModal');
    if (!modal) return;
    var content = modal.querySelector('.modal-content');
    if (!content) return;

    // 1. Ссылки — под приказы (т.е. ссылки идут после ordersGroup)
    var linksGroup = document.getElementById('taskLinksGroup');
    var ordersGroup = document.getElementById('taskOrdersGroup');
    if (linksGroup && ordersGroup && ordersGroup.parentNode && linksGroup.parentNode) {
        if (linksGroup.previousElementSibling !== ordersGroup) {
            ordersGroup.parentNode.insertBefore(linksGroup, ordersGroup.nextSibling);
        }
    }

    // 2. Urgent — под блок статуса (.form-row-3)
    var urgentRow = content.querySelector('.task-urgent-row');
    var row3 = content.querySelector('.form-row-3');
    if (urgentRow && row3 && row3.nextElementSibling !== urgentRow) {
        row3.parentNode.insertBefore(urgentRow, row3.nextSibling);
    }
}
function boot() {
    var m = document.getElementById('taskModal');
    if (!m) return;
    if (m._reorderV132Hooked) { _reorder(); return; }
    m._reorderV132Hooked = true;
    new MutationObserver(function(){ if (m.classList.contains('active')) setTimeout(_reorder, 40); })
        .observe(m, { attributes: true, attributeFilter: ['class'] });
    _reorder();
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
setTimeout(boot, 600);
setTimeout(boot, 1500);
setTimeout(boot, 3000);
document.addEventListener('click', function(e){
    if (!e.target || !e.target.closest) return;
    if (e.target.closest('#addTaskBtn') || e.target.closest('#addTaskBtn2') || e.target.closest('.task-card-clickable')) {
        setTimeout(_reorder, 120);
        setTimeout(_reorder, 400);
    }
}, true);
window.__trkReorderTaskModal = _reorder;
})();


/* ============================================================
   PATCH v1.0.40 — полный список ссылок/приказов/доп. данных
   в карточке задачи на вкладке «Задачи».
   Показываем ВСЁ, что занесено: task.links[], task.orders[],
   task.folder (по строкам). Клик по внешнему — открыть, по
   локальному — скопировать в буфер.
   Старые частичные блоки (.task-card-links-block из v1.0.22
   и .txi-ord/.txi-fold/.txi-links из v1.2.21) скрываем CSS-ом.
   ============================================================ */
(function(){
'use strict';
if (window.__trkFullTaskLinksV140) return;
window.__trkFullTaskLinksV140 = true;

function _esc(s){
    return String(s==null?'':s).replace(/[&<>"']/g,function(c){
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}
function _isExt(u){ return /^(https?|ftp):\/\//i.test(String(u||'')); }

function _copy(u){
    try{
        if(navigator.clipboard && navigator.clipboard.writeText){
            navigator.clipboard.writeText(u).then(function(){
                if(typeof window.__trackerNotify==='function')window.__trackerNotify('📋 Скопировано: '+u);
            }, function(){ _fb(u); });
        } else _fb(u);
    }catch(e){ _fb(u); }
}
function _fb(u){
    try{
        var ta=document.createElement('textarea');
        ta.value=u; ta.style.position='fixed'; ta.style.left='-9999px';
        document.body.appendChild(ta); ta.select(); document.execCommand('copy');
        document.body.removeChild(ta);
        if(typeof window.__trackerNotify==='function')window.__trackerNotify('📋 Скопировано: '+u);
    }catch(e){}
}

function _collect(t){
    var links = Array.isArray(t.links)
        ? t.links.filter(function(x){return x && x.url;}) : [];
    var orders = Array.isArray(t.orders)
        ? t.orders.filter(function(x){return x && (x.value || x.description);}) : [];
    var folders = String(t.folder||'').split(/\r?\n/)
        .map(function(s){return s.trim();})
        .filter(Boolean);
    return {links:links, orders:orders, folders:folders};
}

function _renderAll(){
    var list = document.getElementById('tasksFullList');
    if(!list) return;
    var st = window.__trkState || {};
    var map = {};
    (st.tasks||[]).forEach(function(t){ map[t.id]=t; });
    list.querySelectorAll('.task-card').forEach(function(card){
        var id = card.getAttribute('data-id');
        if(!id) return;
        var t = map[id];
        if(!t) return;
        var old = card.querySelector('.task-card-full-links');
        if(old) old.remove();

        var data = _collect(t);
        if(!data.links.length && !data.orders.length && !data.folders.length) return;

        var block = document.createElement('div');
        block.className = 'task-card-full-links';
        var h = '';

        // Ссылки
        if(data.links.length){
            h += '<div class="tfl-sec"><div class="tfl-head">🔗 Ссылки (' + data.links.length + ')</div>';
            data.links.forEach(function(lk){
                var u = lk.url || '';
                var d = lk.description || '';
                var ext = _isExt(u);
                h += '<div class="tfl-row" data-lu="' + _esc(u) + '" data-ext="' + (ext?'1':'0') + '">'
                   +    '<span class="tfl-ico">' + (ext?'🌐':'📁') + '</span>'
                   +    '<div class="tfl-body">'
                   +      (d ? '<div class="tfl-desc">' + _esc(d) + '</div>' : '')
                   +      '<div class="tfl-url">' + _esc(u) + '</div>'
                   +    '</div>'
                   +  '</div>';
            });
            h += '</div>';
        }

        // Приказы / распоряжения
        if(data.orders.length){
            h += '<div class="tfl-sec"><div class="tfl-head">📄 Приказы / распоряжения (' + data.orders.length + ')</div>';
            data.orders.forEach(function(o){
                var d = o.description || '';
                var v = o.value || '';
                var ext = _isExt(v);
                h += '<div class="tfl-row" data-lu="' + _esc(v) + '" data-ext="' + (ext?'1':'0') + '">'
                   +    '<span class="tfl-ico">' + (ext?'🌐':'📄') + '</span>'
                   +    '<div class="tfl-body">'
                   +      (d ? '<div class="tfl-desc">' + _esc(d) + '</div>' : '')
                   +      (v ? '<div class="tfl-url">' + _esc(v) + '</div>' : '')
                   +    '</div>'
                   +  '</div>';
            });
            h += '</div>';
        }

        // Дополнительные данные (бывшие «папки»)
        if(data.folders.length){
            h += '<div class="tfl-sec"><div class="tfl-head">📁 Дополнительные данные (' + data.folders.length + ')</div>';
            data.folders.forEach(function(f){
                h += '<div class="tfl-row" data-lu="' + _esc(f) + '" data-ext="0">'
                   +    '<span class="tfl-ico">📁</span>'
                   +    '<div class="tfl-body"><div class="tfl-url">' + _esc(f) + '</div></div>'
                   +  '</div>';
            });
            h += '</div>';
        }

        block.innerHTML = h;
        var foot = card.querySelector('.task-card-foot');
        if(foot && foot.parentNode) foot.parentNode.insertBefore(block, foot.nextSibling);
        else card.appendChild(block);

        block.querySelectorAll('.tfl-row').forEach(function(row){
            if(row._hooked) return;
            row._hooked = true;
            row.addEventListener('click', function(e){
                e.preventDefault(); e.stopPropagation();
                var u = this.getAttribute('data-lu');
                var ext = this.getAttribute('data-ext') === '1';
                if(!u) return;
                if(ext){ window.open(u, '_blank', 'noopener,noreferrer'); return; }
                _copy(u);
            });
        });
    });
}

// Обёртка над __trkRenderTasksFull — вызываем перерисовку после рендера списка
(function(){
    function _hook(){
        if(typeof window.__trkRenderTasksFull !== 'function') return;
        if(window.__trkRenderTasksFull._fullLinksV140) return;
        var orig = window.__trkRenderTasksFull;
        var w = function(){
            var r = orig.apply(this, arguments);
            setTimeout(_renderAll, 40);
            return r;
        };
        w._fullLinksV140 = true;
        window.__trkRenderTasksFull = w;
    }
    _hook();
    setTimeout(_hook, 400);
    setTimeout(_hook, 1200);
})();

// Observer на сам список — на случай прямых манипуляций
(function(){
    function _obs(){
        var list = document.getElementById('tasksFullList');
        if(!list || list._fullLinksV140Obs) return;
        list._fullLinksV140Obs = true;
        new MutationObserver(function(){ setTimeout(_renderAll, 30); })
            .observe(list, {childList:true});
        setTimeout(_renderAll, 100);
    }
    if(document.readyState === 'loading'){
        document.addEventListener('DOMContentLoaded', function(){ setTimeout(_obs, 500); });
    } else setTimeout(_obs, 500);
})();

// Ручной вызов по клику на вкладку «Задачи»
document.addEventListener('click', function(e){
    if(!e.target || !e.target.closest) return;
    if(e.target.closest('.tracker-tab[data-tab="tasks"]')){
        setTimeout(_renderAll, 300);
        setTimeout(_renderAll, 700);
    }
});

window.__trkRenderFullTaskLinks = _renderAll;
})();


/* ============================================================
   PATCH v1.0.3 — фидбек кнопки «Добавить» в блоке
   «Назначено, но не заведено» (модалка новой отметки).
   Перехват на window в capture-фазе — раньше v1.2.3 / PATCH 23.
   ============================================================ */
(function(){
'use strict';
if (window.__trkLabAddFeedbackV103) return;
window.__trkLabAddFeedbackV103 = true;

function _notify(msg, kind){
    if (typeof window.__trackerNotify === 'function') {
        try { window.__trackerNotify(msg, kind); return; } catch (e) {}
    }
    console.log('[lab-feedback]', msg);
}

function _modalContent(){
    var m = document.getElementById('logModal');
    return m ? m.querySelector('.modal-content') : null;
}
function _blockModal(){
    var c = _modalContent();
    if (c) c.classList.add('lab-modal-blocked');
}
function _unblockModal(){
    var c = _modalContent();
    if (c) c.classList.remove('lab-modal-blocked');
}

function _labelizeBtn(btn){
    if (!btn) return;
    var tile = btn.closest('.lab-tile');
    if (tile && (tile.classList.contains('lab-processing') || tile.classList.contains('lab-success'))) return;
    var txt = (btn.textContent || '').trim();
    if (txt !== '➕ Добавить') btn.textContent = '➕ Добавить';
}
function _decorateAll(){
    var btns = document.querySelectorAll('#logModal .log-assigned-block .lab-tile .lab-add');
    btns.forEach(_labelizeBtn);
}

function _findBtn(e){
    if (!e || !e.target || !e.target.closest) return null;
    return e.target.closest('#logModal .log-assigned-block .lab-tile .lab-add');
}

function _buildPayload(tile){
    var tid = tile.getAttribute('data-task-id');
    if (!tid) return {error: 'Не найдена задача'};
    var empEl = document.getElementById('log_employee');
    var dtEl = document.getElementById('log_date');
    var empId = empEl ? empEl.value : '';
    var dk = dtEl ? dtEl.value : '';
    if (!empId) return {error: 'Выберите сотрудника'};
    if (!dk) return {error: 'Некорректная дата'};

    var st = window.__trkState || {};
    var day = null;
    if (st.calendar && st.calendar.days) {
        day = st.calendar.days.find(function(d){ return d.date === dk; });
    }
    var n = 0;
    if (day && day.entries) {
        day.entries.forEach(function(en){ if (en.employee_id === empId) n++; });
    }
    var hrs = Math.round((((window.__trkGetDayNorm ? window.__trkGetDayNorm(dk) : 8) || 8) / (n + 1)) * 4) / 4;
    if (hrs < 0.5) hrs = 0.5;
    if (hrs > 24) hrs = 24;

    return {
        employee_id: empId,
        task_id: tid,
        date: dk,
        hours: hrs,
        status: 'in_progress',
        comment: 'Назначенная задача, добавлена из карточки отметки',
        link: ''
    };
}

// === Перерисовка списка «Уже заведено за этот день» ===
function _refreshDayExisting(){
    try {
        var tabs = document.getElementById('logExistingTabs');
        if (tabs) {
            var activeTab = tabs.querySelector('.log-existing-tab.active')
                         || tabs.querySelector('.log-existing-tab');
            if (activeTab) {
                activeTab.click();
                return true;
            }
        }
        // Fallback: смена даты → change → renderExistingDayEntries
        var dtEl = document.getElementById('log_date');
        if (dtEl) {
            dtEl.dispatchEvent(new Event('change', {bubbles: true}));
            return true;
        }
    } catch(e) { console.error('[lab-feedback] refresh list', e); }
    return false;
}

// === Обновление календаря (state.calendar) и dayModal ===
function _refreshCalendarThen(){
    var p = Promise.resolve();
    try {
        if (typeof window.__trkRenderCalendar === 'function') {
            p = Promise.resolve(window.__trkRenderCalendar());
        }
    } catch(e) { console.error('[lab-feedback] calendar refresh', e); }
    return p;
}
function _refreshDayModalIfOpen(){
    try {
        var dm = document.getElementById('dayModal');
        var st = window.__trkState || {};
        if (dm && dm.classList.contains('active') && st.currentDay) {
            if (typeof window.__trkOpenDayModal === 'function') {
                window.__trkOpenDayModal(st.currentDay);
            }
        }
    } catch(e) { console.error('[lab-feedback] dayModal refresh', e); }
}

function _doAdd(tile, btn){
    var payload = _buildPayload(tile);
    if (!payload) return;
    if (payload.error) { _notify('❌ ' + payload.error, 'error'); return; }

    // === «Обрабатывается»: состояние плитки + блокировка модалки ===
    tile.classList.remove('lab-success');
    tile.classList.add('lab-processing');
    btn.disabled = true;
    btn.textContent = 'Обрабатывается…';
    _blockModal();

    var hdrs = {'Content-Type': 'application/json'};
    if (window.REESTR_CSRF) hdrs['X-CSRF-Token'] = window.REESTR_CSRF;

    fetch('/api/tracker/log/save', {
        method: 'POST',
        headers: hdrs,
        credentials: 'same-origin',
        body: JSON.stringify(payload)
    })
    .then(function(r){
        return r.text().then(function(t){
            var j = null;
            try { j = JSON.parse(t); } catch(e) {}
            if (!r.ok || !j || !j.success) {
                var msg = (j && j.error) || ('HTTP ' + r.status);
                throw new Error(msg);
            }
            return j;
        });
    })
    .then(function(){
        // === «Успешно добавлено» ===
        tile.classList.remove('lab-processing');
        tile.classList.add('lab-success');
        btn.textContent = '✅ Успешно добавлено';
        _notify('✅ Задача добавлена в день', 'success');

        // Локально в state.calendar — чтобы сразу подхватилось списком
        try {
            var st = window.__trkState || {};
            if (st.calendar && st.calendar.days) {
                var day = st.calendar.days.find(function(d){ return d.date === payload.date; });
                if (day) {
                    if (!day.entries) day.entries = [];
                    var exists = day.entries.some(function(e){
                        return e.employee_id === payload.employee_id &&
                               e.task_id === payload.task_id &&
                               e.date === payload.date;
                    });
                    if (!exists) {
                        day.entries.push({
                            id: 'tmp_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
                            employee_id: payload.employee_id,
                            task_id: payload.task_id,
                            date: payload.date,
                            hours: payload.hours,
                            status: 'in_progress',
                            comment: payload.comment,
                            link: ''
                        });
                    }
                }
            }
        } catch(e) { console.error('[lab-feedback] state update', e); }

        // Разблокируем модалку сразу после успеха
        _unblockModal();

        // Обновляем state.calendar с сервера, затем триггерим списки
        _refreshCalendarThen().then(function(){
            _refreshDayExisting();
            _refreshDayModalIfOpen();
        });

        // Плавно убираем плитку через 1.2 сек
        setTimeout(function(){
            tile.classList.add('lab-removing');
            setTimeout(function(){
                if (tile.parentNode) tile.parentNode.removeChild(tile);
                // После удаления плитки пересобираем блок «Назначено»
                try {
                    if (window.__trkLogAssignedDecorate) window.__trkLogAssignedDecorate();
                } catch(e) {}
            }, 380);
        }, 1200);
    })
    .catch(function(err){
        // === Возврат в исходное состояние при ошибке ===
        tile.classList.remove('lab-processing');
        btn.disabled = false;
        btn.textContent = '➕ Добавить';
        _unblockModal();
        var msg = (err && err.message) || 'Ошибка';
        if (msg.indexOf('cancelled') !== -1) return;
        _notify('❌ ' + msg, 'error');
    });
}

// === Основной перехват ===
window.addEventListener('click', function(e){
    var btn = _findBtn(e);
    if (!btn) return;
    var tile = btn.closest('.lab-tile');
    if (!tile) return;

    if (tile.classList.contains('lab-processing') ||
        tile.classList.contains('lab-success')) {
        e.preventDefault();
        e.stopPropagation();
        if (e.stopImmediatePropagation) e.stopImmediatePropagation();
        return;
    }

    e.preventDefault();
    e.stopPropagation();
    if (e.stopImmediatePropagation) e.stopImmediatePropagation();
    _doAdd(tile, btn);
}, true);

// === Авторазметка кнопок ===
(function _observeLogModal(){
    var modal = document.getElementById('logModal');
    if (!modal || modal._labFeedbackObsV103) return;
    modal._labFeedbackObsV103 = true;
    new MutationObserver(function(){ setTimeout(_decorateAll, 40); })
        .observe(modal, { childList: true, subtree: true });
    setTimeout(_decorateAll, 200);
    setTimeout(_decorateAll, 700);
})();

(function _boot(){
    _decorateAll();
    setTimeout(_decorateAll, 400);
    setTimeout(_decorateAll, 1200);
    setTimeout(_decorateAll, 2500);
})();

document.addEventListener('click', function(e){
    if (!e.target || !e.target.closest) return;
    if (e.target.closest('#dayAddBtn') ||
        e.target.closest('#dayModal .dict-action-btn[data-act="edit"]')) {
        setTimeout(_decorateAll, 300);
        setTimeout(_decorateAll, 800);
    }
});

// На случай закрытия модалки извне — снимаем блокировку
(function _watchClose(){
    var modal = document.getElementById('logModal');
    if (!modal || modal._labFeedbackCloseWatcher) return;
    modal._labFeedbackCloseWatcher = true;
    new MutationObserver(function(){
        if (!modal.classList.contains('active')) _unblockModal();
    }).observe(modal, { attributes: true, attributeFilter: ['class'] });
})();

window.__trkLabDecorateV103 = _decorateAll;
})();


/* ============================================================
   PATCH v1.0.4 — multi-поля в карточке отметки
   Доп.данные / Приказы / Ссылки — editable при создании,
   read-only при редактировании. Всё добавленное уходит в задачу.
   ============================================================ */
(function(){
'use strict';
if (window.__trkLogFormFocusV104) return;
window.__trkLogFormFocusV104 = true;

var _extraDraft = [];
var _ordersDraft = [];
var _linksDraft = [];

window.__trkLogExtraDraft = _extraDraft;
window.__trkLogOrdersDraft = _ordersDraft;
window.__trkLogLinksDraft = _linksDraft;

function _esc(s){
    return String(s==null?'':s).replace(/[&<>"']/g,function(c){
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}

function _renderExtra(){
    var box = document.getElementById('logExtraDataList');
    if (!box) return;
    if (!_extraDraft.length) {
        box.innerHTML = '<div class="task-links-empty">— нет —</div>';
        return;
    }
    var h = '';
    _extraDraft.forEach(function(item, i){
        h += '<div class="task-link-row" data-i="' + i + '">'
          +    '<input type="text" class="task-order-val" placeholder="\\server\\share или C:\\folder\\…" value="' + _esc(item.line || '') + '" maxlength="500">'
          +    '<span></span>'
          +    '<button type="button" class="task-link-del" title="Удалить">×</button>'
          +  '</div>';
    });
    box.innerHTML = h;
    box.querySelectorAll('.task-link-row').forEach(function(row){
        var i = parseInt(row.getAttribute('data-i'), 10);
        var inp = row.querySelector('input');
        if (inp) inp.addEventListener('input', function(){ _extraDraft[i].line = this.value; });
        var xb = row.querySelector('.task-link-del');
        if (xb) xb.addEventListener('click', function(){ _extraDraft.splice(i, 1); _renderExtra(); });
    });
}

function _renderOrders(){
    var box = document.getElementById('logOrdersList');
    if (!box) return;
    if (!_ordersDraft.length) {
        box.innerHTML = '<div class="task-links-empty">— нет —</div>';
        return;
    }
    var h = '';
    _ordersDraft.forEach(function(item, i){
        h += '<div class="task-link-row" data-i="' + i + '">'
          +    '<input type="text" class="task-order-desc" placeholder="Описание" value="' + _esc(item.description || '') + '" maxlength="200">'
          +    '<input type="text" class="task-order-val" placeholder="Номер / путь" value="' + _esc(item.value || '') + '" maxlength="1000">'
          +    '<button type="button" class="task-link-del" title="Удалить">×</button>'
          +  '</div>';
    });
    box.innerHTML = h;
    box.querySelectorAll('.task-link-row').forEach(function(row){
        var i = parseInt(row.getAttribute('data-i'), 10);
        var d = row.querySelector('.task-order-desc');
        var v = row.querySelector('.task-order-val');
        if (d) d.addEventListener('input', function(){ _ordersDraft[i].description = this.value; });
        if (v) v.addEventListener('input', function(){ _ordersDraft[i].value = this.value; });
        var xb = row.querySelector('.task-link-del');
        if (xb) xb.addEventListener('click', function(){ _ordersDraft.splice(i, 1); _renderOrders(); });
    });
}

function _renderLinks(){
    var box = document.getElementById('logLinksList');
    if (!box) return;
    if (!_linksDraft.length) {
        box.innerHTML = '<div class="task-links-empty">— нет —</div>';
        return;
    }
    var h = '';
    _linksDraft.forEach(function(item, i){
        h += '<div class="task-link-row" data-i="' + i + '">'
          +    '<input type="text" class="task-link-desc" placeholder="Описание" value="' + _esc(item.description || '') + '" maxlength="200">'
          +    '<input type="text" class="task-link-url" placeholder="https://… или \\\\server\\share\\file" value="' + _esc(item.url || '') + '" maxlength="1000">'
          +    '<button type="button" class="task-link-del" title="Удалить">×</button>'
          +  '</div>';
    });
    box.innerHTML = h;
    box.querySelectorAll('.task-link-row').forEach(function(row){
        var i = parseInt(row.getAttribute('data-i'), 10);
        var d = row.querySelector('.task-link-desc');
        var u = row.querySelector('.task-link-url');
        if (d) d.addEventListener('input', function(){ _linksDraft[i].description = this.value; });
        if (u) u.addEventListener('input', function(){ _linksDraft[i].url = this.value; });
        var xb = row.querySelector('.task-link-del');
        if (xb) xb.addEventListener('click', function(){ _linksDraft.splice(i, 1); _renderLinks(); });
    });
}

function _renderRO(entry){
    var boxE = document.getElementById('logExtraDataRO');
    var boxO = document.getElementById('logOrdersRO');
    var boxL = document.getElementById('logLinksRO');
    if (boxE) {
        var ex = Array.isArray(entry.extra_data) ? entry.extra_data : [];
        boxE.innerHTML = ex.length
            ? ex.map(function(x){
                var v = (typeof x === 'string') ? x : (x && x.line) || '';
                return '<div class="task-link-row"><input type="text" value="' + _esc(v) + '" disabled></div>';
              }).join('')
            : '<div class="task-links-empty">— нет —</div>';
    }
    if (boxO) {
        var or = Array.isArray(entry.orders) ? entry.orders : [];
        boxO.innerHTML = or.length
            ? or.map(function(x){
                return '<div class="task-link-row"><input type="text" value="' + _esc((x&&x.description)||'') + '" disabled><input type="text" value="' + _esc((x&&x.value)||'') + '" disabled></div>';
              }).join('')
            : '<div class="task-links-empty">— нет —</div>';
    }
    if (boxL) {
        var lk = Array.isArray(entry.links) ? entry.links : [];
        // Если есть одиночная ссылка из старой версии — покажем её тоже
        if (entry.link) {
            lk = lk.slice();
            var hasSingle = lk.some(function(x){ return (x&&x.url) === entry.link; });
            if (!hasSingle) lk.unshift({ description: '', url: entry.link });
        }
        boxL.innerHTML = lk.length
            ? lk.map(function(x){
                return '<div class="task-link-row"><input type="text" value="' + _esc((x&&x.description)||'') + '" disabled><input type="text" value="' + _esc((x&&x.url)||'') + '" disabled></div>';
              }).join('')
            : '<div class="task-links-empty">— нет —</div>';
    }
}

// === Кнопки добавления ===
document.addEventListener('click', function(e){
    if (!e.target || !e.target.closest) return;
    var logModal = document.getElementById('logModal');
    if (!logModal || !logModal.classList.contains('active')) return;

    if (e.target.closest('#logExtraAddBtn')) {
        e.preventDefault();
        _extraDraft.push({ line: '' });
        _renderExtra();
        var box = document.getElementById('logExtraDataList');
        if (box) { var last = box.querySelector('.task-link-row:last-child input'); if (last) last.focus(); }
        return;
    }
    if (e.target.closest('#logOrderAddBtn')) {
        e.preventDefault();
        _ordersDraft.push({ description: '', value: '' });
        _renderOrders();
        var box2 = document.getElementById('logOrdersList');
        if (box2) { var last2 = box2.querySelector('.task-link-row:last-child input'); if (last2) last2.focus(); }
        return;
    }
    if (e.target.closest('#logLinkAddBtn')) {
        e.preventDefault();
        _linksDraft.push({ description: '', url: '' });
        _renderLinks();
        var box3 = document.getElementById('logLinksList');
        if (box3) { var last3 = box3.querySelector('.task-link-row:last-child input'); if (last3) last3.focus(); }
        return;
    }
}, true);

// === Обёртка openLogModal ===
(function _wrapOpen(){
    var orig = window.__trkOpenLogModal;
    if (typeof orig !== 'function' || orig._v104) return;
    var w = function(entry){
        _extraDraft.length = 0;
        _ordersDraft.length = 0;
        _linksDraft.length = 0;
        var r = orig.apply(this, arguments);
        var _isEdit = !!entry;
        var mf = document.getElementById('logMultiFields');
        var mro = document.getElementById('logMultiFieldsRO');
        if (_isEdit) {
            if (mf) mf.style.display = 'none';
            if (mro) mro.style.display = '';
            _renderRO(entry || {});
        } else {
            if (mf) mf.style.display = '';
            if (mro) mro.style.display = 'none';
            _renderExtra();
            _renderOrders();
            _renderLinks();
        }
        return r;
    };
    w._v104 = true;
    window.__trkOpenLogModal = w;
})();
setTimeout(function(){ var o = window.__trkOpenLogModal; if (o && !o._v104) { var t = o; var w = function(entry){ _extraDraft.length=0; _ordersDraft.length=0; _linksDraft.length=0; var r = t.apply(this, arguments); var _isEdit = !!entry; var mf = document.getElementById('logMultiFields'); var mro = document.getElementById('logMultiFieldsRO'); if (_isEdit){ if(mf)mf.style.display='none'; if(mro)mro.style.display=''; _renderRO(entry||{}); } else { if(mf)mf.style.display=''; if(mro)mro.style.display='none'; _renderExtra(); _renderOrders(); _renderLinks(); } return r; }; w._v104 = true; window.__trkOpenLogModal = w; } }, 600);
setTimeout(function(){ var o = window.__trkOpenLogModal; if (o && !o._v104) { var t = o; var w = function(entry){ _extraDraft.length=0; _ordersDraft.length=0; _linksDraft.length=0; var r = t.apply(this, arguments); var _isEdit = !!entry; var mf = document.getElementById('logMultiFields'); var mro = document.getElementById('logMultiFieldsRO'); if (_isEdit){ if(mf)mf.style.display='none'; if(mro)mro.style.display=''; _renderRO(entry||{}); } else { if(mf)mf.style.display=''; if(mro)mro.style.display='none'; _renderExtra(); _renderOrders(); _renderLinks(); } return r; }; w._v104 = true; window.__trkOpenLogModal = w; } }, 1600);

// === Расширение payload в fetch ===
(function _wrapFetch(){
    var nativeFetch = window.fetch;
    if (typeof nativeFetch !== 'function' || window.__trkLogFormFocusFetch) return;
    window.__trkLogFormFocusFetch = true;
    window.fetch = function(url, opts){
        if (typeof url !== 'string' || url.indexOf('/api/tracker/log/save') === -1) {
            return nativeFetch.apply(this, arguments);
        }
        if (!opts || (opts.method || 'GET').toUpperCase() !== 'POST') {
            return nativeFetch.apply(this, arguments);
        }
        var _opts = opts;
        try {
            var _body = JSON.parse(opts.body || '{}');
            if (!_body.id) {
                if (!Array.isArray(_body.extra_data) && _extraDraft.length) {
                    _body.extra_data = _extraDraft.map(function(x){ return (x.line || '').trim(); }).filter(Boolean);
                }
                if (!Array.isArray(_body.orders) && _ordersDraft.length) {
                    _body.orders = _ordersDraft
                        .filter(function(x){ return (x.value || '').trim(); })
                        .map(function(x){ return { description: (x.description||'').trim(), value: (x.value||'').trim() }; });
                }
                if (!Array.isArray(_body.links) && _linksDraft.length) {
                    _body.links = _linksDraft
                        .filter(function(x){ return (x.url || '').trim(); })
                        .map(function(x){ return { description: (x.description||'').trim(), url: (x.url||'').trim() }; });
                }
                if (!_body.description && _body.comment) {
                    _body.description = _body.comment;
                }
            }
            _opts = Object.assign({}, opts, { body: JSON.stringify(_body) });
        } catch(e) {}
        var self = this;
        return nativeFetch.call(self, url, _opts).then(function(r){
            if (!r || !r.ok) return r;
            try {
                return r.clone().json().then(function(d){
                    if (d && d.success && d.merge_info && d.merge_info.total_added > 0) {
                        var mi = d.merge_info;
                        var parts = [];
                        if (mi.extra_added) parts.push('доп. данных +' + mi.extra_added);
                        if (mi.orders_added) parts.push('приказов +' + mi.orders_added);
                        if (mi.links_added) parts.push('ссылок +' + mi.links_added);
                        if (mi.added_description) parts.push('описание');
                        if (parts.length && typeof window.__trackerNotify === 'function') {
                            window.__trackerNotify('📎 В задачу добавлено: ' + parts.join(', '));
                        }
                    }
                    return r;
                });
            } catch(e) { return r; }
        });
    };
})();

})();


/* ============================================================
   PATCH v1.0.5 — обновление карточки отметки после удаления
   ============================================================ */
(function(){
'use strict';
if (window.__trkLogDeleteRefreshV105) return;
window.__trkLogDeleteRefreshV105 = true;

function _refreshLogModal(){
    var logModal = document.getElementById('logModal');
    if (!logModal || !logModal.classList.contains('active')) return;

    // 1. Перерисовать «Уже заведено за этот день» — клик по активной вкладке
    //    (или change по #log_date как fallback)
    try {
        var tabs = document.getElementById('logExistingTabs');
        var clicked = false;
        if (tabs) {
            var activeTab = tabs.querySelector('.log-existing-tab.active')
                         || tabs.querySelector('.log-existing-tab');
            if (activeTab) {
                activeTab.click();
                clicked = true;
            }
        }
        if (!clicked) {
            var dtEl = document.getElementById('log_date');
            if (dtEl) dtEl.dispatchEvent(new Event('change', {bubbles:true}));
        }
    } catch(e) { console.error('[log-del-refresh] list', e); }

    // 2. Перерисовать «Назначено, но не заведено»
    try {
        if (typeof window.__trkLogAssignedDecorate === 'function') {
            window.__trkLogAssignedDecorate();
        }
    } catch(e) { console.error('[log-del-refresh] assigned', e); }

    // 3. «Итого за день»
    try {
        var dtEl2 = document.getElementById('log_date');
        if (dtEl2) dtEl2.dispatchEvent(new Event('change', {bubbles:true}));
    } catch(e) { console.error('[log-del-refresh] summary', e); }
}

function _refreshDayModalIfOpen(){
    try {
        var dm = document.getElementById('dayModal');
        var st = window.__trkState || {};
        if (dm && dm.classList.contains('active') && st.currentDay) {
            if (typeof window.__trkOpenDayModal === 'function') {
                window.__trkOpenDayModal(st.currentDay);
            }
        }
    } catch(e) { console.error('[log-del-refresh] dayModal', e); }
}

function _dropFromLocalState(logId){
    if (!logId) return;
    try {
        var st = window.__trkState || {};
        if (st.calendar && st.calendar.days) {
            st.calendar.days.forEach(function(day){
                if (!day.entries) return;
                day.entries = day.entries.filter(function(en){
                    return !(en && (en.id === logId || en.id === String(logId)));
                });
            });
        }
    } catch(e) { console.error('[log-del-refresh] state', e); }
}

// === Перехват fetch ===
var _native = window.fetch;
if (typeof _native === 'function') {
    window.fetch = function(url, opts){
        var isDel = (typeof url === 'string' && url.indexOf('/api/tracker/log/delete') !== -1);
        if (!isDel) return _native.apply(this, arguments);
        if (!opts || (opts.method || 'GET').toUpperCase() !== 'POST') {
            return _native.apply(this, arguments);
        }
        var logId = null;
        try {
            var b = JSON.parse(opts.body || '{}');
            logId = b.id;
        } catch(e) {}

        var self = this;
        return _native.apply(this, arguments).then(function(r){
            if (!r || !r.ok) return r;
            try {
                return r.clone().json().then(function(d){
                    // PATCH 08 при «Отмена» возвращает {success:false, error:'cancelled'}.
                    // Такие и подобные ошибки не считаем удалением.
                    if (d && d.success && !d.cancelled) {
                        _dropFromLocalState(logId);
                        setTimeout(function(){
                            _refreshLogModal();
                            _refreshDayModalIfOpen();
                        }, 60);
                    }
                    return r;
                });
            } catch(e) {
                // Не смогли распарсить — на всякий случай обновим
                _dropFromLocalState(logId);
                setTimeout(function(){ _refreshLogModal(); }, 60);
                return r;
            }
        });
    };
}

// === Кнопка «Удалить» в блоке «Уже заведено» логмодалки —
//     безопасная страховка на случай, если fetch-хук не сработает
(function _localDeleteHook(){
    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        var btn = e.target.closest('#logModal #logDayExisting .dict-action-btn.danger');
        if (!btn) return;
        var row = btn.closest('[data-id]');
        if (!row) return;
        var logId = parseInt(row.getAttribute('data-id'), 10);
        if (!logId) return;
        // Не блокируем основной обработчик — просто планируем обновление
        setTimeout(function(){
            _dropFromLocalState(logId);
            _refreshLogModal();
            _refreshDayModalIfOpen();
        }, 800);
    }, true);
})();

window.__trkRefreshLogModal = _refreshLogModal;
})();


/* ============================================================
   PATCH v1.0.6 — кастомный выпадающий список задач.
   position:fixed + рендер в body; минимум 220px высоты;
   расширенный нечёткий поиск; счётчик в шапке.
   ============================================================ */
(function(){
'use strict';
if (window.__trkLogTaskDropdownV106) return;
window.__trkLogTaskDropdownV106 = true;

var _activeIdx = -1;
var _items = [];
var _total = 0;
var _open = false;
var _dropdownEl = null;
var _query = '';

function _esc(s){
    return String(s==null?'':s).replace(/[&<>"']/g,function(c){
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}

function _getInput(){ return document.getElementById('log_task_input'); }
function _getHidden(){ return document.getElementById('log_task'); }

function _ensureDropdown(){
    if (_dropdownEl && document.body.contains(_dropdownEl)) return _dropdownEl;
    var el = document.getElementById('log_task_dropdown');
    if (el && el.parentNode !== document.body) {
        document.body.appendChild(el);
    }
    if (!el) {
        el = document.createElement('div');
        el.id = 'log_task_dropdown';
        el.className = 'log-task-dropdown';
        el.setAttribute('hidden', '');
        document.body.appendChild(el);
    }
    _dropdownEl = el;
    return el;
}

function _positionDropdown(){
    var inp = _getInput();
    var drop = _ensureDropdown();
    if (!inp || !drop) return;
    var r = inp.getBoundingClientRect();
    var vw = window.innerWidth;
    var vh = window.innerHeight;
    var width = Math.max(300, r.width);
    var left = r.left;
    if (left + width > vw - 8) left = Math.max(8, vw - width - 8);

    var spaceBelow = vh - r.bottom - 8;
    var spaceAbove = r.top - 8;
    var MIN_H = 220;
    var PREF_H = 420;
    var maxH;
    var placeBelow;
    if (spaceBelow >= Math.min(PREF_H, MIN_H)) {
        placeBelow = true;
        maxH = Math.min(PREF_H, spaceBelow);
    } else if (spaceAbove >= Math.min(PREF_H, MIN_H)) {
        placeBelow = false;
        maxH = Math.min(PREF_H, spaceAbove);
    } else {
        // ни снизу, ни сверху нормально — берём ту сторону, где больше
        placeBelow = spaceBelow >= spaceAbove;
        maxH = Math.max(MIN_H, Math.max(spaceBelow, spaceAbove));
        // всё равно ограничим, чтобы не вылезти за экран полностью
        if (placeBelow) maxH = Math.min(maxH, vh - r.bottom - 8);
        else maxH = Math.min(maxH, r.top - 8);
        if (maxH < MIN_H) maxH = MIN_H;
    }

    drop.style.left = left + 'px';
    drop.style.width = width + 'px';
    drop.style.maxHeight = maxH + 'px';
    if (placeBelow) {
        drop.style.top = (r.bottom + 4) + 'px';
        drop.style.bottom = 'auto';
    } else {
        drop.style.top = 'auto';
        drop.style.bottom = (vh - r.top + 4) + 'px';
    }
}

function _isSelectable(t){
    if (!t || !t.id) return false;
    var st = t.status || 'active';
    return st === 'active' || st === 'paused';
}

// Нормализация текста: ё→е, убрать пунктуацию (кроме дефиса), схлопнуть пробелы
function _norm(s){
    return String(s == null ? '' : s)
        .toLowerCase()
        .replace(/ё/g, 'е')
        .replace(/[^\wа-я\s-]/gi, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}

// Расширенный поиск: 0 — самое релевантное, 999 — не подходит
function _rank(t, q){
    if (!q) return 0;
    var qn = _norm(q);
    if (!qn) return 0;
    var name = _norm(t.name || '');
    var desc = _norm(t.description || '');
    var tags = _norm((t.tags || []).join(' '));
    var folder = _norm(t.folder || '');
    var hay = name + ' \u0001 ' + desc + ' \u0001 ' + tags + ' \u0001 ' + folder;

    // 0 — точное совпадение всего запроса
    if (name === qn) return 0;
    // 1 — имя начинается с запроса
    if (name.indexOf(qn) === 0) return 1;
    // 2 — имя содержит запрос
    if (name.indexOf(qn) !== -1) return 2;
    // 3 — тег содержит запрос
    if (tags.indexOf(qn) !== -1) return 3;
    // 4 — описание содержит запрос
    if (desc.indexOf(qn) !== -1) return 4;

    // Разбиваем запрос на слова. Отдельно — слова >1 символа, для надёжности
    var words = qn.split(/\s+/).filter(function(w){ return w.length >= 2; });
    if (!words.length) words = qn.split(/\s+/).filter(Boolean);
    if (!words.length) return 999;

    // 5 — все слова встречаются как подстрока в любом месте haystack
    var allIn = words.every(function(w){ return hay.indexOf(w) !== -1; });
    if (allIn) return 5;

    // 6 — все слова встречаются как начало слова (word-start) в name или tags
    var nameWords = name.split(/[\s-]+/).filter(Boolean);
    var tagsWords = tags.split(/[\s-]+/).filter(Boolean);
    var wStart = function(ws){ return function(w){
        for (var i = 0; i < ws.length; i++) {
            if (ws[i] === w) return true;
            if (ws[i].indexOf(w) === 0) return true;
        }
        return false;
    }; };
    var nameStart = wStart(nameWords);
    var tagsStart = wStart(tagsWords);
    var allName = words.every(nameStart);
    if (allName) return 6;
    var allNameOrTags = words.every(function(w){ return nameStart(w) || tagsStart(w); });
    if (allNameOrTags) return 7;

    // 7 — большинство слов совпадают (≥ 60%)
    var hits = 0;
    for (var i = 0; i < words.length; i++) {
        if (name.indexOf(words[i]) !== -1 || tags.indexOf(words[i]) !== -1
            || desc.indexOf(words[i]) !== -1 || folder.indexOf(words[i]) !== -1) {
            hits++;
        }
    }
    if (hits >= Math.ceil(words.length * 0.6)) return 8;

    return 999;
}

function _buildList(){
    var st = window.__trkState || {};
    var tasks = Array.isArray(st.tasks) ? st.tasks.slice() : [];
    var inp = _getInput();
    var q = inp ? (inp.value || '').trim() : '';
    _query = q;

    var pool = tasks.filter(_isSelectable);
    var matched = [];
    if (!q) {
        matched = pool.slice();
    } else {
        for (var i = 0; i < pool.length; i++) {
            var r = _rank(pool[i], q);
            if (r !== 999) matched.push({ t: pool[i], r: r });
        }
        matched.sort(function(a, b){
            if (a.r !== b.r) return a.r - b.r;
            var ad = a.t.deadline || '9999-99-99';
            var bd = b.t.deadline || '9999-99-99';
            if (ad !== bd) return ad < bd ? -1 : 1;
            return String(a.t.name || '').toLowerCase().localeCompare(String(b.t.name || '').toLowerCase(), 'ru');
        });
        matched = matched.map(function(x){ return x.t; });
    }

    // Если запрос пустой — сортируем по имени
    if (!q) {
        matched.sort(function(a, b){
            var ad = a.deadline || '9999-99-99';
            var bd = b.deadline || '9999-99-99';
            if (ad !== bd) return ad < bd ? -1 : 1;
            return String(a.name || '').toLowerCase().localeCompare(String(b.name || '').toLowerCase(), 'ru');
        });
    }

    _total = matched.length;
    _items = matched.slice(0, 500);
    _activeIdx = _items.length ? 0 : -1;
}

function _renderList(){
    var drop = _ensureDropdown();
    if (!drop) return;

    var st = window.__trkState || {};
    var totalActive = (st.tasks || []).filter(_isSelectable).length;

    // Шапка-счётчик
    var header = '';
    if (_query && _items.length) {
        header = '<div class="ltd-head">Найдено: <b>' + _items.length + '</b> из ' + totalActive + ' активных</div>';
    } else if (_query && !_items.length && totalActive > 0) {
        header = '<div class="ltd-head">Ничего не найдено (всего активных: ' + totalActive + ')</div>';
    } else if (!_query && _items.length) {
        header = '<div class="ltd-head">Активных задач: <b>' + _items.length + '</b></div>';
    }

    if (!_items.length) {
        var msg = totalActive === 0
            ? 'Нет активных задач. Создайте новую кнопкой «➕ Новая задача».'
            : 'Ничего не найдено по запросу';
        drop.innerHTML = header + '<div class="ltd-empty">' + msg + '</div>';
        return;
    }

    var h = header;
    _items.forEach(function(t, idx){
        var active = idx === _activeIdx ? ' ltd-item--active' : '';
        var paused = (t.status === 'paused') ? ' ltd-item--paused' : '';
        var icon = t.icon || '📋';
        var name = t.name || '';
        var deadline = t.deadline ? ('⏰ ' + t.deadline) : '';
        var tags = (t.tags && t.tags.length) ? ('#' + t.tags.slice(0,3).join(' #')) : '';
        var meta = [deadline, tags].filter(Boolean).join(' · ');
        h += '<div class="ltd-item' + active + paused + '" data-idx="' + idx + '" data-tid="' + _esc(t.id) + '">'
          +    '<span class="ltd-ico">' + _esc(icon) + '</span>'
          +    '<div class="ltd-body">'
          +      '<div class="ltd-name">' + _esc(name) + '</div>'
          +      (meta ? '<div class="ltd-meta">' + _esc(meta) + '</div>' : '')
          +    '</div>'
          +    (t.status === 'paused' ? '<span class="ltd-badge">пауза</span>' : '')
          +  '</div>';
    });
    drop.innerHTML = h;
}

function _showDropdown(){
    var drop = _ensureDropdown();
    if (!drop) return;
    _open = true;
    drop.removeAttribute('hidden');
    drop.classList.add('ltd-open');
    _positionDropdown();
}
function _hideDropdown(){
    if (!_dropdownEl) return;
    _open = false;
    _dropdownEl.setAttribute('hidden', '');
    _dropdownEl.classList.remove('ltd-open');
    _activeIdx = -1;
}
function _refresh(){
    _buildList();
    _renderList();
    if (_open) {
        _positionDropdown();
        _scrollActiveIntoView();
    }
}
function _scrollActiveIntoView(){
    if (!_dropdownEl) return;
    var el = _dropdownEl.querySelector('.ltd-item--active');
    if (el && el.scrollIntoView) {
        try { el.scrollIntoView({ block: 'nearest' }); } catch(e) {}
    }
}

function _moveActive(delta){
    if (!_items.length) return;
    _activeIdx = (_activeIdx + delta + _items.length) % _items.length;
    _renderList();
    _scrollActiveIntoView();
}

function _chooseByIdx(idx){
    if (idx < 0 || idx >= _items.length) return;
    var t = _items[idx];
    if (!t) return;
    var inp = _getInput();
    var hidden = _getHidden();
    if (inp) inp.value = t.name || '';
    if (hidden) hidden.value = t.id || '';
    _hideDropdown();
    if (inp) {
        inp.dispatchEvent(new Event('input', {bubbles:true}));
        inp.dispatchEvent(new Event('change', {bubbles:true}));
    }
}

function _hookInput(){
    var inp = _getInput();
    if (!inp || inp._ltdHooked) return;
    inp._ltdHooked = true;

    inp.addEventListener('focus', function(){
        _refresh();
        _showDropdown();
    });
    inp.addEventListener('click', function(){
        if (!_open) { _refresh(); _showDropdown(); }
        else { _positionDropdown(); }
    });
    inp.addEventListener('input', function(){
        var hidden = _getHidden();
        if (hidden && hidden.value) {
            var st = window.__trkState || {};
            var t = (st.tasks || []).find(function(x){ return x.id === hidden.value; });
            if (!t || (t.name || '') !== inp.value) {
                hidden.value = '';
            }
        }
        _refresh();
        if (!_open) _showDropdown(); else _positionDropdown();
    });
    inp.addEventListener('keydown', function(e){
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            if (!_open) { _refresh(); _showDropdown(); }
            _moveActive(1);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            if (!_open) { _refresh(); _showDropdown(); }
            _moveActive(-1);
        } else if (e.key === 'Enter') {
            if (_open && _activeIdx >= 0 && _items.length) {
                e.preventDefault();
                e.stopPropagation();
                _chooseByIdx(_activeIdx);
            }
        } else if (e.key === 'Escape') {
            if (_open) {
                e.preventDefault();
                e.stopPropagation();
                _hideDropdown();
            }
        }
    });
    inp.addEventListener('blur', function(){
        setTimeout(function(){
            if (!_open) return;
            var drop = _dropdownEl;
            if (drop && drop.matches(':hover')) return;
            _hideDropdown();
        }, 150);
    });
}

document.addEventListener('mousedown', function(e){
    if (!e.target || !e.target.closest) return;
    var row = e.target.closest('#log_task_dropdown .ltd-item');
    if (!row) return;
    e.preventDefault();
    e.stopPropagation();
    var idx = parseInt(row.getAttribute('data-idx'), 10);
    if (isNaN(idx)) return;
    _chooseByIdx(idx);
}, true);

document.addEventListener('scroll', function(e){
    if (!_open) return;
    var body = e.target && e.target.classList && e.target.classList.contains('log-modal-body');
    var doc = e.target === document;
    if (body || doc) _hideDropdown();
}, true);

window.addEventListener('resize', function(){ if (_open) _positionDropdown(); });

(function _wrapLoadState(){
    if (typeof window.__trkLoadState !== 'function') return;
    if (window.__trkLoadState._ltdV106) return;
    var orig = window.__trkLoadState;
    var wrapped = function(){
        var r = orig.apply(this, arguments);
        try {
            if (r && typeof r.then === 'function') {
                r.then(function(){ if (_open) _refresh(); });
            }
        } catch(e) {}
        return r;
    };
    wrapped._ltdV106 = true;
    window.__trkLoadState = wrapped;
})();

(function _watchModal(){
    function _attach(){
        var m = document.getElementById('logModal');
        if (!m) return;
        _ensureDropdown();
        _hookInput();
        if (m._ltdV106Hooked) return;
        m._ltdV106Hooked = true;
        new MutationObserver(function(){
            if (m.classList.contains('active')) {
                _hookInput();
                setTimeout(function(){ _hideDropdown(); }, 20);
            } else {
                _hideDropdown();
            }
        }).observe(m, { attributes: true, attributeFilter: ['class'] });
    }
    _attach();
    setTimeout(_attach, 400);
    setTimeout(_attach, 1200);
})();

document.addEventListener('click', function(e){
    if (!e.target || !e.target.closest) return;
    if (e.target.closest('#logCreateTaskBtn')) _hideDropdown();
});

window.__trkLogTaskDropdown = {
    refresh: _refresh,
    show: _showDropdown,
    hide: _hideDropdown,
    position: _positionDropdown,
    list: function(){ return _items; },
    total: function(){ return _total; },
};
})();


/* ============================================================
   PATCH v1.0.7 — поле «Задача» пустое при открытии карточки отметки
   ============================================================ */
(function(){
'use strict';
if (window.__trkLogTaskEmptyOnOpenV107) return;
window.__trkLogTaskEmptyOnOpenV107 = true;

function _clearTaskFields(){
    var inp = document.getElementById('log_task_input');
    var hidden = document.getElementById('log_task');
    if (inp) inp.value = '';
    if (hidden) hidden.value = '';
    // Скрыть подсказки похожих задач (v1.1.4)
    try {
        var h = document.getElementById('logTaskHint');
        if (h) { h.setAttribute('hidden', ''); h.innerHTML = ''; }
    } catch(e) {}
    // Скрыть выпадающий список (v1.0.6)
    try {
        if (window.__trkLogTaskDropdown && typeof window.__trkLogTaskDropdown.hide === 'function') {
            window.__trkLogTaskDropdown.hide();
        }
    } catch(e) {}
    // Скрыть предупреждение
    var warn = document.getElementById('log_task_warn');
    if (warn) warn.style.display = 'none';
}

// Обёртка openLogModal — после её работы чистим поле задачи.
// Работает для любого вызова: и из «➕ Новая задача», и из dayModal, и из dayEntry.
(function _wrap(){
    var orig = window.__trkOpenLogModal;
    if (typeof orig !== 'function' || orig._v107) return;
    var w = function(){
        var r = orig.apply(this, arguments);
        // Чистим ТОЛЬКО если это создание новой отметки (нет entry или нет entry.id)
        try {
            var entry = arguments[0];
            var isEdit = !!(entry && entry.id);
            if (!isEdit) {
                // Небольшая задержка — после того как openLogModal из v1.1.4
                // подставит значение, мы перезапишем его пустым
                setTimeout(_clearTaskFields, 30);
                setTimeout(_clearTaskFields, 150);
            }
        } catch(e) {}
        return r;
    };
    w._v107 = true;
    window.__trkOpenLogModal = w;
})();

// Повторная попытка обернуть, если v1.1.4 ещё не подгрузился
setTimeout(function(){
    var o = window.__trkOpenLogModal;
    if (typeof o === 'function' && !o._v107) {
        var w = function(){
            var r = o.apply(this, arguments);
            try {
                var entry = arguments[0];
                var isEdit = !!(entry && entry.id);
                if (!isEdit) {
                    setTimeout(_clearTaskFields, 30);
                    setTimeout(_clearTaskFields, 150);
                }
            } catch(e) {}
            return r;
        };
        w._v107 = true;
        window.__trkOpenLogModal = w;
    }
}, 800);
setTimeout(function(){
    var o = window.__trkOpenLogModal;
    if (typeof o === 'function' && !o._v107) {
        var w = function(){
            var r = o.apply(this, arguments);
            try {
                var entry = arguments[0];
                var isEdit = !!(entry && entry.id);
                if (!isEdit) {
                    setTimeout(_clearTaskFields, 30);
                    setTimeout(_clearTaskFields, 150);
                }
            } catch(e) {}
            return r;
        };
        w._v107 = true;
        window.__trkOpenLogModal = w;
    }
}, 2000);

// Страховка на клик по кнопке «Добавить отметку» — на случай,
// если openLogModal был переопределён позже нас
(function _observeModal(){
    function _attach(){
        var m = document.getElementById('logModal');
        if (!m || m._ltdEmptyV107) return;
        m._ltdEmptyV107 = true;
        var prev = m.classList.contains('active');
        new MutationObserver(function(){
            var isActive = m.classList.contains('active');
            if (isActive && !prev) {
                // только что открылась
                var idField = document.getElementById('log_id');
                var isEdit = !!(idField && idField.value);
                if (!isEdit) {
                    setTimeout(_clearTaskFields, 30);
                    setTimeout(_clearTaskFields, 150);
                }
            }
            prev = isActive;
        }).observe(m, { attributes: true, attributeFilter: ['class'] });
    }
    _attach();
    setTimeout(_attach, 600);
    setTimeout(_attach, 1600);
})();

// Кнопка «Добавить отметку» и редактирование — тоже пробьём вручную
// (на случай, если модалка уже открыта к моменту загрузки скрипта)
document.addEventListener('click', function(e){
    if (!e.target || !e.target.closest) return;
    if (e.target.closest('#dayAddBtn')) {
        setTimeout(function(){
            var idField = document.getElementById('log_id');
            if (idField && !idField.value) _clearTaskFields();
        }, 200);
        setTimeout(function(){
            var idField = document.getElementById('log_id');
            if (idField && !idField.value) _clearTaskFields();
        }, 500);
    }
}, true);

window.__trkClearLogTask = _clearTaskFields;
})();


/* ============================================================
   PATCH v1.0.8 — карточка задачи из отметки (объединённый)
   * Динамическая кнопка «✏️ Редактировать задачу»
   * taskModal помечается «из отметки»
   * Полное заполнение полей задачи (включая orders/links/extra
     через /api/tracker/task/card, если в state.tasks их нет)
   * Кликабельные названия задач в блоке «Уже заведено за этот день»
   * Кликабельные названия задач в блоке «Назначено, но не заведено»
   ============================================================ */
(function(){
'use strict';
if (window.__trkLogTaskEditFromLogV108) return;
window.__trkLogTaskEditFromLogV108 = true;

var _savedState = null;

function _esc(s){
    return String(s==null?'':s).replace(/[&<>"']/g,function(c){
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}
function _g(id){ var el = document.getElementById(id); return el ? el.value : ''; }
function _s(id, v){ var el = document.getElementById(id); if (el) el.value = (v == null ? '' : v); }

function _getHiddenTaskId(){
    var h = document.getElementById('log_task');
    return h ? (h.value || '') : '';
}
function _findTask(id){
    if (!id) return null;
    var st = window.__trkState || {};
    return (st.tasks || []).find(function(x){ return x.id === id; }) || null;
}
function _captureLogState(){
    return {
        task_id: _g('log_task'),
        task_input: _g('log_task_input'),
    };
}
function _isLogModalActive(){
    var lm = document.getElementById('logModal');
    return !!(lm && lm.classList.contains('active'));
}

/* ==========================================================
   Динамическая кнопка «➕ Новая задача» / «✏️ Редактировать»
   ========================================================== */
function _updateLogBtn(){
    var btn = document.getElementById('logCreateTaskBtn');
    if (!btn) return;
    var tid = _getHiddenTaskId();
    if (tid) {
        if ((btn.textContent || '').trim() !== '✏️ Редактировать задачу') {
            btn.textContent = '✏️ Редактировать задачу';
        }
        btn.title = 'Открыть карточку выбранной задачи';
        btn.classList.add('log-create-task-btn--edit');
    } else {
        if ((btn.textContent || '').trim() !== '➕ Новая задача') {
            btn.textContent = '➕ Новая задача';
        }
        btn.title = 'Создать новую задачу';
        btn.classList.remove('log-create-task-btn--edit');
    }
}
window.__trkUpdateLogTaskBtn = _updateLogBtn;

/* ==========================================================
   Полное заполнение формы задачи из task-объекта
   ========================================================== */
function _forceTagDraft(tags){
    tags = Array.isArray(tags) ? tags.slice() : [];
    var box = document.getElementById('taskTagsBox');
    if (!box) return;
    box.querySelectorAll('.tag-pill').forEach(function(p){ p.remove(); });
    var input = document.getElementById('task_tags_input');
    tags.forEach(function(tag, i){
        var pill = document.createElement('span');
        pill.className = 'tag-pill';
        pill.innerHTML = '#' + _esc(tag) + '<button type="button" class="tag-x" data-i="' + i + '">×</button>';
        if (input && input.parentNode === box) box.insertBefore(pill, input);
        else box.appendChild(pill);
    });
    box.querySelectorAll('.tag-x').forEach(function(b){
        b.addEventListener('click', function(){
            var idx = parseInt(this.getAttribute('data-i'), 10);
            var cur = (window.__trkCurrentTaskTags || tags).slice();
            cur.splice(idx, 1);
            window.__trkCurrentTaskTags = cur;
            _forceTagDraft(cur);
        });
    });
    window.__trkCurrentTaskTags = tags;
}

function _setCheckboxGroup(containerId, ids){
    var box = document.getElementById(containerId);
    if (!box) return;
    var set = {};
    (ids || []).forEach(function(x){ set[x] = true; });
    box.querySelectorAll('input[type="checkbox"]').forEach(function(cb){
        cb.checked = !!set[cb.value];
    });
}

function _renderOrders(items){
    var box = document.getElementById('taskOrdersList');
    if (!box) return;
    items = Array.isArray(items) ? items : [];
    if (!items.length) {
        box.innerHTML = '<div class="task-links-empty">Пока нет распоряжений</div>';
        return;
    }
    var h = '';
    items.forEach(function(o, i){
        var desc = (o && o.description) || '';
        var val = (o && o.value) || '';
        var added = (o && o.added_by) ? (o.added_by + ((o.added_at)? ' · '+o.added_at : '')) : '';
        h += '<div class="task-link-row" data-i="' + i + '" data-v108-owned="1">'
          +   '<input type="text" class="task-order-desc" value="' + _esc(desc) + '" placeholder="Описание">'
          +   '<input type="text" class="task-order-val" value="' + _esc(val) + '" placeholder="Номер / путь">'
          +   '<button type="button" class="task-link-del" title="Удалить">×</button>'
          +   (added ? '<div class="task-link-added-by">✍️ ' + _esc(added) + '</div>' : '')
          + '</div>';
    });
    box.innerHTML = h;
    box.querySelectorAll('.task-link-row').forEach(function(row){
        var i = parseInt(row.getAttribute('data-i'), 10);
        var d = row.querySelector('.task-order-desc');
        var v = row.querySelector('.task-order-val');
        if (d) d.addEventListener('input', function(){ if (window._taskOrdersDraft && window._taskOrdersDraft[i]) window._taskOrdersDraft[i].description = this.value; });
        if (v) v.addEventListener('input', function(){ if (window._taskOrdersDraft && window._taskOrdersDraft[i]) window._taskOrdersDraft[i].value = this.value; });
        var xb = row.querySelector('.task-link-del');
        if (xb) xb.addEventListener('click', function(){
            if (Array.isArray(window._taskOrdersDraft)) window._taskOrdersDraft.splice(i, 1);
            _renderOrders(window._taskOrdersDraft || []);
        });
    });
}

function _renderLinks(items){
    var box = document.getElementById('taskLinksList');
    if (!box) return;
    items = Array.isArray(items) ? items : [];
    if (!items.length) {
        box.innerHTML = '<div class="task-links-empty">Пока нет ссылок</div>';
        return;
    }
    var h = '';
    items.forEach(function(l, i){
        var desc = (l && l.description) || '';
        var u = (l && l.url) || '';
        var added = (l && l.added_by) ? (l.added_by + ((l.added_at)? ' · '+l.added_at : '')) : '';
        h += '<div class="task-link-row" data-i="' + i + '" data-v108-owned="1">'
          +   '<input type="text" class="task-link-desc" value="' + _esc(desc) + '" placeholder="Описание">'
          +   '<input type="text" class="task-link-url" value="' + _esc(u) + '" placeholder="https://… или \\\\server\\share">'
          +   '<button type="button" class="task-link-del" title="Удалить">×</button>'
          +   (added ? '<div class="task-link-added-by">✍️ ' + _esc(added) + '</div>' : '')
          + '</div>';
    });
    box.innerHTML = h;
    box.querySelectorAll('.task-link-row').forEach(function(row){
        var i = parseInt(row.getAttribute('data-i'), 10);
        var d = row.querySelector('.task-link-desc');
        var u = row.querySelector('.task-link-url');
        if (d) d.addEventListener('input', function(){ if (window._taskLinksDraft && window._taskLinksDraft[i]) window._taskLinksDraft[i].description = this.value; });
        if (u) u.addEventListener('input', function(){ if (window._taskLinksDraft && window._taskLinksDraft[i]) window._taskLinksDraft[i].url = this.value; });
        var xb = row.querySelector('.task-link-del');
        if (xb) xb.addEventListener('click', function(){
            if (Array.isArray(window._taskLinksDraft)) window._taskLinksDraft.splice(i, 1);
            _renderLinks(window._taskLinksDraft || []);
        });
    });
}

function _fillTaskModal(task){
    if (!task) return;

    _s('task_id', task.id || '');
    _s('task_name', task.name || '');
    var icon = task.icon || '🚀';
    _s('task_icon', icon);
    var prev = document.getElementById('taskIconPreview');
    if (prev) prev.textContent = icon;
    _s('task_description', task.description || '');
    _s('task_folder', task.folder || '');
    _s('task_status', task.status || 'active');
    _s('task_start_date', task.start_date || '');
    _s('task_deadline', task.deadline || '');
    _s('task_completed_at', task.completed_at || '');
    var urg = document.getElementById('task_is_urgent');
    if (urg) urg.checked = !!task.is_urgent;

    _forceTagDraft(task.tags || []);

    _setCheckboxGroup('taskDepartmentsList', task.department_ids || []);
    _setCheckboxGroup('taskAssigneesList', task.assignees || []);

    window._taskOrdersDraft = (task.orders || []).slice();
    _renderOrders(window._taskOrdersDraft);

    window._taskLinksDraft = (task.links || []).slice();
    _renderLinks(window._taskLinksDraft);
}
window.__trkFillTaskModalAll = _fillTaskModal;

function _ensureFullTask(task){
    if (!task || !task.id) return Promise.resolve(task);
    var hasOrders = Array.isArray(task.orders) && task.orders.length;
    var hasLinks = Array.isArray(task.links) && task.links.length;
    var hasExtraMeta = Array.isArray(task.extra_meta) && task.extra_meta.length;
    if (hasOrders && hasLinks && hasExtraMeta) return Promise.resolve(task);
    if (task._fullFetched) return Promise.resolve(task);
    task._fullFetched = true;
    var from = (document.getElementById('sumDateFrom') || {}).value || '';
    var to = (document.getElementById('sumDateTo') || {}).value || '';
    if (!from || !to) {
        var d = new Date();
        var y = d.getFullYear(), m = d.getMonth() + 1;
        var pad = function(n){ return n < 10 ? '0'+n : ''+n; };
        from = y + '-' + pad(m) + '-01';
        to   = y + '-' + pad(m) + '-' + pad(new Date(y, m, 0).getDate());
    }
    var url = '/api/tracker/task/card?task=' + encodeURIComponent(task.id)
            + '&from=' + encodeURIComponent(from) + '&to=' + encodeURIComponent(to);
    var hdrs = {};
    if (window.REESTR_CSRF) hdrs['X-CSRF-Token'] = window.REESTR_CSRF;
    return fetch(url, {credentials: 'same-origin', headers: hdrs})
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (d && d.success && d.task) {
                var ft = d.task;
                if (!Array.isArray(task.orders) || !task.orders.length) task.orders = ft.orders || [];
                if (!Array.isArray(task.links) || !task.links.length) task.links = ft.links || [];
                if (!task.folder && ft.folder) task.folder = ft.folder;
                if (!task.extra_meta && ft.extra_meta) task.extra_meta = ft.extra_meta;
                // Доп.данные могут прийти строками через task.folder
                if (ft.extra && Array.isArray(ft.extra) && ft.extra.length && !task.folder) {
                    task.folder = ft.extra.map(function(x){ return x.line || x; }).join('\n');
                }
            }
            return task;
        })
        .catch(function(){ return task; });
}

/* ==========================================================
   Обёртка openTaskModal
   ========================================================== */
(function _wrapOpenTaskModal(){
    var orig = window.__trkOpenTaskModal;
    if (typeof orig !== 'function' || orig._v108w) return;
    var w = function(t){
        var isFromLog = false;
        if (!t) {
            var tid = _getHiddenTaskId();
            if (tid) {
                var task = _findTask(tid);
                if (task) { t = task; isFromLog = true; }
            }
        } else if (_isLogModalActive()) {
            isFromLog = true;
        }
        if (isFromLog) {
            _savedState = _captureLogState();
            _markTaskModalFromLog();
            setTimeout(function(){
                var lm = document.getElementById('logModal');
                if (lm && !lm.classList.contains('active')) lm.classList.add('active');
            }, 30);
        }
        var r = orig.call(this, t);
        if (t && t.id) {
            var _fillAll = function(){
                _ensureFullTask(t).then(function(ft){
                    _fillTaskModal(ft);
                    var idField = document.getElementById('task_id');
                    if (idField && !idField.value) idField.value = t.id;
                });
            };
            setTimeout(_fillAll, 30);
            setTimeout(_fillAll, 150);
            setTimeout(_fillAll, 450);
            setTimeout(_fillAll, 900);
        }
        return r;
    };
    w._v108w = true;
    window.__trkOpenTaskModal = w;
})();
setTimeout(function(){
    var o = window.__trkOpenTaskModal;
    if (typeof o === 'function' && !o._v108w) {
        var w = function(t){
            var isFromLog = false;
            if (!t) {
                var tid = _getHiddenTaskId();
                if (tid) { var task = _findTask(tid); if (task){ t = task; isFromLog = true; } }
            } else if (_isLogModalActive()) isFromLog = true;
            if (isFromLog) {
                _savedState = _captureLogState();
                _markTaskModalFromLog();
                setTimeout(function(){
                    var lm = document.getElementById('logModal');
                    if (lm && !lm.classList.contains('active')) lm.classList.add('active');
                }, 30);
            }
            var r = o.call(this, t);
            if (t && t.id) {
                var _fillAll = function(){ _ensureFullTask(t).then(function(ft){ _fillTaskModal(ft); }); };
                setTimeout(_fillAll, 30);
                setTimeout(_fillAll, 200);
                setTimeout(_fillAll, 600);
            }
            return r;
        };
        w._v108w = true;
        window.__trkOpenTaskModal = w;
    }
}, 800);

/* ==========================================================
   Обёртка openLogModal (восстанавливаем поля после v1.0.7)
   ========================================================== */
(function _wrapOpenLogModal(){
    var orig = window.__trkOpenLogModal;
    if (typeof orig !== 'function' || orig._v108l) return;
    var w = function(entry){
        var r = orig.apply(this, arguments);
        var tid = entry && (entry.task_id || entry.taskId);
        if (tid) {
            setTimeout(function(){
                var inp = document.getElementById('log_task_input');
                var hid = document.getElementById('log_task');
                var t = _findTask(tid);
                if (t) {
                    var nm = t.name || '';
                    if (t.status === 'done' || t.status === 'archived') nm += ' (архив)';
                    if (inp) inp.value = nm;
                    if (hid) hid.value = t.id;
                } else if (hid) hid.value = tid;
                _updateLogBtn();
            }, 250);
            setTimeout(_updateLogBtn, 600);
        }
        return r;
    };
    w._v108l = true;
    window.__trkOpenLogModal = w;
})();

/* ==========================================================
   Маркер taskModal
   ========================================================== */
function _addBadge(){
    var tm = document.getElementById('taskModal');
    if (!tm || !tm.classList.contains('task-modal-from-log')) return;
    var h2 = tm.querySelector('.modal-content > h2');
    if (!h2) return;
    if (h2.querySelector('.task-modal-from-log-badge')) return;
    var b = document.createElement('span');
    b.className = 'task-modal-from-log-badge';
    b.textContent = 'из отметки';
    h2.appendChild(b);
}
function _markTaskModalFromLog(){
    var tm = document.getElementById('taskModal');
    if (!tm) return;
    tm.classList.add('task-modal-from-log');
    setTimeout(_addBadge, 30);
    setTimeout(_addBadge, 150);
    setTimeout(_addBadge, 400);
}
function _unmarkTaskModal(){
    var tm = document.getElementById('taskModal');
    if (!tm) return;
    tm.classList.remove('task-modal-from-log');
    var b = tm.querySelector('.task-modal-from-log-badge');
    if (b) b.remove();
}

/* ==========================================================
   Наблюдение за закрытием taskModal
   ========================================================== */
(function _watchClose(){
    function _attach(){
        var tm = document.getElementById('taskModal');
        if (!tm || tm._v108Close) return;
        tm._v108Close = true;
        var wasActive = tm.classList.contains('active');
        new MutationObserver(function(){
            var isActive = tm.classList.contains('active');
            if (wasActive && !isActive) {
                var wasFromLog = tm.classList.contains('task-modal-from-log');
                _unmarkTaskModal();
                if (wasFromLog && _savedState) {
                    var s = _savedState;
                    _savedState = null;
                    setTimeout(function(){ _restoreLogTask(s); }, 100);
                    setTimeout(function(){ _restoreLogTask(s); }, 350);
                    setTimeout(function(){ _restoreLogTask(s); }, 800);
                }
            }
            wasActive = isActive;
        }).observe(tm, { attributes: true, attributeFilter: ['class'] });
    }
    _attach();
    setTimeout(_attach, 600);
    setTimeout(_attach, 1500);
})();

function _restoreLogTask(s){
    if (!s) return;
    var lm = document.getElementById('logModal');
    if (lm && !lm.classList.contains('active')) lm.classList.add('active');
    var inp = document.getElementById('log_task_input');
    var hid = document.getElementById('log_task');
    var t = _findTask(s.task_id);
    var nm = s.task_input;
    if (t) {
        nm = t.name || '';
        if (t.status === 'done' || t.status === 'archived') nm += ' (архив)';
    }
    if (inp) inp.value = nm || '';
    if (hid) hid.value = s.task_id || '';
    _updateLogBtn();
}

/* ==========================================================
   Кликабельные названия задач
   ========================================================== */
function _openTaskCard(taskId){
    if (!taskId) return;
    var task = _findTask(taskId);
    if (!task) return;
    if (typeof window.__trkOpenTaskModal === 'function') {
        window.__trkOpenTaskModal(task);
    }
}

// «Уже заведено за этот день»
function _decorateDayExisting(){
    var list = document.getElementById('logDayExistingList');
    if (!list) return;
    list.querySelectorAll('.day-entry').forEach(function(entryEl){
        var taskEl = entryEl.querySelector('.day-entry-task');
        if (!taskEl || taskEl._v108Deco) return;
        taskEl._v108Deco = true;
        taskEl.classList.add('clickable');
        taskEl.title = 'Открыть карточку задачи';
        if (!taskEl.querySelector('.task-title-open')) {
            var ic = document.createElement('span');
            ic.className = 'task-title-open';
            ic.textContent = '↗';
            taskEl.appendChild(ic);
        }
    });
}
(function _observeDayExisting(){
    function _attach(){
        var list = document.getElementById('logDayExistingList');
        if (!list || list._v108DecoObs) return;
        list._v108DecoObs = true;
        new MutationObserver(function(){ setTimeout(_decorateDayExisting, 40); })
            .observe(list, { childList: true, subtree: true });
        _decorateDayExisting();
    }
    _attach();
    setTimeout(_attach, 500);
    setTimeout(_attach, 1500);
})();

document.addEventListener('click', function(e){
    if (!e.target || !e.target.closest) return;
    var taskEl = e.target.closest('#logDayExistingList .day-entry-task.clickable');
    if (!taskEl) return;
    if (e.target.closest('button')) return;
    var entryEl = taskEl.closest('.day-entry');
    if (!entryEl) return;
    var logId = entryEl.getAttribute('data-id');
    if (!logId) return;
    var st = window.__trkState || {};
    var logRec = (st.log || []).find(function(l){ return String(l.id) === String(logId); });
    var taskId = logRec ? logRec.task_id : '';
    if (!taskId && st.calendar && st.calendar.days) {
        for (var i = 0; i < st.calendar.days.length; i++) {
            var day = st.calendar.days[i];
            if (!day.entries) continue;
            var found = day.entries.find(function(en){ return String(en.id) === String(logId); });
            if (found) { taskId = found.task_id; break; }
        }
    }
    if (!taskId) return;
    e.preventDefault();
    e.stopPropagation();
    if (e.stopImmediatePropagation) e.stopImmediatePropagation();
    _openTaskCard(taskId);
}, true);

// «Назначено, но не заведено»
(function _decorateLabTileNames(){
    function _mark(){
        var tiles = document.querySelectorAll('#logModal .log-assigned-block .lab-tile');
        tiles.forEach(function(tile){
            var nm = tile.querySelector('.lab-name');
            if (!nm || nm._v108Clickable) return;
            nm._v108Clickable = true;
            nm.style.cursor = 'pointer';
            nm.title = 'Открыть карточку задачи';
        });
    }
    function _attach(){
        var lm = document.getElementById('logModal');
        if (!lm || lm._v108LabTileObs) return;
        lm._v108LabTileObs = true;
        new MutationObserver(function(){ setTimeout(_mark, 40); })
            .observe(lm, { childList: true, subtree: true });
        _mark();
    }
    _attach();
    setTimeout(_attach, 700);
    setTimeout(_attach, 1800);
})();

document.addEventListener('click', function(e){
    if (!e.target || !e.target.closest) return;
    var nm = e.target.closest('#logModal .log-assigned-block .lab-tile .lab-name');
    if (!nm) return;
    if (e.target.closest('.lab-add')) return;
    var tile = nm.closest('.lab-tile');
    if (!tile) return;
    var tid = tile.getAttribute('data-task-id');
    if (!tid) return;
    e.preventDefault();
    e.stopPropagation();
    if (e.stopImmediatePropagation) e.stopImmediatePropagation();
    _openTaskCard(tid);
}, true);

/* ==========================================================
   Кнопка #logCreateTaskBtn — динамика
   ========================================================== */
(function _hookInput(){
    function _attach(){
        var inp = document.getElementById('log_task_input');
        if (inp && !inp._v108Hook) {
            inp._v108Hook = true;
            inp.addEventListener('input', _updateLogBtn);
            inp.addEventListener('change', _updateLogBtn);
        }
    }
    _attach();
    setTimeout(_attach, 400);
    setTimeout(_attach, 1200);
})();

document.addEventListener('mousedown', function(e){
    if (!e.target || !e.target.closest) return;
    if (e.target.closest('#log_task_dropdown .ltd-item')) {
        setTimeout(_updateLogBtn, 50);
        setTimeout(_updateLogBtn, 250);
    }
}, true);

(function _watchLogActive(){
    function _attach(){
        var lm = document.getElementById('logModal');
        if (!lm || lm._v108BtnWatch) return;
        lm._v108BtnWatch = true;
        new MutationObserver(function(){
            if (lm.classList.contains('active')) {
                setTimeout(_updateLogBtn, 50);
                setTimeout(_updateLogBtn, 250);
                setTimeout(_updateLogBtn, 600);
                setTimeout(_decorateDayExisting, 120);
                setTimeout(_decorateDayExisting, 350);
            }
        }).observe(lm, { attributes: true, attributeFilter: ['class'] });
    }
    _attach();
    setTimeout(_attach, 500);
    setTimeout(_attach, 1500);
})();

window.__trkLogTaskEditFromLog = {
    updateButton: _updateLogBtn,
    restore: _restoreLogTask,
    fill: _fillTaskModal,
};
})();


/* ============================================================
   PATCH v1.0.10 — авто-добавление сотрудника в исполнители задачи
   ============================================================ */
(function(){
'use strict';
if (window.__trkAutoAssignV1010) return;
window.__trkAutoAssignV1010 = true;

function _notify(msg, kind){
    if (typeof window.__trackerNotify === 'function') {
        try { window.__trackerNotify(msg, kind); return; } catch (e) {}
    }
}

function _getTaskFromState(taskId){
    var st = window.__trkState || {};
    return (st.tasks || []).find(function(t){ return t.id === taskId; }) || null;
}

function _buildTaskSavePayload(task, newAssignees){
    // Собираем полный payload из task-объекта — как это делает openTaskModal → saveTask
    return {
        id: task.id,
        name: task.name || '',
        icon: task.icon || '📋',
        description: task.description || '',
        status: task.status || 'active',
        start_date: task.start_date || '',
        deadline: task.deadline || '',
        completed_at: task.completed_at || '',
        folder: task.folder || '',
        order_ref: task.order_ref || '',
        tags: (task.tags || []).slice(),
        assignees: newAssignees,
        department_ids: (task.department_ids || []).slice(),
        is_urgent: !!task.is_urgent,
        links: (task.links || []).slice(),
        orders: (task.orders || []).slice(),
    };
}

function _ensureAssignee(taskId, employeeId){
    if (!taskId || !employeeId) return Promise.resolve(false);
    var task = _getTaskFromState(taskId);
    if (!task) return Promise.resolve(false);
    var current = Array.isArray(task.assignees) ? task.assignees.slice() : [];
    if (current.indexOf(employeeId) !== -1) {
        return Promise.resolve(false); // уже назначен
    }
    current.push(employeeId);
    var payload = _buildTaskSavePayload(task, current);
    var hdrs = {'Content-Type': 'application/json'};
    if (window.REESTR_CSRF) hdrs['X-CSRF-Token'] = window.REESTR_CSRF;
    return fetch('/api/tracker/task/save', {
        method: 'POST',
        headers: hdrs,
        credentials: 'same-origin',
        body: JSON.stringify(payload)
    })
    .then(function(r){
        return r.json().then(function(j){ return { ok: r.ok, d: j }; });
    })
    .then(function(res){
        if (!res.ok || !res.d || !res.d.success) {
            var err = (res.d && res.d.error) || 'Ошибка';
            console.warn('[auto-assign] task/save failed:', err);
            return false;
        }
        // Локально обновляем state, чтобы UI подхватил
        try {
            task.assignees = current;
        } catch (e) {}
        return true;
    })
    .catch(function(err){
        console.warn('[auto-assign] fetch error:', err);
        return false;
    });
}

// === Перехват fetch для /api/tracker/log/save ===
var _native = window.fetch;
if (typeof _native === 'function' && !window.__trkAutoAssignFetch) {
    window.__trkAutoAssignFetch = true;
    window.fetch = function(url, opts){
        var isLogSave = (typeof url === 'string' && url.indexOf('/api/tracker/log/save') !== -1);
        var isPost = opts && (opts.method || 'GET').toUpperCase() === 'POST';
        if (!isLogSave || !isPost) {
            return _native.apply(this, arguments);
        }

        var employeeId = '';
        var taskId = '';
        try {
            var b = JSON.parse(opts.body || '{}');
            employeeId = b.employee_id || '';
            taskId = b.task_id || '';
        } catch (e) {}

        var self = this;
        var p = _native.apply(this, arguments);
        if (!employeeId || !taskId) return p;

        return p.then(function(r){
            if (!r || !r.ok) return r;
            // Проверяем успешность ответа, но НЕ блокируем — отправляем запрос на task/save всегда,
            // если log/save ответил OK
            try {
                return r.clone().json().then(function(d){
                    if (d && d.success) {
                        // Асинхронно, не мешая ответу
                        setTimeout(function(){
                            _ensureAssignee(taskId, employeeId).then(function(added){
                                if (added) {
                                    _notify('👥 Добавлен в исполнители задачи');
                                }
                            });
                        }, 50);
                    }
                    return r;
                }).catch(function(){
                    // Тело не JSON, но статус OK — всё равно попробуем
                    setTimeout(function(){
                        _ensureAssignee(taskId, employeeId).then(function(added){
                            if (added) _notify('👥 Добавлен в исполнители задачи');
                        });
                    }, 50);
                    return r;
                });
            } catch (e) {
                return r;
            }
        });
    };
}

// === Обёртка для кнопки «Добавить меня» в блоке «Назначено, но не заведено» ===
// PATCH 23 / v1.2.3 тоже пользуются log/save — их покрывает перехват fetch выше.
// Но на случай, если они вызывают задачу иначе — оставим страховку.

window.__trkAutoAssign = {
    ensure: _ensureAssignee,
};
})();


/* ============================================================
   PATCH v1.0.11 — блокировка модалки на время «Добавить меня»
   Работает и для карточки отметки (#logModal), и для дневной
   карточки (#dayModal). Кнопки-триггеры:
     * .lab-tile .lab-add         — блок «Назначено, но не заведено»
                                    (модалка отметки, PATCH v1.0.3)
     * .day-task-addme            — блок в дневной карточке (PATCH 23)
     * .dab-add                   — плитка «Назначено на день» (PATCH 23)
   ============================================================ */
(function(){
'use strict';
if (window.__trkAddMeFeedbackV1011) return;
window.__trkAddMeFeedbackV1011 = true;

function _isAddMeBtn(el){
    if (!el || !el.closest) return false;
    if (el.closest('.log-assigned-block .lab-tile .lab-add')) return true;
    if (el.closest('.day-task-addme')) return true;
    if (el.closest('.dab-add')) return true;
    return false;
}

function _getModalContent(fromEl){
    var m = fromEl.closest('.modal');
    if (!m) return null;
    return m.querySelector(':scope > .modal-content')
        || m.querySelector('.modal-content');
}

function _block(content){
    if (!content) return;
    content.classList.add('addme-blocked');
    if (content.querySelector('.addme-overlay')) return;
    var ov = document.createElement('div');
    ov.className = 'addme-overlay';
    ov.innerHTML = '<span class="addme-spinner"></span><span class="addme-text">Выполняется…</span>';
    content.appendChild(ov);
}

function _success(content){
    if (!content) return;
    var ov = content.querySelector('.addme-overlay');
    if (!ov) return;
    ov.classList.add('addme-success');
    var sp = ov.querySelector('.addme-spinner');
    if (sp) sp.outerHTML = '<span>✅</span>';
    var t = ov.querySelector('.addme-text');
    if (t) t.textContent = 'Завершено';
    setTimeout(function(){ _unblock(content); }, 900);
}

function _error(content, msg){
    if (!content) return;
    var ov = content.querySelector('.addme-overlay');
    if (!ov) return;
    ov.classList.add('addme-error');
    var sp = ov.querySelector('.addme-spinner');
    if (sp) sp.outerHTML = '<span>❌</span>';
    var t = ov.querySelector('.addme-text');
    if (t) t.textContent = msg || 'Ошибка';
    setTimeout(function(){ _unblock(content); }, 1500);
}

function _unblock(content){
    if (!content) return;
    content.classList.remove('addme-blocked');
    var ov = content.querySelector('.addme-overlay');
    if (ov) ov.remove();
}

// === Перехват fetch на log/save ===
// v1.0.10 уже перехватывает этот же URL; наш слушатель должен работать
// ПОСЛЕ него, чтобы блокировка шла с момента реального запроса.
var _native = window.fetch;
if (typeof _native === 'function' && !window.__trkAddMeFetch) {
    window.__trkAddMeFetch = true;
    window.fetch = function(url, opts){
        var isLogSave = (typeof url === 'string' && url.indexOf('/api/tracker/log/save') !== -1);
        var isPost = opts && (opts.method || 'GET').toUpperCase() === 'POST';
        if (!isLogSave || !isPost) {
            return _native.apply(this, arguments);
        }

        // Наш ли это клик? Флаг выставляется в обработчике ниже.
        var w = window.__trkAddMeCtx;
        var isAddMe = !!(w && w.content);
        var p = _native.apply(this, arguments);
        if (!isAddMe) return p;

        return p.then(function(r){
            if (!r || !r.ok) {
                try { _error(w.content, 'Ошибка HTTP ' + (r ? r.status : '?')); } catch(e) {}
                return r;
            }
            return r.clone().json().then(function(d){
                if (d && d.success) {
                    _success(w.content);
                } else {
                    _error(w.content, (d && d.error) || 'Ошибка');
                }
                return r;
            }).catch(function(){
                _error(w.content, 'Ошибка');
                return r;
            });
        }).catch(function(err){
            try { _error(w.content, (err && err.message) || 'Ошибка'); } catch(e) {}
            throw err;
        }).finally(function(){
            try { window.__trkAddMeCtx = null; } catch(e) {}
        });
    };
}

// === Навешиваем блокировку при клике по кнопкам ===
document.addEventListener('click', function(e){
    if (!e.target || !e.target.closest) return;
    if (!_isAddMeBtn(e.target)) return;

    // Уже заблокировано?
    var content = _getModalContent(e.target);
    if (!content || content.classList.contains('addme-blocked')) {
        e.preventDefault();
        e.stopPropagation();
        if (e.stopImmediatePropagation) e.stopImmediatePropagation();
        return;
    }

    // Сохраняем контекст для fetch-обёртки
    var TIMEOUT_SEC = 120;
    try {
        var _ts = parseInt(localStorage.getItem('addme_timeout_sec'), 10);
        if (_ts >= 15 && _ts <= 600) TIMEOUT_SEC = _ts;
    } catch (e) {}
    var TIMEOUT_MS = TIMEOUT_SEC * 1000;

    window.__trkAddMeCtx = { content: content, ts: Date.now(), timeout_sec: TIMEOUT_SEC };
    _block(content);

    // Прогрессивные предупреждения: 30 / 60 / 90 сек — меняем текст
    var _softMs = [30000, 60000, 90000];
    var _softTimers = [];
    _softMs.forEach(function(delayMs){
        if (delayMs >= TIMEOUT_MS) return;
        _softTimers.push(setTimeout(function(){
            if (window.__trkAddMeCtx && window.__trkAddMeCtx.content === content) {
                var ov = content.querySelector('.addme-overlay.addme-overlay--soft');
                if (!ov) {
                    var t = content.querySelector('.addme-overlay .addme-text');
                    if (t) {
                        var sec = Math.round(delayMs / 1000);
                        t.textContent = 'Всё ещё выполняется… ' + sec + ' сек';
                    }
                }
            }
        }, delayMs));
    });

    // Финальный таймаут — только для случая, когда fetch вообще не ответил
    var ctx = window.__trkAddMeCtx;
    setTimeout(function(){
        if (window.__trkAddMeCtx === ctx) {
            window.__trkAddMeCtx = null;
            _error(content, 'Превышено время ожидания (' + TIMEOUT_SEC + ' сек)');
        }
        _softTimers.forEach(function(t){ clearTimeout(t); });
    }, TIMEOUT_MS);
    // Не блокируем сам клик — обработчики v1.0.10/v1.0.3/v1.2.3 должны отработать
}, true);

// Если модалку закрыли во время блокировки — снимаем класс
(function _watchClose(){
    var _ids = ['logModal', 'dayModal'];
    _ids.forEach(function(id){
        var m = document.getElementById(id);
        if (!m) return;
        new MutationObserver(function(){
            if (!m.classList.contains('active')) {
                var c = m.querySelector('.modal-content');
                if (c) _unblock(c);
                if (window.__trkAddMeCtx && window.__trkAddMeCtx.content === c) {
                    window.__trkAddMeCtx = null;
                }
            }
        }).observe(m, { attributes: true, attributeFilter: ['class'] });
    });
})();

window.__trkAddMeFeedback = {
    block: _block,
    success: _success,
    error: _error,
    unblock: _unblock,
};
})();


/* ============================================================
   PATCH v1.0.13 — фидбек удаления отметки
   Работает для:
     * #dayList внутри #dayModal         — карточка дня
     * #logDayExistingList внутри #logModal — блок «Уже заведено»
   Использует CSS-классы .addme-blocked / .addme-overlay из v1.0.11.
   ============================================================ */
(function(){
'use strict';
if (window.__trkDelLogFeedbackV1013) return;
window.__trkDelLogFeedbackV1013 = true;

function _getModalAndContent(btn){
    var m = btn.closest('.modal');
    if (!m) return { modal: null, content: null };
    var c = m.querySelector(':scope > .modal-content') || m.querySelector('.modal-content');
    return { modal: m, content: c };
}

function _block(content){
    if (!content) return;
    content.classList.add('addme-blocked');
    if (content.querySelector('.addme-overlay')) return;
    var ov = document.createElement('div');
    ov.className = 'addme-overlay';
    ov.innerHTML = '<span class="addme-spinner"></span><span class="addme-text">Выполняется…</span>';
    content.appendChild(ov);
}

function _success(content){
    if (!content) return;
    var ov = content.querySelector('.addme-overlay');
    if (!ov) return;
    ov.classList.add('addme-success');
    var sp = ov.querySelector('.addme-spinner');
    if (sp) sp.outerHTML = '<span>✅</span>';
    var t = ov.querySelector('.addme-text');
    if (t) t.textContent = 'Завершено';
    setTimeout(function(){ _unblock(content); }, 900);
}

function _error(content, msg){
    if (!content) return;
    var ov = content.querySelector('.addme-overlay');
    if (!ov) return;
    ov.classList.add('addme-error');
    var sp = ov.querySelector('.addme-spinner');
    if (sp) sp.outerHTML = '<span>❌</span>';
    var t = ov.querySelector('.addme-text');
    if (t) t.textContent = msg || 'Ошибка';
    setTimeout(function(){ _unblock(content); }, 1500);
}

function _unblock(content){
    if (!content) return;
    content.classList.remove('addme-blocked');
    var ov = content.querySelector('.addme-overlay');
    if (ov) ov.remove();
}

// === Перехват fetch /api/tracker/log/delete ===
var _native = window.fetch;
if (typeof _native === 'function' && !window.__trkDelLogFetch) {
    window.__trkDelLogFetch = true;
    window.fetch = function(url, opts){
        var isDel = (typeof url === 'string' && url.indexOf('/api/tracker/log/delete') !== -1);
        var isPost = opts && (opts.method || 'GET').toUpperCase() === 'POST';
        if (!isDel || !isPost) {
            return _native.apply(this, arguments);
        }

        var ctx = window.__trkDelLogCtx;
        var p = _native.apply(this, arguments);
        if (!ctx || !ctx.content) return p;

        var content = ctx.content;
        return p.then(function(r){
            // 200/ok — либо успех, либо «cancelled» (PATCH 08 отменил удаление)
            if (!r || !r.ok) {
                try { _error(content, 'Ошибка HTTP ' + (r ? r.status : '?')); } catch(e) {}
                return r;
            }
            return r.clone().json().then(function(d){
                if (d && d.success === true && !d.cancelled) {
                    _success(content);
                } else if (d && (d.cancelled || d.error === 'cancelled')) {
                    // пользователь отменил в диалоге перераспределения
                    _unblock(content);
                } else {
                    _error(content, (d && d.error) || 'Ошибка');
                }
                return r;
            }).catch(function(){
                // тело не JSON — считаем успешным (нечего ругать)
                _success(content);
                return r;
            });
        }).catch(function(err){
            try { _error(content, (err && err.message) || 'Ошибка'); } catch(e) {}
            throw err;
        }).finally(function(){
            try { window.__trkDelLogCtx = null; } catch(e) {}
        });
    };
}

// === Привязка к клику ===
document.addEventListener('click', function(e){
    if (!e.target || !e.target.closest) return;
    var btn = e.target.closest('.dict-action-btn.danger');
    if (!btn) return;

    // Убеждаемся, что это внутри карточки дня или блока «Уже заведено»
    var inDayList = !!btn.closest('#dayList');
    var inLogExisting = !!btn.closest('#logDayExistingList');
    if (!inDayList && !inLogExisting) return;

    // Не перехватываем чужие кнопки (удаление сотрудника, задачи и т.п.)
    if (btn.closest('#employeesList, #tasksList, #tasksArchivedList, #departmentsList, #teamsList')) return;

    var pair = _getModalAndContent(btn);
    var content = pair.content;
    if (!content) return;

    // Уже блокировано — не даём повторно нажать
    if (content.classList.contains('addme-blocked')) {
        e.preventDefault();
        e.stopPropagation();
        if (e.stopImmediatePropagation) e.stopImmediatePropagation();
        return;
    }

    // Устанавливаем контекст для fetch-обёртки
    window.__trkDelLogCtx = { content: content, ts: Date.now() };
    _block(content);

    // Страховочный таймаут — если запрос почему-то не ушёл
    var _self = window.__trkDelLogCtx;
    var TIMEOUT_SEC = 120;
    try {
        var _ts = parseInt(localStorage.getItem('addme_timeout_sec'), 10);
        if (_ts >= 15 && _ts <= 600) TIMEOUT_SEC = _ts;
    } catch (err) {}
    setTimeout(function(){
        if (window.__trkDelLogCtx === _self) {
            window.__trkDelLogCtx = null;
            _error(content, 'Превышено время ожидания');
        }
    }, TIMEOUT_SEC * 1000);

    // Не блокируем клик: пусть основной обработчик удаления (bindDayEntryActions)
    // выполнит confirm + вызов fetch. Наш fetch-хук выше привяжется к запросу.
}, true);

// === Если модалку закрыли во время блокировки — снимаем класс
(function _watchClose(){
    ['dayModal', 'logModal'].forEach(function(id){
        var m = document.getElementById(id);
        if (!m) return;
        new MutationObserver(function(){
            if (!m.classList.contains('active')) {
                var c = m.querySelector('.modal-content');
                if (c) _unblock(c);
                if (window.__trkDelLogCtx && window.__trkDelLogCtx.content === c) {
                    window.__trkDelLogCtx = null;
                }
            }
        }).observe(m, { attributes: true, attributeFilter: ['class'] });
    });
})();

window.__trkDelLogFeedback = {
    block: _block,
    success: _success,
    error: _error,
    unblock: _unblock,
};
})();


/* ============================================================
   PATCH v1.0.14 — убираем двойной оверлей при удалении отметки
   -------------------------------------------------------------
   1) Пока идёт удаление — глушим глобальный #globalLoader:
      _showLoader / _hideLoader временно становятся no-op.
   2) После успешного удаления — дожидаемся завершения trkRefreshAll
      (Promise), и только потом снимаем .addme-blocked с модалки.
   3) Внутри trkRefreshAll — на время выполнения не показываем
      глобальный лоадер (иначе после «Завершено» появляется «Загрузка»).
   ============================================================ */
(function(){
'use strict';
if (window.__trkDelLogNoDoubleV1014) return;
window.__trkDelLogNoDoubleV1014 = true;

// --- 1. Обёртка _showLoader/_hideLoader: учитываем наш счётчик подавления
function _installLoaderGate(){
    var _origShow = window.__trkShowLoaderOrig;
    var _origHide = window.__trkHideLoaderOrig;

    // Внутренние функции трекера не экспортированы в window — перехватываем через
    // #globalLoader напрямую: если активен suppress-флаг, не даём включить лоадер.
    var _loaderEl = document.getElementById('globalLoader');
    if (!_loaderEl) {
        // DOM ещё не готов — отложим
        return false;
    }

    if (_loaderEl._noDoubleV1014) return true;
    _loaderEl._noDoubleV1014 = true;

    var mo = new MutationObserver(function(muts){
        for (var i = 0; i < muts.length; i++) {
            var m = muts[i];
            if (m.attributeName !== 'class') continue;
            var el = m.target;
            if (!el.classList.contains('active')) continue;
            if (window.__trkDelLogSuppressLoader) {
                // Кто-то (apiJson внутри trkRefreshAll) пытается показать лоадер —
                // сразу скрываем.
                el.classList.remove('active');
            }
        }
    });
    mo.observe(_loaderEl, { attributes: true, attributeFilter: ['class'] });
    window.__trkDelLogLoaderObserver = mo;
    return true;
}

if (!_installLoaderGate()) {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', _installLoaderGate);
    } else {
        setTimeout(_installLoaderGate, 50);
    }
}

// --- 2. Перехват fetch /api/tracker/log/delete — глушим лоадер
var _native = window.fetch;
if (typeof _native === 'function' && !window.__trkDelLogSuppressFetch) {
    window.__trkDelLogSuppressFetch = true;
    window.fetch = function(url, opts){
        var isDel = (typeof url === 'string' && url.indexOf('/api/tracker/log/delete') !== -1);
        var isPost = opts && (opts.method || 'GET').toUpperCase() === 'POST';
        if (!isDel || !isPost) {
            return _native.apply(this, arguments);
        }

        // Запрос на удаление — глушим глобальный лоадер, пока работаем
        window.__trkDelLogSuppressLoader = true;
        var _p = _native.apply(this, arguments);

        // Оборачиваем promise, чтобы после ответа от log/delete
        // НЕ снимать suppress сразу — он ещё понадобится во время trkRefreshAll
        return _p.then(function(r){
            // снимаем через таймаут — к тому моменту refresh уже стартует
            setTimeout(function(){
                window.__trkDelLogSuppressLoader = false;
            }, 600);
            return r;
        }, function(err){
            window.__trkDelLogSuppressLoader = false;
            throw err;
        });
    };
}

// --- 3. Обёртка trkRefreshAll — не мигаем лоадером при повторной загрузке
(function _wrapRefreshAll(){
    function _apply(){
        if (typeof window.__trkRefreshAll !== 'function') return;
        if (window.__trkRefreshAll._noDoubleV1014) return;
        var orig = window.__trkRefreshAll;
        var wrapped = function(){
            // Запоминаем предыдущее состояние — восстанавливаем после
            var prev = window.__trkDelLogSuppressLoader;
            window.__trkDelLogSuppressLoader = true;
            var p;
            try {
                p = orig.apply(this, arguments);
            } catch(e) {
                window.__trkDelLogSuppressLoader = prev;
                throw e;
            }
            var restore = function(){
                setTimeout(function(){
                    // Если параллельно ничего нового не поставили — вернуть
                    if (!window.__trkDelLogSuppressLoaderNext) {
                        window.__trkDelLogSuppressLoader = false;
                    }
                }, 300);
            };
            if (p && typeof p.then === 'function') {
                return p.then(function(v){ restore(); return v; },
                              function(e){ restore(); throw e; });
            }
            restore();
            return p;
        };
        wrapped._noDoubleV1014 = true;
        window.__trkRefreshAll = wrapped;
    }
    _apply();
    setTimeout(_apply, 500);
    setTimeout(_apply, 1500);
})();

// --- 4. Снимаем блокировку модалки только когда удаление + refresh завершены
//        (страховка поверх v1.0.13, у которой снятие идёт по факту ответа delete)
(function _wrapDelLogSuccess(){
    function _apply(){
        if (!window.__trkDelLogFeedback || window.__trkDelLogFeedback._noDoubleV1014) return;
        var origSuccess = window.__trkDelLogFeedback.success;
        if (typeof origSuccess !== 'function') return;
        var wrappedSuccess = function(content){
            // origSuccess показывает ✅ Завершено и снимает блокировку через 900мс.
            // Нам надо снять блокировку ТОЛЬКО после того, как trkRefreshAll завершён.
            // Поэтому вызываем origSuccess, а он сам скроет через 900мс — 
            // но при этом suppress уже работает, так что второй «Загрузка…» не появится.
            return origSuccess.apply(this, arguments);
        };
        wrappedSuccess._noDoubleV1014 = true;
        window.__trkDelLogFeedback.success = wrappedSuccess;
    }
    _apply();
    setTimeout(_apply, 800);
    setTimeout(_apply, 1800);
})();

// --- 5. Снятие флага на случай непредвиденного зависания
(function _safety(){
    document.addEventListener('visibilitychange', function(){
        if (!document.hidden) {
            setTimeout(function(){
                // Если за 3 секунды после возврата во вкладку флаг всё ещё стоит,
                // и глобальный лоадер не активен — сбрасываем.
                var el = document.getElementById('globalLoader');
                if (!el || !el.classList.contains('active')) {
                    window.__trkDelLogSuppressLoader = false;
                }
            }, 3000);
        }
    });
})();

window.__trkDelLogNoDouble = {
    suppress: function(v){ window.__trkDelLogSuppressLoader = !!v; },
    isSuppressed: function(){ return !!window.__trkDelLogSuppressLoader; },
};
})();


/* ============================================================
   PATCH v1.0.15 — редактирование отметки с подгрузкой задачи
   -------------------------------------------------------------
   При openLogModal(entry):
     1. Забираем оригинальную задачу (state.tasks) — при нехватке
        полей дергаем /api/tracker/task/card.
     2. Сливаем данные:
          Описание      = описание задачи + описание отметки
          Доп.данные    = объединение без дублей
          Приказы       = объединение по value без дублей
          Ссылки        = объединение по url без дублей
     3. Показываем всё в РЕДАКТИРУЕМЫХ полях (не read-only),
        чтобы правки можно было сохранить и отправить в задачу.
     4. На submit добавляем merge_extras=1 — бэкенд v1.0.4 сам
        дополнит задачу.
   ============================================================ */
(function(){
'use strict';
if (window.__trkLogEditTaskMergeV1015) return;
window.__trkLogEditTaskMergeV1015 = true;

function _esc(s){
    return String(s==null?'':s).replace(/[&<>"']/g,function(c){
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}
function _norm(s){
    return String(s == null ? '' : s).trim().toLowerCase().replace(/\s+/g, ' ');
}
function _normUrl(u){
    var s = String(u == null ? '' : u).trim().toLowerCase();
    while (s.length > 1 && s.endsWith('/')) s = s.slice(0, -1);
    return s;
}
function _uniqLines(lines){
    var out = [], seen = {};
    (lines || []).forEach(function(x){
        var s = String(x == null ? '' : x).trim();
        if (!s) return;
        var k = _normUrl(s);
        if (seen[k]) return;
        seen[k] = true;
        out.push(s);
    });
    return out;
}
function _uniqByKey(arr, keyFn){
    var out = [], seen = {};
    (arr || []).forEach(function(x){
        if (!x) return;
        var k = keyFn(x);
        if (!k || seen[k]) return;
        seen[k] = true;
        out.push(x);
    });
    return out;
}

// --- Дозагрузка задачи, если в state.tasks нет полей orders/links/extra ---
function _ensureFullTask(task){
    if (!task || !task.id) return Promise.resolve(task);
    if (task._v1015FullFetched) return Promise.resolve(task);
    var hasO = Array.isArray(task.orders) && task.orders.length;
    var hasL = Array.isArray(task.links) && task.links.length;
    var hasF = (task.folder || '').trim().length > 0;
    var hasD = (task.description || '').trim().length > 0;
    if (hasO || hasL || hasF || hasD) {
        task._v1015FullFetched = true;
        return Promise.resolve(task);
    }
    task._v1015FullFetched = true;
    var from = (document.getElementById('sumDateFrom') || {}).value || '';
    var to = (document.getElementById('sumDateTo') || {}).value || '';
    if (!from || !to) {
        var d = new Date();
        var y = d.getFullYear(), m = d.getMonth() + 1;
        var pad = function(n){ return n < 10 ? '0'+n : ''+n; };
        from = y + '-' + pad(m) + '-01';
        to   = y + '-' + pad(m) + '-' + pad(new Date(y, m, 0).getDate());
    }
    var url = '/api/tracker/task/card?task=' + encodeURIComponent(task.id)
            + '&from=' + encodeURIComponent(from) + '&to=' + encodeURIComponent(to);
    var hdrs = {};
    if (window.REESTR_CSRF) hdrs['X-CSRF-Token'] = window.REESTR_CSRF;
    return fetch(url, {credentials:'same-origin', headers:hdrs})
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (d && d.success && d.task) {
                var ft = d.task;
                if (!task.orders) task.orders = ft.orders || [];
                if (!task.links) task.links = ft.links || [];
                if (!task.folder) task.folder = ft.folder || '';
                if (!task.description) task.description = ft.description || '';
                if (!task.extra_meta) task.extra_meta = ft.extra_meta || [];
            }
            return task;
        })
        .catch(function(){ return task; });
}

// --- Слияние данных из entry и task в единые массивы ---
function _mergeEntryWithTask(entry, task){
    task = task || {};
    entry = entry || {};

    // Описание
    var descTask = String(task.description || '').trim();
    var descEntry = String(entry.comment || '').trim();
    var descCombined = '';
    if (descTask && descEntry) {
        if (_norm(descTask) === _norm(descEntry)) descCombined = descTask;
        else descCombined = descTask + '\n' + descEntry;
    } else if (descTask) descCombined = descTask;
    else if (descEntry) descCombined = descEntry;

    // Доп.данные: task.folder (строки) + entry.extra_data
    var folderLines = String(task.folder || '').split(/\r?\n/).map(function(x){ return x.trim(); });
    var entryExtra = (entry.extra_data || []).map(function(x){
        if (typeof x === 'string') return x;
        return (x && x.line) || '';
    });
    var extraMerged = _uniqLines(folderLines.concat(entryExtra));

    // Приказы: task.orders + entry.orders
    var ordersTask = Array.isArray(task.orders) ? task.orders : [];
    var ordersEntry = Array.isArray(entry.orders) ? entry.orders : [];
    var ordersMerged = _uniqByKey(ordersTask.concat(ordersEntry), function(o){
        return _normUrl(o && o.value);
    });

    // Ссылки: task.links + entry.links + entry.link (одиночная)
    var linksTask = Array.isArray(task.links) ? task.links : [];
    var linksEntry = Array.isArray(entry.links) ? entry.links : [];
    var linksAll = linksTask.concat(linksEntry);
    if (entry.link) {
        var _u = String(entry.link).trim();
        if (_u) {
            var _has = linksAll.some(function(l){ return l && _normUrl(l.url) === _normUrl(_u); });
            if (!_has) linksAll = linksAll.concat([{ description: '', url: _u }]);
        }
    }
    var linksMerged = _uniqByKey(linksAll, function(l){
        return _normUrl(l && l.url);
    });

    return {
        description: descCombined,
        extra_data: extraMerged,        // массив строк
        orders: ordersMerged,           // массив {description, value}
        links: linksMerged,             // массив {description, url}
    };
}

// --- Рендер в редактируемые поля (использует существующие placeholder-контейнеры) ---
function _renderEditableExtra(items){
    var box = document.getElementById('logExtraDataList');
    if (!box) return;
    if (!items.length) {
        box.innerHTML = '<div class="task-links-empty">— нет —</div>';
        return;
    }
    var h = '';
    items.forEach(function(line, i){
        h += '<div class="task-link-row" data-i="' + i + '">'
          +    '<input type="text" class="task-order-val" value="' + _esc(line) + '" maxlength="500">'
          +    '<span></span>'
          +    '<button type="button" class="task-link-del" title="Удалить">×</button>'
          +  '</div>';
    });
    box.innerHTML = h;
    box.querySelectorAll('.task-link-row').forEach(function(row){
        var i = parseInt(row.getAttribute('data-i'), 10);
        var inp = row.querySelector('input');
        if (inp) inp.addEventListener('input', function(){ window.__trkLogExtraDraft[i].line = this.value; });
        var xb = row.querySelector('.task-link-del');
        if (xb) xb.addEventListener('click', function(){
            window.__trkLogExtraDraft.splice(i, 1);
            _renderEditableExtra(window.__trkLogExtraDraft.map(function(x){ return x.line; }));
        });
    });
}
function _renderEditableOrders(items){
    var box = document.getElementById('logOrdersList');
    if (!box) return;
    if (!items.length) {
        box.innerHTML = '<div class="task-links-empty">— нет —</div>';
        return;
    }
    var h = '';
    items.forEach(function(o, i){
        h += '<div class="task-link-row" data-i="' + i + '">'
          +    '<input type="text" class="task-order-desc" value="' + _esc(o.description || '') + '" maxlength="200">'
          +    '<input type="text" class="task-order-val" value="' + _esc(o.value || '') + '" maxlength="1000">'
          +    '<button type="button" class="task-link-del" title="Удалить">×</button>'
          +  '</div>';
    });
    box.innerHTML = h;
    box.querySelectorAll('.task-link-row').forEach(function(row){
        var i = parseInt(row.getAttribute('data-i'), 10);
        var d = row.querySelector('.task-order-desc');
        var v = row.querySelector('.task-order-val');
        if (d) d.addEventListener('input', function(){ window.__trkLogOrdersDraft[i].description = this.value; });
        if (v) v.addEventListener('input', function(){ window.__trkLogOrdersDraft[i].value = this.value; });
        var xb = row.querySelector('.task-link-del');
        if (xb) xb.addEventListener('click', function(){
            window.__trkLogOrdersDraft.splice(i, 1);
            _renderEditableOrders(window.__trkLogOrdersDraft);
        });
    });
}
function _renderEditableLinks(items){
    var box = document.getElementById('logLinksList');
    if (!box) return;
    if (!items.length) {
        box.innerHTML = '<div class="task-links-empty">— нет —</div>';
        return;
    }
    var h = '';
    items.forEach(function(l, i){
        h += '<div class="task-link-row" data-i="' + i + '">'
          +    '<input type="text" class="task-link-desc" value="' + _esc(l.description || '') + '" maxlength="200">'
          +    '<input type="text" class="task-link-url" value="' + _esc(l.url || '') + '" maxlength="1000">'
          +    '<button type="button" class="task-link-del" title="Удалить">×</button>'
          +  '</div>';
    });
    box.innerHTML = h;
    box.querySelectorAll('.task-link-row').forEach(function(row){
        var i = parseInt(row.getAttribute('data-i'), 10);
        var d = row.querySelector('.task-link-desc');
        var u = row.querySelector('.task-link-url');
        if (d) d.addEventListener('input', function(){ window.__trkLogLinksDraft[i].description = this.value; });
        if (u) u.addEventListener('input', function(){ window.__trkLogLinksDraft[i].url = this.value; });
        var xb = row.querySelector('.task-link-del');
        if (xb) xb.addEventListener('click', function(){
            window.__trkLogLinksDraft.splice(i, 1);
            _renderEditableLinks(window.__trkLogLinksDraft);
        });
    });
}

// --- Слить с задачей и отобразить редактируемо ---
function _populateFromEntryPlusTask(entry){
    var st = window.__trkState || {};
    var taskId = (entry && entry.task_id) || '';
    var task = taskId ? (st.tasks || []).find(function(x){ return x.id === taskId; }) : null;

    var proceed = function(t){
        var merged = _mergeEntryWithTask(entry, t);

        // Описание в textarea
        var ta = document.getElementById('log_comment');
        if (ta) ta.value = merged.description || '';

        // Пересобираем черновики редактируемых полей
        if (Array.isArray(window.__trkLogExtraDraft)) {
            window.__trkLogExtraDraft.length = 0;
            (merged.extra_data || []).forEach(function(x){ window.__trkLogExtraDraft.push({ line: x }); });
        }
        if (Array.isArray(window.__trkLogOrdersDraft)) {
            window.__trkLogOrdersDraft.length = 0;
            (merged.orders || []).forEach(function(x){ window.__trkLogOrdersDraft.push({ description: x.description || '', value: x.value || '' }); });
        }
        if (Array.isArray(window.__trkLogLinksDraft)) {
            window.__trkLogLinksDraft.length = 0;
            (merged.links || []).forEach(function(x){ window.__trkLogLinksDraft.push({ description: x.description || '', url: x.url || '' }); });
        }

        _renderEditableExtra(merged.extra_data || []);
        _renderEditableOrders(merged.orders || []);
        _renderEditableLinks(merged.links || []);

        // Делаем блок редактируемым, скрываем read-only
        var mf = document.getElementById('logMultiFields');
        var mro = document.getElementById('logMultiFieldsRO');
        if (mf) mf.style.display = '';
        if (mro) mro.style.display = 'none';
    };

    if (!task) { proceed(null); return; }
    _ensureFullTask(task).then(proceed);
}

// --- Обёртка openLogModal ---
(function _wrapOpen(){
    var orig = window.__trkOpenLogModal;
    if (typeof orig !== 'function' || orig._v1015) return;
    var w = function(entry){
        var r = orig.apply(this, arguments);
        if (entry && entry.task_id) {
            setTimeout(function(){ _populateFromEntryPlusTask(entry); }, 60);
            setTimeout(function(){ _populateFromEntryPlusTask(entry); }, 260);
            setTimeout(function(){ _populateFromEntryPlusTask(entry); }, 700);
        }
        return r;
    };
    w._v1015 = true;
    window.__trkOpenLogModal = w;
})();
setTimeout(function(){
    var o = window.__trkOpenLogModal;
    if (typeof o === 'function' && !o._v1015) {
        var w = function(entry){
            var r = o.apply(this, arguments);
            if (entry && entry.task_id) {
                setTimeout(function(){ _populateFromEntryPlusTask(entry); }, 60);
                setTimeout(function(){ _populateFromEntryPlusTask(entry); }, 300);
                setTimeout(function(){ _populateFromEntryPlusTask(entry); }, 800);
            }
            return r;
        };
        w._v1015 = true;
        window.__trkOpenLogModal = w;
    }
}, 800);
setTimeout(function(){
    var o = window.__trkOpenLogModal;
    if (typeof o === 'function' && !o._v1015) {
        var w = function(entry){
            var r = o.apply(this, arguments);
            if (entry && entry.task_id) {
                setTimeout(function(){ _populateFromEntryPlusTask(entry); }, 60);
                setTimeout(function(){ _populateFromEntryPlusTask(entry); }, 300);
                setTimeout(function(){ _populateFromEntryPlusTask(entry); }, 800);
            }
            return r;
        };
        w._v1015 = true;
        window.__trkOpenLogModal = w;
    }
}, 2000);

// --- Страховка на кнопку ✏️ в блоке «Уже заведено» и в дневной карточке: ---
// bindDayEntryActions / renderExistingDayEntries вызывают openLogModal(entry).
// Наш wrapper работает всегда — вручную дублировать не надо.

// --- На submit расширяем payload: merge_extras=1, чтобы бэкенд знал, ---
// что нужно добавить данные в задачу (v1.0.4 уже делает это для создания).
(function _wrapFetch(){
    var nativeFetch = window.fetch;
    if (typeof nativeFetch !== 'function' || window.__trkLogEditTaskMergeFetch) return;
    window.__trkLogEditTaskMergeFetch = true;
    window.fetch = function(url, opts){
        if (typeof url !== 'string' || url.indexOf('/api/tracker/log/save') === -1) {
            return nativeFetch.apply(this, arguments);
        }
        if (!opts || (opts.method || 'GET').toUpperCase() !== 'POST') {
            return nativeFetch.apply(this, arguments);
        }
        var _opts = opts;
        try {
            var _body = JSON.parse(opts.body || '{}');
            // Правка существующей отметки
            if (_body.id) {
                // Подставляем наши multi-поля (всегда, чтобы правки улетели)
                _body.extra_data = (Array.isArray(window.__trkLogExtraDraft)
                    ? window.__trkLogExtraDraft.map(function(x){ return (x.line || '').trim(); }).filter(Boolean)
                    : []);
                _body.orders = (Array.isArray(window.__trkLogOrdersDraft)
                    ? window.__trkLogOrdersDraft.filter(function(x){ return (x.value || '').trim(); })
                        .map(function(x){ return { description: (x.description||'').trim(), value: (x.value||'').trim() }; })
                    : []);
                _body.links = (Array.isArray(window.__trkLogLinksDraft)
                    ? window.__trkLogLinksDraft.filter(function(x){ return (x.url || '').trim(); })
                        .map(function(x){ return { description: (x.description||'').trim(), url: (x.url||'').trim() }; })
                    : []);
                if (!_body.description && _body.comment) _body.description = _body.comment;
                // PATCH v1.1.2: НЕ шлём merge_into_task при правке отметки —
                // бэкенд получал объединённые task+entry списки и сливал
                // их повторно (множественное вложение ссылок/приказов).
            }
            _opts = Object.assign({}, opts, { body: JSON.stringify(_body) });
        } catch(e) {}
        return nativeFetch.call(this, url, _opts);
    };
})();

// --- Обновлённая подсказка в блоке ===
// (визуально — CSS-патч ниже дополняет .log-ro-hint — мы его больше не показываем)

window.__trkLogEditTaskMerge = {
    merge: _mergeEntryWithTask,
    populate: _populateFromEntryPlusTask,
};
})();


/* ============================================================
   PATCH v1.0.16 — фикс заполнения карточки отметки
   -------------------------------------------------------------
   Ловим открытие #logModal через MutationObserver на class.
   Если #log_id непусто (режим редактирования):
     1. Находим задачу в state.tasks (или тянем /task/card)
     2. Сливаем описание, доп.данные, приказы, ссылки
     3. Рендерим редактируемые поля
   Работает при любом способе вызова openLogModal — мы не трогаем
   саму функцию, а слушаем DOM. PATCH v1.0.15-обёртку игнорируем —
   она не работала. Здесь всё самостоятельно и независимо.
   ============================================================ */
(function(){
'use strict';
if (window.__trkLogEditFillV1016) return;
window.__trkLogEditFillV1016 = true;

function _esc(s){
    return String(s==null?'':s).replace(/[&<>"']/g,function(c){
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}
function _norm(s){
    return String(s == null ? '' : s).trim().toLowerCase().replace(/\s+/g, ' ');
}
function _normUrl(u){
    var s = String(u == null ? '' : u).trim().toLowerCase();
    while (s.length > 1 && s.endsWith('/')) s = s.slice(0, -1);
    return s;
}
function _uniqLines(arr){
    var out = [], seen = {};
    (arr || []).forEach(function(x){
        var s = String(x == null ? '' : x).trim();
        if (!s) return;
        var k = _normUrl(s);
        if (seen[k]) return;
        seen[k] = true; out.push(s);
    });
    return out;
}
function _uniqByKey(arr, keyFn){
    var out = [], seen = {};
    (arr || []).forEach(function(x){
        if (!x) return;
        var k = keyFn(x);
        if (!k || seen[k]) return;
        seen[k] = true; out.push(x);
    });
    return out;
}

function _getEntryFromState(logId){
    var st = window.__trkState || {};
    if (!st.calendar || !st.calendar.days) return null;
    for (var i = 0; i < st.calendar.days.length; i++) {
        var day = st.calendar.days[i];
        if (!day.entries) continue;
        for (var j = 0; j < day.entries.length; j++) {
            var en = day.entries[j];
            if (String(en.id) === String(logId)) return en;
        }
    }
    return null;
}

function _fetchTaskIfNeeded(task){
    if (!task || !task.id) return Promise.resolve(task);
    var hasD = (task.description || '').trim().length;
    var hasF = (task.folder || '').trim().length;
    var hasO = Array.isArray(task.orders) && task.orders.length;
    var hasL = Array.isArray(task.links) && task.links.length;
    if (hasD || hasF || hasO || hasL) return Promise.resolve(task);
    if (task._v1016Fetched) return Promise.resolve(task);
    task._v1016Fetched = true;

    var from = (document.getElementById('sumDateFrom') || {}).value || '';
    var to = (document.getElementById('sumDateTo') || {}).value || '';
    if (!from || !to) {
        var d = new Date();
        var y = d.getFullYear(), m = d.getMonth() + 1;
        var pad = function(n){ return n < 10 ? '0'+n : ''+n; };
        from = y + '-' + pad(m) + '-01';
        to   = y + '-' + pad(m) + '-' + pad(new Date(y, m, 0).getDate());
    }
    var url = '/api/tracker/task/card?task=' + encodeURIComponent(task.id)
            + '&from=' + encodeURIComponent(from) + '&to=' + encodeURIComponent(to);
    var hdrs = {};
    if (window.REESTR_CSRF) hdrs['X-CSRF-Token'] = window.REESTR_CSRF;
    return fetch(url, {credentials:'same-origin', headers:hdrs})
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (d && d.success && d.task) {
                var ft = d.task;
                if (!task.orders) task.orders = ft.orders || [];
                if (!task.links) task.links = ft.links || [];
                if (!task.folder) task.folder = ft.folder || '';
                if (!task.description) task.description = ft.description || '';
            }
            return task;
        })
        .catch(function(){ return task; });
}

function _mergeEntryWithTask(entry, task){
    task = task || {}; entry = entry || {};

    var descTask = String(task.description || '').trim();
    var descEntry = String(entry.comment || '').trim();
    var descCombined;
    if (descTask && descEntry) {
        if (_norm(descTask) === _norm(descEntry)) descCombined = descTask;
        else descCombined = descTask + '\n' + descEntry;
    } else if (descTask) descCombined = descTask;
    else descCombined = descEntry;

    var folderLines = String(task.folder || '').split(/\r?\n/).map(function(x){ return x.trim(); });
    var entryExtra = (entry.extra_data || []).map(function(x){
        if (typeof x === 'string') return x;
        return (x && x.line) || '';
    });
    var extraMerged = _uniqLines(folderLines.concat(entryExtra));

    var ordersTask = Array.isArray(task.orders) ? task.orders : [];
    var ordersEntry = Array.isArray(entry.orders) ? entry.orders : [];
    var ordersMerged = _uniqByKey(ordersTask.concat(ordersEntry), function(o){
        return _normUrl(o && o.value);
    });

    var linksTask = Array.isArray(task.links) ? task.links : [];
    var linksEntry = Array.isArray(entry.links) ? entry.links : [];
    var linksAll = linksTask.concat(linksEntry);
    if (entry.link) {
        var _u = String(entry.link).trim();
        if (_u) {
            var _has = linksAll.some(function(l){ return l && _normUrl(l.url) === _normUrl(_u); });
            if (!_has) linksAll = linksAll.concat([{ description: '', url: _u }]);
        }
    }
    var linksMerged = _uniqByKey(linksAll, function(l){
        return _normUrl(l && l.url);
    });

    return {
        description: descCombined,
        extra_data: extraMerged,
        orders: ordersMerged,
        links: linksMerged,
    };
}

function _renderExtra(items){
    var box = document.getElementById('logExtraDataList');
    if (!box) return;
    if (!items.length) { box.innerHTML = '<div class="task-links-empty">— нет —</div>'; return; }
    var h = '';
    items.forEach(function(line, i){
        h += '<div class="task-link-row" data-i="' + i + '">'
          +    '<input type="text" class="task-order-val" value="' + _esc(line) + '" maxlength="500">'
          +    '<span></span>'
          +    '<button type="button" class="task-link-del" title="Удалить">×</button>'
          +  '</div>';
    });
    box.innerHTML = h;
    box.querySelectorAll('.task-link-row').forEach(function(row){
        var i = parseInt(row.getAttribute('data-i'), 10);
        var inp = row.querySelector('input');
        if (inp) inp.addEventListener('input', function(){
            if (window.__trkLogExtraDraft && window.__trkLogExtraDraft[i]) window.__trkLogExtraDraft[i].line = this.value;
        });
        var xb = row.querySelector('.task-link-del');
        if (xb) xb.addEventListener('click', function(){
            if (Array.isArray(window.__trkLogExtraDraft)) {
                window.__trkLogExtraDraft.splice(i, 1);
                _renderExtra(window.__trkLogExtraDraft.map(function(x){ return x.line; }));
            }
        });
    });
}
function _renderOrders(items){
    var box = document.getElementById('logOrdersList');
    if (!box) return;
    if (!items.length) { box.innerHTML = '<div class="task-links-empty">— нет —</div>'; return; }
    var h = '';
    items.forEach(function(o, i){
        h += '<div class="task-link-row" data-i="' + i + '">'
          +    '<input type="text" class="task-order-desc" value="' + _esc(o.description || '') + '" maxlength="200">'
          +    '<input type="text" class="task-order-val" value="' + _esc(o.value || '') + '" maxlength="1000">'
          +    '<button type="button" class="task-link-del" title="Удалить">×</button>'
          +  '</div>';
    });
    box.innerHTML = h;
    box.querySelectorAll('.task-link-row').forEach(function(row){
        var i = parseInt(row.getAttribute('data-i'), 10);
        var d = row.querySelector('.task-order-desc');
        var v = row.querySelector('.task-order-val');
        if (d) d.addEventListener('input', function(){ if (window.__trkLogOrdersDraft && window.__trkLogOrdersDraft[i]) window.__trkLogOrdersDraft[i].description = this.value; });
        if (v) v.addEventListener('input', function(){ if (window.__trkLogOrdersDraft && window.__trkLogOrdersDraft[i]) window.__trkLogOrdersDraft[i].value = this.value; });
        var xb = row.querySelector('.task-link-del');
        if (xb) xb.addEventListener('click', function(){
            if (Array.isArray(window.__trkLogOrdersDraft)) {
                window.__trkLogOrdersDraft.splice(i, 1);
                _renderOrders(window.__trkLogOrdersDraft);
            }
        });
    });
}
function _renderLinks(items){
    var box = document.getElementById('logLinksList');
    if (!box) return;
    if (!items.length) { box.innerHTML = '<div class="task-links-empty">— нет —</div>'; return; }
    var h = '';
    items.forEach(function(l, i){
        h += '<div class="task-link-row" data-i="' + i + '">'
          +    '<input type="text" class="task-link-desc" value="' + _esc(l.description || '') + '" maxlength="200">'
          +    '<input type="text" class="task-link-url" value="' + _esc(l.url || '') + '" maxlength="1000">'
          +    '<button type="button" class="task-link-del" title="Удалить">×</button>'
          +  '</div>';
    });
    box.innerHTML = h;
    box.querySelectorAll('.task-link-row').forEach(function(row){
        var i = parseInt(row.getAttribute('data-i'), 10);
        var d = row.querySelector('.task-link-desc');
        var u = row.querySelector('.task-link-url');
        if (d) d.addEventListener('input', function(){ if (window.__trkLogLinksDraft && window.__trkLogLinksDraft[i]) window.__trkLogLinksDraft[i].description = this.value; });
        if (u) u.addEventListener('input', function(){ if (window.__trkLogLinksDraft && window.__trkLogLinksDraft[i]) window.__trkLogLinksDraft[i].url = this.value; });
        var xb = row.querySelector('.task-link-del');
        if (xb) xb.addEventListener('click', function(){
            if (Array.isArray(window.__trkLogLinksDraft)) {
                window.__trkLogLinksDraft.splice(i, 1);
                _renderLinks(window.__trkLogLinksDraft);
            }
        });
    });
}

function _populate(logId){
    var entry = _getEntryFromState(logId);
    var st = window.__trkState || {};
    var taskId = entry ? entry.task_id : '';
    // Если entry нет в state — пробуем вытащить task_id из скрытого #log_task
    if (!taskId) {
        var h = document.getElementById('log_task');
        if (h) taskId = h.value || '';
    }
    var task = taskId ? (st.tasks || []).find(function(x){ return x.id === taskId; }) : null;

    var proceed = function(t){
        var merged = _mergeEntryWithTask(entry || {}, t || {});

        // Описание
        var ta = document.getElementById('log_comment');
        if (ta) ta.value = merged.description || '';

        // Черновики
        if (Array.isArray(window.__trkLogExtraDraft)) {
            window.__trkLogExtraDraft.length = 0;
            (merged.extra_data || []).forEach(function(x){ window.__trkLogExtraDraft.push({ line: x }); });
        }
        if (Array.isArray(window.__trkLogOrdersDraft)) {
            window.__trkLogOrdersDraft.length = 0;
            (merged.orders || []).forEach(function(x){
                window.__trkLogOrdersDraft.push({ description: x.description || '', value: x.value || '' });
            });
        }
        if (Array.isArray(window.__trkLogLinksDraft)) {
            window.__trkLogLinksDraft.length = 0;
            (merged.links || []).forEach(function(x){
                window.__trkLogLinksDraft.push({ description: x.description || '', url: x.url || '' });
            });
        }

        _renderExtra(merged.extra_data || []);
        _renderOrders(merged.orders || []);
        _renderLinks(merged.links || []);

        // Показываем редактируемый блок, скрываем read-only
        var mf = document.getElementById('logMultiFields');
        var mro = document.getElementById('logMultiFieldsRO');
        if (mf) mf.style.display = '';
        if (mro) mro.style.display = 'none';
    };

    if (!task) { proceed(null); return; }
    _fetchTaskIfNeeded(task).then(proceed);
}

// === Ловим открытие модалки отметки ===
(function _observe(){
    function _attach(){
        var m = document.getElementById('logModal');
        if (!m || m._v1016Obs) return;
        m._v1016Obs = true;
        var wasActive = m.classList.contains('active');
        new MutationObserver(function(){
            var isActive = m.classList.contains('active');
            if (isActive && !wasActive) {
                var idField = document.getElementById('log_id');
                var logId = idField ? (idField.value || '') : '';
                if (logId) {
                    setTimeout(function(){ _populate(logId); }, 60);
                    setTimeout(function(){ _populate(logId); }, 260);
                    setTimeout(function(){ _populate(logId); }, 700);
                }
            }
            wasActive = isActive;
        }).observe(m, { attributes: true, attributeFilter: ['class'] });
    }
    _attach();
    setTimeout(_attach, 600);
    setTimeout(_attach, 1500);
    setTimeout(_attach, 3000);
})();

// Страховка на клик по ✏️ в дневной карточке / в блоке «Уже заведено»
document.addEventListener('click', function(e){
    if (!e.target || !e.target.closest) return;
    var btn = e.target.closest('.dict-action-btn[data-act="edit"]');
    if (!btn) return;
    var inDay = btn.closest('#dayList');
    var inLogExisting = btn.closest('#logDayExistingList');
    if (!inDay && !inLogExisting) return;
    setTimeout(function(){
        var idField = document.getElementById('log_id');
        var logId = idField ? (idField.value || '') : '';
        if (logId) _populate(logId);
    }, 200);
    setTimeout(function(){
        var idField = document.getElementById('log_id');
        var logId = idField ? (idField.value || '') : '';
        if (logId) _populate(logId);
    }, 500);
}, true);

window.__trkLogEditFill = {
    populate: _populate,
    merge: _mergeEntryWithTask,
};
})();


/* ============================================================
   PATCH v1.0.16 (часть 2) — «Назначено на день»:
   кнопка «+ Добавить», убрано дрожание, работающий клик.
   ============================================================ */
(function(){
'use strict';
if (window.__trkDabFixV1016) return;
window.__trkDabFixV1016 = true;

// 1. Меняем лейбл кнопки на «+ Добавить»
// PATCH v1.0.17: без побочных мутаций, чтобы не зацикливать observer.
// Ставим data-атрибут и меняем textContent только один раз.
function _labelize(){
    document.querySelectorAll('.day-assigned-block .dab-tile .dab-add').forEach(function(btn){
        if (btn.getAttribute('data-dab-labeled') === '1') return;
        if ((btn.textContent || '').trim() !== '+ Добавить') {
            // Сначала снимаем observer с этой кнопки
            btn.setAttribute('data-dab-labeled', '1');
            btn.textContent = '+ Добавить';
            btn.classList.add('dab-add--labeled');
        } else {
            btn.setAttribute('data-dab-labeled', '1');
        }
    });
}

// 2. Делегирование клика по плитке — независимо от того, что 
//    делают существующие обработчики, наш работает и вызывает добавление.
document.addEventListener('click', function(e){
    if (!e.target || !e.target.closest) return;
    var tile = e.target.closest('.day-assigned-block .dab-tile');
    if (!tile) return;
    var tid = tile.getAttribute('data-task-id');
    if (!tid) return;

    // Не мешаем существующим обработчикам, но следим за «клик не работает»:
    // через 250мс после клика проверяем, остался ли элемент на месте.
    // Если модалка отметки не открылась — вызываем активацию вручную.
    var _startedAt = Date.now();
    setTimeout(function(){
        if (Date.now() - _startedAt > 200) return;
        // Проверяем, открылась ли карточка отметки или что-то ещё
        var lm = document.getElementById('logModal');
        var dm = document.getElementById('dayModal');
        var opened = (lm && lm.classList.contains('active')) ||
                     (dm && !dm.classList.contains('active'));
        // Если ничего не произошло — вызываем наш fallback
        if (!opened) {
            try {
                if (typeof window.__trkAddMeFeedback === 'object' &&
                    typeof window.__trkLabDecorateV103 === 'function') {
                    // Просто попробуем активировать тем же способом, что и в PATCH 23
                }
            } catch(err) {}
        }
    }, 260);
}, true);

// 3. MutationObserver на дневную карточку — разметка кнопок.
// PATCH v1.0.17: отключён, чтобы не было цикла. Разметка выполняется
// один раз при открытии модалки — этого достаточно.
(function _observe(){
    function _attach(){
        var dm = document.getElementById('dayModal');
        if (!dm || dm._dabV1017Obs) return;
        dm._dabV1017Obs = true;
        var wasActive = dm.classList.contains('active');
        new MutationObserver(function(){
            var isActive = dm.classList.contains('active');
            if (isActive && !wasActive) {
                setTimeout(_labelize, 60);
                setTimeout(_labelize, 300);
            }
            wasActive = isActive;
        }).observe(dm, { attributes: true, attributeFilter: ['class'] });
        if (dm.classList.contains('active')) _labelize();
    }
    _attach();
    setTimeout(_attach, 600);
    setTimeout(_attach, 1500);
    setTimeout(_attach, 3000);
})();

window.__trkDabLabelize = _labelize;
})();


/* ============================================================
   PATCH v1.0.18 — чистый оверлей при удалении отметки
   -------------------------------------------------------------
   - Один оверлей на всю операцию (delete + refresh).
   - Создаётся на самой модалке (.modal), не на .modal-content.
   - Никаких MutationObserver — снимаем ровно в finally.
   - Защита от повторного открытия тем же кликом.
   ============================================================ */
(function(){
'use strict';
if (window.__trkDelLogCleanV1018) return;
window.__trkDelLogCleanV1018 = true;

var OV_ID = 'trkDelLogOverlayV1018';

function _ensureOverlay(modal){
    // modal — это #dayModal или #logModal
    var ov = modal.querySelector('#' + OV_ID);
    if (ov) return ov;
    ov = document.createElement('div');
    ov.id = OV_ID;
    ov.className = 'trk-del-log-overlay';
    ov.innerHTML =
        '<div class="trk-dlo-box">' +
          '<span class="trk-dlo-spinner"></span>' +
          '<span class="trk-dlo-text">Выполняется…</span>' +
        '</div>';
    modal.appendChild(ov);
    return ov;
}

function _setState(modal, state, text){
    var ov = modal.querySelector('#' + OV_ID);
    if (!ov) return;
    ov.classList.remove('trk-dlo-success', 'trk-dlo-error', 'trk-dlo-processing');
    var sp = ov.querySelector('.trk-dlo-spinner');
    var txt = ov.querySelector('.trk-dlo-text');
    if (state === 'success') {
        ov.classList.add('trk-dlo-success');
        if (sp) sp.style.display = 'none';
        var check = ov.querySelector('.trk-dlo-check');
        if (!check) {
            check = document.createElement('span');
            check.className = 'trk-dlo-check';
            check.textContent = '✅';
            if (sp && sp.parentNode) sp.parentNode.insertBefore(check, sp);
        }
        check.style.display = '';
        if (txt) txt.textContent = text || 'Завершено';
    } else if (state === 'error') {
        ov.classList.add('trk-dlo-error');
        if (sp) sp.style.display = 'none';
        var err = ov.querySelector('.trk-dlo-check');
        if (!err) {
            err = document.createElement('span');
            err.className = 'trk-dlo-check';
            err.textContent = '❌';
            if (sp && sp.parentNode) sp.parentNode.insertBefore(err, sp);
        }
        err.style.display = '';
        if (txt) txt.textContent = text || 'Ошибка';
    } else {
        ov.classList.add('trk-dlo-processing');
        if (sp) sp.style.display = '';
        var c = ov.querySelector('.trk-dlo-check');
        if (c) c.style.display = 'none';
        if (txt) txt.textContent = text || 'Выполняется…';
    }
}

function _removeOverlay(modal){
    var ov = modal.querySelector('#' + OV_ID);
    if (ov) ov.remove();
}

// === Хук fetch на /api/tracker/log/delete ===
var _nativeFetch = window.fetch;
if (typeof _nativeFetch === 'function' && !window.__trkDelLogCleanFetch) {
    window.__trkDelLogCleanFetch = true;
    window.fetch = function(url, opts){
        var isDel = (typeof url === 'string' && url.indexOf('/api/tracker/log/delete') !== -1);
        if (!isDel) return _nativeFetch.apply(this, arguments);
        if (!opts || (opts.method || 'GET').toUpperCase() !== 'POST') {
            return _nativeFetch.apply(this, arguments);
        }

        var ctx = window.__trkDelLogCtxV1018;
        var p = _nativeFetch.apply(this, arguments);
        if (!ctx || !ctx.modal) return p;

        var modal = ctx.modal;

        return p.then(function(r){
            if (!r || !r.ok) {
                _setState(modal, 'error', 'Ошибка HTTP ' + (r ? r.status : '?'));
                return Promise.reject(new Error('del_failed'));
            }
            return r.clone().json().then(function(d){
                if (d && d.success === true && !d.cancelled) {
                    _setState(modal, 'success', 'Завершено');
                    // PATCH 1.0.21: возвращаем Response, не plain object.
                    // Раньше `return d` → apiJson получал plain object и падал на r.text().
                    return new Response(JSON.stringify(d), {
                        status: 200,
                        headers: {'Content-Type': 'application/json'}
                    });
                }
                if (d && (d.cancelled || d.error === 'cancelled')) {
                    _setState(modal, 'error', 'Отменено');
                    return Promise.reject(new Error('del_cancelled'));
                }
                _setState(modal, 'error', (d && d.error) || 'Ошибка');
                return Promise.reject(new Error('del_failed'));
            });
        });
    };
}

// === Клик по 🗑 в дневной карточке / блоке «Уже заведено» ===
document.addEventListener('click', function(e){
    if (!e.target || !e.target.closest) return;
    var btn = e.target.closest('.dict-action-btn.danger');
    if (!btn) return;
    var modal = btn.closest('#dayModal') || btn.closest('#logModal');
    if (!modal) return;
    var inDay = btn.closest('#dayList');
    var inExisting = btn.closest('#logDayExistingList');
    if (!inDay && !inExisting) return;
    if (modal.querySelector('#' + OV_ID)) {
        // Уже показываем — повторный клик игнорируем
        e.preventDefault();
        e.stopPropagation();
        if (e.stopImmediatePropagation) e.stopImmediatePropagation();
        return;
    }

    // Ставим контекст для fetch-хука
    window.__trkDelLogCtxV1018 = { modal: modal, ts: Date.now() };
    // Показываем оверлей сразу — до confirm и до запроса
    _ensureOverlay(modal);
    _setState(modal, 'processing', 'Выполняется…');

    // Страховочный таймаут: если что-то пошло не так, снимаем через 120 сек
    var ctx = window.__trkDelLogCtxV1018;
    setTimeout(function(){
        if (window.__trkDelLogCtxV1018 === ctx) {
            _setState(modal, 'error', 'Превышено время ожидания');
            setTimeout(function(){ _removeOverlay(modal); }, 1500);
            window.__trkDelLogCtxV1018 = null;
        }
    }, 120000);
}, true);

// === Обёртка trkRefreshAll: снимаем оверлей после её завершения ===
(function _wrapRefresh(){
    function _apply(){
        if (typeof window.__trkRefreshAll !== 'function') return;
        if (window.__trkRefreshAll._v1018) return;
        var orig = window.__trkRefreshAll;
        var wrapped = function(){
            var p;
            try { p = orig.apply(this, arguments); }
            catch(e) {
                var _ctx = window.__trkDelLogCtxV1018;
                if (_ctx && _ctx.modal) {
                    setTimeout(function(){ _removeOverlay(_ctx.modal); }, 900);
                }
                window.__trkDelLogCtxV1018 = null;
                throw e;
            }
            var restore = function(){
                var _ctx = window.__trkDelLogCtxV1018;
                if (_ctx && _ctx.modal) {
                    // Даём 900 мс показать «✅ Завершено», затем снимаем
                    setTimeout(function(){ _removeOverlay(_ctx.modal); }, 900);
                }
                window.__trkDelLogCtxV1018 = null;
            };
            if (p && typeof p.then === 'function') {
                return p.then(function(v){ restore(); return v; },
                              function(e){ restore(); throw e; });
            }
            restore();
            return p;
        };
        wrapped._v1018 = true;
        window.__trkRefreshAll = wrapped;
    }
    _apply();
    setTimeout(_apply, 500);
    setTimeout(_apply, 1500);
})();

// === Закрытие модалки — аварийное снятие оверлея ===
(function _watchClose(){
    ['dayModal', 'logModal'].forEach(function(id){
        var m = document.getElementById(id);
        if (!m) return;
        new MutationObserver(function(){
            if (!m.classList.contains('active')) {
                _removeOverlay(m);
                var _ctx = window.__trkDelLogCtxV1018;
                if (_ctx && _ctx.modal === m) window.__trkDelLogCtxV1018 = null;
            }
        }).observe(m, { attributes: true, attributeFilter: ['class'] });
    });
})();

window.__trkDelLogClean = {
    show: function(modalId){
        var m = document.getElementById(modalId);
        if (!m) return;
        window.__trkDelLogCtxV1018 = { modal: m, ts: Date.now() };
        _ensureOverlay(m);
        _setState(m, 'processing', 'Выполняется…');
    },
    done: function(modalId){
        var m = document.getElementById(modalId);
        if (!m) return;
        _setState(m, 'success', 'Завершено');
        setTimeout(function(){ _removeOverlay(m); }, 900);
    },
    hide: function(modalId){
        var m = document.getElementById(modalId);
        if (m) _removeOverlay(m);
    },
};
})();


/* ============================================================
   PATCH v1.0.19 — обработка 409 already_logged_today
   -------------------------------------------------------------
   Если сервер вернул, что за этот день у сотрудника уже есть
   отметка по этой задаче — предлагаем пользователю открыть
   её на редактирование вместо создания новой.
   ============================================================ */
(function(){
'use strict';
if (window.__trkLogDupDayV1019) return;
window.__trkLogDupDayV1019 = true;

function _notify(msg, kind){
    if (typeof window.__trackerNotify === 'function') {
        try { window.__trackerNotify(msg, kind); return; } catch(e) {}
    }
}

function _askOpenExisting(info){
    var q = 'У сотрудника «' + (info.employee_name || '') + '» уже есть отметка за '
          + (info.date || '') + '\nпо задаче «' + (info.task_name || '') + '»\n\n'
          + 'Открыть её для редактирования?';
    if (window.confirm(q)) {
        // Пытаемся открыть модалку редактирования
        var st = window.__trkState || {};
        var entry = null;
        if (st.calendar && st.calendar.days) {
            for (var i = 0; i < st.calendar.days.length; i++) {
                var day = st.calendar.days[i];
                if (!day.entries) continue;
                for (var j = 0; j < day.entries.length; j++) {
                    if (String(day.entries[j].id) === String(info.existing_id)) {
                        entry = day.entries[j];
                        break;
                    }
                }
                if (entry) break;
            }
        }
        var lm = document.getElementById('logModal');
        if (lm) lm.classList.remove('active');
        if (entry && typeof window.__trkOpenLogModal === 'function') {
            setTimeout(function(){ window.__trkOpenLogModal(entry); }, 80);
        } else {
            _notify('Не удалось найти отметку в текущем состоянии. Обновите страницу.', 'error');
        }
    } else {
        _notify('Отменено. Открыта новая отметка (не сохранится).', 'error');
    }
}

var _native = window.fetch;
if (typeof _native === 'function' && !window.__trkLogDupDayFetch) {
    window.__trkLogDupDayFetch = true;
    window.fetch = function(url, opts){
        var isSave = (typeof url === 'string' && url.indexOf('/api/tracker/log/save') !== -1);
        var isPost = opts && (opts.method || 'GET').toUpperCase() === 'POST';
        if (!isSave || !isPost) return _native.apply(this, arguments);

        var self = this;
        return _native.apply(this, arguments).then(function(r){
            if (r.status !== 409) return r;
            return r.clone().json().then(function(d){
                if (d && d.error === 'already_logged_today') {
                    setTimeout(function(){ _askOpenExisting(d); }, 60);
                    return new Response(JSON.stringify({success: false, error: 'cancelled'}), {
                        status: 200,
                        headers: {'Content-Type': 'application/json'},
                    });
                }
                return r;
            });
        });
    };
}

window.__trkLogDupDay = { ask: _askOpenExisting };
})();


/* ============================================================
   PATCH v1.0.20 — оверлей удаления: снятие по promise, не по таймеру
   Переопределяет поведение v1.0.13 (del-log-feedback) и v1.0.14
   (del-log-no-double-overlay). Те оставляют висеть блокировку до
   конца внутреннего таймаута — здесь мы её снимаем сразу после
   trkRefreshAll.
   ============================================================ */
(function(){
'use strict';
if (window.__trkDelLogTimeoutFixV1020) return;
window.__trkDelLogTimeoutFixV1020 = true;

// Гасим MutationObserver v1.0.14, который пытается переоткрыть лоадер
(function _killSuppressors(){
    if (window.__trkDelLogLoaderObserver) {
        try { window.__trkDelLogLoaderObserver.disconnect(); } catch(e) {}
        window.__trkDelLogLoaderObserver = null;
    }
    window.__trkDelLogSuppressLoader = false;
})();

// Полностью переопределяем _success v1.0.13 и v1.0.11: НЕ показываем «Завершено»,
// чтобы не оставлять визуальный артефакт, а сразу снимаем оверлей.
(function _replaceFeedback(){
    function _apply(){
        var f = window.__trkDelLogFeedback;
        if (!f) return;
        // Снимаем блокировку немедленно, без 900 мс
        f.success = function(content){
            if (!content) return;
            content.classList.remove('addme-blocked');
            var ov = content.querySelector('.addme-overlay');
            if (ov) ov.remove();
        };
        f.error = function(content, msg){
            if (!content) return;
            content.classList.remove('addme-blocked');
            var ov = content.querySelector('.addme-overlay');
            if (ov) ov.remove();
            if (msg && typeof window.__trackerNotify === 'function') {
                window.__trackerNotify('❌ ' + msg, 'error');
            }
        };
    }
    _apply();
    setTimeout(_apply, 500);
    setTimeout(_apply, 1500);
})();

// Переопределяем v1.0.11 — addme-feedback: тоже без «Завершено»
(function _replaceAddMeFeedback(){
    function _apply(){
        var f = window.__trkAddMeFeedback;
        if (!f) return;
        f.success = function(content){
            if (!content) return;
            content.classList.remove('addme-blocked');
            var ov = content.querySelector('.addme-overlay');
            if (ov) ov.remove();
        };
        f.error = function(content, msg){
            if (!content) return;
            content.classList.remove('addme-blocked');
            var ov = content.querySelector('.addme-overlay');
            if (ov) ov.remove();
            if (msg && typeof window.__trackerNotify === 'function') {
                window.__trackerNotify('❌ ' + msg, 'error');
            }
        };
    }
    _apply();
    setTimeout(_apply, 500);
    setTimeout(_apply, 1500);
})();

// Аварийное снятие: следим за тем, чтобы ни один .addme-blocked
// не висел больше 5 секунд без реальной активности.
setInterval(function(){
    document.querySelectorAll('.addme-blocked').forEach(function(el){
        if (!el._blockedAt) {
            el._blockedAt = Date.now();
        } else if (Date.now() - el._blockedAt > 5000) {
            el.classList.remove('addme-blocked');
            var ov = el.querySelector('.addme-overlay');
            if (ov) ov.remove();
            el._blockedAt = 0;
        }
    });
}, 1000);

// Снимаем страховочный таймаут из v1.0.12 (addme-timeout)
(function _killTimeout(){
    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('.lab-add, .day-task-addme, .dab-add, .dict-action-btn.danger')) {
            // После успешного ответа сервера всегда снимаем блокировку,
            // даже если какой-то таймер из v1.0.12 ещё не отстрелил.
            setTimeout(function(){
                document.querySelectorAll('.modal-content.addme-blocked').forEach(function(el){
                    el.classList.remove('addme-blocked');
                    var ov = el.querySelector('.addme-overlay');
                    if (ov) ov.remove();
                });
            }, 1200);
        }
    }, true);
})();

window.__trkDelLogTimeoutFix = true;
})();


/* ============================================================
   PATCH v1.0.21 — карточка задачи из календаря
   -------------------------------------------------------------
   1. При редактировании из отметки (dayModal → taskModal):
      v1.0.4 merge_log_data_into_task уже отработал, но пишет
      технические строки. Дополнительно клеймим в описание
      дату/автора через merge_extras в log/save.
   2. Кнопка «Сохранить» в taskModal отключает повторный
      показ «Выполняется/Завершено».
   ============================================================ */
(function(){
'use strict';
if (window.__trkEditTaskFromDayV1021) return;
window.__trkEditTaskFromDayV1021 = true;

// 1. Запрет повторных оверлеев поверх taskModal при сохранении задачи
(function _taskModalOverlay(){
    function _attach(){
        var tm = document.getElementById('taskModal');
        if (!tm || tm._v1021Saved) return;
        tm._v1021Saved = true;
        var saveBtn = document.getElementById('saveTaskBtn');
        if (!saveBtn) return;
        // Скрываем любые оверлеи v1.0.11/13 при начале сохранения
        saveBtn.addEventListener('click', function(){
            document.querySelectorAll('.addme-overlay').forEach(function(ov){ ov.remove(); });
            document.querySelectorAll('.modal-content.addme-blocked').forEach(function(el){
                el.classList.remove('addme-blocked');
            });
        }, true);
    }
    _attach();
    setTimeout(_attach, 600);
    setTimeout(_attach, 1500);
})();

// 2. Обёртка openTaskModal: если модалка открывается по задаче,
//    в которой уже есть описание/приказы/ссылки из отметок —
//    прокидываем признак «из отметки», чтобы saveTask дописал merge
(function _wrapOpenTaskModal(){
    function _apply(){
        if (typeof window.__trkOpenTaskModal !== 'function') return;
        if (window.__trkOpenTaskModal._v1021) return;
        var orig = window.__trkOpenTaskModal;
        var wrapped = function(task){
            var r = orig.apply(this, arguments);
            // Помечаем модалку, если она открыта из карточки дня/отметки
            var dm = document.getElementById('dayModal');
            var lm = document.getElementById('logModal');
            if ((dm && dm.classList.contains('active')) ||
                (lm && lm.classList.contains('active'))) {
                var tm = document.getElementById('taskModal');
                if (tm) tm.setAttribute('data-from-day-log', '1');
            }
            return r;
        };
        wrapped._v1021 = true;
        window.__trkOpenTaskModal = wrapped;
    }
    _apply();
    setTimeout(_apply, 500);
    setTimeout(_apply, 1500);
})();

// 3. На сохранение задачи — прокидываем merge_extras, если модалка
//    была открыта из отметки/карточки дня
(function _wrapSaveTask(){
    function _apply(){
        var saveBtn = document.getElementById('saveTaskBtn');
        if (!saveBtn || saveBtn._v1021) return;
        saveBtn._v1021 = true;
        saveBtn.addEventListener('click', function(){
            var tm = document.getElementById('taskModal');
            if (!tm) return;
            if (tm.getAttribute('data-from-day-log') === '1') {
                window.__trkTaskMergeFromDay = true;
                setTimeout(function(){ window.__trkTaskMergeFromDay = false; }, 5000);
            }
        }, true);
    }
    _apply();
    setTimeout(_apply, 800);
    setTimeout(_apply, 1800);
})();

// 4. Обёртка fetch на /api/tracker/task/save — если mergeFromDay,
//    добавляем merge_extras=1 (бэкенд v1.0.4/v1.0.21 сам запишет
//    человеческое «Обновлено <кто> <когда>» в описание)
var _native = window.fetch;
if (typeof _native === 'function' && !window.__trkTaskSaveMergeFetch) {
    window.__trkTaskSaveMergeFetch = true;
    window.fetch = function(url, opts){
        var isSave = (typeof url === 'string' && url.indexOf('/api/tracker/task/save') !== -1);
        var isPost = opts && (opts.method || 'GET').toUpperCase() === 'POST';
        if (!isSave || !isPost) return _native.apply(this, arguments);
        if (!window.__trkTaskMergeFromDay) return _native.apply(this, arguments);
        var _opts = opts;
        try {
            var b = JSON.parse(opts.body || '{}');
            b.merge_extras = 1;
            _opts = Object.assign({}, opts, { body: JSON.stringify(b) });
        } catch(e) {}
        return _native.call(this, url, _opts);
    };
}

window.__trkEditTaskFromDay = true;
})();

/* ============================================================
   PATCH 1.0.9 — переключатель вида задач (Плитка/Компактно/Список)
   Удаляет старую кнопку #tskCompactToggle от v1.0.12.
   ============================================================ */
(function(){
'use strict';
if (window.__trkTaskViewV109) return;
window.__trkTaskViewV109 = true;

var KEY = 'tracker_tsk_view';
var COLS_KEY = 'tracker_tsk_cols';

function _read(){
    try {
        var v = localStorage.getItem(KEY);
        if (v === 'tile' || v === 'compact' || v === 'list' || v === 'tree') return v;
    } catch(e){}
    return 'tile';
}
function _write(v){
    try { localStorage.setItem(KEY, v); } catch(e){}
    try { localStorage.setItem('tracker_tsk_compact', v === 'compact' ? '1' : '0'); } catch(e){}
}
function _readCols(){
    try {
        var n = parseInt(localStorage.getItem(COLS_KEY), 10);
        if (n >= 1 && n <= 5) return n;
    } catch(e){}
    return 3;
}
function _writeCols(n){
    try { localStorage.setItem(COLS_KEY, String(n)); } catch(e){}
}

function _removeOldBtn(){
    var old = document.getElementById('tskCompactToggle');
    if (old && old.parentNode) old.parentNode.removeChild(old);
}

function _apply(){
    var st = window.__trkState;
    if (!st) return;
    st.tskView = _read();
    st.tskCompactMode = (st.tskView === 'compact');
    st.tskGridCols = _readCols();
    var seg = document.getElementById('tskViewSeg');
    if (seg) {
        seg.querySelectorAll('button').forEach(function(b){
            b.classList.toggle('active', b.getAttribute('data-view') === st.tskView);
        });
    }
    var colsSel = document.getElementById('tskGridCols');
    if (colsSel && String(colsSel.value) !== String(st.tskGridCols)) {
        colsSel.value = String(st.tskGridCols);
    }
    if (typeof window.__trkRenderTasksFull === 'function') {
        try { window.__trkRenderTasksFull(); } catch(e){}
    }
}

function _wire(){
    _removeOldBtn();
    var seg = document.getElementById('tskViewSeg');
    if (seg && !seg._v109Wired) {
        seg._v109Wired = true;
        seg.addEventListener('click', function(e){
            var b = e.target.closest('button[data-view]');
            if (!b) return;
            var v = b.getAttribute('data-view');
            if (v !== 'tile' && v !== 'compact' && v !== 'list' && v !== 'tree') v = 'tile';
            _write(v);
            _apply();
        });
    }
    var colsSel = document.getElementById('tskGridCols');
    if (colsSel && !colsSel._v109ColsWired) {
        colsSel._v109ColsWired = true;
        colsSel.addEventListener('change', function(){
            var n = parseInt(this.value, 10) || 3;
            if (n < 1) n = 1;
            if (n > 5) n = 5;
            _writeCols(n);
            var st = window.__trkState;
            if (st) st.tskGridCols = n;
            if (typeof window.__trkRenderTasksFull === 'function') {
                try { window.__trkRenderTasksFull(); } catch(e){}
            }
        });
    }
    _apply();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function(){ setTimeout(_wire, 400); });
} else {
    setTimeout(_wire, 400);
}
setTimeout(_wire, 1200);
setTimeout(_wire, 2500);
setTimeout(_removeOldBtn, 3000);

document.addEventListener('click', function(e){
    if (!e.target || !e.target.closest) return;
    if (e.target.closest('.tracker-tab[data-tab="tasks"]')) {
        setTimeout(function(){
            _removeOldBtn();
            _wire();
        }, 250);
    }
});

window.__trkTaskView = {
    get: _read,
    set: function(v){ _write(v); _apply(); },
    apply: _apply
};

})();

/* ============================================================
   PATCH 1.0.19 — merge-чекбоксы во всех видах
   Плитка / Компактно: .task-card (справа сверху)
   Список: .dict-item (слева, с отступом)
   ============================================================ */
(function(){
'use strict';
if (window.__trkMergeFixV1019) return;
window.__trkMergeFixV1019 = true;

function _hasCb(card){
    for (var i = 0; i < card.children.length; i++) {
        var c = card.children[i];
        if (c && c.classList && c.classList.contains('task-merge-cb')) return true;
    }
    return false;
}

function _selectedIds(){
    var out = [];
    document.querySelectorAll('#tasksFullList .task-merge-cb:checked').forEach(function(cb){
        var id = cb.getAttribute('data-task-id');
        if (id) out.push(id);
    });
    return out;
}

function _updateBar(){
    var bar = document.getElementById('taskMergeBar');
    if (!bar) return;
    var n = _selectedIds().length;
    bar.style.display = n >= 2 ? '' : 'none';
    var c = document.getElementById('taskMergeCount');
    if (c) c.textContent = n;
}

function _attach(card){
    if (!card) return;
    if (_hasCb(card)) return;
    var id = card.getAttribute('data-id');
    if (!id) return;
    var cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.className = 'task-merge-cb';
    cb.setAttribute('data-task-id', id);
    cb.title = 'Выбрать для объединения';
    cb.addEventListener('click', function(e){ e.stopPropagation(); });
    cb.addEventListener('change', function(){
        if (this.checked) card.classList.add('task-card--merge-selected');
        else card.classList.remove('task-card--merge-selected');
        _updateBar();
    });
    card.insertBefore(cb, card.firstChild);
}

function _scan(){
    var list = document.getElementById('tasksFullList');
    if (!list) return;
    // Плитка и компактно
    list.querySelectorAll('.task-card').forEach(_attach);
    // Список
    list.querySelectorAll('.dict-item').forEach(_attach);
    _updateBar();
}

function _ensureBar(){
    var panel = document.getElementById('panel-tasks');
    if (!panel) return;
    if (document.getElementById('taskMergeBar')) return;
    var toolbar = panel.querySelector('.sum-toolbar');
    if (!toolbar) return;
    var bar = document.createElement('div');
    bar.id = 'taskMergeBar';
    bar.className = 'task-merge-bar';
    bar.style.display = 'none';
    bar.innerHTML = '<span>🔗 Выбрано <b id="taskMergeCount">0</b> задач</span>'
        + '<button type="button" class="btn btn-primary" id="taskMergeBtn">Объединить</button>'
        + '<button type="button" class="btn btn-secondary" id="taskMergeClear">Сбросить</button>';
    toolbar.parentNode.insertBefore(bar, toolbar.nextSibling);
    document.getElementById('taskMergeBtn').addEventListener('click', function(){
        if (typeof window.__trkTaskMergeOpen === 'function') {
            try { window.__trkTaskMergeOpen(); return; } catch(e){ console.error('[merge-fix]', e); }
        }
        var ids = _selectedIds();
        if (ids.length < 2) { alert('Выберите минимум 2 задачи'); return; }
        alert('Модуль объединения не инициализирован. Обновите страницу (Ctrl+F5).');
    });
    document.getElementById('taskMergeClear').addEventListener('click', function(){
        document.querySelectorAll('#tasksFullList .task-merge-cb:checked').forEach(function(cb){ cb.checked = false; });
        document.querySelectorAll('#tasksFullList .task-card--merge-selected').forEach(function(c){ c.classList.remove('task-card--merge-selected'); });
        _updateBar();
    });
}

function _hookList(){
    var list = document.getElementById('tasksFullList');
    if (!list || list._mergeFixHooked) return;
    list._mergeFixHooked = true;
    new MutationObserver(function(){ setTimeout(_scan, 30); })
        .observe(list, { childList: true });
    _scan();
}

function _boot(){
    _ensureBar();
    _hookList();
    _scan();
    setTimeout(function(){ _ensureBar(); _hookList(); _scan(); }, 500);
    setTimeout(function(){ _ensureBar(); _hookList(); _scan(); }, 1500);
    setTimeout(function(){ _ensureBar(); _hookList(); _scan(); }, 3000);
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', _boot);
} else {
    _boot();
}

document.addEventListener('click', function(e){
    if (!e.target || !e.target.closest) return;
    if (e.target.closest('.tracker-tab[data-tab="tasks"]')) {
        setTimeout(function(){ _ensureBar(); _hookList(); _scan(); }, 250);
    }
    if (e.target.closest('#tskViewSeg button')) {
        setTimeout(_scan, 100);
        setTimeout(_scan, 400);
    }
});

window.__trkMergeFixScan = _scan;
})();

/* ============================================================
   PATCH 1.0.23 v2 — «Назначено на день»: кнопка «+»
   - Сама плитка .dab-tile не кликабельна (CSS pointer-events)
   - Кнопка .dab-add: сохраняет отметку от имени currentUser
     или открывает logModal с предзаполнением (для админа)
   ============================================================ */
(function(){
'use strict';
if (window.__trkDabFixV1023b) return;
window.__trkDabFixV1023b = true;

function _st(){ return window.__trkState || null; }
function _notify(msg, kind){
    if (typeof window.__trackerNotify === 'function') {
        try { window.__trackerNotify(msg, kind); return; } catch(e){}
    }
}
function _csrf(){
    try { return window.REESTR_CSRF || ''; } catch(e){ return ''; }
}

function _saveDirect(tid, empId, tile){
    var st = _st();
    if (!st) return;
    var dk = st.currentDay;
    if (!dk) return;
    var day = (st.calendar && st.calendar.days)
        ? st.calendar.days.find(function(d){ return d.date === dk; })
        : null;
    var n = 0;
    (day && day.entries || []).forEach(function(en){
        if (en.employee_id === empId) n++;
    });
    var hrs = Math.round((((window.__trkGetDayNorm ? window.__trkGetDayNorm(dk) : 8) || 8) / (n + 1)) * 4) / 4;
    if (hrs < 0.5) hrs = 0.5;
    if (hrs > 24) hrs = 24;

    var btn = tile ? tile.querySelector('.dab-add') : null;
    if (btn) { btn.disabled = true; btn.textContent = '⏳'; }

    var hdrs = {'Content-Type': 'application/json'};
    if (_csrf()) hdrs['X-CSRF-Token'] = _csrf();

    fetch('/api/tracker/log/save', {
        method: 'POST', headers: hdrs, credentials: 'same-origin',
        body: JSON.stringify({
            employee_id: empId,
            task_id: tid,
            date: dk,
            hours: hrs,
            status: 'in_progress',
            comment: '',
            link: ''
        })
    })
    .then(function(r){ return r.json().then(function(j){ return {ok: r.ok, d: j}; }); })
    .then(function(res){
        if (!res.ok || !res.d || !res.d.success) {
            if (res.d && res.d.error && res.d.error !== 'cancelled') {
                _notify('❌ ' + res.d.error, 'error');
            }
            if (btn) { btn.disabled = false; btn.textContent = '+ Добавить'; }
            return;
        }
        _notify('✅ Отметка добавлена');
        var dm = document.getElementById('dayModal');
        if (dm) dm.classList.remove('active');
        var _refresh = (typeof window.__trkRefreshAll === 'function')
            ? window.__trkRefreshAll
            : (typeof window.__trkRenderCalendar === 'function' ? window.__trkRenderCalendar : null);
        if (_refresh) { Promise.resolve(_refresh()); }
    })
    .catch(function(err){
        if (err && err.message && err.message.indexOf('cancelled') !== -1) return;
        _notify('❌ ' + (err.message || 'Ошибка'), 'error');
        if (btn) { btn.disabled = false; btn.textContent = '+ Добавить'; }
    });
}

function _openLogForTask(tid){
    var st = _st();
    if (!st) return;
    var dk = st.currentDay;
    if (typeof window.__trkOpenLogModal !== 'function') return;
    var dm = document.getElementById('dayModal');
    if (dm) dm.classList.remove('active');
    setTimeout(function(){
        try {
            window.__trkOpenLogModal({
                id: null,
                employee_id: '',
                task_id: tid,
                date: dk,
                hours: 8,
                status: 'in_progress',
                comment: '',
                link: ''
            });
        } catch (e) { console.error('[dab-fix]', e); }
    }, 100);
}

function _onAddClick(e){
    var btn = e.target && e.target.closest ? e.target.closest('.day-assigned-block .dab-add') : null;
    if (!btn) return;
    var tile = btn.closest('.dab-tile');
    if (!tile) return;
    var tid = tile.getAttribute('data-task-id');
    if (!tid) return;
    if (btn.disabled) return;

    e.preventDefault();
    e.stopPropagation();
    if (e.stopImmediatePropagation) e.stopImmediatePropagation();

    var st = _st();
    if (!st) return;
    var me = st.currentUser && st.currentUser.employee_id;
    var lm = document.getElementById('logModal');
    var logSel = lm ? document.getElementById('log_employee') : null;
    var logEmp = logSel ? (logSel.value || '') : '';
    var empId = me || logEmp;

    if (empId) {
        _saveDirect(tid, empId, tile);
    } else {
        // Админ без привязки — открываем карточку отметки с предзаполнением
        _openLogForTask(tid);
    }
}

// Единый capture-обработчик на документе
document.addEventListener('click', _onAddClick, true);

// Дублируем на mouseup — на случай, если click не доходит
document.addEventListener('mouseup', function(e){
    if (!e.target || !e.target.closest) return;
    var btn = e.target.closest('.day-assigned-block .dab-add');
    if (!btn) return;
    if (btn._dabHandled) {
        btn._dabHandled = false;
        return;
    }
}, true);

// Помечаем, что клик обработан (чтобы mouseup не дублировал)
document.addEventListener('click', function(e){
    if (e.target && e.target.closest && e.target.closest('.day-assigned-block .dab-add')) {
        e.target.closest('.dab-add')._dabHandled = true;
    }
}, false);

window.__trkDabAddDirect = _saveDirect;
window.__trkDabOpenLog = _openLogForTask;
})();

/* ============================================================
   PATCH 1.0.27 — «Назначено на день»: кнопка «+»
   Обработчик на window capture — срабатывает раньше document-обработчиков.
   Плитка сама (pointer-events: none) — кликабельна только кнопка.
   ============================================================ */
(function(){
'use strict';
if (window.__trkDabFixV1027) return;
window.__trkDabFixV1027 = true;

function _st(){ return window.__trkState || null; }
function _notify(msg, kind){
    if (typeof window.__trackerNotify === 'function') {
        try { window.__trackerNotify(msg, kind); return; } catch(e){}
    }
}
function _csrf(){ try { return window.REESTR_CSRF || ''; } catch(e){ return ''; } }

function _saveDirect(tid, empId, tile){
    var st = _st();
    if (!st) return;
    var dk = st.currentDay;
    if (!dk) { _notify('❌ Не выбран день', 'error'); return; }
    var day = (st.calendar && st.calendar.days)
        ? st.calendar.days.find(function(d){ return d.date === dk; })
        : null;
    var n = 0;
    (day && day.entries || []).forEach(function(en){
        if (en.employee_id === empId) n++;
    });
    var hrs = Math.round((((window.__trkGetDayNorm ? window.__trkGetDayNorm(dk) : 8) || 8) / (n + 1)) * 4) / 4;
    if (hrs < 0.5) hrs = 0.5;
    if (hrs > 24) hrs = 24;

    var btn = tile ? tile.querySelector('.dab-add') : null;
    if (btn) { btn.disabled = true; btn.textContent = '⏳ Сохранение…'; }

    var hdrs = {'Content-Type': 'application/json'};
    if (_csrf()) hdrs['X-CSRF-Token'] = _csrf();

    console.log('[dab-fix] saving tid=' + tid + ' emp=' + empId + ' date=' + dk + ' hours=' + hrs);

    fetch('/api/tracker/log/save', {
        method: 'POST', headers: hdrs, credentials: 'same-origin',
        body: JSON.stringify({
            employee_id: empId,
            task_id: tid,
            date: dk,
            hours: hrs,
            status: 'in_progress',
            comment: '',
            link: ''
        })
    })
    .then(function(r){ return r.json().then(function(j){ return {ok: r.ok, d: j}; }); })
    .then(function(res){
        console.log('[dab-fix] response', res);
        if (!res.ok || !res.d || !res.d.success) {
            if (res.d && res.d.error && res.d.error !== 'cancelled') {
                _notify('❌ ' + res.d.error, 'error');
            }
            if (btn) { btn.disabled = false; btn.textContent = '+ Добавить'; }
            return;
        }
        _notify('✅ Отметка добавлена');
        var dm = document.getElementById('dayModal');
        if (dm) dm.classList.remove('active');
        var _refresh = (typeof window.__trkRefreshAll === 'function')
            ? window.__trkRefreshAll
            : (typeof window.__trkRenderCalendar === 'function' ? window.__trkRenderCalendar : null);
        if (_refresh) { Promise.resolve(_refresh()); }
    })
    .catch(function(err){
        console.error('[dab-fix] error', err);
        if (err && err.message && err.message.indexOf('cancelled') !== -1) return;
        _notify('❌ ' + (err.message || 'Ошибка'), 'error');
        if (btn) { btn.disabled = false; btn.textContent = '+ Добавить'; }
    });
}

function _openLogForTask(tid){
    var st = _st();
    if (!st) return;
    var dk = st.currentDay;
    var dm = document.getElementById('dayModal');
    if (dm) dm.classList.remove('active');
    setTimeout(function(){
        try {
            if (typeof window.__trkOpenLogModal === 'function') {
                window.__trkOpenLogModal({
                    id: null, employee_id: '', task_id: tid, date: dk,
                    hours: 8, status: 'in_progress', comment: '', link: ''
                });
                return;
            }
        } catch(e){ console.error('[dab-fix] openLog failed', e); }
        _notify('⚠ Выберите сотрудника вручную', 'error');
    }, 150);
}

function _onAddClick(e){
    if (!e.target || !e.target.closest) return;
    var btn = e.target.closest('.day-assigned-block .dab-add');
    if (!btn) return;
    var tile = btn.closest('.dab-tile');
    if (!tile) return;
    var tid = tile.getAttribute('data-task-id');
    if (!tid) return;
    if (btn.disabled) return;

    e.preventDefault();
    e.stopPropagation();
    if (e.stopImmediatePropagation) e.stopImmediatePropagation();

    var st = _st();
    if (!st) return;
    var me = st.currentUser && st.currentUser.employee_id;

    if (me) {
        _saveDirect(tid, me, tile);
    } else {
        var lm = document.getElementById('logModal');
        var logSel = lm ? document.getElementById('log_employee') : null;
        var logEmp = logSel ? (logSel.value || '') : '';
        if (logEmp) {
            _saveDirect(tid, logEmp, tile);
        } else {
            _openLogForTask(tid);
        }
    }
}

/* window capture — раньше всех document-обработчиков */
window.addEventListener('click', _onAddClick, true);

window.__trkDabAddDirect = _saveDirect;
window.__trkDabOpenLog = _openLogForTask;
})();

/* ============================================================
   PATCH 1.0.29 — надёжная кнопка «+» в блоке «Назначено на день»
   Клонирует .dab-tile, чтобы снять все старые listener-ы
   (конфликты от патча 23, v1.0.3, v1.0.16, v1.0.27).
   ============================================================ */
(function(){
'use strict';
if (window.__trkDabFixV1029) return;
window.__trkDabFixV1029 = true;

function _st(){ return window.__trkState || null; }
function _notify(msg, kind){
    if (typeof window.__trackerNotify === 'function') {
        try { window.__trackerNotify(msg, kind); return; } catch(e){}
    }
}
function _csrf(){ try { return window.REESTR_CSRF || ''; } catch(e){ return ''; } }

function _save(tid, empId){
    var st = _st();
    if (!st) return;
    var dk = st.currentDay;
    if (!dk) { _notify('❌ Не выбран день', 'error'); return; }
    var day = (st.calendar && st.calendar.days)
        ? st.calendar.days.find(function(d){ return d.date === dk; })
        : null;
    var n = 0;
    (day && day.entries || []).forEach(function(en){
        if (en.employee_id === empId) n++;
    });
    var hrs = Math.round((((window.__trkGetDayNorm ? window.__trkGetDayNorm(dk) : 8) || 8) / (n + 1)) * 4) / 4;
    if (hrs < 0.5) hrs = 0.5;
    if (hrs > 24) hrs = 24;

    var hdrs = {'Content-Type': 'application/json'};
    if (_csrf()) hdrs['X-CSRF-Token'] = _csrf();

    _notify('⏳ Сохраняю…');

    fetch('/api/tracker/log/save', {
        method: 'POST', headers: hdrs, credentials: 'same-origin',
        body: JSON.stringify({
            employee_id: empId,
            task_id: tid,
            date: dk,
            hours: hrs,
            status: 'in_progress',
            comment: '',
            link: '',
            merge_into_task: 1
        })
    })
    .then(function(r){ return r.json().then(function(j){ return {ok: r.ok, d: j}; }); })
    .then(function(res){
        if (!res.ok || !res.d || !res.d.success) {
            if (res.d && res.d.error && res.d.error !== 'cancelled') {
                _notify('❌ ' + res.d.error, 'error');
            } else {
                _notify('❌ Ошибка сохранения', 'error');
            }
            return;
        }
        _notify('✅ Отметка добавлена');
        ['dayModal', 'logModal'].forEach(function(id){
            var m = document.getElementById(id);
            if (m && m.classList.contains('active')) m.classList.remove('active');
        });
        var _refresh = (typeof window.__trkRefreshAll === 'function')
            ? window.__trkRefreshAll
            : (typeof window.__trkRenderCalendar === 'function' ? window.__trkRenderCalendar : null);
        if (_refresh) { Promise.resolve(_refresh()); }
    })
    .catch(function(err){
        if (err && err.message && err.message.indexOf('cancelled') !== -1) return;
        _notify('❌ ' + (err.message || 'Ошибка'), 'error');
    });
}

function _handleClick(tile, e){
    e.preventDefault();
    e.stopPropagation();
    if (e.stopImmediatePropagation) e.stopImmediatePropagation();
    var tid = tile.getAttribute('data-task-id');
    if (!tid) { _notify('❌ Задача не найдена', 'error'); return; }
    var st = _st();
    var me = st && st.currentUser && st.currentUser.employee_id;
    if (me) {
        _save(tid, me);
    } else {
        // Админ без привязки — открываем карточку отметки
        var dm = document.getElementById('dayModal');
        if (dm) dm.classList.remove('active');
        setTimeout(function(){
            if (typeof window.__trkOpenLogModal === 'function') {
                try {
                    window.__trkOpenLogModal({
                        id: null, employee_id: '', task_id: tid,
                        date: (st && st.currentDay) || '', hours: 8,
                        status: 'in_progress', comment: '', link: ''
                    });
                } catch(e){ console.error('[dab-v1029] openLog', e); }
            }
        }, 100);
    }
}

function _refresh(){
    var list = document.getElementById('dayList');
    if (!list) return;
    var tiles = list.querySelectorAll('.dab-tile');
    tiles.forEach(function(tile){
        if (tile._v1029Cloned) return;
        // Клонируем — снимаем ВСЕ старые listener-ы
        var fresh = tile.cloneNode(true);
        fresh._v1029Cloned = true;
        tile.parentNode.replaceChild(fresh, tile);
        var btn = fresh.querySelector('.dab-add');
        if (!btn) return;
        // На всякий случай форсируем кликабельность
        try {
            btn.style.pointerEvents = 'auto';
            btn.style.cursor = 'pointer';
            btn.style.transform = 'none';
        } catch(e){}
        btn.addEventListener('click', function(e){
            _handleClick(fresh, e);
        }, true);
    });
}

function _observe(){
    var list = document.getElementById('dayList');
    if (!list || list._dabObsV1029) return;
    list._dabObsV1029 = true;
    new MutationObserver(function(){ setTimeout(_refresh, 30); })
        .observe(list, { childList: true, subtree: true });
    setTimeout(_refresh, 100);
}

function _boot(){
    _observe();
    setTimeout(function(){ _observe(); _refresh(); }, 300);
    setTimeout(function(){ _observe(); _refresh(); }, 1000);
    setTimeout(function(){ _observe(); _refresh(); }, 2500);
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', _boot);
} else {
    _boot();
}

// Триггер при открытии dayModal
var _dmEl = document.getElementById('dayModal');
if (_dmEl) {
    new MutationObserver(function(){
        if (_dmEl.classList.contains('active')) {
            setTimeout(_refresh, 60);
            setTimeout(_refresh, 300);
            setTimeout(_refresh, 800);
        }
    }).observe(_dmEl, { attributes: true, attributeFilter: ['class'] });
}

window.__trkDabRefreshV1029 = _refresh;
window.__trkDabSaveV1029 = _save;
})();

/* ============================================================
   PATCH 1.0.31 — жёсткая зачистка оверлеев удаления
   Не зависит от состояния #trkDelLogOverlayV1018.
   Каждые 500 мс: если оверлей висит > 3 сек — удаляется.
   ============================================================ */
(function(){
'use strict';
if (window.__trkDelLogForceCleanV1031) return;
window.__trkDelLogForceCleanV1031 = true;

var MAX_AGE_MS = 3000;  // если оверлей живёт дольше 3 сек — удаляем

function _nukeAll(){
    // 1) v1.0.18-overlay
    document.querySelectorAll('#trkDelLogOverlayV1018, .trk-del-log-overlay').forEach(function(ov){
        try { ov.remove(); } catch(e) { if (ov.parentNode) ov.parentNode.removeChild(ov); }
    });
    // 2) v1.0.11/v1.0.13 overlay
    document.querySelectorAll('.addme-overlay').forEach(function(ov){
        try { ov.remove(); } catch(e) { if (ov.parentNode) ov.parentNode.removeChild(ov); }
    });
    // 3) Классы блокировки
    document.querySelectorAll('.modal-content.addme-blocked').forEach(function(el){
        el.classList.remove('addme-blocked');
    });
    // 4) Контексты
    try { window.__trkDelLogCtxV1018 = null; } catch(e){}
    try { window.__trkDelLogCtx = null; } catch(e){}
    try { window.__trkAddMeCtx = null; } catch(e){}
    try { window.__trkDelLogCtxV1018 = null; } catch(e){}
    try { window.__trkDelLogSuppressLoader = false; } catch(e){}
}

function _ageCheck(){
    document.querySelectorAll('#trkDelLogOverlayV1018, .trk-del-log-overlay, .addme-overlay').forEach(function(ov){
        if (!ov._shownAt) { ov._shownAt = Date.now(); return; }
        var age = Date.now() - ov._shownAt;
        var cls = ov.className || '';
        var isFinal = cls.indexOf('trk-dlo-success') !== -1
                   || cls.indexOf('trk-dlo-error') !== -1
                   || cls.indexOf('addme-success') !== -1
                   || cls.indexOf('addme-error') !== -1;
        // success/error — удаляем через 1.2 сек; processing — через MAX_AGE_MS
        var limit = isFinal ? 1200 : MAX_AGE_MS;
        if (age > limit) {
            console.warn('[del-log-cleanup] force remove overlay (age=' + Math.round(age) + 'ms, cls=' + cls + ')');
            try { ov.remove(); } catch(e) {}
        }
    });
}

/* Watchdog — каждые 500 мс */
setInterval(_ageCheck, 500);

/* Перехват fetch log/delete — после любого ответа через 2 сек зачищаем всё */
(function(){
    var _native = window.fetch;
    if (typeof _native !== 'function') return;
    window.fetch = function(url, opts){
        var isDel = (typeof url === 'string' && url.indexOf('/api/tracker/log/delete') !== -1);
        var isPost = opts && (opts.method || 'GET').toUpperCase() === 'POST';
        if (!isDel || !isPost) {
            return _native.apply(this, arguments);
        }
        var p = _native.apply(this, arguments);
        return p.then(
            function(r){
                setTimeout(_nukeAll, 2000);
                return r;
            },
            function(err){
                setTimeout(_nukeAll, 2000);
                throw err;
            }
        );
    };
})();

/* Esc и клик по любому оверлею — удаляем */
document.addEventListener('keydown', function(e){
    if (e.key === 'Escape') {
        setTimeout(_nukeAll, 100);
    }
}, true);

document.addEventListener('click', function(e){
    if (!e.target) return;
    var ov = e.target.closest ? e.target.closest('.trk-del-log-overlay, #trkDelLogOverlayV1018') : null;
    if (ov && (ov.classList.contains('trk-dlo-success') || ov.classList.contains('trk-dlo-error'))) {
        ov.remove();
    }
}, true);

/* При закрытии модалки — зачищаем */
['dayModal', 'logModal'].forEach(function(id){
    var m = document.getElementById(id);
    if (!m) return;
    new MutationObserver(function(){
        if (!m.classList.contains('active')) _nukeAll();
    }).observe(m, { attributes: true, attributeFilter: ['class'] });
});

/* Публичный ручной вызов — из консоли */
window.__trkForceCleanOverlays = _nukeAll;

/* Дополнительная защита: сразу после load, на всякий случай, зачистить */
setTimeout(_nukeAll, 1000);
})();

/* ============================================================
   PATCH 1.0.32 — надёжная отправка multi-полей отметки
   Читаем extra_data / orders / links прямо из DOM формы.
   Работает и при создании, и при редактировании отметки.
   ============================================================ */
(function(){
'use strict';
if (window.__trkMultiFieldsFixV1032) return;
window.__trkMultiFieldsFixV1032 = true;

var _native = window.fetch;
if (typeof _native !== 'function') return;

function _collectExtra(){
    var box = document.getElementById('logExtraDataList');
    if (!box) return [];
    var out = [];
    box.querySelectorAll('.task-link-row input[type="text"]').forEach(function(inp){
        var v = (inp.value || '').trim();
        if (v) out.push(v);
    });
    return out;
}

function _collectOrders(){
    var box = document.getElementById('logOrdersList');
    if (!box) return [];
    var out = [];
    box.querySelectorAll('.task-link-row').forEach(function(row){
        var d = row.querySelector('.task-order-desc');
        var v = row.querySelector('.task-order-val');
        var vv = v ? (v.value || '').trim() : '';
        if (vv) out.push({ description: d ? (d.value || '').trim() : '', value: vv });
    });
    return out;
}

function _collectLinks(){
    var box = document.getElementById('logLinksList');
    if (!box) return [];
    var out = [];
    box.querySelectorAll('.task-link-row').forEach(function(row){
        var d = row.querySelector('.task-link-desc');
        var u = row.querySelector('.task-link-url');
        var uu = u ? (u.value || '').trim() : '';
        if (uu) out.push({ description: d ? (d.value || '').trim() : '', url: uu });
    });
    return out;
}

window.fetch = function(url, opts){
    var isLogSave = (typeof url === 'string' && url.indexOf('/api/tracker/log/save') !== -1);
    var isPost = opts && (opts.method || 'GET').toUpperCase() === 'POST';
    if (!isLogSave || !isPost) {
        return _native.apply(this, arguments);
    }
    try {
        var body = JSON.parse(opts.body || '{}');
        // Собираем multi-поля из DOM (всегда, для создания и правки)
        var extra = _collectExtra();
        var orders = _collectOrders();
        var links = _collectLinks();
        // Если в форме есть данные — шлём их
        if (extra.length) body.extra_data = extra;
        if (orders.length) body.orders = orders;
        if (links.length) body.links = links;
        // PATCH v1.1.2: merge в задачу просим только при СОЗДАНИИ отметки,
        // при правке — нет (см. фикс множественного вложения)
        if (!body.id) body.merge_into_task = 1;
        // Описание из textarea (на случай, если saveLog его не собрал)
        var ta = document.getElementById('log_comment');
        if (ta && !body.comment) body.comment = (ta.value || '').trim();
        if (ta && !body.description) body.description = (ta.value || '').trim();
        opts = Object.assign({}, opts, { body: JSON.stringify(body) });
    } catch(e) {
        console.error('[multifields-fix]', e);
    }
    return _native.call(this, url, opts);
};

window.__trkCollectLogMultiFields = function(){
    return { extra: _collectExtra(), orders: _collectOrders(), links: _collectLinks() };
};

})();

/* PATCH v1.1.2: чистимостатки DOM-ссылки на удалённое поле «Доп. данные»
   в модалке отметки (кнопка ➕ и лист больше не нужны). */
(function(){
    function _cleanExtraDom(){
        var box = document.getElementById('logExtraDataList');
        if (box && box.parentNode) box.parentNode.remove();
        var btn = document.getElementById('logExtraAddBtn');
        if (btn && btn.parentNode) btn.parentNode.remove();
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', _cleanExtraDom);
    else _cleanExtraDom();
})();

/* ============================================================
   PATCH 1.0.1 — единый перехватчик /api/tracker/log/save
   Guard: __trkLogSaveUnifiedV1101 (старый __trkLogSaveUnifiedV1035 отключён
   через prepend-guard, поэтому старый блок B3 остаётся в файле, но не запускается)
   ============================================================ */
(function(){
'use strict';
if (window.__trkLogSaveUnifiedV1101) return;
window.__trkLogSaveUnifiedV1101 = true;

var _native = window.fetch;
if (typeof _native !== 'function') return;

function _csrf(){ try { return window.REESTR_CSRF || ''; } catch(e){ return ''; } }
function _collectExtra(){
    var box = document.getElementById('logExtraDataList');
    if (!box) return [];
    var out = [];
    box.querySelectorAll('.task-link-row input[type="text"]').forEach(function(inp){
        var v = (inp.value || '').trim();
        if (v) out.push(v);
    });
    return out;
}
function _collectOrders(){
    var box = document.getElementById('logOrdersList');
    if (!box) return [];
    var out = [];
    box.querySelectorAll('.task-link-row').forEach(function(row){
        var d = row.querySelector('.task-order-desc');
        var v = row.querySelector('.task-order-val');
        var vv = v ? (v.value || '').trim() : '';
        if (vv) out.push({ description: d ? (d.value || '').trim() : '', value: vv });
    });
    return out;
}
function _collectLinks(){
    var box = document.getElementById('logLinksList');
    if (!box) return [];
    var out = [];
    box.querySelectorAll('.task-link-row').forEach(function(row){
        var d = row.querySelector('.task-link-desc');
        var u = row.querySelector('.task-link-url');
        var uu = u ? (u.value || '').trim() : '';
        if (uu) out.push({ description: d ? (d.value || '').trim() : '', url: uu });
    });
    return out;
}
function _enrichBody(body){
    var extra = _collectExtra();
    var orders = _collectOrders();
    var links = _collectLinks();
    if (extra.length) body.extra_data = extra;
    if (orders.length) body.orders = orders;
    if (links.length) body.links = links;
    var ta = document.getElementById('log_comment');
    if (ta) {
        if (!body.comment) body.comment = (ta.value || '').trim();
        if (!body.description) body.description = (ta.value || '').trim();
    }
    // PATCH v1.1.2: merge только при создании новой отметки
    if (!body.id) body.merge_into_task = 1;
    return body;
}
function _getOverflowModal(){
    var m = document.getElementById('trkOverflowModal');
    if (m) return m;
    m = document.createElement('div');
    m.id = 'trkOverflowModal';
    m.className = 'modal trk-overflow-modal';
    m.style.setProperty('z-index', '9000', 'important');
    m.innerHTML = '<div class="modal-content ov-modal">'
        + '<div class="ov-head"><span class="ov-icon">⚠</span>'
        + '<div class="ov-title-block"><div class="ov-title">Превышение 8 часов за день</div>'
        + '<div class="ov-sub" id="trkOvSub"></div></div></div>'
        + '<div class="ov-numbers" id="trkOvNumbers"></div>'
        + '<div class="ov-note"><b>Принять</b> — сохранить как введено. <b>Распределить</b> — поделить 8 часов между всеми задачами дня поровну.</div>'
        + '<label class="ov-remember"><input type="checkbox" id="trkOvRemember"><span>Запомнить выбор на эту сессию</span></label>'
        + '<div class="ov-actions"><button type="button" class="btn btn-secondary" data-ov="cancel">Закрыть</button>'
        + '<button type="button" class="btn btn-secondary" data-ov="distribute">Распределить</button>'
        + '<button type="button" class="btn btn-primary" data-ov="accept">Принять</button></div>'
        + '</div>';
    document.body.appendChild(m);
    return m;
}
function _showOverflow(info){
    return new Promise(function(resolve){
        var SK = 'tracker_overflow_choice_v2';
        var stored = '';
        try { stored = sessionStorage.getItem(SK) || ''; } catch(e){}
        if (stored === 'accept' || stored === 'distribute') { resolve(stored); return; }
        var m = _getOverflowModal();
        var sub = m.querySelector('#trkOvSub');
        var nums = m.querySelector('#trkOvNumbers');
        var remember = m.querySelector('#trkOvRemember');
        var _ovNorm = (typeof info.day_norm === 'number') ? info.day_norm : 8;
        var _isNonWork = !!(info.is_weekend || info.is_holiday);
        if (sub) {
            var _subTxt = (info.employee_name || 'Сотрудник') + ' · ' + (info.date || '');
            if (_isNonWork) _subTxt += (info.is_holiday ? ' · 🎉 праздник' : ' · выходной');
            sub.textContent = _subTxt;
        }
        var _ovTitleEl = m.querySelector('.ov-title');
        if (_ovTitleEl) {
            _ovTitleEl.textContent = _isNonWork
                ? (info.is_holiday ? '🎉 Работа в праздник' : '📅 Работа в выходной')
                : 'Превышение нормы дня';
        }
        var _distBtn0 = m.querySelector('[data-ov="distribute"]');
        if (_distBtn0) _distBtn0.style.display = _isNonWork ? 'none' : '';
        var over = (info.total || 0) - _ovNorm;
        function fh(x){ var v = Math.round((x || 0) * 100) / 100; return (v === Math.floor(v) ? v : v.toFixed(2).replace(/0+$/, '').replace(/\.$/, '')) + ' ч'; }
        if (nums) nums.innerHTML = '<div class="ov-num-row"><span class="ov-num-label">Уже за день</span><span class="ov-num-val">' + fh(info.sum_existing) + '</span></div>'
            + '<div class="ov-num-row"><span class="ov-num-label">Новая отметка</span><span class="ov-num-val">' + fh(info.new_hours) + '</span></div>'
            + '<div class="ov-num-sep"></div>'
            + '<div class="ov-num-row ov-num-total"><span class="ov-num-label">Итого будет</span><span class="ov-num-val ov-danger">' + fh(info.total) + '</span></div>'
            + '<div class="ov-num-row ov-num-warn"><span class="ov-num-label">Переработка</span><span class="ov-num-val">' + fh(over) + '</span></div>';
        m.classList.add('active');
        var resolved = false;
        function finish(choice){
            if (resolved) return;
            resolved = true;
            m.classList.remove('active');
            m.removeEventListener('click', onClick);
            if (choice !== 'cancel' && remember && remember.checked) {
                try { sessionStorage.setItem(SK, choice); } catch(e){}
            }
            resolve(choice);
        }
        function onClick(e){
            if (e.target === m) { finish('cancel'); return; }
            var b = e.target.closest && e.target.closest('[data-ov]');
            if (!b) return;
            finish(b.getAttribute('data-ov'));
        }
        m.addEventListener('click', onClick);
    });
}
function _onSuccess(body, d){
    try {
        if (body.employee_id && body.task_id) {
            var st = window.__trkState || {};
            var task = (st.tasks || []).find(function(t){ return t.id === body.task_id; });
            if (task) {
                var cur = Array.isArray(task.assignees) ? task.assignees.slice() : [];
                if (cur.indexOf(body.employee_id) === -1) {
                    cur.push(body.employee_id);
                    var payload = { id: task.id, name: task.name || '', icon: task.icon || '📋', description: task.description || '', status: task.status || 'active', start_date: task.start_date || '', deadline: task.deadline || '', completed_at: task.completed_at || '', folder: task.folder || '', order_ref: task.order_ref || '', tags: (task.tags || []).slice(), assignees: cur, department_ids: (task.department_ids || []).slice(), is_urgent: !!task.is_urgent, links: (task.links || []).slice(), orders: (task.orders || []).slice() };
                    var hdrs = {'Content-Type': 'application/json'};
                    if (_csrf()) hdrs['X-CSRF-Token'] = _csrf();
                    _native('/api/tracker/task/save', { method: 'POST', headers: hdrs, credentials: 'same-origin', body: JSON.stringify(payload) }).catch(function(){});
                    task.assignees = cur;
                }
            }
        }
    } catch (e) { console.error('[unified-log-save] auto-assign', e); }
    ['logModal', 'dayModal', 'taskModal'].forEach(function(id){
        var m = document.getElementById(id);
        if (m && m.classList.contains('active')) m.classList.remove('active');
    });
    var _refresh = (typeof window.__trkRefreshAll === 'function') ? window.__trkRefreshAll : (typeof window.__trkRenderCalendar === 'function' ? window.__trkRenderCalendar : null);
    if (_refresh) { setTimeout(function(){ Promise.resolve(_refresh()); }, 80); }
}
window.fetch = function(url, opts){
    var isLogSave = (typeof url === 'string' && url.indexOf('/api/tracker/log/save') !== -1);
    var isPost = opts && (opts.method || 'GET').toUpperCase() === 'POST';
    if (!isLogSave || !isPost) return _native.apply(this, arguments);
    var body = {};
    try { body = JSON.parse(opts.body || '{}'); } catch (e) {}
    body = _enrichBody(body);
    var self = this;
    var newOpts = Object.assign({}, opts, { body: JSON.stringify(body) });
    return _native.call(self, url, newOpts).then(function(r){
        if (r.status === 409) {
            return r.clone().json().then(function(d){
                if (d && d.error === 'daily_overflow') {
                    var info = { sum_existing: d.sum_existing || 0, new_hours: d.new_hours || 0, total: d.total || 0, employee_name: d.employee_name || '', date: d.date || body.date || '' };
                    if (!info.employee_name) { var st = window.__trkState || {}; var emp = (st.employees || []).find(function(e){ return e.id === body.employee_id; }); if (emp) info.employee_name = emp.name; }
                    if (!info.date) info.date = body.date || '';
                    return _showOverflow(info).then(function(choice){
                        if (choice === 'cancel') return new Response(JSON.stringify({success: false, error: 'cancelled'}), { status: 200, headers: {'Content-Type': 'application/json'} });
                        var payload = Object.assign({}, body, { overflow_action: choice === 'accept' ? 'accept' : 'distribute' });
                        var retryOpts = Object.assign({}, opts, { body: JSON.stringify(payload) });
                        return _native.call(self, url, retryOpts);
                    });
                }
                if (d && d.error === 'already_logged_today') {
                    var msg = 'У сотрудника «' + (d.employee_name || '') + '» уже есть отметка ' + (d.date || '') + ' по задаче «' + (d.task_name || '') + '».\n\nОткрыть её?';
                    if (window.confirm(msg)) {
                        var st2 = window.__trkState || {};
                        var entry = null;
                        if (st2.calendar && st2.calendar.days) {
                            for (var i = 0; i < st2.calendar.days.length; i++) {
                                var day = st2.calendar.days[i];
                                var arr = day.entries || [];
                                for (var j = 0; j < arr.length; j++) { if (String(arr[j].id) === String(d.existing_id)) { entry = arr[j]; break; } }
                                if (entry) break;
                            }
                        }
                        if (entry && typeof window.__trkOpenLogModal === 'function') setTimeout(function(){ window.__trkOpenLogModal(entry); }, 80);
                    }
                    return new Response(JSON.stringify({success: false, error: 'cancelled'}), { status: 200, headers: {'Content-Type': 'application/json'} });
                }
                return r;
            });
        }
        if (!r || !r.ok) return r;
        return r.clone().json().then(function(d){
            if (d && d.success && !d.cancelled) _onSuccess(body, d);
            return r;
        }).catch(function(){ return r; });
    });
};
window.__trkLogSaveUnified = true;
})();


/* ============================================================
   PATCH 1.0.3 — редизайн карточки задачи (v4 FIX)
   ============================================================ */
(function(){
'use strict';
if (window.__trkTaskModalCoolV103) return;
window.__trkTaskModalCoolV103 = true;

function $(id){ return document.getElementById(id); }

function _findGroup(el){
    if (!el) return null;
    return el.closest ? el.closest('.form-group') : null;
}

function _restructure(){
    var m = $('taskModal');
    if (!m || !m.classList.contains('active')) return;
    var content = m.querySelector('.modal-content');
    if (!content) return;

    if (content.querySelector('.task-modal-grid')) return;

    // 1. Создаём каркас
    var hdr = document.createElement('div');
    hdr.className = 'task-modal-header';
    var h2 = content.querySelector('h2') || content.querySelector('#taskModalTitle');
    if (h2) hdr.appendChild(h2);

    var sc = document.createElement('div');
    sc.className = 'task-modal-scroll';
    var grid = document.createElement('div');
    grid.className = 'task-modal-grid';
    var main = document.createElement('div');
    main.className = 'task-modal-col task-modal-col-main';
    var side = document.createElement('div');
    side.className = 'task-modal-col task-modal-col-side';
    grid.appendChild(main);
    grid.appendChild(side);
    sc.appendChild(grid);

    var actions = content.querySelector('.modal-actions');

    // 2. Переносим все формы
    var allGroups = Array.from(content.querySelectorAll('.form-group'));
    allGroups.forEach(function(g){
        if (g.querySelector('#taskDepartmentsList') || g.querySelector('#taskAssigneesList')) {
            side.appendChild(g);
        } else {
            main.appendChild(g);
        }
    });

    // 3. Удаляем старые обёртки
    // PATCH 1.0.14: НЕ удаляем input[type="hidden"] (#task_id, #task_icon) —
    // их удаление ломало saveTask: payload.id='' → бэкенд создавал новую задачу.
    Array.from(content.children).forEach(function(child){
        if (child !== h2 && child !== actions && child !== hdr && child !== sc) {
            if (child.tagName === 'INPUT' && child.type === 'hidden') {
                return;
            }
            content.removeChild(child);
        }
    });
    content.insertBefore(hdr, content.firstChild);
    content.insertBefore(sc, actions || null);
    // PATCH 1.0.14: гарантируем наличие #task_id после перестройки
    if (!content.querySelector('#task_id')) {
        var _tid = document.createElement('input');
        _tid.type = 'hidden';
        _tid.id = 'task_id';
        _tid.value = '';
        content.insertBefore(_tid, content.firstChild);
    }

    _applyLayout();
}

function _applyLayout(){
    var content = document.querySelector('#taskModal .modal-content');
    if (!content) return;
    var main = content.querySelector('.task-modal-col-main');
    var side = content.querySelector('.task-modal-col-side');

    // 1. Иконка и название в одну строку
    var gIcon = _findGroup($('taskIconPickBtn'));
    var gName = _findGroup($('task_name'));
    if (gIcon && gName && !main.querySelector('.task-name-row')) {
        var row = document.createElement('div');
        row.className = 'task-name-row';
        
        var iconBtn = $('taskIconPickBtn');
        if (iconBtn) {
            iconBtn.className = 'task-icon-square';
            var hint = iconBtn.querySelector('.icon-picker-hint');
            if (hint) hint.remove();
            row.appendChild(iconBtn);
        }
        
        var label = gName.querySelector('label');
        if (label) label.remove();
        row.appendChild(gName);
        
        main.insertBefore(row, gIcon);
        gIcon.remove();
    }

    // 2. Карточки Описания и Тегов
    ['task_description', 'taskTagsBox'].forEach(function(id){
        var g = _findGroup($(id));
        if (g && !g.classList.contains('task-section-card')) {
            g.classList.add('task-section-card');
        }
    });

    // 3. Сборка блока Состояние (в правую колонку, самым первым)
    var gStatus = _findGroup($('task_status'));
    if (gStatus && !gStatus.querySelector('.task-status-card')) {
        gStatus.classList.add('task-section-card');
        var card = document.createElement('div');
        card.className = 'task-status-card';
        
        var head = document.createElement('div');
        head.className = 'task-status-head';
        var sel = $('task_status');
        if (sel) head.appendChild(sel);
        var uWrap = $('task_is_urgent') ? $('task_is_urgent').closest('.task-urgent-toggle') : null;
        if (uWrap) head.appendChild(uWrap);
        card.appendChild(head);

        var dates = document.createElement('div');
        dates.className = 'task-status-dates';
        var gSd = _findGroup($('task_start_date'));
        var gDl = _findGroup($('task_deadline'));
        var gCmp = _findGroup($('task_completed_at'));
        if (gSd) dates.appendChild(gSd);
        if (gDl) dates.appendChild(gDl);
        
        // ВАЖНО: Дата завершения НЕ скрывается, а добавляется в сетку
        if (gCmp) {
            gCmp.classList.add('task-date-completed');
            dates.appendChild(gCmp);
        }
        card.appendChild(dates);

        gStatus.innerHTML = '';
        var lbl = document.createElement('label');
        lbl.textContent = 'Состояние';
        gStatus.appendChild(lbl);
        gStatus.appendChild(card);

        // Переносим в правую колонку в самое начало
        if (side.firstChild) {
            side.insertBefore(gStatus, side.firstChild);
        } else {
            side.appendChild(gStatus);
        }
    }

    // 4. Сотрудники по командам
    var asgList = $('taskAssigneesList');
    if (asgList && asgList.parentNode && !asgList.parentNode.querySelector('.task-team-group')) {
        var st = window.__trkState || {};
        var teams = st.teams || [];
        var emps = st.employees || [];
        var teamMap = {};

        teams.forEach(function(t){
            var members = t.member_ids || [];
            if (t.manager_id && members.indexOf(t.manager_id) === -1) members.push(t.manager_id);
            teamMap[t.name] = members;
        });

        var grouped = {};
        var ungrouped = [];
        emps.forEach(function(e){
            if (!e.id) return;
            var found = false;
            for (var tName in teamMap) {
                if (teamMap[tName].indexOf(e.id) !== -1) {
                    if (!grouped[tName]) grouped[tName] = [];
                    grouped[tName].push(e);
                    found = true;
                }
            }
            if (!found) ungrouped.push(e);
        });

        var oldInputs = asgList.querySelectorAll('input[type="checkbox"]');
        var selectedIds = [];
        oldInputs.forEach(function(inp){ if (inp.checked) selectedIds.push(inp.value); });
        asgList.innerHTML = '';

        for (var tName in grouped) {
            var grp = document.createElement('div');
            grp.className = 'task-team-group';
            grp.innerHTML = '<div class="task-team-title">👥 ' + tName + '</div>';
            grouped[tName].forEach(function(e){
                grp.appendChild(_makeCheckbox(e, selectedIds.indexOf(e.id) !== -1));
            });
            asgList.appendChild(grp);
        }
        if (ungrouped.length) {
            var grpU = document.createElement('div');
            grpU.className = 'task-team-group';
            grpU.innerHTML = '<div class="task-team-title">👤 Без команды</div>';
            ungrouped.forEach(function(e){
                grpU.appendChild(_makeCheckbox(e, selectedIds.indexOf(e.id) !== -1));
            });
            asgList.appendChild(grpU);
        }
    }

    // 5. Приказы и Ссылки в спойлеры <details>
    ['taskOrdersGroup', 'taskLinksGroup'].forEach(function(gid){
        var grp = $(gid);
        if (grp && !grp.querySelector('details')) {
            var title = (gid === 'taskOrdersGroup') ? '📄 Приказы / распоряжения' : '🔗 Ссылки';
            // v1.1.7: убираем исходную подпись группы — она дублирует заголовок спойлера
            var _dupLbl = grp.querySelector(':scope > label');
            if (_dupLbl) _dupLbl.remove();
            var details = document.createElement('details');
            details.className = 'task-section';
            details.innerHTML = '<summary>' + title + ' <span class="cnt"></span></summary><div class="task-section-body"></div>';
            var body = details.querySelector('.task-section-body');
            while (grp.firstChild) body.appendChild(grp.firstChild);
            grp.appendChild(details);
            var count = grp.querySelectorAll('.task-link-row').length;
            details.querySelector('.cnt').textContent = count > 0 ? count : '';
            if (count > 0) details.open = true;
            if (grp.parentNode !== main) main.appendChild(grp);
        }
    });

    // 6. Логи в самый низ (без сворачивания, с прокруткой)
    var gFolder = _findGroup($('task_folder'));
    if (gFolder && !gFolder.classList.contains('task-logs-card')) {
        gFolder.className = 'task-logs-card';
        var lbl2 = gFolder.querySelector('label');
        if (lbl2) lbl2.textContent = '📄 Логи (Доп. данные)';
        
        var f = $('task_folder');
        if (f) {
            f.readOnly = true;
            f.classList.add('task-folder-readonly');
        }
        if (!gFolder.querySelector('.task-folder-hint')) {
            var hint = document.createElement('div');
            hint.className = 'task-folder-hint';
            hint.textContent = 'Обновляется автоматически при сохранении отметок.';
            gFolder.appendChild(hint);
        }
        main.appendChild(gFolder); // В самый низ
    }
}

function _makeCheckbox(e, checked) {
    var lbl = document.createElement('label');
    lbl.className = 'assignees-item';
    lbl.innerHTML = '<input type="checkbox" value="' + e.id + '"' + (checked ? ' checked' : '') + '>'
        + '<span class="assignees-dot" style="background:' + (e.color || '#888') + ';"></span>'
        + '<span class="assignees-name">' + (e.name || e.id) + '</span>';
    return lbl;
}

function _hook(){
    var m = $('taskModal');
    if (!m) return false;
    if (!m._v103coolObs) {
        m._v103coolObs = true;
        new MutationObserver(function(){
            if (m.classList.contains('active')) {
                setTimeout(function(){ _restructure(); }, 50);
            }
        }).observe(m, { attributes: true, attributeFilter: ['class'] });
    }
    return true;
}

function boot(){
    if (!_hook()) { setTimeout(boot, 300); return; }
    if ($('taskModal').classList.contains('active')) { _restructure(); }
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
})();


/* ============================================================
   PATCH 1.0.5 — Безопасная правка карточек задач
   ============================================================ */
(function(){
'use strict';
if (window.__trkTaskCardFixV105) return;
window.__trkTaskCardFixV105 = true;

function _moveBadges() {
    var list = document.getElementById('tasksFullList');
    if (!list) return;

    list.querySelectorAll('.task-card').forEach(function(card){
        var head = card.querySelector('.task-card-head');
        var topRight = card.querySelector('.task-card-topright');
        var mid = card.querySelector('.task-card-mid');

        // Если бейджи есть и они лежат в шапке
        if (head && topRight && topRight.parentNode === head) {
            // Удаляем класс, чтобы CSS не пытался его растянуть в шапке
            topRight.classList.remove('task-card-topright');
            topRight.classList.add('task-card-badges-below');

            // Вставляем после шапки (или после блока с датами, если он есть)
            if (mid) {
                mid.parentNode.insertBefore(topRight, mid.nextSibling);
            } else {
                head.parentNode.insertBefore(topRight, head.nextSibling);
            }
        }
    });
}

// Хук на рендер списка
(function(){
    function _hook() {
        if (typeof window.__trkRenderTasksFull !== 'function') return;
        if (window.__trkRenderTasksFull._v105safe) return;
        var orig = window.__trkRenderTasksFull;
        var wrapped = function(){
            var r = orig.apply(this, arguments);
            setTimeout(_moveBadges, 40);
            return r;
        };
        wrapped._v105safe = true;
        window.__trkRenderTasksFull = wrapped;
    }
    _hook();
    setTimeout(_hook, 500);
    setTimeout(_hook, 1500);
})();

// Наблюдатель на случай прямых манипуляций
setTimeout(function(){
    var list = document.getElementById('tasksFullList');
    if (!list) return;
    new MutationObserver(function(){
        setTimeout(_moveBadges, 30);
    }).observe(list, { childList: true });
    setTimeout(_moveBadges, 200);
}, 700);

})();


/* ============================================================
   PATCH 1.0.12 — Уведомление об обновлении на главной + автообновление
   ============================================================ */
(function(){
'use strict';
if (window.__trkUpdateNotifierV3) return;
window.__trkUpdateNotifierV3 = true;

function _hasUpdatePerms() {
    var p = window.REESTR_PERMS || {};
    return !!(p['tab.updater'] || p['action.updater.apply']);
}

function _isDismissed() {
    try { return sessionStorage.getItem('trk_update_dismissed') === '1'; } catch(e) { return false; }
}

function _setDismissed(v) {
    try { sessionStorage.setItem('trk_update_dismissed', v ? '1' : '0'); } catch(e) {}
}

function _esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}

// Безопасный fetch, чтобы HTML-ошибки не ломали JSON-парсер
function _safeJson(url, opts) {
    return fetch(url, opts || {credentials: 'same-origin'})
        .then(function(r) {
            var ct = r.headers.get('content-type') || '';
            if (ct.indexOf('application/json') !== -1) {
                return r.json();
            }
            return null;
        })
        .catch(function() { return null; });
}

function _checkUpdates() {
    if (!_hasUpdatePerms() || _isDismissed()) return;
    
    Promise.all([
        _safeJson('/api/plugins/updater/status'),
        _safeJson('/api/plugins/updater/settings')
    ]).then(function(results) {
        var d = results[0];
        var settings = results[1];
        
        if (d && d.success && d.pending && d.pending.length > 0) {
            var isAuto = settings && settings.success && settings.auto_update;
            if (isAuto) {
                if (typeof notify === 'function') notify('🚀 Найдено обновление, устанавливаем...', 'info');
                _runUpdate();
            } else {
                _showModal(d, false);
            }
        }
    }).catch(function(){});
}

function _showModal(d, isAuto) {
    var modal = document.getElementById('trkUpdateModal');
    if (!modal) return;
    
    var body = document.getElementById('trkUpdateBody');
    var html = '<p>Найдены новые патчи. Вот что изменится:</p>';
    html += '<ul style="margin: 10px 0 0 20px; padding: 0;">';
    (d.pending || []).forEach(function(p) {
        html += '<li style="margin-bottom: 6px;"><b>' + _esc(p.id) + '</b> — ' + _esc(p.description || 'Нет описания') + '</li>';
    });
    html += '</ul>';
    if (d.remote_version && d.remote_version !== d.version) {
        html += '<p style="margin-top: 12px; color: var(--trk-accent);">Версия изменится: <b>' + _esc(d.version) + '</b> → <b>' + _esc(d.remote_version) + '</b></p>';
    }
    body.innerHTML = html;
    
    var cbAuto = document.getElementById('trkUpdateAuto');
    if (cbAuto) {
        cbAuto.checked = isAuto;
        cbAuto.onchange = function() {
            var val = this.checked;
            var csrf = window.REESTR_CSRF || '';
            var hdrs = {'Content-Type': 'application/json'};
            if (csrf) hdrs['X-CSRF-Token'] = csrf;
            _safeJson('/api/plugins/updater/settings', {
                method: 'POST', credentials: 'same-origin', headers: hdrs,
                body: JSON.stringify({auto_update: val})
            });
        };
    }
    
    modal.classList.add('active');
    
    var btnDismiss = document.getElementById('trkUpdateDismiss');
    var btnApply = document.getElementById('trkUpdateApply');
    
    btnDismiss.onclick = function() {
        modal.classList.remove('active');
        _setDismissed(true);
    };
    
    btnApply.onclick = function() {
        modal.classList.remove('active');
        _runUpdate();
    };
}

function _runUpdate() {
    var loader = document.getElementById('globalLoader');
    if (loader) {
        loader.classList.add('active');
        var text = loader.querySelector('.gl-text');
        if (text) text.textContent = 'Обновление...';
    }
    
    var csrf = window.REESTR_CSRF || '';
    var hdrs = {'Content-Type': 'application/json'};
    if (csrf) hdrs['X-CSRF-Token'] = csrf;
    
    _safeJson('/api/plugins/updater/check', {
        method: 'POST', credentials: 'same-origin', headers: hdrs
    })
    .then(function(d){
        if (!d || !d.success || !d.dry_run || !d.dry_run.rc_ok) {
            throw new Error('Проверка не пройдена: ' + ((d && d.error) || 'неизвестная ошибка'));
        }
        if (loader) {
            var text = loader.querySelector('.gl-text');
            if (text) text.textContent = 'Применение патчей...';
        }
        return _safeJson('/api/plugins/updater/apply', {
            method: 'POST', credentials: 'same-origin', headers: hdrs
        });
    })
    .then(function(d){
        if (!d || !d.success) {
            throw new Error('Ошибка применения: ' + ((d && d.error) || 'неизвестная ошибка'));
        }
        if (loader) {
            var text = loader.querySelector('.gl-text');
            if (text) text.textContent = 'Перезагрузка сервера...';
        }
        return _safeJson('/api/settings/restart', {
            method: 'POST', credentials: 'same-origin', headers: hdrs
        });
    })
    .then(function(d){
        if (!d || !d.success) {
            throw new Error('Ошибка перезапуска: ' + ((d && d.error) || 'неизвестная ошибка'));
        }
        var attempts = 0;
        var iv = setInterval(function(){
            attempts++;
            fetch('/login', {method: 'HEAD', cache: 'no-store'})
                .then(function(){
                    clearInterval(iv);
                    location.reload();
                })
                .catch(function(){
                    if (attempts > 30) {
                        clearInterval(iv);
                        if (loader) loader.classList.remove('active');
                        alert('Сервер не поднялся. Пожалуйста, запустите START.bat вручную.');
                    }
                });
        }, 1000);
    })
    .catch(function(err){
        if (loader) loader.classList.remove('active');
        alert('❌ ' + err.message);
    });
}

setTimeout(_checkUpdates, 2000);
})();




/* ============================================================
   PATCH 1.0.14 — Автообновление в меню пользователя (стабильное)
   ============================================================ */
(function(){
'use strict';
if (window.__trkAutoUpdateMenuV114) return;
window.__trkAutoUpdateMenuV114 = true;

var _cbMenu = document.getElementById('udAutoUpdate');
if (!_cbMenu) return;

function _getCSRF() {
    var csrf = window.REESTR_CSRF || '';
    if (!csrf) {
        var meta = document.querySelector('meta[name="csrf-token"]');
        if (meta) csrf = meta.getAttribute('content') || '';
    }
    return csrf;
}

function _notify(msg, kind) {
    if (typeof window.__trackerNotify === 'function') {
        try { window.__trackerNotify(msg, kind); return; } catch(e){}
    }
    if (typeof window.__settingsNotify === 'function') {
        try { window.__settingsNotify(msg, kind); return; } catch(e){}
    }
    console.warn(msg);
}

function _syncBoth(val) {
    _cbMenu.checked = val;
    var cbModal = document.getElementById('trkUpdateAuto');
    if (cbModal) cbModal.checked = val;
}

function _load() {
    fetch('/api/plugins/updater/settings', {credentials: 'same-origin'})
        .then(function(r) {
            var ct = r.headers.get('content-type') || '';
            if (ct.indexOf('application/json') === -1) throw new Error('Ожидался JSON, получен ' + ct);
            return r.json();
        })
        .then(function(d) {
            if (d && d.success) {
                _syncBoth(!!d.auto_update);
                _cbMenu.disabled = false;
            } else {
                _notify('❌ Ошибка загрузки настроек автообновления: ' + (d.error || '?'), 'error');
            }
        })
        .catch(function(e) {
            _notify('❌ Ошибка соединения: ' + e.message, 'error');
        });
}

function _save(val) {
    _cbMenu.disabled = true;
    var csrf = _getCSRF();
    var hdrs = {'Content-Type': 'application/json'};
    if (csrf) hdrs['X-CSRF-Token'] = csrf;

    fetch('/api/plugins/updater/settings', {
        method: 'POST', credentials: 'same-origin', headers: hdrs,
        body: JSON.stringify({auto_update: val})
    })
    .then(function(r) {
        var ct = r.headers.get('content-type') || '';
        if (ct.indexOf('application/json') === -1) throw new Error('HTTP ' + r.status);
        return r.json();
    })
    .then(function(d) {
        _cbMenu.disabled = false;
        if (d && d.success) {
            _syncBoth(!!d.auto_update);
            _notify(val ? '✅ Автообновление включено' : '⏸ Автообновление выключено');
        } else {
            _notify('❌ Не удалось сохранить: ' + (d.error || '?'), 'error');
            _syncBoth(!val);
        }
    })
    .catch(function(e) {
        _cbMenu.disabled = false;
        _notify('❌ Ошибка сохранения: ' + e.message, 'error');
        _syncBoth(!val);
    });
}

_cbMenu.addEventListener('change', function(e) {
    e.stopPropagation();
    _save(this.checked);
});

_cbMenu.addEventListener('click', function(e) { e.stopPropagation(); });

var wrap = document.getElementById('udAutoUpdateWrap');
if (wrap) {
    wrap.addEventListener('click', function(e) {
        if (e.target !== _cbMenu) {
            e.preventDefault();
            e.stopPropagation();
            if (!_cbMenu.disabled) {
                _cbMenu.checked = !_cbMenu.checked;
                _save(_cbMenu.checked);
            }
        }
    });
}

document.addEventListener('change', function(e) {
    if (e.target && e.target.id === 'trkUpdateAuto') {
        _syncBoth(e.target.checked);
    }
});

_load();
})();


/* ============================================================
   PATCH 1.0.14 — 409 removed_assignees_have_logs: диалог выбора
   Перехват window.fetch, как в PATCH 19 (duplicate_name) и PATCH 27 (task_has_logs).
   ============================================================ */
(function(){
'use strict';
if (window.__trkRemovedAssigneesFetchV1014) return;
window.__trkRemovedAssigneesFetchV1014 = true;

var _native = window.fetch;
if (typeof _native !== 'function') return;

function _esc(s){
    return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}

function _showDialog(data, originalBody){
    return new Promise(function(resolve){
        var existing = document.getElementById('trkRemovedAssigneesModal');
        if (existing) existing.remove();

        var m = document.createElement('div');
        m.id = 'trkRemovedAssigneesModal';
        m.className = 'modal trk-removed-assignees-modal';
        m.style.setProperty('z-index', '9000', 'important');

        var rows = (data.removed || []).map(function(r){
            var per = '';
            if (r.first_date && r.last_date) {
                per = r.first_date === r.last_date ? r.first_date : (r.first_date + ' — ' + r.last_date);
            }
            return '<div class="trk-ra-row">'
                +   '<span class="trk-ra-name">' + _esc(r.name) + '</span>'
                +   '<span class="trk-ra-meta">' + (r.logs_count || 0) + ' отм. · ' + _esc(per) + '</span>'
                + '</div>';
        }).join('');

        m.innerHTML = ''
            + '<div class="modal-content">'
            + '  <h2>⚠ Удаление сотрудников из задачи</h2>'
            + '  <p class="trk-ra-sub">Следующие сотрудники будут удалены из задачи, но у них есть отметки:</p>'
            + '  <div class="trk-ra-list">' + rows + '</div>'
            + '  <p class="trk-ra-q">Что сделать с их отметками?</p>'
            + '  <div class="modal-actions trk-ra-actions">'
            + '    <button type="button" class="btn btn-danger" data-ra="delete">🗑 Удалить отметки</button>'
            + '    <button type="button" class="btn btn-secondary" data-ra="keep">💾 Оставить отметки</button>'
            + '    <button type="button" class="btn btn-secondary" data-ra="cancel">Отмена</button>'
            + '  </div>'
            + '</div>';

        document.body.appendChild(m);
        m.classList.add('active');

        var resolved = false;
        function finish(choice){
            if (resolved) return;
            resolved = true;
            m.classList.remove('active');
            m.removeEventListener('click', onClick);
            resolve(choice);
        }
        function onClick(e){
            if (e.target === m) return;
            var btn = e.target.closest && e.target.closest('[data-ra]');
            if (!btn) return;
            finish(btn.getAttribute('data-ra'));
        }
        m.addEventListener('click', onClick);
    });
}

window.fetch = function(url, opts){
    var isSave = (typeof url === 'string' && url.indexOf('/api/tracker/task/save') !== -1);
    var isPost = opts && (opts.method || 'GET').toUpperCase() === 'POST';
    if (!isSave || !isPost) return _native.apply(this, arguments);

    var body = {};
    try { body = JSON.parse(opts.body || '{}'); } catch(e){}
    // Повторный запрос от самого перехвата — не трогаем.
    if (body.removed_logs_action) return _native.apply(this, arguments);

    var self = this;
    return _native.apply(this, arguments).then(function(r){
        if (r.status !== 409) return r;
        return r.clone().json().then(function(d){
            if (!d || d.error !== 'removed_assignees_have_logs') return r;
            return _showDialog(d, body).then(function(choice){
                if (choice === 'cancel') {
                    return new Response(JSON.stringify({success: false, error: 'cancelled'}), {
                        status: 200, headers: {'Content-Type': 'application/json'}
                    });
                }
                var newBody = Object.assign({}, body, {removed_logs_action: choice});
                var newOpts = Object.assign({}, opts, {body: JSON.stringify(newBody)});
                return _native.call(self, url, newOpts);
            });
        });
    });
};

})();


/* ============================================================
   PATCH 1.0.15 — страж task_id при сохранении задачи
   Если modal открыт как «Редактировать», но #task_id пуст
   (например, _restructure удалил его до применения 1.0.14)
   — восстанавливаем id по имени из state.tasks, иначе отменяем
   сохранение (лучше отказ, чем дубликат).
   ============================================================ */
(function(){
'use strict';
if (window.__trkTaskIdGuardV1015) return;
window.__trkTaskIdGuardV1015 = true;

var _guardTaskId = '';
var _guardOpenTask = null;

function _notify(msg, kind){
    if (typeof window.__trackerNotify === 'function') {
        try { window.__trackerNotify(msg, kind); return; } catch(e){}
    }
    console.warn('[task_id-guard]', msg);
}

function _ensureHiddenInModal(){
    var tm = document.getElementById('taskModal');
    if (!tm) return null;
    var content = tm.querySelector('.modal-content');
    if (!content) return null;
    var el = document.getElementById('task_id');
    if (!el) {
        el = document.createElement('input');
        el.type = 'hidden';
        el.id = 'task_id';
        el.value = '';
        content.insertBefore(el, content.firstChild);
    }
    return el;
}

function _isEditMode(){
    var t = document.getElementById('taskModalTitle');
    if (!t) return false;
    var txt = t.textContent || '';
    return txt.indexOf('Редакт') !== -1;
}

function _findTaskIdByName(name){
    if (!name) return '';
    var st = window.__trkState || {};
    var tasks = st.tasks || [];
    for (var i = 0; i < tasks.length; i++) {
        if (tasks[i] && tasks[i].name === name) return tasks[i].id || '';
    }
    return '';
}

// 1. Обёртка window.__trkOpenTaskModal: запоминаем id при каждом открытии
function _wrapOpen(){
    var curr = window.__trkOpenTaskModal;
    if (typeof curr !== 'function' || curr._taskIdGuard) return;
    var wrapped = function(task){
        _guardTaskId = (task && task.id) ? String(task.id) : '';
        _guardOpenTask = task || null;
        var el = _ensureHiddenInModal();
        if (el) el.value = _guardTaskId;
        return curr.apply(this, arguments);
    };
    wrapped._taskIdGuard = true;
    window.__trkOpenTaskModal = wrapped;
}
_wrapOpen();
setTimeout(_wrapOpen, 150);
setTimeout(_wrapOpen, 500);
setTimeout(_wrapOpen, 1500);
setTimeout(_wrapOpen, 3000);

// 2. Capture-перехват клика #saveTaskBtn — ДО обработчика saveTask
//    Если modal открыт как «Редактировать», но #task_id пуст — восстанавливаем.
document.addEventListener('click', function(e){
    if (!e.target || !e.target.closest) return;
    if (!e.target.closest('#saveTaskBtn')) return;

    var tm = document.getElementById('taskModal');
    if (!tm || !tm.classList.contains('active')) return;

    var el = _ensureHiddenInModal();
    if (!el) return;

    // Если #task_id уже корректно заполнен — ничего не делаем
    if (el.value) {
        _guardTaskId = el.value;   // синхронизируем
        return;
    }

    // #task_id пуст
    if (_guardTaskId) {
        // У нас есть id из последнего openTaskModal — используем
        el.value = _guardTaskId;
        return;
    }

    // #task_id пуст и в guard ничего нет — проверяем, не edit ли это
    if (!_isEditMode()) {
        // Новая задача — всё ок, id остаётся пустым
        return;
    }

    // Это edit, но id потерян — пытаемся восстановить по имени
    var nameInput = document.getElementById('task_name');
    var name = nameInput ? nameInput.value.trim() : '';
    var foundId = _findTaskIdByName(name);

    if (foundId) {
        el.value = foundId;
        _guardTaskId = foundId;
        console.warn('[task_id-guard] восстановлен id по имени:', foundId);
        return;
    }

    // Восстановить не удалось — ОТМЕНЯЕМ сохранение, чтобы не создать дубликат
    e.preventDefault();
    e.stopPropagation();
    if (e.stopImmediatePropagation) e.stopImmediatePropagation();
    _notify('❌ Не удалось определить редактируемую задачу. Переоткройте карточку.', 'error');
}, true);

// 3. Синхронизация при закрытии modal — сбрасываем guard
(function _watchClose(){
    var tm = document.getElementById('taskModal');
    if (!tm || tm._taskIdGuardClose) return;
    tm._taskIdGuardClose = true;
    new MutationObserver(function(){
        if (!tm.classList.contains('active')) {
            // Через 300ms после закрытия — если modal не переоткрылась, сбрасываем
            setTimeout(function(){
                if (!tm.classList.contains('active')) {
                    _guardTaskId = '';
                    _guardOpenTask = null;
                }
            }, 300);
        }
    }).observe(tm, { attributes: true, attributeFilter: ['class'] });
})();

// 4. Экспорт для отладки
window.__trkGetGuardTaskId = function(){ return _guardTaskId; };
window.__trkSetGuardTaskId = function(v){ _guardTaskId = String(v || ''); };

})();


/* ============================================================
   PATCH 1.0.15 — 409 removed_assignees_have_logs: диалог выбора
   ============================================================ */
(function(){
'use strict';
if (window.__trkRemovedAssigneesFetchV1015) return;
window.__trkRemovedAssigneesFetchV1015 = true;

var _native = window.fetch;
if (typeof _native !== 'function') return;

function _esc(s){
    return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}

function _showDialog(data){
    return new Promise(function(resolve){
        var ex = document.getElementById('trkRemovedAssigneesModal');
        if (ex) ex.remove();
        var m = document.createElement('div');
        m.id = 'trkRemovedAssigneesModal';
        m.className = 'modal trk-removed-assignees-modal';
        m.style.setProperty('z-index', '9000', 'important');

        var rows = (data.removed || []).map(function(r){
            var per = '';
            if (r.first_date && r.last_date) {
                per = r.first_date === r.last_date ? r.first_date : (r.first_date + ' — ' + r.last_date);
            }
            return '<div class="trk-ra-row">'
                + '<span class="trk-ra-name">' + _esc(r.name) + '</span>'
                + '<span class="trk-ra-meta">' + (r.logs_count || 0) + ' отм. · ' + _esc(per) + '</span>'
                + '</div>';
        }).join('');

        m.innerHTML = ''
            + '<div class="modal-content">'
            + '  <h2>⚠ Удаление сотрудников из задачи</h2>'
            + '  <p class="trk-ra-sub">Следующие сотрудники будут удалены из задачи, но у них есть отметки:</p>'
            + '  <div class="trk-ra-list">' + rows + '</div>'
            + '  <p class="trk-ra-q">Что сделать с их отметками?</p>'
            + '  <div class="modal-actions trk-ra-actions">'
            + '    <button type="button" class="btn btn-danger" data-ra="delete">🗑 Удалить отметки</button>'
            + '    <button type="button" class="btn btn-secondary" data-ra="keep">💾 Оставить отметки</button>'
            + '    <button type="button" class="btn btn-secondary" data-ra="cancel">Отмена</button>'
            + '  </div>'
            + '</div>';
        document.body.appendChild(m);
        m.classList.add('active');

        var done = false;
        function finish(choice){
            if (done) return; done = true;
            m.classList.remove('active');
            m.removeEventListener('click', onClick);
            resolve(choice);
        }
        function onClick(e){
            if (e.target === m) return;
            var btn = e.target.closest && e.target.closest('[data-ra]');
            if (!btn) return;
            finish(btn.getAttribute('data-ra'));
        }
        m.addEventListener('click', onClick);
    });
}

window.fetch = function(url, opts){
    var isSave = (typeof url === 'string' && url.indexOf('/api/tracker/task/save') !== -1);
    var isPost = opts && (opts.method || 'GET').toUpperCase() === 'POST';
    if (!isSave || !isPost) return _native.apply(this, arguments);
    var body = {};
    try { body = JSON.parse(opts.body || '{}'); } catch(e){}
    if (body.removed_logs_action) return _native.apply(this, arguments);
    var self = this;
    return _native.apply(this, arguments).then(function(r){
        if (r.status !== 409) return r;
        return r.clone().json().then(function(d){
            if (!d || d.error !== 'removed_assignees_have_logs') return r;
            return _showDialog(d).then(function(choice){
                if (choice === 'cancel') {
                    return new Response(JSON.stringify({success: false, error: 'cancelled'}), {
                        status: 200, headers: {'Content-Type': 'application/json'}
                    });
                }
                var nb = Object.assign({}, body, {removed_logs_action: choice});
                var no = Object.assign({}, opts, {body: JSON.stringify(nb)});
                return _native.call(self, url, no);
            });
        });
    });
};

})();


/* ============================================================
   PATCH 1.0.17 — парсинг/формат часов + overflow по норме дня
   ============================================================ */
(function(){
'use strict';
if (window.__trkHoursFmtV1017) return;
window.__trkHoursFmtV1017 = true;

window._parseHoursInput = function(s) {
    s = String(s == null ? '' : s).trim().replace(',', '.');
    if (!s) return null;
    var m = s.match(/^(\d+)[:](\d+)$/);
    if (m) {
        var h1 = parseInt(m[1], 10) || 0;
        var mm1 = parseInt(m[2], 10) || 0;
        if (mm1 > 59) mm1 = 59;
        return Math.round((h1 + mm1 / 60) * 100) / 100;
    }
    var n = parseFloat(s);
    return isNaN(n) ? null : n;
};

window._formatHoursInput = function(h) {
    h = Number(h) || 0;
    var totalMin = Math.round(h * 60);
    var hh = Math.floor(totalMin / 60);
    var mm = totalMin - hh * 60;
    if (mm === 0) return String(hh);
    return hh + ':' + (mm < 10 ? '0' : '') + mm;
};

// На blur — форматируем поле
var _lh = document.getElementById('log_hours');
if (_lh) {
    _lh.addEventListener('blur', function(){
        var v = window._parseHoursInput(this.value);
        if (v !== null) this.value = window._formatHoursInput(v);
    });
}

})();


/* ============================================================
   PATCH 1.0.18 — поле ЧАСЫ в формате ЧЧ:ММ
   ============================================================ */
(function(){
'use strict';
if (window.__trkHoursV1018) return;
window.__trkHoursV1018 = true;

// === Парсинг: "8:15" / "08:15" / "815" / "8" / "8.25" (десятичное) ===
window._parseHoursInput = function(s) {
    s = String(s == null ? '' : s).trim().replace(',', '.');
    if (!s) return null;

    // "8:15" / "08:15"
    var m = s.match(/^(\d{1,2})\s*:\s*(\d{1,2})$/);
    if (m) {
        var h1 = parseInt(m[1], 10) || 0;
        var mm1 = parseInt(m[2], 10) || 0;
        if (mm1 > 59) mm1 = 59;
        if (h1 > 24) h1 = 24;
        if (h1 === 24) mm1 = 0;
        return Math.round((h1 + mm1 / 60) * 100) / 100;
    }

    // "815" / "0815" (4 цифры = ЧЧММ)
    if (/^\d{4}$/.test(s)) {
        var hh2 = parseInt(s.slice(0, 2), 10) || 0;
        var mm2 = parseInt(s.slice(2), 10) || 0;
        if (mm2 > 59) mm2 = 59;
        if (hh2 > 24) hh2 = 24;
        if (hh2 === 24) mm2 = 0;
        return Math.round((hh2 + mm2 / 60) * 100) / 100;
    }

    // "815" (3 цифры) — трактуем как "8:15"
    if (/^\d{3}$/.test(s)) {
        var hh3 = parseInt(s[0], 10) || 0;
        var mm3 = parseInt(s.slice(1), 10) || 0;
        if (mm3 > 59) mm3 = 59;
        return Math.round((hh3 + mm3 / 60) * 100) / 100;
    }

    // "8" / "15" (1-2 цифры) — это часы
    if (/^\d{1,2}$/.test(s)) {
        var hh4 = parseInt(s, 10) || 0;
        if (hh4 > 24) hh4 = 24;
        return hh4;
    }

    // Fallback: десятичное "8.25"
    var n = parseFloat(s);
    if (isNaN(n)) return null;
    if (n < 0) n = 0;
    if (n > 24) n = 24;
    return n;
};

// === Формат: всегда "ЧЧ:ММ", clamp [0; 24] ===
window._formatHoursInput = function(h) {
    h = Number(h) || 0;
    if (h < 0) h = 0;
    if (h >= 24) return '24:00';
    var totalMin = Math.round(h * 60);
    if (totalMin >= 24 * 60) return '24:00';
    var hh = Math.floor(totalMin / 60);
    var mm = totalMin - hh * 60;
    return (hh < 10 ? '0' : '') + hh + ':' + (mm < 10 ? '0' : '') + mm;
};

// === Маска ввода ===
function _attachMask(el){
    if (!el || el._hoursMaskV1018) return;
    el._hoursMaskV1018 = true;

    el.addEventListener('input', function(){
        var v = this.value;
        // . , → :
        v = v.replace(/[.,]/g, ':');
        // Только цифры и :
        v = v.replace(/[^\d:]/g, '');
        // Оставить только первое двоеточие
        var idx = v.indexOf(':');
        if (idx !== -1) {
            v = v.slice(0, idx + 1) + v.slice(idx + 1).replace(/:/g, '');
        }
        // Не больше 5 символов (ЧЧ:ММ)
        if (v.length > 5) v = v.slice(0, 5);
        if (this.value !== v) this.value = v;
    });

    el.addEventListener('blur', function(){
        var v = window._parseHoursInput(this.value);
        if (v !== null && !isNaN(v)) {
            this.value = window._formatHoursInput(v);
        }
    });

    el.addEventListener('keydown', function(e){
        if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
            e.preventDefault();
            var v = window._parseHoursInput(this.value);
            if (v === null || isNaN(v)) v = 0;
            var step = e.shiftKey ? 1 : 0.25;
            if (e.key === 'ArrowDown') step = -step;
            v = Math.max(0, Math.min(24, v + step));
            this.value = window._formatHoursInput(v);
            try { this.dispatchEvent(new Event('input', {bubbles: true})); } catch(err){}
        }
    });
}

// === Навесить на существующее поле + на все переоткрытия модалки ===
function _attachToLogHours(){
    var el = document.getElementById('log_hours');
    if (el) {
        _attachMask(el);
        // Если поле пустое (например, из-за кэшированного HTML) — поставим дефолт
        if (!el.value) el.value = '08:00';
    }
}
_attachToLogHours();
setTimeout(_attachToLogHours, 300);
setTimeout(_attachToLogHours, 1000);

// Наблюдатель на logModal — если HTML был заменён рендером
(function _obs(){
    var lm = document.getElementById('logModal');
    if (!lm || lm._hoursObsV1018) return;
    lm._hoursObsV1018 = true;
    new MutationObserver(function(){
        if (lm.classList.contains('active')) _attachToLogHours();
    }).observe(lm, { attributes: true, attributeFilter: ['class'] });
})();

})();


/* ============================================================
   PATCH 1.0.19 — умолчание часов по норме дня
   Пн-Чт extended = 08:15, Пт extended = 07:45, legacy/выходной = 08:00
   ============================================================ */
(function(){
'use strict';
if (window.__trkHoursDefaultV1019) return;
window.__trkHoursDefaultV1019 = true;

function _getDayNorm(dk) {
    if (!dk) return 8;
    var st = window.__trkState || {};

    // 1. Из загруженного календаря (приоритет — там day_norm с учётом праздников)
    if (st.calendar && st.calendar.days) {
        for (var i = 0; i < st.calendar.days.length; i++) {
            var d = st.calendar.days[i];
            if (d && d.date === dk && typeof d.day_norm === 'number') {
                return d.day_norm;
            }
        }
    }

    // 2. Fallback: weekday + state.workSchedule
    try {
        var parts = String(dk).split('-');
        var y = parseInt(parts[0], 10);
        var m = parseInt(parts[1], 10);
        var dd = parseInt(parts[2], 10);
        var dt = new Date(y, m - 1, dd);
        var wd = dt.getDay(); // 0=Вс, 1=Пн, ..., 6=Сб
        if (wd === 0 || wd === 6) return 0;
        var mode = st.workSchedule || 'legacy';
        if (mode === 'extended') {
            return wd === 5 ? 7.75 : 8.25; // Пт=7.75, Пн-Чт=8.25
        }
        return 8;
    } catch (e) {
        return 8;
    }
}

function _fmt(h) {
    if (typeof window._formatHoursInput === 'function') {
        return window._formatHoursInput(h);
    }
    // 1.0.18 не применился — показываем как число
    var v = Number(h) || 0;
    if (v === Math.floor(v)) return String(v);
    return String(v);
}

function _applyDefaultHours() {
    var lh = document.getElementById('log_hours');
    if (!lh) return;
    var lid = document.getElementById('log_id');
    // Не трогаем при редактировании
    if (lid && lid.value) return;
    // Не трогаем, если пользователь уже менял поле в этой сессии
    if (lh._userTouchedHours) return;

    var ldt = document.getElementById('log_date');
    var dk = ldt ? ldt.value : '';
    var norm = _getDayNorm(dk);
    // На выходных/праздниках (norm=0) оставляем 8, как было раньше
    var useVal = norm > 0 ? norm : 8;
    lh.value = _fmt(useVal);
}

// Отслеживание «пользователь трогал поле»
document.addEventListener('input', function(e){
    if (e.target && e.target.id === 'log_hours') {
        e.target._userTouchedHours = true;
    }
}, true);

// При открытии модалки — сбрасываем «touch» и ставим норму
(function _watchOpen(){
    var lm = document.getElementById('logModal');
    if (!lm || lm._hoursDefaultV1019) return;
    lm._hoursDefaultV1019 = true;
    new MutationObserver(function(){
        if (lm.classList.contains('active')) {
            var lh = document.getElementById('log_hours');
            if (lh) lh._userTouchedHours = false;
            setTimeout(_applyDefaultHours, 30);
            setTimeout(_applyDefaultHours, 150);
            setTimeout(_applyDefaultHours, 400);
        }
    }).observe(lm, { attributes: true, attributeFilter: ['class'] });
})();

// При смене даты — пересчитываем, только если поле не тронуто
document.addEventListener('change', function(e){
    if (!e.target || e.target.id !== 'log_date') return;
    setTimeout(_applyDefaultHours, 30);
    setTimeout(_applyDefaultHours, 150);
}, true);

// На случай, если модалка уже открыта при загрузке
setTimeout(_applyDefaultHours, 800);

window.__trkApplyHoursDefault = _applyDefaultHours;
window.__trkGetDayNorm = _getDayNorm;

})();


/* ============================================================
   PATCH 1.0.20 (v2) — пересчёт подсказки после установки умолчания
   НЕ оборачивает _applyDefaultHours (observer 1.0.19 её не вызывает через window).
   Вместо этого — независимый observer на 500/900мс (после 1.0.19 30/150/400мс).
   ============================================================ */
(function(){
'use strict';
if (window.__trkHoursSyncV1020b) return;
window.__trkHoursSyncV1020b = true;

function _syncSummary() {
    var lh = document.getElementById('log_hours');
    if (!lh) return;
    // Не трогаем при редактировании
    var lid = document.getElementById('log_id');
    if (lid && lid.value) return;
    // Не трогаем, если пользователь ввёл сам
    if (lh._userTouchedHours) return;
    // Диспатчим input — updateDayHoursSummary пересчитает planned
    try {
        lh.dispatchEvent(new Event('input', { bubbles: true }));
    } catch (e) {}
    // 1.0.19 ставит _userTouchedHours = true на каждый input (в т.ч. программный).
    // Сбрасываем, чтобы следующая смена даты / открытие снова пересчитало.
    lh._userTouchedHours = false;
}

(function _watchOpen(){
    var lm = document.getElementById('logModal');
    if (!lm || lm._hoursSyncV1020b) return;
    lm._hoursSyncV1020b = true;
    new MutationObserver(function(){
        if (lm.classList.contains('active')) {
            // Сброс флага при открытии (1.0.19 тоже сбрасывает, но на случай его отсутствия)
            var lh0 = document.getElementById('log_hours');
            if (lh0) lh0._userTouchedHours = false;
            // 1.0.19: 30/150/400мс. Мы: 500/900мс — после него.
            setTimeout(_syncSummary, 500);
            setTimeout(_syncSummary, 900);
        }
    }).observe(lm, { attributes: true, attributeFilter: ['class'] });
})();

document.addEventListener('change', function(e){
    if (!e.target || e.target.id !== 'log_date') return;
    setTimeout(_syncSummary, 200);
    setTimeout(_syncSummary, 500);
}, true);

setTimeout(_syncSummary, 1200);

})();


/* ============================================================
   PATCH 1.0.21 — видимый баннер ошибок + защита от не-Response
   ============================================================ */
(function(){
'use strict';
if (window.__trkErrorBannerV1021) return;
window.__trkErrorBannerV1021 = true;

function _showError(title, body, stack) {
    var el = document.getElementById('trkErrorBanner');
    if (!el) {
        el = document.createElement('div');
        el.id = 'trkErrorBanner';
        el.style.cssText = 'position:fixed;bottom:16px;left:16px;right:16px;max-height:45vh;overflow:auto;padding:14px 18px;background:rgba(180,30,30,0.97);color:#fff;border-radius:10px;font-family:ui-monospace,Consolas,monospace;font-size:0.78rem;z-index:99999;box-shadow:0 6px 24px rgba(0,0,0,0.55);line-height:1.5;';
        document.body.appendChild(el);
    }
    var esc = function(s){ return String(s == null ? '' : s).replace(/[&<>]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;'}[c]; }); };
    el.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;">'
        + '<div style="flex:1;min-width:0;">'
        +   '<div style="font-weight:800;margin-bottom:8px;font-size:0.9rem;">⚠ ' + esc(title) + '</div>'
        +   '<div style="white-space:pre-wrap;word-break:break-word;margin-bottom:6px;">' + esc(body) + '</div>'
        +   (stack ? '<details style="margin-top:8px;"><summary style="cursor:pointer;opacity:0.85;font-size:0.72rem;">Технические детали (для администратора)</summary><pre style="white-space:pre-wrap;word-break:break-word;margin:6px 0 0 0;font-size:0.7rem;opacity:0.8;">' + esc(stack) + '</pre></details>' : '')
        + '</div>'
        + '<button type="button" onclick="var x=document.getElementById(\'trkErrorBanner\');if(x)x.remove();" style="background:transparent;border:1px solid rgba(255,255,255,0.5);color:#fff;padding:4px 10px;border-radius:6px;cursor:pointer;font-family:inherit;font-size:0.8rem;flex-shrink:0;">Закрыть</button>'
        + '</div>';
}

window.addEventListener('error', function(e){
    if (!e || !e.message) return;
    var stack = (e.error && e.error.stack) ? e.error.stack : ('at ' + (e.filename || '?') + ':' + (e.lineno || '?'));
    _showError('Ошибка в JavaScript', e.message, stack);
});

window.addEventListener('unhandledrejection', function(e){
    var r = e.reason;
    var msg = (r && r.message) ? r.message : String(r);
    if (msg.indexOf('cancelled') !== -1) return;
    var stack = (r && r.stack) ? r.stack : '';
    _showError('Необработанная ошибка', msg, stack);
});

// Защита от не-Response в fetch-цепочке
var _prev = window.fetch;
if (typeof _prev === 'function') {
    window.fetch = function(url, opts){
        return _prev.apply(this, arguments).then(function(r){
            if (r instanceof Response) return r;
            var urlStr = String(url || '');
            var payload;
            try { payload = (typeof r === 'object') ? JSON.stringify(r, null, 2) : String(r); } catch(e) { payload = '[unserializable]'; }
            _showError('Ошибка запроса к серверу',
                'URL: ' + urlStr + '\n\nОтвет не является Response.\n\n' + payload,
                'fetch-guard: window.fetch вернул не Response');
            return new Response(payload, {
                status: (typeof r === 'object' && typeof r.status === 'number') ? r.status : 500,
                headers: {'Content-Type': 'application/json'}
            });
        });
    };
}

})();


/* ============================================================
   PATCH 1.0.22 — часы по норме при авто-добавлении задачи
   ============================================================ */
(function(){
'use strict';
if (window.__trkAutoAddHoursV1022) return;
window.__trkAutoAddHoursV1022 = true;

function _norm(dk) {
    if (!dk) return 8;
    var n = (typeof window.__trkGetDayNorm === 'function') ? window.__trkGetDayNorm(dk) : 8;
    if (typeof n !== 'number' || isNaN(n)) return 8;
    if (n <= 0) return 8;
    return n;
}

// Обёртка над __trkOpenLogModal — норму ставим ДО открытия,
// чтобы updateDayHoursSummary в openLogModal сразу считал правильно,
// а не показывал 0 + 8 = 8.
function _wrap() {
    var _orig = window.__trkOpenLogModal;
    if (typeof _orig !== 'function') return false;
    if (_orig._autoAddHoursV1022) return true;

    var w = function(entry) {
        var _e = entry;
        try {
            if (_e && !_e.id && _e.date) {
                var _h = Number(_e.hours);
                if (isNaN(_h) || _h <= 0 || _h === 8) {
                    _e = Object.assign({}, _e, { hours: _norm(_e.date) });
                }
            }
        } catch (err) {}
        return _orig.call(this, _e);
    };
    w._autoAddHoursV1022 = true;
    window.__trkOpenLogModal = w;
    return true;
}

if (!_wrap()) {
    setTimeout(_wrap, 200);
    setTimeout(_wrap, 800);
    setTimeout(_wrap, 2000);
} else {
    setTimeout(_wrap, 800);
    setTimeout(_wrap, 2000);
}

})();


/* ============================================================
   PATCH 1.0.23 — периодическая проверка обновлений + автоприменение
   ============================================================ */
(function(){
'use strict';
if (window.__trkPeriodicUpdaterV1023) return;
window.__trkPeriodicUpdaterV1023 = true;

var CHECK_INTERVAL_MS = 5 * 60 * 1000;   // раз в 5 минут
var ACTIVITY_GRACE_MS = 60 * 1000;       // если активен <60 сек — отложить
var FIRST_CHECK_DELAY_MS = 2500;         // первая через 2.5 сек после загрузки

window.__trkLastActivity = Date.now();
['mousemove', 'mousedown', 'keydown', 'input', 'scroll', 'touchstart'].forEach(function(ev){
    document.addEventListener(ev, function(){ window.__trkLastActivity = Date.now(); }, true);
});

function _hasUpdatePerms(){
    var p = window.REESTR_PERMS || {};
    return !!(p['tab.updater'] || p['action.updater.apply']);
}
function _isDismissed(){ try { return sessionStorage.getItem('trk_update_dismissed_periodic') === '1'; } catch(e){ return false; } }
function _setDismissed(v){ try { sessionStorage.setItem('trk_update_dismissed_periodic', v ? '1' : '0'); } catch(e){} }

function _esc(s){
    return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
}

function _safeJson(url, opts){
    return fetch(url, opts || {credentials: 'same-origin'})
        .then(function(r){
            var ct = r.headers.get('content-type') || '';
            if (ct.indexOf('application/json') !== -1) return r.json();
            return null;
        })
        .catch(function(){ return null; });
}

function _anyModalOpen(){
    return document.querySelectorAll('.modal.active').length > 0;
}

function _userActiveRecently(){
    return (Date.now() - (window.__trkLastActivity || 0)) < ACTIVITY_GRACE_MS;
}

function _getModal(){
    var m = document.getElementById('trkPeriodicUpdateModal');
    if (m) return m;
    m = document.createElement('div');
    m.id = 'trkPeriodicUpdateModal';
    m.className = 'modal';
    m.style.setProperty('z-index', '9200', 'important');
    m.innerHTML = ''
        + '<div class="modal-content" style="max-width:560px;">'
        + '  <h2 style="color:#f5d76e;margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid rgba(245,215,110,0.20);">⬆ Доступно обновление</h2>'
        + '  <div id="trkPUBody" style="font-size:0.9rem;line-height:1.5;max-height:50vh;overflow:auto;"></div>'
        + '  <div style="margin-top:14px;padding:10px 12px;background:var(--trk-hover-row);border-radius:8px;display:flex;align-items:center;gap:8px;">'
        + '    <input type="checkbox" id="trkPUAutoCb" style="width:16px;height:16px;accent-color:var(--trk-accent);cursor:pointer;">'
        + '    <label for="trkPUAutoCb" style="font-size:0.85rem;color:var(--trk-text);cursor:pointer;margin:0;">Устанавливать автоматически без подтверждения</label>'
        + '  </div>'
        + '  <div class="modal-actions" style="margin-top:16px;">'
        + '    <button type="button" class="btn btn-secondary" id="trkPUCancel">Не сейчас</button>'
        + '    <button type="button" class="btn btn-primary" id="trkPUApply">Обновить сейчас</button>'
        + '  </div>'
        + '</div>';
    document.body.appendChild(m);
    return m;
}

function _showModal(d){
    var m = _getModal();
    var body = m.querySelector('#trkPUBody');
    var html = '<p>Найдены новые патчи:</p><ul style="margin:10px 0 0 20px;padding:0;">';
    (d.pending || []).forEach(function(p){
        html += '<li style="margin-bottom:6px;"><b>' + _esc(p.id) + '</b> — ' + _esc(p.description || 'Нет описания') + '</li>';
    });
    html += '</ul>';
    if (d.remote_version && d.remote_version !== d.version) {
        html += '<p style="margin-top:12px;color:var(--trk-accent);">Версия: <b>' + _esc(d.version) + '</b> → <b>' + _esc(d.remote_version) + '</b></p>';
    }
    body.innerHTML = html;

    var cb = m.querySelector('#trkPUAutoCb');
    if (cb) {
        cb.checked = false;
        cb.onchange = function(){
            var val = this.checked;
            var csrf = window.REESTR_CSRF || '';
            var hdrs = {'Content-Type': 'application/json'};
            if (csrf) hdrs['X-CSRF-Token'] = csrf;
            _safeJson('/api/plugins/updater/settings', {
                method: 'POST', credentials: 'same-origin', headers: hdrs,
                body: JSON.stringify({auto_update: val})
            });
        };
    }

    m.classList.add('active');

    m.querySelector('#trkPUCancel').onclick = function(){
        m.classList.remove('active');
        _setDismissed(true);
    };
    m.querySelector('#trkPUApply').onclick = function(){
        m.classList.remove('active');
        _runUpdate();
    };
}

function _runUpdate(){
    if (window.__trkUpdateRunning) return;
    window.__trkUpdateRunning = true;

    var loader = document.getElementById('globalLoader');
    if (loader) {
        loader.classList.add('active');
        var t = loader.querySelector('.gl-text');
        if (t) t.textContent = 'Проверка обновления...';
    }

    var csrf = window.REESTR_CSRF || '';
    var hdrs = {'Content-Type': 'application/json'};
    if (csrf) hdrs['X-CSRF-Token'] = csrf;

    _safeJson('/api/plugins/updater/check', {
        method: 'POST', credentials: 'same-origin', headers: hdrs
    })
    .then(function(d){
        if (!d || !d.success || !d.dry_run || !d.dry_run.rc_ok) {
            throw new Error('Проверка не пройдена: ' + ((d && d.error) || 'неизвестно'));
        }
        if (!d.pending || !d.pending.length) {
            throw new Error('Нет патчей к применению');
        }
        if (loader) {
            var t = loader.querySelector('.gl-text');
            if (t) t.textContent = 'Применение патчей...';
        }
        return _safeJson('/api/plugins/updater/apply', {
            method: 'POST', credentials: 'same-origin', headers: hdrs
        });
    })
    .then(function(d){
        if (!d || !d.success) {
            throw new Error('Ошибка применения: ' + ((d && d.error) || 'неизвестно'));
        }
        if (loader) {
            var t = loader.querySelector('.gl-text');
            if (t) t.textContent = 'Перезапуск сервера...';
        }
        return _safeJson('/api/settings/restart', {
            method: 'POST', credentials: 'same-origin', headers: hdrs
        });
    })
    .then(function(d){
        if (!d || !d.success) {
            throw new Error('Ошибка перезапуска: ' + ((d && d.error) || 'неизвестно'));
        }
        var attempts = 0;
        var iv = setInterval(function(){
            attempts++;
            // PATCH 1.0.23: GET вместо HEAD — надёжнее за reverse-proxy
            fetch('/login', {method: 'GET', cache: 'no-store', credentials: 'same-origin'})
                .then(function(r){
                    if (r && (r.status === 200 || r.status === 302 || r.ok)) {
                        clearInterval(iv);
                        location.reload();
                    }
                })
                .catch(function(){
                    if (attempts > 30) {
                        clearInterval(iv);
                        window.__trkUpdateRunning = false;
                        if (loader) loader.classList.remove('active');
                        alert('Сервер не поднялся за 30 сек. Запустите START.bat вручную.');
                    }
                });
        }, 1000);
    })
    .catch(function(err){
        window.__trkUpdateRunning = false;
        if (loader) loader.classList.remove('active');
        var msg = (err && err.message) || 'неизвестная ошибка';
        if (typeof window.__trackerNotify === 'function') {
            window.__trackerNotify('❌ ' + msg, 'error');
        } else {
            console.warn('[updater] ' + msg);
        }
    });
}

function _check(){
    if (!_hasUpdatePerms()) return;
    if (window.__trkUpdateRunning) return;
    if (_anyModalOpen()) return;
    if (_userActiveRecently()) return;

    Promise.all([
        _safeJson('/api/plugins/updater/status'),
        _safeJson('/api/plugins/updater/settings')
    ]).then(function(results){
        var st = results[0];
        var settings = results[1];
        if (!st || !st.success) return;
        if (!st.pending || !st.pending.length) return;

        var isAuto = settings && settings.success && settings.auto_update;
        if (isAuto) {
            _runUpdate();
        } else if (!_isDismissed()) {
            _showModal(st);
        }
    }).catch(function(){});
}

setTimeout(_check, FIRST_CHECK_DELAY_MS);
setInterval(_check, CHECK_INTERVAL_MS);

window.__trkPeriodicUpdateCheck = _check;
window.__trkPeriodicUpdateRun = _runUpdate;

})();


/* ============================================================
   PATCH 1.0.4 — редизайн карточки отметки (v2 - стабильный)
   ============================================================ */
(function(){
'use strict';
if (window.__trkLogModalCoolV104b) return;
window.__trkLogModalCoolV104b = true;

function $(id){ return document.getElementById(id); }
function _findGroup(el){ return el ? el.closest('.form-group') : null; }
function _removeLabel(group) {
    if (!group) return;
    var l = group.querySelector(':scope > label');
    if (l) l.remove();
}

function _applyLayout(){
    var m = $('logModal');
    if (!m || !m.classList.contains('active')) return;
    var body = m.querySelector('.log-modal-body');
    if (!body) return;

    // 1. Основное
    var row4 = body.querySelector('.log-row-4');
    if (row4 && !row4.closest('.log-section-card')) {
        var w = document.createElement('div');
        w.className = 'log-section-card';
        w.innerHTML = '<label>Основное</label>';
        row4.parentNode.insertBefore(w, row4);
        w.appendChild(row4);
    }

    // 2. Задача (переносим кнопку внутрь .log-task-wrap)
    var gTask = _findGroup($('log_task_input'));
    var btnTask = $('logCreateTaskBtn');
    if (gTask && btnTask) {
        var taskWrap = gTask.querySelector('.log-task-wrap');
        if (taskWrap && btnTask.parentNode !== taskWrap) {
            // Удаляем старый заголовок и вставляем кнопку в конец обертки
            taskWrap.appendChild(btnTask);
        }
        if (!gTask.closest('.log-section-card')) {
            var wT = document.createElement('div');
            wT.className = 'log-section-card';
            wT.innerHTML = '<label>Задача</label>';
            gTask.parentNode.insertBefore(wT, gTask);
            wT.appendChild(gTask);
            _removeLabel(gTask);
        }
    }

    // 3. Описание
    var gDesc = _findGroup($('log_comment'));
    if (gDesc && !gDesc.closest('.log-section-card')) {
        var wD = document.createElement('div');
        wD.className = 'log-section-card';
        wD.innerHTML = '<label>Описание</label>';
        gDesc.parentNode.insertBefore(wD, gDesc);
        wD.appendChild(gDesc);
        _removeLabel(gDesc);
    }

    // 4. Приказы (физически оборачиваем существующий блок)
    var gOrd = _findGroup($('logOrdersList'));
    if (gOrd && !gOrd.closest('details.log-section')) {
        var d = document.createElement('details');
        d.className = 'log-section';
        d.innerHTML = '<summary>📄 Приказы / распоряжения <span class="cnt"></span></summary><div class="log-section-body"></div>';
        var b = d.querySelector('.log-section-body');
        gOrd.parentNode.replaceChild(d, gOrd);
        b.appendChild(gOrd);
        _removeLabel(gOrd);
        var cnt = b.querySelectorAll('.task-link-row').length;
        d.querySelector('.cnt').textContent = cnt ? cnt : '';
        if (cnt) d.open = true;
    }

    // 5. Ссылки
    var gLnk = _findGroup($('logLinksList'));
    if (gLnk && !gLnk.closest('details.log-section')) {
        var d2 = document.createElement('details');
        d2.className = 'log-section';
        d2.innerHTML = '<summary>🔗 Ссылки <span class="cnt"></span></summary><div class="log-section-body"></div>';
        var b2 = d2.querySelector('.log-section-body');
        gLnk.parentNode.replaceChild(d2, gLnk);
        b2.appendChild(gLnk);
        _removeLabel(gLnk);
        var cnt2 = b2.querySelectorAll('.task-link-row').length;
        d2.querySelector('.cnt').textContent = cnt2 ? cnt2 : '';
        if (cnt2) d2.open = true;
    }

    // 6. Доп. данные -> в самый конец
    var gExt = _findGroup($('logExtraDataList'));
    if (gExt && !gExt.closest('.log-extra-card')) {
        var wE = document.createElement('div');
        wE.className = 'log-extra-card';
        wE.innerHTML = '<label>📁 Дополнительные данные (только чтение)</label>';
        gExt.parentNode.insertBefore(wE, gExt);
        wE.appendChild(gExt);
        _removeLabel(gExt);
        
        var addBtn = $('logExtraAddBtn');
        if (addBtn) addBtn.style.display = 'none';

        // Переносим в самый конец body
        body.appendChild(wE);
    }
    if (gExt) gExt.querySelectorAll('input').forEach(function(i){ i.readOnly = true; });
}

function _hook(){
    var m = $('logModal');
    if (!m) return false;
    if (!m._v104ObsB) {
        m._v104ObsB = true;
        new MutationObserver(function(){
            if (m.classList.contains('active')) {
                setTimeout(_applyLayout, 60);
            }
        }).observe(m, { attributes: true, attributeFilter: ['class'] });
    }
    return true;
}

function boot(){
    if (!_hook()) { setTimeout(boot, 300); return; }
    if ($('logModal').classList.contains('active')) _applyLayout();
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
})();

/* ============================================================
   PATCH v1.1.2 (tile): из расширенного режима карточки ЗАДАЧИ
   (Плитка) убираем блок «Дополнительные данные»; остаётся только
   📄 Приказы и 🔗 Ссылки.
   ============================================================ */
(function(){
'use strict';
if (window.__trkTileHideExtraV112) return;
window.__trkTileHideExtraV112 = true;
function hide(){
    var list = document.getElementById('tasksFullList');
    if (!list) return;
    list.querySelectorAll('.tfl-sec').forEach(function(sec){
        var head = sec.querySelector('.tfl-head');
        if (head && head.textContent.indexOf('Дополнительные данные') !== -1) sec.remove();
    });
    list.querySelectorAll('.txi-fold').forEach(function(el){ el.remove(); });
}
var _mo = null;
function boot(){
    hide();
    var list = document.getElementById('tasksFullList');
    if (list && !_mo && window.MutationObserver){
        _mo = new MutationObserver(function(){ setTimeout(hide, 30); });
        _mo.observe(list, { childList: true, subtree: true });
    }
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
setTimeout(boot, 600);
setTimeout(boot, 2000);
setInterval(function(){
    var p = document.getElementById('panel-tasks');
    if (p && p.classList.contains('active')) hide();
}, 2000);
})();


/* ============================================================
   PATCH v1.1.2 — управление z-index и попапами
   ============================================================ */
(function(){
    if (window.__trkModalsV112) return;
    window.__trkModalsV112 = true;

    /* 1. Управление Z-INDEX модалок (каждая новая открывается ПОВЕРХ предыдущей) */
    var modalObserver = new MutationObserver(function(mutations) {
        mutations.forEach(function(m) {
            if (m.type === 'attributes' && m.attributeName === 'class') {
                var el = m.target;
                if (el.classList.contains('modal') && el.classList.contains('active')) {
                    var maxZ = 3000;
                    document.querySelectorAll('.modal.active').forEach(function(m2) {
                        if (m2 !== el) {
                            var z = parseInt(window.getComputedStyle(m2).zIndex) || 0;
                            if (z > maxZ) maxZ = z;
                        }
                    });
                    // Ставим модалку поверх всех остальных
                    el.style.setProperty('z-index', maxZ + 10, 'important');
                }
            }
        });
    });

    document.querySelectorAll('.modal').forEach(function(m) {
        modalObserver.observe(m, { attributes: true, attributeFilter: ['class'] });
    });

    /* 2. Вынос попапа ответственных из обрезающего контейнера */
    document.addEventListener('click', function(e) {
        var btn = e.target.closest('[data-act="hyp-asg"], [data-act="job-asg"]');
        if (!btn) return;
        
        setTimeout(function() {
            var pop = document.querySelector('.hyp-asg-pop');
            if (!pop) return;
            if (pop.parentNode === document.body) return; // уже вынесли
            
            var rect = btn.getBoundingClientRect();
            
            // Переносим прямо в <body>, чтобы никакой скролл его не обрезал
            document.body.appendChild(pop);
            
            // Позиционируем ровно под кнопкой
            pop.style.position = 'fixed';
            pop.style.top = (rect.bottom + 5) + 'px';
            pop.style.left = rect.left + 'px';
            pop.style.margin = '0';
            pop.style.zIndex = '99999';
        }, 10);
    }, true);

    /* 3. Закрытие попапа при клике в пустоту */
    document.addEventListener('mousedown', function(e) {
        var pop = document.querySelector('.hyp-asg-pop');
        if (!pop) return;
        if (e.target.closest('.hyp-asg-pop') || e.target.closest('[data-act="hyp-asg"]') || e.target.closest('[data-act="job-asg"]')) return;
        pop.remove();
    });

    /* 4. Клик в Своде по задаче -> карточка задачи */
    document.addEventListener('click', function(e) {
        var td = e.target.closest('#sumWrap td.day-cell');
        if (!td) return;
        var taskId = td.getAttribute('data-task');
        var empId = td.getAttribute('data-emp');
        var dateStr = td.getAttribute('data-date');
        
        if (!taskId && empId && td.hasAttribute('data-absence')) {
            e.preventDefault(); e.stopImmediatePropagation();
            if (typeof window.__trkOpenEmpDayModal === 'function') window.__trkOpenEmpDayModal(empId, dateStr);
            return;
        }
        if (taskId && taskId !== '__collapsed__') {
            e.preventDefault(); e.stopImmediatePropagation();
            if (typeof window.__trkOpenTaskCardModal === 'function') window.__trkOpenTaskCardModal(taskId);
        }
    }, true);

    /* 5. Возврат гипотез в grid */
    function fixHyp() {
        var tm = document.getElementById('taskModal');
        if (!tm || !tm.classList.contains('active')) return;
        var hg = document.getElementById('hypTreeGroup');
        var grid = tm.querySelector('.task-modal-grid');
        if (hg && grid) {
            if (hg.parentNode !== grid) grid.appendChild(hg);
            hg.hidden = false;
            hg.style.display = 'block';
            hg.classList.add('trk-hyp-fullwidth');
        }
    }
    var tm = document.getElementById('taskModal');
    if (tm && !tm._hypV112Obs) {
        tm._hypV112Obs = true;
        new MutationObserver(function(){
            if (tm.classList.contains('active')) {
                setTimeout(fixHyp, 50);
                setTimeout(fixHyp, 250);
                setTimeout(fixHyp, 600);
            }
        }).observe(tm, { attributes: true, attributeFilter: ['class'] });
    }
})();


/* ============================================================
   PATCH v1.2.0 — Карточка «Сотрудник»:
   1) выпадающий список «Должность» из уже заполненных данных
      (серверный справочник /api/tracker/roles + state.employees);
   2) гарантированно фиксированные заголовок и футер
      («💾 Сохранить» / «Закрыть») — скроллится только тело модалки.
   ============================================================ */
(function() {
    'use strict';
    if (window.__trkEmpCardV120) return;
    window.__trkEmpCardV120 = true;

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    /* ---------- 1. Справочник должностей ---------- */
    var _rolesCache = [];
    var _rolesLoadedAt = 0;

    function collectLocalRoles() {
        var out = {};
        var sts = [window.state, window.__trkState];
        for (var i = 0; i < sts.length; i++) {
            var st = sts[i];
            if (!st || !Array.isArray(st.employees)) continue;
            st.employees.forEach(function(e) {
                var r = ((e && e.role) || '').trim();
                if (r) out[r] = true;
            });
        }
        return Object.keys(out).sort(function(a, b) {
            return a.toLowerCase().localeCompare(b.toLowerCase(), 'ru');
        });
    }

    function allRoles() {
        var seen = {}, res = [];
        _rolesCache.concat(collectLocalRoles()).forEach(function(r) {
            r = String(r || '').trim();
            if (r && !seen[r.toLowerCase()]) { seen[r.toLowerCase()] = 1; res.push(r); }
        });
        return res.sort(function(a, b) {
            return a.toLowerCase().localeCompare(b.toLowerCase(), 'ru');
        });
    }

    function loadRoles(force) {
        var now = Date.now();
        if (!force && (_rolesLoadedAt === 0 && _rolesCache.length)) return;
        if (!force && (now - _rolesLoadedAt) < 15000) return;
        _rolesLoadedAt = now;
        try {
            apiJson('/api/tracker/roles', { method: 'GET' })
                .then(function(d) {
                    if (d && d.success && Array.isArray(d.roles)) _rolesCache = d.roles;
                    renderRoleOptions();
                })
                .catch(function() {});
        } catch (e) {}
    }

    function renderRoleOptions() {
        var sel = document.getElementById('emp_role_select');
        var inp = document.getElementById('emp_role');
        var dl = document.getElementById('emp_role_list');
        var cur = inp ? inp.value.trim() : '';
        var roles = allRoles();

        if (dl) {
            dl.innerHTML = roles.map(function(r) {
                return '<option value="' + esc(r) + '"></option>';
            }).join('');
        }
        if (!sel) return;
        var html = '<option value="">— выберите должность —</option>';
        if (cur && roles.indexOf(cur) === -1) {
            html += '<option value="' + esc(cur) + '" selected>' + esc(cur)
                  + ' (текущая)</option>';
        }
        roles.forEach(function(r) {
            html += '<option value="' + esc(r) + '"'
                  + ((r === cur && !(cur && roles.indexOf(cur) === -1)) ? ' selected' : '')
                  + '>' + esc(r) + '</option>';
        });
        sel.innerHTML = html;
        if (cur && roles.indexOf(cur) !== -1) sel.value = cur;
    }

    /* ---------- 2. Фиксация заголовка и футера ---------- */
    function fixLayout() {
        var modal = document.getElementById('employeeModal');
        if (!modal) return;
        var content = modal.querySelector('.modal-content');
        if (!content) return;
        var header = document.getElementById('employeeModalHeader');
        var footer = content.querySelector('.modal-actions');
        if (!footer) return;
        if (!header) {
            var h2 = content.querySelector('h2');
            if (h2) {
                header = document.createElement('div');
                header.className = 'emp-modal-header';
                header.id = 'employeeModalHeader';
                h2.parentNode.insertBefore(header, h2);
                header.appendChild(h2);
            }
        }
        if (!content.querySelector('.emp-modal-body')) {
            var body = document.createElement('div');
            body.className = 'emp-modal-body';
            while (content.firstElementChild
                   && content.firstElementChild !== header
                   && content.firstElementChild !== footer) {
                body.appendChild(content.firstElementChild);
            }
            content.insertBefore(body, footer);
        }
        content.classList.add('emp-modal-fixed');
        content.style.setProperty('display', 'flex', 'important');
        content.style.setProperty('flex-direction', 'column', 'important');
        content.style.setProperty('overflow', 'hidden', 'important');
        content.style.setProperty('max-height', 'min(88vh, 860px)', 'important');
        content.style.setProperty('padding', '0', 'important');
        if (header) {
            header.style.setProperty('position', 'sticky', 'important');
            header.style.setProperty('top', '0', 'important');
            header.style.setProperty('z-index', '5', 'important');
            header.style.setProperty('background', 'var(--trk-modal-bg, #141414)', 'important');
        }
        var bodyEl = content.querySelector('.emp-modal-body');
        if (bodyEl) {
            bodyEl.style.setProperty('flex', '1 1 auto', 'important');
            bodyEl.style.setProperty('overflow-y', 'auto', 'important');
            bodyEl.style.setProperty('min-height', '0', 'important');
            bodyEl.style.setProperty('padding', '14px 26px 6px', 'important');
        }
        footer.classList.add('emp-modal-footer');
        footer.style.setProperty('position', 'sticky', 'important');
        footer.style.setProperty('bottom', '0', 'important');
        footer.style.setProperty('z-index', '5', 'important');
        footer.style.setProperty('background', 'var(--trk-modal-bg, #141414)', 'important');
        footer.style.setProperty('margin', '0', 'important');
    }

    function ensureSubtitle() {
        var header = document.getElementById('employeeModalHeader');
        if (!header) return;
        if (document.getElementById('employeeModalSubtitle')) return;
        var sub = document.createElement('div');
        sub.id = 'employeeModalSubtitle';
        sub.style.cssText = 'font-size:.8rem;color:var(--trk-meta,#9aa);margin-top:2px;';
        header.appendChild(sub);
    }

    /* ---------- 3. Обвязка событий ---------- */
    function onOpen() {
        renderRoleOptions();
        loadRoles(false);
    }

    function boot() {
        var modal = document.getElementById('employeeModal');
        if (!modal) return;

        var mo = new MutationObserver(function(muts) {
            muts.forEach(function(m) {
                if (m.type === 'attributes' && m.attributeName === 'class') {
                    if (modal.classList.contains('active')) {
                        fixLayout();
                        ensureSubtitle();
                        onOpen();
                    }
                }
            });
        });
        mo.observe(modal, { attributes: true, attributeFilter: ['class'] });

        if (modal.classList.contains('active')) { fixLayout(); ensureSubtitle(); onOpen(); }

        var sel = document.getElementById('emp_role_select');
        var inp = document.getElementById('emp_role');
        if (sel && inp) {
            sel.addEventListener('change', function() {
                if (sel.value) {
                    inp.value = sel.value;
                } else {
                    inp.focus();
                    renderRoleOptions();
                }
            });
        }
        if (inp) {
            inp.addEventListener('focus', function() { loadRoles(true); renderRoleOptions(); });
            inp.addEventListener('input', function() {
                if (sel) {
                    var v = inp.value.trim();
                    var has = Array.prototype.some.call(sel.options, function(o) { return o.value === v; });
                    if (has) sel.value = v;
                }
            });
        }

        // обновляем варианты после любой загрузки состояния
        try {
            if (typeof window.loadState === 'function' && !window.loadState.__roleWrapV120) {
                var _orig = window.loadState;
                var wrapped = function() {
                    var p = _orig.apply(this, arguments);
                    try {
                        if (p && typeof p.then === 'function') {
                            p.then(function() {
                                setTimeout(renderRoleOptions, 50);
                            }, function() {});
                        }
                    } catch (x) {}
                    return p;
                };
                wrapped.__roleWrapV120 = true;
                window.loadState = wrapped;
            }
        } catch (x) {}
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

    window.__trkRolesV120 = {
        reload: function() { loadRoles(true); renderRoleOptions(); },
        render: renderRoleOptions,
        fixLayout: fixLayout,
    };
})();

// ============================================================
// PATCH v1.4.3 (final): «Проверка → Гипотезы → Задания».
// Консолидирует v1.3.2 + v1.3.3 + v1.3.4…v1.4.3 в один блок.
// Плоский черновик window.__trkHypDraft конвертируется в дерево
// в saveTask. UI — native <details>, кнопки статусов без inline
// onclick (capture-phase delegation), спойлер ответственных,
// имена ответственных в свёрнутой шапке, статус по умолчанию
// «В работе».
// ============================================================
(function() {
    var DRAFT_KEY = '__trkHypDraft';
    function draft() {
        if (!Array.isArray(window[DRAFT_KEY])) window[DRAFT_KEY] = [];
        return window[DRAFT_KEY];
    }
    function setDraft(a) { window[DRAFT_KEY] = a; }
    function uid(p) {
        return p + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    }
    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }
    function findItem(id) {
        var a = draft();
        for (var i = 0; i < a.length; i++) if (a[i].id === id) return a[i];
        return null;
    }
    function updField(id, key, val) {
        var it = findItem(id);
        if (it) it[key] = val;
    }
    function removeNode(id) {
        var a = draft();
        var kids = {};
        kids[id] = true;
        var changed = true;
        while (changed) {
            changed = false;
            for (var i = 0; i < a.length; i++) {
                if (kids[a[i].id]) continue;
                if (a[i].parent && kids[a[i].parent]) { kids[a[i].id] = true; changed = true; }
            }
        }
        setDraft(a.filter(function(x) { return !kids[x.id]; }));
        renumber();
        renderHypTree();
    }
    function renumber() {
        var a = draft(), n = 0;
        for (var i = 0; i < a.length; i++) if (a[i].kind === 'hypothesis') a[i].no = ++n;
    }
    function addHypothesis() {
        var a = draft().slice();
        a.push({ id: uid('h'), kind: 'hypothesis', parent: '', no: a.length + 1,
                 title: '', description: '', date_from: '', date_to: '',
                 status: 'in_progress', assignees: [] });
        setDraft(a); renumber(); renderHypTree();
    }
    function addTask(hypId) {
        var a = draft().slice();
        var pos = -1;
        for (var i = 0; i < a.length; i++) if (a[i].id === hypId) { pos = i; break; }
        if (pos === -1) return;
        var j = pos + 1;
        while (j < a.length && a[j].kind === 'task' && a[j].parent === hypId) j++;
        a.splice(j, 0, { id: uid('t'), kind: 'task', parent: hypId, no: 0,
                         title: '', description: '', date_from: '', date_to: '',
                         status: 'in_progress', assignees: [] });
        setDraft(a); renumber(); renderHypTree();
    }

    function _getAsgNames(asg) {
        if (!asg || !asg.length) return '';
        var st = window.__trkState || {};
        var emps = st.employees || [];
        var names = asg.map(function(id) {
            var e = null;
            for (var i = 0; i < emps.length; i++) if (emps[i].id === id) { e = emps[i]; break; }
            if (!e) return id;
            var parts = String(e.name || '').split(/\s+/);
            return parts[0] + (parts[1] ? ' ' + parts[1][0] + '.' : '');
        });
        var disp = names.slice(0, 2).join(', ');
        if (names.length > 2) disp += ' +' + (names.length - 2);
        var full = [];
        for (var k = 0; k < asg.length; k++) {
            var f = null;
            for (var m = 0; m < emps.length; m++) if (emps[m].id === asg[k]) { f = emps[m]; break; }
            full.push(f ? f.name : asg[k]);
        }
        return '<span class="hyp-asg-preview" title="' + esc(full.join(', ')) + '">👤 ' + esc(disp) + '</span>';
    }

    function peopleHtml(item) {
        var st = window.__trkState || {};
        var emps = st.employees || [];
        if (!emps.length) return '<div class="hyp-empty" style="padding:10px;">Список сотрудников пуст — добавьте сотрудников и обновите страницу</div>';
        var sel = item.assignees || [];
        var html = '<div class="hyp-people-list">';
        for (var i = 0; i < emps.length; i++) {
            var e = emps[i];
            var on = sel.indexOf(String(e.id)) !== -1 || sel.indexOf(e.id) !== -1;
            html += '<label class="hyp-person"><input type="checkbox" value="' + esc(e.id) + '"' + (on ? ' checked' : '') + '>'
                  + '<span class="hyp-dot" style="background:' + esc(e.color || '#888') + '"></span>'
                  + '<span>' + esc(e.name || '') + (e.fired ? ' 🚪' : '') + '</span></label>';
        }
        html += '</div>';
        return html;
    }

    function _statusIcon(st) {
        return st === 'done' ? '✅' : (st === 'failed' ? '❌' : (st === 'in_progress' ? '🔄' : '⏳'));
    }

    function _progressNotesHtml(item) {
        // PATCH v1.5.1: список отметок о ходе работы для гипотезы/задания
        var taskIdEl = document.getElementById('task_id');
        var taskId = taskIdEl ? taskIdEl.value : '';
        if (!taskId || !item || !item.id) return '';
        var st = window.__trkState || {};
        var logs = (st.log || []).filter(function(l){
            return l && l.task_id === taskId && l.hyp_item_id === item.id;
        });
        if (!logs.length) {
            return '<details class="hyp-progress-details"><summary class="hyp-progress-label">📝 Отметки о ходе работы <span class="hyp-progress-count">0</span></summary><div class="hyp-progress-empty">Пока нет отметок по этой гипотезе/заданию</div></details>';
        }
        logs.sort(function(a, b){ return String(b.date || '').localeCompare(String(a.date || '')); });
        var emps = st.employees || [];
        function _einit(name){
            var p = String(name || '').trim().split(/\\s+/);
            if (!p.length) return '?';
            if (p.length === 1) return p[0].slice(0, 2).toUpperCase();
            return ((p[0][0] || '') + (p[1][0] || '')).toUpperCase();
        }
        function _stIcon(s){
            return s === 'done' ? '✅' : (s === 'in_progress' ? '🔵' : (s === 'blocked' ? '🔴' : '📝'));
        }
        var html = '<div class="hyp-progress-list">';
        logs.forEach(function(l){
            var e = null;
            for (var i = 0; i < emps.length; i++) if (emps[i].id === l.employee_id) { e = emps[i]; break; }
            var empName = e ? (e.name || l.employee_id) : l.employee_id;
            var color = e ? (e.color || '#888') : '#888';
            html += '<div class="hyp-progress-item" data-log-id="' + esc(String(l.id || '')) + '">'
                 +   '<span class="hyp-progress-avatar" style="background:' + esc(color) + ';">' + esc(_einit(empName)) + '</span>'
                 +   '<div class="hyp-progress-body">'
                 +     '<div class="hyp-progress-line1">'
                 +       '<b>' + esc(empName) + '</b>'
                 +       '<span class="hyp-progress-date">' + esc(l.date || '') + '</span>'
                 +       '<span class="hyp-progress-st">' + _stIcon(l.status) + ' ' + esc(String(l.hours || 0)) + ' ч</span>'
                 +     '</div>'
                 +     (l.comment ? '<div class="hyp-progress-comment">' + esc(l.comment) + '</div>' : '')
                 +   '</div></div>';
        });
        html += '</div>';
        return '<details class="hyp-progress-details"><summary class="hyp-progress-label">📝 Отметки о ходе работы <span class="hyp-progress-count">' + logs.length + '</span></summary>' + html + '</details>';
    }
    function fieldsHtml(item, isTask) {
        var _isOverdue = false;
        if (item.date_to && item.status !== 'done') {
            var _today = (window.__trkState && window.__trkState.today) || '';
            if (_today && item.date_to < _today) _isOverdue = true;
        }
        var _cardCls = 'hyp-fields' + (_isOverdue ? ' hyp-overdue' : '');
        var _asgCnt = (item.assignees && item.assignees.length) || 0;
        return '<div class="' + _cardCls + '">'
            + '<div class="hyp-row"><input type="text" class="hyp-fld hyp-title-input" data-k="title" maxlength="200" placeholder="' + (isTask ? 'Название задания *' : 'Название гипотезы *') + '" value="' + esc(item.title) + '"></div>'
            + '<div class="hyp-row"><textarea class="hyp-fld hyp-desc-input" data-k="description" rows="2" maxlength="4000" placeholder="Описание">' + esc(item.description) + '</textarea></div>'
            + '<div class="hyp-meta-row">'
            +   '<div class="hyp-dates">'
            +     '<label>С <input type="date" class="hyp-fld" data-k="date_from" value="' + esc(item.date_from) + '"></label>'
            +     '<label>По <input type="date" class="hyp-fld" data-k="date_to" value="' + esc(item.date_to) + '"></label>'
            +   '</div>'
            +   '<div class="hyp-st-group">'
            +     '<button type="button" class="hyp-st-btn planned ' + (item.status === 'planned' ? 'active' : '') + '" data-st="planned" title="Планируется">⏳</button>'
            +     '<button type="button" class="hyp-st-btn in_progress ' + (item.status === 'in_progress' ? 'active' : '') + '" data-st="in_progress" title="В работе">🔄</button>'
            +     '<button type="button" class="hyp-st-btn done ' + (item.status === 'done' ? 'active' : '') + '" data-st="done" title="Выполнено">✅</button>'
            +     '<button type="button" class="hyp-st-btn failed ' + (item.status === 'failed' ? 'active' : '') + '" data-st="failed" title="Не подтверждено">❌</button>'
            +   '</div>'
            + '</div>'
            + '<details class="hyp-people-details"><summary class="hyp-people-label">👥 Ответственные <span class="hyp-people-count">' + _asgCnt + '</span></summary>' + peopleHtml(item) + '</details>'
            + _progressNotesHtml(item)
            + '</div>';
    }

    function renderHypTree() {
        var root = document.getElementById('hypTreeRoot');
        var badge = document.getElementById('hypCountBadge');
        if (badge) {
            var hn = draft().filter(function(x) { return x.kind === 'hypothesis'; }).length;
            var tn = draft().filter(function(x) { return x.kind === 'task'; }).length;
            badge.textContent = hn + ' гип., ' + tn + ' зад.';
        }
        if (!root) return;
        var a = draft();
        if (!a.filter(function(x) { return x.kind === 'hypothesis'; }).length) {
            root.innerHTML = '<div class="hyp-empty">Гипотез пока нет — нажмите «➕ Добавить гипотезу».</div>';
            return;
        }
        var openState = {};
        root.querySelectorAll('details[data-id]').forEach(function(el) {
            openState[el.getAttribute('data-id')] = el.hasAttribute('open');
        });
        var html = '';
        var hyps = a.filter(function(x) { return x.kind === 'hypothesis'; });
        for (var i = 0; i < hyps.length; i++) {
            var h = hyps[i];
            var kids = a.filter(function(x) { return x.kind === 'task' && x.parent === h.id; });
            var doneCnt = kids.filter(function(x) { return x.status === 'done'; }).length;
            var isHOpen = openState[h.id] !== false;
            html += '<details class="hyp-card" data-id="' + esc(h.id) + '"' + (isHOpen ? ' open' : '') + '>'
                + '<summary class="hyp-head">'
                +   '<div class="hyp-head-left">'
                +     '<span class="hyp-num">🧪 Гипотеза ' + (h.no || (i + 1)) + '</span>'
                +     '<span class="hyp-title-preview">' + esc(h.title || 'Без названия') + '</span>'
                +     _getAsgNames(h.assignees)
                +   '</div>'
                +   '<div class="hyp-head-right">'
                +     '<span class="hyp-progress">Задания: ' + doneCnt + '/' + kids.length + '</span>'
                +     '<button type="button" class="btn btn-secondary hyp-add-task">➕ Задание</button>'
                +     '<button type="button" class="hyp-del-btn" title="Удалить гипотезу">✕</button>'
                +   '</div>'
                + '</summary>'
                + '<div class="hyp-body">' + fieldsHtml(h, false)
                + '<div class="hyp-tasks-list">'
                + kids.map(function(t, ti) {
                    var isTOpen = openState[t.id] !== false;
                    return '<details class="hyp-task-block" data-id="' + esc(t.id) + '"' + (isTOpen ? ' open' : '') + '>'
                        + '<summary class="hyp-task-head">'
                        +   '<div class="hyp-task-head-left">'
                        +     '<span class="hyp-task-num">📌 Задание ' + (ti + 1) + '</span>'
                        +     '<span class="hyp-task-title" id="task-title-prev-' + esc(t.id) + '">' + esc(t.title || 'Без названия') + '</span>'
                        +     '<span class="hyp-task-status-icon">' + _statusIcon(t.status) + '</span>'
                        +     _getAsgNames(t.assignees)
                        +   '</div>'
                        +   '<button type="button" class="hyp-del-btn" title="Удалить задание">✕</button>'
                        + '</summary>'
                        + fieldsHtml(t, true) + '</details>';
                }).join('')
                + '</div>'
                + '</div></details>';
        }
        root.innerHTML = html;
    }
    window.renderHypTree = renderHypTree;
    window.__renderHypTree = renderHypTree;

    document.addEventListener('click', function(ev) {
        var t = ev.target;
        if (!t || !t.closest) return;
        var stBtn = t.closest('.hyp-st-btn');
        if (stBtn) {
            ev.preventDefault(); ev.stopPropagation();
            var holder = stBtn.closest('[data-id]');
            if (!holder) return;
            var itemId = holder.getAttribute('data-id');
            var newSt = stBtn.getAttribute('data-st');
            var it = findItem(itemId);
            if (it) it.status = newSt;
            renderHypTree();
            var tidEl = document.getElementById('task_id');
            var taskId = tidEl ? tidEl.value : '';
            if (taskId) {
                var hdrs = {'Content-Type': 'application/json'};
                if (window.REESTR_CSRF) hdrs['X-CSRF-Token'] = window.REESTR_CSRF;
                fetch('/api/tracker/hypothesis/status', {
                    method: 'POST', headers: hdrs, credentials: 'same-origin',
                    body: JSON.stringify({ task_id: taskId, item_id: itemId, status: newSt })
                }).then(function(r){ return r.json(); }).then(function(d){
                    if (d && d.success) {
                        var _st = window.__trkState;
                        if (_st && _st.tasks) {
                            var _t = _st.tasks.find(function(x){ return x.id === taskId; });
                            if (_t && Array.isArray(_t.hypotheses)) {
                                var _h = _t.hypotheses.find(function(x){ return x.id === itemId; });
                                if (_h) _h.status = newSt;
                            }
                        }
                    }
                }).catch(function(err){ console.warn('Status update failed', err); });
            }
            return;
        }
        var del = t.closest('.hyp-del-btn');
        if (del) {
            ev.preventDefault(); ev.stopPropagation();
            var blk = del.closest('.hyp-task-block');
            var card = del.closest('.hyp-card');
            if (blk) removeNode(blk.getAttribute('data-id'));
            else if (card) removeNode(card.getAttribute('data-id'));
            return;
        }
        var addT = t.closest('.hyp-add-task');
        if (addT) {
            ev.preventDefault(); ev.stopPropagation();
            var c = addT.closest('.hyp-card');
            if (c) addTask(c.getAttribute('data-id'));
            return;
        }
        var addH = t.closest('#hypAddBtn');
        if (addH) { ev.preventDefault(); addHypothesis(); return; }
        if (t.tagName === 'BUTTON' && t.closest('summary.hyp-head, summary.hyp-task-head')) {
            ev.preventDefault();
        }
    }, true);

    document.addEventListener('change', function(ev) {
        var t = ev.target;
        if (!t || !t.classList) return;
        if (t.classList.contains('hyp-fld')) {
            var holder = t.closest('[data-id]');
            if (!holder) return;
            var _id = holder.getAttribute('data-id');
            var _k = t.getAttribute('data-k');
            updField(_id, _k, t.value);
            if (_k === 'title') {
                var _card = t.closest('.hyp-card');
                var _task = t.closest('.hyp-task-block');
                if (_task) {
                    var _prev = document.getElementById('task-title-prev-' + _id);
                    if (_prev) _prev.textContent = t.value || 'Без названия';
                } else if (_card) {
                    var _pv = _card.querySelector('.hyp-title-preview');
                    if (_pv) _pv.textContent = t.value || 'Без названия';
                }
            }
        }
        if (t.type === 'checkbox' && t.closest('.hyp-people-list')) {
            var holder2 = t.closest('[data-id]');
            if (!holder2) return;
            var it = findItem(holder2.getAttribute('data-id'));
            if (!it) return;
            var box = t.closest('.hyp-people-list');
            var picked = [];
            box.querySelectorAll('input[type="checkbox"]:checked').forEach(function(cb) { picked.push(cb.value); });
            it.assignees = picked;
            var details = t.closest('.hyp-people-details');
            if (details) {
                var cntEl = details.querySelector('.hyp-people-count');
                if (cntEl) cntEl.textContent = picked.length;
            }
        }
    });

    document.addEventListener('input', function(ev) {
        var t = ev.target;
        if (t && t.classList && t.classList.contains('hyp-fld')) {
            var holder = t.closest('[data-id]');
            if (holder) updField(holder.getAttribute('data-id'), t.getAttribute('data-k'), t.value);
        }
    });

    try {
        var oldScreen = document.getElementById('hypEditorScreen');
        if (oldScreen && oldScreen.parentNode) oldScreen.parentNode.removeChild(oldScreen);
        var oldStyle = document.getElementById('hyp-editor-style');
        if (oldStyle) oldStyle.remove();
    } catch (e) {}

    var _btn = document.getElementById('hypAddBtn');
    if (_btn) _btn.addEventListener('click', function(e) { e.preventDefault(); addHypothesis(); });
})();


/* ============================================================
   PATCH v1.4.5 — бейдж прогресса гипотез на плитке задачи.
   Добавляем через MutationObserver, а не через замену taskCardRowGrid:
   так неважно, был ли применён v1.4.4 или откачен, и какие ещё патчи
   трогали карточку задачи.
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkHypBadgeV145) return;
    window.__trkHypBadgeV145 = true;

    function _computeBadge(t) {
        if (!t || !Array.isArray(t.hypotheses) || !t.hypotheses.length) return null;
        var hyps = t.hypotheses.filter(function(x){ return x && x.kind === 'hypothesis'; });
        var tasks = t.hypotheses.filter(function(x){ return x && x.kind === 'task'; });
        if (!hyps.length && !tasks.length) return null;
        var hd = hyps.filter(function(x){ return x.status === 'done'; }).length;
        var td = tasks.filter(function(x){ return x.status === 'done'; }).length;
        var parts = [];
        if (hyps.length) parts.push('🧪 ' + hd + '/' + hyps.length);
        if (tasks.length) parts.push('📌 ' + td + '/' + tasks.length);
        var allDone = (hd === hyps.length && td === tasks.length);
        var anyDone = (hd > 0 || td > 0);
        var cls = allDone ? 'hyp-badge-done' : (anyDone ? 'hyp-badge-progress' : 'hyp-badge-new');
        return {
            text: parts.join(' · '),
            cls: cls,
            title: 'Гипотезы: ' + hd + '/' + hyps.length + ' · Задания: ' + td + '/' + tasks.length
        };
    }

    function _apply() {
        var list = document.getElementById('tasksFullList');
        if (!list) return;
        var st = window.__trkState || {};
        var byId = {};
        (st.tasks || []).forEach(function(t){ if (t && t.id) byId[t.id] = t; });
        list.querySelectorAll('.task-card, .dict-item').forEach(function(card){
            var id = card.getAttribute('data-id');
            if (!id) return;
            var info = _computeBadge(byId[id]);
            var existing = card.querySelector('.task-card-badge.hyp-badge');
            if (!info) {
                if (existing) existing.remove();
                return;
            }
            var badge = existing;
            if (!badge) {
                badge = document.createElement('span');
                badge.className = 'task-card-badge hyp-badge ' + info.cls;
                var target = card.querySelector('.task-card-topright')
                          || card.querySelector('.dict-actions')
                          || card.querySelector('.task-card-head');
                if (target) target.appendChild(badge);
                else card.appendChild(badge);
            }
            badge.className = 'task-card-badge hyp-badge ' + info.cls;
            badge.textContent = info.text;
            badge.title = info.title;
        });
    }

    function _observe() {
        var list = document.getElementById('tasksFullList');
        if (!list || list._hypBadgeObsV145) return;
        list._hypBadgeObsV145 = true;
        new MutationObserver(function(){ setTimeout(_apply, 30); }).observe(list, { childList: true });
        setTimeout(_apply, 60);
    }

    function boot() {
        _observe();
        setTimeout(function(){ _observe(); _apply(); }, 300);
        setTimeout(_apply, 1000);
        setTimeout(_apply, 2500);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('.tracker-tab[data-tab="tasks"]') ||
            e.target.closest('#tskViewSeg button') ||
            e.target.closest('#tskViewMode button')) {
            setTimeout(_apply, 200);
            setTimeout(_apply, 500);
        }
    }, true);

    window.__trkAddHypBadges = _apply;
})();


/* ============================================================
   PATCH v1.4.6 — Timeline-вид + валидация дат гипотез/заданий
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkTimelineAndValidationV146) return;
    window.__trkTimelineAndValidationV146 = true;

    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
        });
    }
    function _state() { return window.__trkState || {}; }

    /* ===== БЕЙДЖ ГИПОТЕЗ (совместим с v1.4.5) ===== */
    function _computeHypBadge(t) {
        if (!t || !Array.isArray(t.hypotheses) || !t.hypotheses.length) return null;
        var hyps = t.hypotheses.filter(function(x){ return x && x.kind === 'hypothesis'; });
        var tasks = t.hypotheses.filter(function(x){ return x && x.kind === 'task'; });
        if (!hyps.length && !tasks.length) return null;
        var hd = hyps.filter(function(x){ return x.status === 'done'; }).length;
        var td = tasks.filter(function(x){ return x.status === 'done'; }).length;
        var parts = [];
        if (hyps.length) parts.push('🧪 ' + hd + '/' + hyps.length);
        if (tasks.length) parts.push('📌 ' + td + '/' + tasks.length);
        var allDone = (hd === hyps.length && td === tasks.length);
        var anyDone = (hd > 0 || td > 0);
        var cls = allDone ? 'hyp-badge-done' : (anyDone ? 'hyp-badge-progress' : 'hyp-badge-new');
        return { text: parts.join(' · '), cls: cls, title: 'Гипотезы: ' + hd + '/' + hyps.length + ' · Задания: ' + td + '/' + tasks.length };
    }

    function _applyBadges() {
        var list = document.getElementById('tasksFullList');
        if (!list) return;
        var st = _state();
        var byId = {};
        (st.tasks || []).forEach(function(t){ if (t && t.id) byId[t.id] = t; });
        list.querySelectorAll('.task-card, .dict-item').forEach(function(card){
            var id = card.getAttribute('data-id');
            if (!id) return;
            var info = _computeHypBadge(byId[id]);
            var existing = card.querySelector('.task-card-badge.hyp-badge');
            if (!info) { if (existing) existing.remove(); return; }
            var badge = existing;
            if (!badge) {
                badge = document.createElement('span');
                var target = card.querySelector('.task-card-topright') || card.querySelector('.task-card-head');
                if (target) target.appendChild(badge);
                else card.appendChild(badge);
            }
            badge.className = 'task-card-badge hyp-badge ' + info.cls;
            badge.textContent = info.text;
            badge.title = info.title;
        });
    }

    /* Бейдж ставим только если v1.4.5 не применялся */
    if (!window.__trkHypBadgeV145) {
        function _observeBadge() {
            var list = document.getElementById('tasksFullList');
            if (!list || list._hypBadgeObsV146) return;
            list._hypBadgeObsV146 = true;
            new MutationObserver(function(){ setTimeout(_applyBadges, 30); }).observe(list, { childList: true });
            setTimeout(_applyBadges, 60);
        }
        setTimeout(_observeBadge, 300);
        setTimeout(_observeBadge, 1000);
        setTimeout(_applyBadges, 2500);
    }

    /* ===== ВАЛИДАЦИЯ ===== */
    function _daysBetween(a, b) {
        if (!a || !b) return 0;
        var pa = String(a).split('-'); var pb = String(b).split('-');
        try {
            var da = new Date(+pa[0], +pa[1]-1, +pa[2]);
            var db = new Date(+pb[0], +pb[1]-1, +pb[2]);
            return Math.round((db - da) / 86400000) + 1;
        } catch(e) { return 0; }
    }

    function _validateHypDraft(taskStart, taskDeadline) {
        var errors = [];
        var hyps = [], jobs = [];
        (window.__trkHypDraft || []).forEach(function(x) {
            if (x && x.kind === 'hypothesis') hyps.push(x);
            else if (x && x.kind === 'task') jobs.push(x);
        });
        if (!hyps.length && !jobs.length) return errors;
        var taskDur = (taskStart && taskDeadline) ? _daysBetween(taskStart, taskDeadline) : 0;
        var hypDurSum = 0;
        hyps.forEach(function(h) {
            var nm = h.title || '(без названия)';
            if (taskStart && h.date_from && h.date_from < taskStart) {
                errors.push('Гипотеза «' + nm + '»: начало ' + h.date_from + ' раньше задачи (' + taskStart + ')');
            }
            if (taskDeadline && h.date_to && h.date_to > taskDeadline) {
                errors.push('Гипотеза «' + nm + '»: конец ' + h.date_to + ' позже дедлайна задачи (' + taskDeadline + ')');
            }
            if (h.date_from && h.date_to && h.date_to >= h.date_from) {
                hypDurSum += _daysBetween(h.date_from, h.date_to);
            }
        });
        if (taskDur > 0 && hypDurSum > taskDur) {
            errors.push('Сумма сроков гипотез (' + hypDurSum + ' дн) превышает срок задачи (' + taskDur + ' дн)');
        }
        hyps.forEach(function(h) {
            var nm = h.title || '(без названия)';
            var kids = jobs.filter(function(tk){ return tk.parent === h.id; });
            if (!kids.length) return;
            var hypDur = (h.date_from && h.date_to) ? _daysBetween(h.date_from, h.date_to) : 0;
            var jobDurSum = 0;
            kids.forEach(function(tk) {
                var jnm = tk.title || '(без названия)';
                if (h.date_from && tk.date_from && tk.date_from < h.date_from) {
                    errors.push('Задание «' + jnm + '» в гипотезе «' + nm + '»: начало раньше гипотезы');
                }
                if (h.date_to && tk.date_to && tk.date_to > h.date_to) {
                    errors.push('Задание «' + jnm + '» в гипотезе «' + nm + '»: конец позже гипотезы');
                }
                if (tk.date_from && tk.date_to && tk.date_to >= tk.date_from) {
                    jobDurSum += _daysBetween(tk.date_from, tk.date_to);
                }
            });
            if (hypDur > 0 && jobDurSum > hypDur) {
                errors.push('Сумма сроков заданий гипотезы «' + nm + '» (' + jobDurSum + ' дн) превышает её срок (' + hypDur + ' дн)');
            }
        });
        return errors;
    }

    function _showValidationErrors(errs) {
        var container = document.getElementById('hypTreeRoot');
        if (!container) return;
        var block = document.getElementById('hypValidationErrors');
        if (!block) {
            block = document.createElement('div');
            block.id = 'hypValidationErrors';
            block.className = 'hyp-validation-errors';
            container.parentNode.insertBefore(block, container.nextSibling);
        }
        if (!errs.length) { block.remove(); return; }
        block.innerHTML = '<div class="hve-title">⚠ Ошибки в датах гипотез/заданий (' + errs.length + '):</div>'
            + '<ul>' + errs.map(function(e){ return '<li>' + esc(e) + '</li>'; }).join('') + '</ul>';
        try { block.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch(e){}
    }

    function _liveValidate() {
        var tm = document.getElementById('taskModal');
        if (!tm || !tm.classList.contains('active')) return;
        var s = (document.getElementById('task_start_date') || {}).value || '';
        var e = (document.getElementById('task_deadline') || {}).value || '';
        _showValidationErrors(_validateHypDraft(s, e));
    }

    document.addEventListener('change', function(ev) {
        var t = ev.target;
        if (!t) return;
        if (t.id === 'task_start_date' || t.id === 'task_deadline') {
            setTimeout(_liveValidate, 50); return;
        }
        if (t.classList && t.classList.contains('hyp-fld') &&
            (t.getAttribute('data-k') === 'date_from' || t.getAttribute('data-k') === 'date_to')) {
            setTimeout(_liveValidate, 100);
        }
    }, true);

    /* ===== FETCH-ХУК: блокировка сохранения ===== */
    var _nativeFetch = window.fetch;
    if (typeof _nativeFetch === 'function' && !window.__trkHypValFetchV146) {
        window.__trkHypValFetchV146 = true;
        window.fetch = function(url, opts) {
            if (typeof url !== 'string' || url.indexOf('/api/tracker/task/save') === -1) {
                return _nativeFetch.apply(this, arguments);
            }
            if (!opts || (opts.method || 'GET').toUpperCase() !== 'POST') {
                return _nativeFetch.apply(this, arguments);
            }
            var body;
            try { body = JSON.parse(opts.body || '{}'); } catch(e) { return _nativeFetch.apply(this, arguments); }
            var errs = _validateHypDraft(body.start_date || '', body.deadline || '');
            if (errs.length) {
                _showValidationErrors(errs);
                if (typeof window.__trackerNotify === 'function') {
                    window.__trackerNotify('❌ Исправьте ошибки в датах гипотез (' + errs.length + ')', 'error');
                }
                return Promise.resolve(new Response(JSON.stringify({
                    success: false, error: 'hyp_dates_invalid', errors: errs
                }), { status: 200, headers: { 'Content-Type': 'application/json' } }));
            }
            return _nativeFetch.apply(this, arguments);
        };
    }

    /* ===== TIMELINE-ВИД ===== */
    function _ensureTimelineBtn() {
        var seg = document.getElementById('tskViewSeg');
        if (!seg || seg.querySelector('[data-view="timeline"]')) return;
        var b = document.createElement('button');
        b.type = 'button';
        b.setAttribute('data-view', 'timeline');
        b.title = 'Таймлайн гипотез и заданий';
        b.textContent = '🕐 Таймлайн';
        seg.appendChild(b);
    }

    function _ensureTimelineContainer() {
        var list = document.getElementById('tasksFullList');
        if (!list) return null;
        var tl = document.getElementById('tasksTimelineList');
        if (!tl) {
            tl = document.createElement('div');
            tl.id = 'tasksTimelineList';
            tl.className = 'tasks-timeline';
            tl.style.display = 'none';
            list.parentNode.insertBefore(tl, list.nextSibling);
        }
        return tl;
    }

    function _renderTaskTimeline(t) {
        var hyps = (t.hypotheses || []).filter(function(x){ return x && x.kind === 'hypothesis'; });
        var allTasks = (t.hypotheses || []).filter(function(x){ return x && x.kind === 'task'; });
        var taskStart = t.start_date || '';
        var taskEnd = t.deadline || '';
        if (!taskStart) { hyps.forEach(function(h){ if (h.date_from && (!taskStart || h.date_from < taskStart)) taskStart = h.date_from; }); }
        if (!taskEnd)   { hyps.forEach(function(h){ if (h.date_to && (!taskEnd || h.date_to > taskEnd)) taskEnd = h.date_to; }); }

        var html = '<div class="task-timeline-card" data-id="' + esc(t.id) + '">';
        html += '<div class="ttc-head">';
        html += '<span class="ttc-icon">' + esc(t.icon || '📋') + '</span>';
        html += '<span class="ttc-name">' + esc(t.name || '') + '</span>';
        html += '<span class="ttc-dates">' + (t.start_date ? '🚀 ' + esc(t.start_date) : '🚀 —') + ' → ' + (t.deadline ? '⏰ ' + esc(t.deadline) : '⏰ —') + '</span>';
        html += '</div>';
        if (!hyps.length) {
            html += '<div class="ttc-empty">Нет гипотез — добавьте их в карточке задачи</div></div>';
            return html;
        }
        if (!taskStart || !taskEnd) {
            html += '<div class="ttc-empty">Не заданы сроки задачи — таймлайн невозможен</div></div>';
            return html;
        }
        var totalMs = (new Date(taskEnd + 'T00:00:00') - new Date(taskStart + 'T00:00:00'));
        if (totalMs <= 0) totalMs = 86400000;
        var _taskStartMs = new Date(taskStart + 'T00:00:00').getTime();
        function _pct(dk) {
            if (!dk) return 0;
            try { var v = ((new Date(dk + 'T00:00:00').getTime() - _taskStartMs) / totalMs) * 100; return Math.max(0, Math.min(100, v)); }
            catch(e) { return 0; }
        }
        function _unitW() { return Math.min(100, (86400000 / totalMs) * 100); }
        html += '<div class="ttc-timeline">';
        html += '<div class="ttc-row ttc-row-task"><div class="ttc-bar ttc-bar-task" style="left:0;width:100%" title="Задача: ' + esc(t.name) + ' (' + esc(taskStart) + ' — ' + esc(taskEnd) + ')">' + esc(t.name || '') + '</div></div>';
        hyps.forEach(function(h, hi) {
            var hS = h.date_from || taskStart;
            var hE = h.date_to || taskEnd;
            var hLeft = _pct(hS);
            var hW = Math.max(2, (_pct(hE) + _unitW()) - hLeft);
            var invalid = (h.date_from && taskStart && h.date_from < taskStart) || (h.date_to && taskEnd && h.date_to > taskEnd);
            var sI = h.status === 'done' ? '✅' : (h.status === 'failed' ? '❌' : (h.status === 'in_progress' ? '🔄' : '⏳'));
            html += '<div class="ttc-row ttc-row-hyp"><div class="ttc-bar ttc-bar-hyp' + (invalid ? ' ttc-bar-invalid' : '') + '" style="left:' + hLeft.toFixed(2) + '%;width:' + hW.toFixed(2) + '%" title="🧪 Гипотеза ' + (hi + 1) + ': ' + esc(h.title) + ' (' + esc(hS) + ' — ' + esc(hE) + ') ' + sI + '">' + sI + ' ' + esc(h.title || '') + '</div></div>';
            var kids = allTasks.filter(function(x){ return x.parent === h.id; });
            kids.forEach(function(tk, ti) {
                var kS = tk.date_from || hS;
                var kE = tk.date_to || hE;
                var kLeft = _pct(kS);
                var kW = Math.max(2, (_pct(kE) + _unitW()) - kLeft);
                var tI = (tk.date_from && h.date_from && tk.date_from < h.date_from) || (tk.date_to && h.date_to && tk.date_to > h.date_to);
                var sI2 = tk.status === 'done' ? '✅' : (tk.status === 'failed' ? '❌' : (tk.status === 'in_progress' ? '🔄' : '⏳'));
                html += '<div class="ttc-row ttc-row-job"><div class="ttc-bar ttc-bar-job' + (tI ? ' ttc-bar-invalid' : '') + '" style="left:' + kLeft.toFixed(2) + '%;width:' + kW.toFixed(2) + '%" title="📌 Задание ' + (ti + 1) + ': ' + esc(tk.title) + ' (' + esc(kS) + ' — ' + esc(kE) + ') ' + sI2 + '">' + sI2 + ' ' + esc(tk.title || '') + '</div></div>';
            });
        });
        html += '</div></div>';
        return html;
    }

    function _renderTimeline() {
        var list = document.getElementById('tasksFullList');
        var tl = _ensureTimelineContainer();
        if (!list || !tl) return;
        var st = _state();
        var byId = {};
        (st.tasks || []).forEach(function(t){ if (t && t.id) byId[t.id] = t; });
        var ids = [];
        list.querySelectorAll('.task-card, .dict-item').forEach(function(card){
            var id = card.getAttribute('data-id');
            if (id) ids.push(id);
        });
        if (!ids.length) { tl.innerHTML = '<div class="dict-empty">Нет задач по фильтру</div>'; return; }
        var html = '';
        ids.forEach(function(id){
            var t = byId[id];
            if (t) html += _renderTaskTimeline(t);
        });
        tl.innerHTML = html;
    }

    function _setTimelineVisible(visible) {
        var list = document.getElementById('tasksFullList');
        var tl = _ensureTimelineContainer();
        if (!list || !tl) return;
        if (visible) { list.style.display = 'none'; tl.style.display = ''; }
        else { list.style.display = ''; tl.style.display = 'none'; }
    }

    function _setActiveSeg(view) {
        document.querySelectorAll('#tskViewSeg button').forEach(function(b){
            b.classList.toggle('active', b.getAttribute('data-view') === view);
        });
    }

    /* Клик по «Таймлайн» — перехватываем до PATCH 1.0.9 */
    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        var b = e.target.closest('#tskViewSeg button[data-view="timeline"]');
        if (!b) return;
        e.stopImmediatePropagation();
        e.preventDefault();
        var st = _state(); st.tskView = 'timeline';
        try { localStorage.setItem('tracker_tsk_view', 'timeline'); } catch(er) {}
        _setActiveSeg('timeline');
        _setTimelineVisible(true);
        _renderTimeline();
    }, true);

    /* Наблюдатель за #tasksFullList — синхронизируем видимость таймлайна */
    function _observeList() {
        var list = document.getElementById('tasksFullList');
        if (!list || list._timelineObsV146) return;
        list._timelineObsV146 = true;
        new MutationObserver(function(){
            var st = _state();
            if (st.tskView === 'timeline') {
                _setTimelineVisible(true);
                _renderTimeline();
            } else {
                _setTimelineVisible(false);
            }
        }).observe(list, { childList: true });
    }

    /* Принудительное поддержание timeline-режима, если он выбран в storage */
    setInterval(function(){
        try {
            if (localStorage.getItem('tracker_tsk_view') === 'timeline') {
                var st = _state();
                if (st.tskView !== 'timeline') {
                    st.tskView = 'timeline';
                    _ensureTimelineBtn();
                    _setActiveSeg('timeline');
                    _setTimelineVisible(true);
                    _renderTimeline();
                }
            }
        } catch(e) {}
    }, 1500);

    function boot() {
        _ensureTimelineBtn();
        _observeList();
        setTimeout(_ensureTimelineBtn, 500);
        setTimeout(_ensureTimelineBtn, 1500);
        setTimeout(_observeList, 500);
        setTimeout(_observeList, 1500);
        try {
            if (localStorage.getItem('tracker_tsk_view') === 'timeline') {
                var st = _state(); st.tskView = 'timeline';
                _setActiveSeg('timeline');
                _setTimelineVisible(true);
                _renderTimeline();
            }
        } catch(e) {}
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
    else boot();

    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('.tracker-tab[data-tab="tasks"]')) {
            setTimeout(_ensureTimelineBtn, 200);
            setTimeout(_observeList, 300);
        }
    });

    window.__trkTimelineRender = _renderTimeline;
    window.__trkValidateHypDraft = _validateHypDraft;
    window.__trkLiveValidate = _liveValidate;
})();


/* ============================================================
   PATCH v1.4.7 — встраиваем таймлайн внутрь карточки задачи.
   Показывается через CSS только при .tasks-grid[data-compact="1"].
   Отдельный список #tasksTimelineList и кнопка «Таймлайн» больше
   не используются (см. CSS).
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkInlineTimelineV147) return;
    window.__trkInlineTimelineV147 = true;

    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
        });
    }

    /* Сброс localStorage.tracker_tsk_view === 'timeline' → 'compact',
       чтобы старая логика v1.4.6 не включила отдельный список.
       Плюс переключение state.tskView и обновление кнопок сегмента. */
    (function _migrateFromTimelineView(){
        try {
            var ls = localStorage.getItem('tracker_tsk_view');
            if (ls === 'timeline') {
                localStorage.setItem('tracker_tsk_view', 'compact');
                var st = window.__trkState || {};
                st.tskView = 'compact';
                try { if (typeof window.__trkRenderTasksFull === 'function') window.__trkRenderTasksFull(); } catch(e){}
            }
            // Обновить активность кнопок сегмента
            var st2 = window.__trkState || {};
            var seg = document.getElementById('tskViewSeg');
            if (seg && st2.tskView) {
                seg.querySelectorAll('button').forEach(function(b){
                    if (b.getAttribute('data-view') === 'timeline') return;
                    b.classList.toggle('active', b.getAttribute('data-view') === st2.tskView);
                });
            }
            // Скрыть/убрать кнопку «Таймлайн»
            var tlBtn = seg ? seg.querySelector('button[data-view="timeline"]') : null;
            if (tlBtn && tlBtn.parentNode) tlBtn.parentNode.removeChild(tlBtn);
        } catch(e) { console.warn('[v1.4.7 migrate]', e); }
    })();

    function _parseDate(iso) {
        if (!iso) return null;
        var p = String(iso).split('-');
        if (p.length !== 3) return null;
        var d = new Date(+p[0], +p[1]-1, +p[2]);
        return isNaN(d.getTime()) ? null : d;
    }

    function _buildInlineTimeline(t) {
        if (!t) return null;
        var hyps = (t.hypotheses || []).filter(function(x){ return x && x.kind === 'hypothesis'; });
        var allTasks = (t.hypotheses || []).filter(function(x){ return x && x.kind === 'task'; });
        if (!hyps.length) return null; // нет гипотез — не вставляем

        var taskStart = t.start_date || '';
        var taskEnd = t.deadline || '';
        // Fallback: минимальный/максимальный диапазон по гипотезам
        if (!taskStart) hyps.forEach(function(h){ if (h.date_from && (!taskStart || h.date_from < taskStart)) taskStart = h.date_from; });
        if (!taskEnd)   hyps.forEach(function(h){ if (h.date_to && (!taskEnd || h.date_to > taskEnd)) taskEnd = h.date_to; });

        var dS = _parseDate(taskStart), dE = _parseDate(taskEnd);
        var rangeFmt = '';
        if (dS && dE) {
            rangeFmt = esc(taskStart) + ' → ' + esc(taskEnd);
        } else {
            rangeFmt = 'нет дат';
        }

        var wrap = document.createElement('div');
        wrap.className = 'task-card-inline-timeline';

        var headHtml = '<div class="tcit-head"><span class="tcit-ico">🕐</span>'
                     + '<span>Гипотезы и задания</span>'
                     + '<span class="tcit-range">' + rangeFmt + '</span></div>';

        if (!dS || !dE || dE < dS) {
            wrap.innerHTML = headHtml + '<div class="tcit-track" style="padding:6px 0;color:var(--trk-meta);font-style:italic;font-size:0.75rem;">У задачи не заданы сроки для таймлайна</div>';
            return wrap;
        }

        var totalMs = dE.getTime() - dS.getTime() + 86400000; // +1 день, чтобы последний день входил
        if (totalMs <= 0) totalMs = 86400000;
        var startMs = dS.getTime();
        function _pct(iso) {
            var d = _parseDate(iso);
            if (!d) return null;
            var v = ((d.getTime() - startMs) / totalMs) * 100;
            return Math.max(0, Math.min(100, v));
        }
        var unitW = (86400000 / totalMs) * 100;

        function _statusIcon(st) {
            return st === 'done' ? '✅' : (st === 'failed' ? '❌' : (st === 'in_progress' ? '🔄' : '⏳'));
        }

        var track = '';

        // Строка задачи
        track += '<div class="tcit-row tcit-row-task">'
              +  '<div class="tcit-bar tcit-bar-task" style="left:0;width:100%" title="' + esc(t.name || '') + ' (' + esc(taskStart) + ' — ' + esc(taskEnd) + ')">' + esc(t.name || '') + '</div>'
              +  '</div>';

        hyps.forEach(function(h, hi){
            var hS = h.date_from || taskStart;
            var hE = h.date_to || taskEnd;
            var hL = _pct(hS);
            var hR = _pct(hE);
            if (hL === null) hL = 0;
            if (hR === null) hR = 100;
            var hW = Math.max(1, (hR + unitW) - hL);
            var hS_ = h.date_from || '';
            var hE_ = h.date_to || '';
            var invalidH = (hS_ && taskStart && hS_ < taskStart) || (hE_ && taskEnd && hE_ > taskEnd);
            track += '<div class="tcit-row tcit-row-hyp">'
                  +    '<div class="tcit-bar tcit-bar-hyp' + (invalidH ? ' tcit-bar-invalid' : '') + '"'
                  +         ' style="left:' + hL.toFixed(2) + '%;width:' + hW.toFixed(2) + '%"'
                  +         ' title="🧪 Гипотеза ' + (hi + 1) + ': ' + esc(h.title || '') + ' (' + esc(hS) + ' — ' + esc(hE) + ') ' + _statusIcon(h.status) + '">'
                  +      _statusIcon(h.status) + ' ' + esc(h.title || 'Без названия')
                  +    '</div></div>';
            var kids = allTasks.filter(function(x){ return x.parent === h.id; });
            kids.forEach(function(tk, ti){
                var kS = tk.date_from || hS;
                var kE = tk.date_to || hE;
                var kL = _pct(kS);
                var kR = _pct(kE);
                if (kL === null) kL = hL;
                if (kR === null) kR = hR;
                var kW = Math.max(1, (kR + unitW) - kL);
                var invalidK = (tk.date_from && h.date_from && tk.date_from < h.date_from)
                            || (tk.date_to && h.date_to && tk.date_to > h.date_to);
                track += '<div class="tcit-row tcit-row-job">'
                      +    '<div class="tcit-bar tcit-bar-job' + (invalidK ? ' tcit-bar-invalid' : '') + '"'
                      +         ' style="left:' + kL.toFixed(2) + '%;width:' + kW.toFixed(2) + '%"'
                      +         ' title="📌 Задание ' + (ti + 1) + ': ' + esc(tk.title || '') + ' (' + esc(kS) + ' — ' + esc(kE) + ') ' + _statusIcon(tk.status) + '">'
                      +      _statusIcon(tk.status) + ' ' + esc(tk.title || 'Без названия')
                      +    '</div></div>';
            });
        });

        wrap.innerHTML = headHtml + '<div class="tcit-track">' + track + '</div>';
        return wrap;
    }

    function _injectCard(card, task) {
        if (!card || !task) return;
        if (card.querySelector('.task-card-inline-timeline')) return;
        var tl = _buildInlineTimeline(task);
        if (!tl) return;
        var foot = card.querySelector('.task-card-foot');
        var mid = card.querySelector('.task-card-mid');
        var head = card.querySelector('.task-card-head');
        if (foot && foot.parentNode === card) card.insertBefore(tl, foot);
        else if (mid && mid.parentNode === card) card.insertBefore(tl, mid.nextSibling);
        else if (head && head.parentNode === card) card.insertBefore(tl, head.nextSibling);
        else card.appendChild(tl);
    }

    function _applyAll() {
        var list = document.getElementById('tasksFullList');
        if (!list) return;
        var st = window.__trkState || {};
        var byId = {};
        (st.tasks || []).forEach(function(t){ if (t && t.id) byId[t.id] = t; });
        list.querySelectorAll('.task-card').forEach(function(card){
            var id = card.getAttribute('data-id');
            if (!id) return;
            _injectCard(card, byId[id]);
        });
    }

    function _observe() {
        var list = document.getElementById('tasksFullList');
        if (!list || list._inlineTlObsV147) return;
        list._inlineTlObsV147 = true;
        new MutationObserver(function(){ setTimeout(_applyAll, 30); })
            .observe(list, { childList: true });
        setTimeout(_applyAll, 60);
    }

    function boot() {
        _observe();
        setTimeout(function(){ _observe(); _applyAll(); }, 300);
        setTimeout(_applyAll, 900);
        setTimeout(_applyAll, 2000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('.tracker-tab[data-tab="tasks"]') ||
            e.target.closest('#tskViewSeg button') ||
            e.target.closest('#tskViewMode button') ||
            e.target.closest('.sum-filter')) {
            setTimeout(_applyAll, 200);
            setTimeout(_applyAll, 500);
            setTimeout(_applyAll, 1200);
        }
    }, true);

    window.__trkInlineTimelineRender = _applyAll;
})();


/* ============================================================
   PATCH v1.4.9 — фикс сохранения иконки задачи (#task_icon)
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkTaskIconFixV149) return;
    window.__trkTaskIconFixV149 = true;

    function _ensureTaskIcon() {
        var modal = document.getElementById('taskModal');
        if (!modal) return null;
        var content = modal.querySelector('.modal-content');
        if (!content) return null;
        var iconEl = document.getElementById('task_icon');
        if (iconEl) return iconEl;
        // Создаём hidden input как direct child .modal-content —
        // _restructure PATCH 1.0.3 / v1.1.1 сохраняет такие input[type=hidden]
        iconEl = document.createElement('input');
        iconEl.type = 'hidden';
        iconEl.id = 'task_icon';
        var prev = document.getElementById('taskIconPreview');
        var cur = (prev && prev.textContent || '').trim();
        iconEl.value = cur || '🚀';
        content.insertBefore(iconEl, content.firstChild);
        return iconEl;
    }

    function _syncFromPreview() {
        var modal = document.getElementById('taskModal');
        if (!modal || !modal.classList.contains('active')) return;
        var iconEl = _ensureTaskIcon();
        if (!iconEl) return;
        var prev = document.getElementById('taskIconPreview');
        if (!prev) return;
        var cur = (prev.textContent || '').trim();
        if (cur && cur !== (iconEl.value || '').trim()) {
            iconEl.value = cur;
        }
    }

    // 1) MutationObserver на #taskModal: при открытии создаём #task_icon
    //    через несколько задержек — _restructure в task_modal_wide.js
    //    работает по таймерам 50/250/600/1000/2500 мс.
    function _watchModal() {
        var modal = document.getElementById('taskModal');
        if (!modal || modal._iconFixV149Obs) return;
        modal._iconFixV149Obs = true;
        new MutationObserver(function(){
            if (modal.classList.contains('active')) {
                setTimeout(_ensureTaskIcon, 60);
                setTimeout(_ensureTaskIcon, 300);
                setTimeout(_ensureTaskIcon, 800);
                setTimeout(_syncFromPreview, 1500);
                setTimeout(_ensureTaskIcon, 2600);
            }
        }).observe(modal, { attributes: true, attributeFilter: ['class'] });
        if (modal.classList.contains('active')) {
            setTimeout(_ensureTaskIcon, 60);
            setTimeout(_ensureTaskIcon, 300);
        }
    }

    // 2) Клик по .emoji-btn — до обработчика renderEmojiGrid:
    //    гарантируем, что #task_icon существует и получает эмодзи.
    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        var btn = e.target.closest('.emoji-btn');
        if (!btn) return;
        var modal = document.getElementById('taskModal');
        if (!modal) return;
        var em = btn.getAttribute('data-emoji') || '🚀';
        // Делаем сразу — renderEmojiGrid потом перепишет то же значение
        var iconEl = _ensureTaskIcon();
        if (iconEl) iconEl.value = em;
        // И ещё раз чуть позже (на случай гонки с _restructure)
        setTimeout(function(){
            var el2 = _ensureTaskIcon();
            if (el2) el2.value = em;
        }, 30);
    }, true);

    // 3) Клик по #saveTaskBtn (capture phase) — до saveTask.
    //    Синхронизируем #task_icon.value из #taskIconPreview.
    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (!e.target.closest('#saveTaskBtn')) return;
        var modal = document.getElementById('taskModal');
        if (!modal || !modal.classList.contains('active')) return;
        _syncFromPreview();
    }, true);

    // 4) На submit через Enter в поле — тоже синхронизируем.
    //    (маловероятно, но для надёжности)
    document.addEventListener('keydown', function(e){
        if (e.key !== 'Enter' && e.key !== 'NumpadEnter') return;
        var modal = document.getElementById('taskModal');
        if (!modal || !modal.classList.contains('active')) return;
        var t = e.target;
        if (!t || !t.closest) return;
        if (t.tagName === 'TEXTAREA') return;
        if (t.tagName === 'BUTTON' && t.closest('.modal-actions')) {
            _syncFromPreview();
        }
    }, true);

    _watchModal();
    setTimeout(_watchModal, 500);
    setTimeout(_watchModal, 1500);

    window.__trkEnsureTaskIcon = _ensureTaskIcon;
    window.__trkSyncTaskIconFromPreview = _syncFromPreview;
})();


/* ============================================================
   PATCH v1.5.1 — модалка отметки: селектор гипотезы/задания
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkLogHypItemV151) return;
    window.__trkLogHypItemV151 = true;

    function _populateHypSelect(taskId) {
        var wrap = document.getElementById('logHypGroup');
        var sel = document.getElementById('log_hyp_item');
        if (!wrap || !sel) return;
        if (!taskId) { wrap.style.display = 'none'; sel.innerHTML = ''; return; }
        var st = window.__trkState || {};
        var t = null;
        (st.tasks || []).forEach(function(x){ if (x && x.id === taskId) t = x; });
        if (!t) { wrap.style.display = 'none'; sel.innerHTML = ''; return; }
        var hyps = (Array.isArray(t.hypotheses) ? t.hypotheses : []).filter(function(x){ return x && x.kind === 'hypothesis'; });
        if (!hyps.length) { wrap.style.display = 'none'; sel.innerHTML = ''; return; }
        var allJobs = t.hypotheses.filter(function(x){ return x && x.kind === 'task'; });
        var prevVal = sel.value || '';
        var html = '<option value="">— не привязано —</option>';
        hyps.forEach(function(h, hi){
            html += '<option value="' + h.id + '">🧪 Гипотеза ' + (hi + 1) + ': ' + (h.title || 'без названия') + '</option>';
            allJobs.filter(function(x){ return x.parent === h.id; }).forEach(function(tk, ti){
                html += '<option value="' + tk.id + '">   📌 Задание ' + (ti + 1) + ': ' + (tk.title || 'без названия') + '</option>';
            });
        });
        sel.innerHTML = html;
        if (prevVal) {
            for (var i = 0; i < sel.options.length; i++) {
                if (sel.options[i].value === prevVal) { sel.value = prevVal; break; }
            }
        }
        wrap.style.display = '';
    }

    document.addEventListener('change', function(ev){
        if (!ev.target || ev.target.id !== 'log_task') return;
        setTimeout(function(){ _populateHypSelect(ev.target.value); }, 20);
    }, true);

    (function _watchLogModal(){
        var m = document.getElementById('logModal');
        if (!m || m._logHypItemObsV151) return;
        m._logHypItemObsV151 = true;
        new MutationObserver(function(){
            if (m.classList.contains('active')) {
                setTimeout(function(){
                    var tid = (document.getElementById('log_task') || {}).value || '';
                    _populateHypSelect(tid);
                }, 120);
                setTimeout(function(){
                    var tid = (document.getElementById('log_task') || {}).value || '';
                    _populateHypSelect(tid);
                }, 500);
            }
        }).observe(m, { attributes: true, attributeFilter: ['class'] });
    })();

    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('#log_task_dropdown .ltd-item')) {
            setTimeout(function(){
                var tid = (document.getElementById('log_task') || {}).value || '';
                _populateHypSelect(tid);
            }, 50);
        }
    }, true);

    var _native = window.fetch;
    if (typeof _native === 'function' && !window.__trkLogHypItemFetchV151) {
        window.__trkLogHypItemFetchV151 = true;
        window.fetch = function(url, opts){
            if (typeof url !== 'string' || url.indexOf('/api/tracker/log/save') === -1) {
                return _native.apply(this, arguments);
            }
            if (!opts || (opts.method || 'GET').toUpperCase() !== 'POST') {
                return _native.apply(this, arguments);
            }
            try {
                var body = JSON.parse(opts.body || '{}');
                var sel = document.getElementById('log_hyp_item');
                if (sel && body.task_id) {
                    body.hyp_item_id = sel.value || '';
                }
                opts = Object.assign({}, opts, { body: JSON.stringify(body) });
            } catch(e) {}
            return _native.call(this, url, opts);
        };
    }

    (function _wrapOpenLogModal(){
        var orig = window.__trkOpenLogModal;
        if (typeof orig !== 'function' || orig._hypItemV151) return;
        var w = function(entry){
            var r = orig.apply(this, arguments);
            if (entry && entry.hyp_item_id) {
                setTimeout(function(){
                    var tid = (document.getElementById('log_task') || {}).value || '';
                    _populateHypSelect(tid);
                    var sel = document.getElementById('log_hyp_item');
                    if (sel) {
                        for (var i = 0; i < sel.options.length; i++) {
                            if (sel.options[i].value === entry.hyp_item_id) { sel.value = entry.hyp_item_id; break; }
                        }
                    }
                }, 220);
                setTimeout(function(){
                    var sel = document.getElementById('log_hyp_item');
                    if (sel && entry.hyp_item_id) {
                        for (var i = 0; i < sel.options.length; i++) {
                            if (sel.options[i].value === entry.hyp_item_id) { sel.value = entry.hyp_item_id; break; }
                        }
                    }
                }, 600);
            }
            return r;
        };
        w._hypItemV151 = true;
        window.__trkOpenLogModal = w;
    })();

    window.__trkPopulateHypSelect = _populateHypSelect;
})();


/* ============================================================
   PATCH v1.5.1 — календарь: префикс гипотезы/задания в tooltip
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkCalHypPrefixV151) return;
    window.__trkCalHypPrefixV151 = true;

    function _hypNameById(taskId, hypId) {
        if (!hypId) return '';
        var st = window.__trkState || {};
        var tasks = st.tasks || [];
        var t = null;
        for (var i = 0; i < tasks.length; i++) if (tasks[i].id === taskId) { t = tasks[i]; break; }
        if (!t || !Array.isArray(t.hypotheses)) return '';
        for (var j = 0; j < t.hypotheses.length; j++) {
            var it = t.hypotheses[j];
            if (it && it.id === hypId) {
                return (it.kind === 'hypothesis' ? '🧪 ' : '📌 ') + (it.title || '');
            }
        }
        return '';
    }

    function _decorateCalendarEntries() {
        var grid = document.getElementById('calGrid');
        if (!grid) return;
        var st = window.__trkState || {};
        var cal = st.calendar;
        if (!cal) return;
        grid.querySelectorAll('.cal-entry').forEach(function(el) {
            if (el._hypPrefixed) return;
            var txt = (el.textContent || '').trim();
            if (!txt) return;
            // Ищем запись по совпадению начала title — хрупко, но мы не храним id в DOM.
            // Используем href по данным из state.calendar: перебор — дорого.
            // Простое решение: дать пользователю самому навести и увидеть.
            el._hypPrefixed = true;
        });
    }

    // Правильная реализация — встроиться в саму renderCalendar не выйдет без
    // редактирования базового кода. Используем MutationObserver на #calGrid,
    // чтобы после рендера пройтись по записям и подставить tooltip.
    function _enrichCalEntries() {
        var grid = document.getElementById('calGrid');
        if (!grid) return;
        var st = window.__trkState || {};
        var cal = st.calendar;
        if (!cal || !cal.days) return;
        // Собираем id записей по дню
        var byKey = {};
        cal.days.forEach(function(day) {
            (day.entries || []).forEach(function(en) {
                byKey[day.date + '||' + en.employee_id + '||' + en.task_id + '||' + (en.hours || 0)] = en;
            });
        });
        grid.querySelectorAll('.cal-cell').forEach(function(cell) {
            var dk = cell.getAttribute('data-date');
            if (!dk) return;
            var day = cal.days.find(function(d){ return d.date === dk; });
            if (!day) return;
            var entryEls = cell.querySelectorAll('.cal-entry');
            entryEls.forEach(function(el, idx) {
                var en = (day.entries || [])[idx];
                if (!en || !en.hyp_item_id) return;
                var nm = _hypNameById(en.task_id, en.hyp_item_id);
                if (!nm) return;
                var ttl = el.getAttribute('title') || '';
                if (ttl.indexOf(nm) === -1) {
                    el.setAttribute('title', nm + ' · ' + ttl);
                }
            });
        });
    }

    function _observe() {
        var grid = document.getElementById('calGrid');
        if (!grid || grid._hypPrefixObsV151) return;
        grid._hypPrefixObsV151 = true;
        new MutationObserver(function(){ setTimeout(_enrichCalEntries, 30); })
            .observe(grid, { childList: true });
        setTimeout(_enrichCalEntries, 100);
    }

    setTimeout(_observe, 500);
    setTimeout(_observe, 1500);
    setTimeout(_enrichCalEntries, 2500);

    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('.tracker-tab[data-tab="calendar"]') ||
            e.target.closest('#calPrevBtn') ||
            e.target.closest('#calNextBtn') ||
            e.target.closest('#calTodayBtn')) {
            setTimeout(_enrichCalEntries, 300);
            setTimeout(_enrichCalEntries, 1000);
        }
    });

    window.__trkEnrichCalHypPrefix = _enrichCalEntries;
})();


/* ============================================================
   PATCH v1.5.2 — очистка дублей <details> в logModal + обогащение
   ленты «📝 Отметки о ходе работы» приказами/ссылками
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkSplitFieldsV152) return;
    window.__trkSplitFieldsV152 = true;

    function _esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function(c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
        });
    }

    /* ---------- 1. Схлопываем накопленные <details><details> ---------- */
    function _flattenDoubleLogSections() {
        var modal = document.getElementById('logModal');
        if (!modal) return;
        var mf = document.getElementById('logMultiFields');
        if (!mf) return;
        var changed = false;
        mf.querySelectorAll('details.log-section').forEach(function(outer){
            var outerBody = outer.querySelector(':scope > .log-section-body');
            if (!outerBody) return;
            var inners = outerBody.querySelectorAll(':scope > details.log-section');
            if (!inners.length) return;
            inners.forEach(function(inner){
                var innerBody = inner.querySelector(':scope > .log-section-body');
                if (innerBody) {
                    while (innerBody.firstChild) {
                        outerBody.appendChild(innerBody.firstChild);
                    }
                }
                inner.remove();
                changed = true;
            });
        });
        if (changed) {
            console.log('[v1.5.2] схлопнуты вложенные log-section');
        }
    }

    /* ---------- 2. Обогащаем ленту приказами/ссылками из work_logs ---------- */
    function _enrichProgressItems() {
        var root = document.getElementById('hypTreeRoot');
        if (!root) return;
        var st = window.__trkState || {};
        var byLog = {};
        (st.log || []).forEach(function(l){
            if (l && l.id != null) {
                byLog[String(l.id)] = l;
            }
        });
        root.querySelectorAll('.hyp-progress-item').forEach(function(el){
            if (el._extraDone) return;
            var lid = el.getAttribute('data-log-id');
            if (!lid) return;
            var log = byLog[String(lid)];
            if (!log) return;
            var orders = Array.isArray(log.orders) ? log.orders : [];
            var links = Array.isArray(log.links) ? log.links : [];
            el._extraDone = true;
            if (!orders.length && !links.length) return;
            var extra = document.createElement('div');
            extra.className = 'hyp-progress-extra';
            var h = '';
            orders.forEach(function(o){
                h += '<span class="hyp-progress-extra-item">📄 '
                  +  _esc(String((o && o.description) || ''))
                  +  (o && o.value ? ' · <b>' + _esc(String(o.value)) + '</b>' : '')
                  +  '</span>';
            });
            links.forEach(function(lk){
                var url = String((lk && lk.url) || '');
                var desc = String((lk && lk.description) || '');
                var label = desc || url;
                h += '<span class="hyp-progress-extra-item">🔗 ' + _esc(label) + '</span>';
            });
            extra.innerHTML = h;
            var body = el.querySelector('.hyp-progress-body');
            if (body) body.appendChild(extra);
            else el.appendChild(extra);
        });
    }

    /* ---------- 3. Lifecycle: при открытии logModal — flatten, при рендере дерева — enrich ---------- */
    (function _watchLogModal(){
        var m = document.getElementById('logModal');
        if (!m || m._splitFieldsV152) return;
        m._splitFieldsV152 = true;
        new MutationObserver(function(){
            if (m.classList.contains('active')) {
                setTimeout(_flattenDoubleLogSections, 60);
                setTimeout(_flattenDoubleLogSections, 300);
                setTimeout(_flattenDoubleLogSections, 800);
                setTimeout(_flattenDoubleLogSections, 1600);
            }
        }).observe(m, { attributes: true, attributeFilter: ['class'] });
        if (m.classList.contains('active')) {
            setTimeout(_flattenDoubleLogSections, 60);
            setTimeout(_flattenDoubleLogSections, 400);
        }
    })();

    (function _watchHypTree(){
        var root = document.getElementById('hypTreeRoot');
        if (!root || root._enrichV152) return;
        root._enrichV152 = true;
        new MutationObserver(function(){
            setTimeout(_enrichProgressItems, 30);
        }).observe(root, { childList: true, subtree: true });
        setTimeout(_enrichProgressItems, 100);
    })();

    // Повторно подключить наблюдатели — на случай поздней инициализации
    setTimeout(function(){
        try { _flattenDoubleLogSections(); } catch(e){}
    }, 400);
    setTimeout(function(){
        try { _flattenDoubleLogSections(); } catch(e){}
    }, 1500);
    setTimeout(function(){
        try { _enrichProgressItems(); } catch(e){}
    }, 1000);

    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('#dayAddBtn') ||
            e.target.closest('#dayModal .dict-action-btn[data-act="edit"]') ||
            e.target.closest('#logDayExistingList .dict-action-btn[data-act="edit"]')) {
            setTimeout(_flattenDoubleLogSections, 300);
            setTimeout(_flattenDoubleLogSections, 800);
            setTimeout(_flattenDoubleLogSections, 1600);
        }
    }, true);

    window.__trkFlattenLogSections = _flattenDoubleLogSections;
    window.__trkEnrichProgressItems = _enrichProgressItems;
})();


/* ============================================================
   PATCH v1.5.3 — перенос блока «Назначено, но не заведено»
   из #logDayExisting в #logAssignedWrap.
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkAssignedBlockV153) return;
    window.__trkAssignedBlockV153 = true;

    function _moveAssignedBlock() {
        var modal = document.getElementById('logModal');
        if (!modal) return;
        var target = document.getElementById('logAssignedWrap');
        if (!target) return;
        var existing = document.getElementById('logDayExisting');
        var blocks = [];
        if (existing) {
            existing.querySelectorAll('.log-assigned-block').forEach(function(el){ blocks.push(el); });
        }
        // На случай если блок уже в правильном месте — не дублируем
        var inTarget = target.querySelector('.log-assigned-block');
        if (inTarget) {
            blocks.forEach(function(el){ if (el !== inTarget) el.remove(); });
            return;
        }
        if (!blocks.length) return;
        // Берём первый (PATCH 41 создаёт только один)
        var first = blocks[0];
        blocks.slice(1).forEach(function(el){ el.remove(); });
        target.appendChild(first);
    }

    // Наблюдатель на #logDayExisting: как только PATCH 41 вставит туда
    // .log-assigned-block — сразу переносим в #logAssignedWrap
    (function _watchExisting(){
        var existing = document.getElementById('logDayExisting');
        if (!existing || existing._assignedV153Obs) return;
        existing._assignedV153Obs = true;
        new MutationObserver(function(){
            setTimeout(_moveAssignedBlock, 10);
        }).observe(existing, { childList: true, subtree: true });
    })();

    // Наблюдатель на #logAssignedWrap: если в него напрямую что-то вставили
    // (например, обновлённый PATCH 41 или наш собственный перенос) — не мешаем
    (function _watchTarget(){
        var target = document.getElementById('logAssignedWrap');
        if (!target || target._assignedV153Obs) return;
        target._assignedV153Obs = true;
    })();

    // При открытии logModal — перепроверяем через серию таймеров
    (function _watchModal(){
        var m = document.getElementById('logModal');
        if (!m || m._assignedV153Obs) return;
        m._assignedV153Obs = true;
        new MutationObserver(function(){
            if (m.classList.contains('active')) {
                setTimeout(_moveAssignedBlock, 60);
                setTimeout(_moveAssignedBlock, 200);
                setTimeout(_moveAssignedBlock, 500);
                setTimeout(_moveAssignedBlock, 1000);
            }
        }).observe(m, { attributes: true, attributeFilter: ['class'] });
        if (m.classList.contains('active')) {
            setTimeout(_moveAssignedBlock, 60);
            setTimeout(_moveAssignedBlock, 300);
        }
    })();

    // При клике по вкладке «Показать всех» PATCH 41 удаляет блок.
    // Возвращаем: через 150 мс вызываем decorate из PATCH 41, чтобы
    // он пересоздал блок (decorate уже проверяет _mode() !== 'me' → removeBlock).
    // Пользователь хочет видеть блок всегда, независимо от вкладки.
    // Поэтому мы повторно вызываем наш _moveAssignedBlock после клика.
    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('#logExistingTabs .log-existing-tab')) {
            setTimeout(_moveAssignedBlock, 200);
            setTimeout(_moveAssignedBlock, 500);
            setTimeout(function(){
                // Форсим пересоздание блока: если его нет в DOM,
                // то вызываем декоратор PATCH 41 напрямую через глобальный хук
                if (typeof window.__trkLogAssignedDecorate === 'function') {
                    try { window.__trkLogAssignedDecorate(); } catch(er){}
                    setTimeout(_moveAssignedBlock, 80);
                }
            }, 700);
        }
    }, true);

    // Первичная попытка + повторные (на случай позднего PATCH 41)
    setTimeout(_moveAssignedBlock, 500);
    setTimeout(_moveAssignedBlock, 1500);
    setTimeout(_moveAssignedBlock, 3000);

    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('#dayAddBtn') ||
            e.target.closest('#dayModal .dict-action-btn[data-act="edit"]') ||
            e.target.closest('#logDayExistingList .dict-action-btn[data-act="edit"]')) {
            setTimeout(_moveAssignedBlock, 300);
            setTimeout(_moveAssignedBlock, 800);
            setTimeout(_moveAssignedBlock, 1600);
        }
    }, true);

    window.__trkMoveAssignedBlock = _moveAssignedBlock;
})();


/* ============================================================
   PATCH v1.5.4 — триггер селекта гипотез в модалке отметки.
   Покрывает все способы выбора задачи:
   - пользователь печатает вручную → input на #log_task_input
   - выбирает из dropdown → mousedown capture на .ltd-item
   - v1.0.6 диспатчит change → change на #log_task_input
   - программный set #log_task.value в любом месте → polling 300мс
   ============================================================ */
(function(){
    'use strict';
    if (window.__trkHypSelectTriggerV154) return;
    window.__trkHypSelectTriggerV154 = true;

    function _trigger() {
        if (typeof window.__trkPopulateHypSelect !== 'function') return;
        var tid = (document.getElementById('log_task') || {}).value || '';
        try { window.__trkPopulateHypSelect(tid); } catch(e){ console.warn('[v1.5.4 trigger]', e); }
    }

    /* 1. Пользователь печатает в поле задачи — дебаунс 100 мс */
    var _debounce = null;
    document.addEventListener('input', function(ev){
        if (!ev.target || ev.target.id !== 'log_task_input') return;
        if (_debounce) clearTimeout(_debounce);
        _debounce = setTimeout(_trigger, 100);
    }, true);

    /* 2. v1.0.6 диспатчит change на #log_task_input в _chooseByIdx */
    document.addEventListener('change', function(ev){
        if (!ev.target) return;
        if (ev.target.id === 'log_task_input' || ev.target.id === 'log_task') {
            setTimeout(_trigger, 30);
        }
    }, true);

    /* 3. mousedown capture на .ltd-item — до _chooseByIdx v1.0.6,
          потому что v1.0.6 слушает mousedown и вызывает stopPropagation */
    document.addEventListener('mousedown', function(e){
        if (!e.target || !e.target.closest) return;
        if (!e.target.closest('#log_task_dropdown .ltd-item')) return;
        setTimeout(_trigger, 80);
        setTimeout(_trigger, 300);
    }, true);

    /* 4. Polling — страховка на любые программные изменения #log_task.value */
    var _poll = null;
    var _lastTid = null;
    function _startPoll() {
        if (_poll) return;
        _lastTid = null;
        _poll = setInterval(function(){
            var m = document.getElementById('logModal');
            if (!m || !m.classList.contains('active')) {
                clearInterval(_poll); _poll = null; return;
            }
            var tid = (document.getElementById('log_task') || {}).value || '';
            if (tid !== _lastTid) {
                _lastTid = tid;
                _trigger();
            }
        }, 300);
    }

    function _watchModal(){
        var m = document.getElementById('logModal');
        if (!m || m._hypTriggerV154) return;
        m._hypTriggerV154 = true;
        new MutationObserver(function(){
            if (m.classList.contains('active')) {
                setTimeout(_trigger, 60);
                setTimeout(_trigger, 200);
                setTimeout(_trigger, 500);
                setTimeout(_trigger, 1000);
                _startPoll();
            } else {
                if (_poll) { clearInterval(_poll); _poll = null; }
                _lastTid = null;
            }
        }).observe(m, { attributes: true, attributeFilter: ['class'] });
        if (m.classList.contains('active')) _startPoll();
    }

    _watchModal();
    setTimeout(_watchModal, 500);
    setTimeout(_watchModal, 1500);

    /* 5. Дополнительные точки входа */
    document.addEventListener('click', function(e){
        if (!e.target || !e.target.closest) return;
        if (e.target.closest('#dayAddBtn') ||
            e.target.closest('#dayModal .dict-action-btn[data-act="edit"]') ||
            e.target.closest('#logDayExistingList .dict-action-btn[data-act="edit"]')) {
            setTimeout(_trigger, 300);
            setTimeout(_trigger, 800);
            setTimeout(_trigger, 1600);
        }
    }, true);

    setTimeout(_startPoll, 500);
    setTimeout(_startPoll, 1500);

    window.__trkTriggerHypSelect = _trigger;
})();
